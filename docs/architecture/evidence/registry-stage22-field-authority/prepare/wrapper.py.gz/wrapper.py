#!/usr/bin/env python3
"""Bind the unchanged component runner to a fresh build and committed registry inputs."""
import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
REGISTRY = Path('/private/tmp/verum-registry-t1636-auth')
REGISTRY_COMMIT = '6c055769bab8deca3787b55e782e7ca61a7ce2c4'
REGISTRY_TREE = '0a8e4d476bfbef99df285b3d5b34640494816cf3'
LANGUAGE_COMMIT = 'e86f2abd77e041e2f29cdcbf30d9629435e64f7e'
HELPER = Path('/private/tmp/verum-registry-stage22-type-boundaries.py')
HELPER_SHA256 = 'f1d85bf7d7489f406a25802038cc91296776a5225bd835d5ef72bdd24815c77a'
RUNNER = Path('tools/run_publication_envelope.py')
COMPONENT_NAMES = ('prepare', 'prepare_copy', 'credentials_file', 'auth_bounds',
                   'auth', 'auth_isolation', 'metadata', 'envelope')
ORIGINAL_CHECKS = {'exit_zero', 'within_deadline', 'exact_stdout', 'source_unchanged',
                   'project_unchanged', 'executable_unchanged'}


def load_python(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def helpers():
    import hashlib
    if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA256:
        raise ValueError('reviewed v3 build-identity helper changed')
    return load_python('stage22_boundaries', HELPER)


def registry_identity(helper):
    tree = helper.registry_identity(REGISTRY)
    helper.require(tree == REGISTRY_TREE, 'registry tree pin mismatch')
    return tree


def committed_bytes(helper, relative):
    helper.require(not relative.is_absolute() and '..' not in relative.parts,
                   'component path must be relative to the frozen registry')
    source = REGISTRY / relative
    helper.require(source.is_file() and not source.is_symlink(), f'non-regular component input: {relative}')
    contents = source.read_bytes()
    helper.require(contents == helper.git(REGISTRY, 'show', f'{REGISTRY_COMMIT}:{relative}'),
                   f'component input differs from committed bytes: {relative}')
    return contents


def component_inputs(helper, runner, name):
    selected = runner.COMPONENTS[name]
    modules = selected['modules']
    assets = selected.get('assets', ())
    fragments = selected.get('appended_fragments', {})
    roster = (*modules, *assets, *fragments.values(), selected['fixture'], selected['expected'], RUNNER)
    sources = {path: committed_bytes(helper, path) for path in roster}
    fixture = sources[selected['fixture']]
    helper.require(fixture.count(selected['header']) == 1, 'component fixture header changed')
    helper.require(bool(sources[selected['expected']].strip()), 'empty component completion oracle')
    inputs = {**{path: sources[path] for path in (*modules, *assets)},
              Path('src/main.vr'): fixture.replace(selected['header'], runner.NEW_HEADER, 1),
              Path('verum.toml'): runner.MANIFEST}
    assemblies = []
    for target, fragment in fragments.items():
        helper.require(target in modules, 'fragment target is not a selected production module')
        inputs[target] = sources[target] + b'\n' + sources[fragment]
        assemblies.append({'target': str(target), 'production_sha256': helper.sha_bytes(sources[target]),
                           'fragment': str(fragment), 'fragment_sha256': helper.sha_bytes(sources[fragment]),
                           'separator_hex': '0a', 'assembled_sha256': helper.sha_bytes(inputs[target]),
                           'transformation': 'Append only: preserve every production byte, then newline and exact test fragment.'})
    return sources, inputs, assemblies


def retain_inputs(root, contents):
    for relative, value in contents.items():
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(value)


def receipt_matches(helper, receipt, selected, source_hashes, input_hashes, assemblies, cli, cli_sha, returncode):
    checks = receipt.get('checks', {})
    return (returncode == 0 and receipt.get('status') == 'passed'
            and receipt.get('returncode') == 0
            and receipt.get('timed_out') is False and receipt.get('interrupted') is False
            and receipt.get('runner_error') is None
            and set(checks) == ORIGINAL_CHECKS and all(value is True for value in checks.values())
            and receipt.get('component') == selected
            and receipt.get('language_source_commit_supplied') == LANGUAGE_COMMIT
            and receipt.get('command') == [str(cli), 'run', '--tier', 'interpret']
            and receipt.get('cli_sha256') == cli_sha
            and receipt.get('expected_cli_sha256') == cli_sha
            and receipt.get('cli_sha256_after') == cli_sha
            and receipt.get('source_inputs') == source_hashes
            and receipt.get('source_inputs_after') == source_hashes
            and receipt.get('project_inputs') == input_hashes
            and receipt.get('project_inputs_after') == input_hashes
            and receipt.get('module_assemblies') == assemblies)


def run(args):
    helper = helpers()
    helper.require(args.language_commit == LANGUAGE_COMMIT, 'stage22 requires the full frozen e86 source SHA')
    helper.require(args.component in COMPONENT_NAMES, 'unknown component')
    helper.require(math.isfinite(args.timeout) and 0 < args.timeout <= 600, 'deadline must be positive and at most 600 seconds')
    manifest = args.build_manifest.resolve(strict=True)
    build, cli = helper.validate_build(manifest, args.expected_build_manifest_sha256,
                                      args.expected_cli_sha256, args.language_commit)
    registry_identity(helper)
    committed_bytes(helper, RUNNER)
    runner = load_python('frozen_publication_component', REGISTRY / RUNNER)
    sources, inputs, assemblies = component_inputs(helper, runner, args.component)
    source_hashes = {str(path): helper.sha_bytes(value) for path, value in sources.items()}
    input_hashes = {str(path): helper.sha_bytes(value) for path, value in inputs.items()}
    evidence = args.evidence_dir.resolve()
    evidence.mkdir(exist_ok=False)
    retain_inputs(evidence / 'inputs/source', sources)
    retain_inputs(evidence / 'inputs/project', inputs)
    for source, name in ((manifest, 'build-manifest.json'), (Path(__file__), 'wrapper.py'),
                         (HELPER, 'build-identity-helper.py')):
        shutil.copyfile(source, evidence / name)
    original_environment = dict(os.environ)
    removed = sorted(key for key in original_environment if key.startswith('VERUM_'))
    selected_environment = {key: value for key, value in original_environment.items() if not key.startswith('VERUM_')}
    selected_environment['TMPDIR'] = '/private/tmp'
    record = {'registry_commit': REGISTRY_COMMIT, 'registry_tree': REGISTRY_TREE,
              'language_commit': LANGUAGE_COMMIT, 'component': args.component,
              'build_manifest_sha256': args.expected_build_manifest_sha256,
              'cli': build['cli'], 'schema': build['schema'], 'artifacts': build['artifacts'],
              'source_inputs': source_hashes, 'project_inputs': input_hashes,
              'module_assemblies': assemblies, 'component_scope': runner.COMPONENTS[args.component]['scope'],
              'wrapper_sha256': helper.digest(Path(__file__)), 'helper_sha256': HELPER_SHA256,
              'scope': 'Identity-bound invocation of the unchanged committed component runner. Its original result/logs remain in component/. No receipt or oracle is rewritten. Component scope still limits acceptance.',
              'removed_environment_keys': removed, 'deadline_seconds': args.timeout,
              'environment_policy': 'Remove inherited VERUM_* overrides and set TMPDIR=/private/tmp. The unchanged runner adds its recorded NO_COLOR/VERUM_NO_OBJECT_CACHE/TMPDIR settings.'}
    helper.write_json(evidence / 'started.json', record)
    failure = None
    returncode = None
    try:
        os.environ.clear(); os.environ.update(selected_environment)
        returncode = runner.run(argparse.Namespace(verum=str(cli), component=args.component,
            language_commit=LANGUAGE_COMMIT, expected_cli_sha256=args.expected_cli_sha256,
            evidence_dir=str(evidence / 'component'), timeout=args.timeout))
    except (Exception, KeyboardInterrupt) as error:
        failure = f'{type(error).__name__}: {error}'
    finally:
        os.environ.clear(); os.environ.update(original_environment)
    checks = {}
    errors = {}
    probes = {
        'registry_unchanged': lambda: registry_identity(helper) == REGISTRY_TREE,
        'committed_source_inputs_unchanged': lambda: all(helper.sha_bytes(committed_bytes(helper, path)) == source_hashes[str(path)] for path in sources),
        'retained_source_inputs_unchanged': lambda: helper.snapshot(evidence / 'inputs/source') == source_hashes,
        'retained_project_inputs_unchanged': lambda: helper.snapshot(evidence / 'inputs/project') == input_hashes,
        'wrapper_unchanged': lambda: helper.digest(Path(__file__)) == record['wrapper_sha256'],
        'helper_unchanged': lambda: helper.digest(HELPER) == HELPER_SHA256,
        'retained_build_manifest_unchanged': lambda: helper.digest(evidence / 'build-manifest.json') == args.expected_build_manifest_sha256,
        'retained_wrapper_unchanged': lambda: helper.digest(evidence / 'wrapper.py') == record['wrapper_sha256'],
        'retained_helper_unchanged': lambda: helper.digest(evidence / 'build-identity-helper.py') == HELPER_SHA256,
        'build_unchanged': lambda: helper.validate_build(manifest, args.expected_build_manifest_sha256, args.expected_cli_sha256, LANGUAGE_COMMIT)[1] == cli,
    }
    for name, probe in probes.items():
        try:
            checks[name] = bool(probe())
        except Exception as error:
            checks[name] = False; errors[name] = f'{type(error).__name__}: {error}'
    receipt_path = evidence / 'component/result.json'
    try:
        receipt = json.loads(receipt_path.read_text())
        checks['original_component_accepted'] = receipt_matches(helper, receipt, args.component,
            source_hashes, input_hashes, assemblies, cli, args.expected_cli_sha256, returncode)
        checks['original_logs_match'] = all(helper.digest(evidence / 'component' / name) == receipt.get('logs', {}).get(name)
                                          for name in ('stdout.log', 'stderr.log'))
        record['component_receipt'] = {'path': str(receipt_path), 'sha256': helper.digest(receipt_path)}
        record['component_status'] = receipt.get('status')
    except Exception as error:
        checks['original_component_accepted'] = False
        checks['original_logs_match'] = False
        errors['component_receipt'] = f'{type(error).__name__}: {error}'
    record.update(returncode=returncode, failure=failure, checks=checks, errors=errors,
                  status='passed' if failure is None and all(checks.values()) else 'failed')
    helper.write_json(evidence / 'result.json', record)
    print(json.dumps({'status': record['status'], 'component': args.component,
                      'result': str(evidence / 'result.json'), 'component_returncode': returncode,
                      'failure': failure}), flush=True)
    return 0 if record['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--component', choices=COMPONENT_NAMES, required=True)
    parser.add_argument('--build-manifest', type=Path, required=True)
    parser.add_argument('--expected-build-manifest-sha256', required=True)
    parser.add_argument('--expected-cli-sha256', required=True)
    parser.add_argument('--language-commit', required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    parser.add_argument('--timeout', type=float, default=600)
    args = parser.parse_args()
    try:
        return run(args)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f'PREFLIGHT REFUSED: {error}\n')


if __name__ == '__main__':
    raise SystemExit(main())
