"""Apply the reviewed parser Rust-unit marker invalidation once; never build."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

PLAN = Path('/private/tmp/verum-stage22-parser-invalidation-plan.json')
PLAN_SHA256 = '592f70beee3a22d38738e962bcff3faf268dc0084596c055b32c8591668a04e4'
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target')
BACKUP = Path('/private/tmp/verum-stage22-parser-fingerprint-before')
RECEIPT = Path('/private/tmp/verum-stage22-parser-invalidation-result.json')
ROOT = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
COUNTS = {'debug': 62, 'precompile-bootstrap/release': 9}


def identity(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or path.resolve(strict=True) != path:
        raise RuntimeError(f'not an exact regular nonsymlink path: {path}')
    raw = path.read_bytes()
    after = path.lstat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode):
        raise RuntimeError(f'file changed during validation: {path}')
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
            'mtime_ns': after.st_mtime_ns, 'mode': oct(stat.S_IMODE(after.st_mode))}


def require_identity(path, expected):
    observed = identity(path)
    if observed != expected:
        raise RuntimeError(f'identity does not match reviewed plan: {path}; expected {expected}, observed {observed}')
    return observed


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def persist(record):
    temporary = RECEIPT.with_name(RECEIPT.name + '.tmp')
    created = False
    try:
        with temporary.open('x') as stream:
            created = True
            stream.write(json.dumps(record, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, RECEIPT)
        created = False
        sync_directory(RECEIPT.parent)
    finally:
        if created:
            temporary.unlink()


def git(*parts):
    return subprocess.check_output(['git', '-C', str(ROOT), *parts], text=True).strip()


def reviewed_entries():
    raw = PLAN.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PLAN_SHA256:
        raise RuntimeError('reviewed plan hash differs')
    plan = json.loads(raw)
    if plan['target'] != str(TARGET) or plan['backup_root'] != str(BACKUP):
        raise RuntimeError('reviewed target or backup location differs')
    entries = []
    seen_paths = set()
    seen_profiles = set()
    for profile in plan['profiles']:
        name = profile['profile']
        if name in seen_profiles or name not in COUNTS:
            raise RuntimeError('unexpected or duplicated profile')
        seen_profiles.add(name)
        if profile['marker_count'] != COUNTS[name] or len(profile['markers']) != COUNTS[name]:
            raise RuntimeError('marker count differs from reviewed plan')
        for entry in profile['markers']:
            marker = Path(entry['marker'])
            companion = Path(entry['fingerprint_json'])
            relative = marker.relative_to(TARGET)
            prefix = Path(name) / 'build' / entry['package']
            suffix = relative.relative_to(prefix)
            if len(suffix.parts) != 3 or suffix.parts[1] != 'fingerprint':
                raise RuntimeError(f'unexpected unit shape: {marker}')
            if not marker.name.startswith(('lib-', 'bin-')) or marker.suffix or companion != marker.with_suffix('.json'):
                raise RuntimeError(f'not an exact library/binary marker pair: {marker}')
            for key, path in [('marker', marker), ('fingerprint_json', companion)]:
                destination = Path(entry['backup_' + key])
                if destination != BACKUP / path.relative_to(TARGET):
                    raise RuntimeError(f'backup path differs: {destination}')
                if path in seen_paths:
                    raise RuntimeError(f'duplicate operation source: {path}')
                seen_paths.add(path)
            entries.append(entry)
    if seen_profiles != set(COUNTS) or len(entries) != 71:
        raise RuntimeError('reviewed 71-marker set incomplete')
    # Finish the entire validation pass before creating backups or unlinking anything.
    for entry in entries:
        for key in ['marker', 'fingerprint_json']:
            require_identity(Path(entry[key]), entry[key + '_before'])
    return entries


def backup_file(source, destination, expected):
    require_identity(source, expected)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() or destination.is_symlink():
        raise RuntimeError(f'backup already exists: {destination}')
    shutil.copy2(source, destination)
    with destination.open('rb') as stream:
        os.fsync(stream.fileno())
    sync_directory(destination.parent)
    require_identity(destination, expected)
    require_identity(source, expected)
    return {'source': str(source), 'retained': str(destination), **expected}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True,
                        help='apply the already reviewed exact marker-only plan; no build is run')
    parser.parse_args()
    # Refuse reuse, including partial prior operations; preserve all prior evidence.
    if BACKUP.exists() or BACKUP.is_symlink() or RECEIPT.exists() or RECEIPT.is_symlink() or RECEIPT.with_name(RECEIPT.name + '.tmp').exists():
        parser.error('backup or operation receipt already exists; inspect the prior operation instead of retrying')
    record = {'status': 'validating', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'plan': str(PLAN), 'plan_sha256': PLAN_SHA256, 'target': str(TARGET),
              'backup_root': str(BACKUP), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Preserve and unlink only the exact reviewed 71 lib/bin fingerprint markers. No Cargo/build, no source edits, no test/build-script markers or native LLVM/solver cache changes.',
              'exclusive_idle_target_required': True, 'backups': [], 'removed': [], 'pending_unlink': None}
    try:
        entries = reviewed_entries()
        record.update(source_commit_observed=git('rev-parse', 'HEAD'),
                      source_clean=not bool(git('status', '--porcelain')), validated_markers=len(entries))
        if not record['source_clean']:
            raise RuntimeError('Root source is not clean; refuse before any target change')
        record['status'] = 'validated'
        persist(record)
        BACKUP.mkdir()
        sync_directory(BACKUP.parent)
        # Complete and verify every backup before the first destructive operation.
        for entry in entries:
            for key in ['marker', 'fingerprint_json']:
                row = backup_file(Path(entry[key]), Path(entry['backup_' + key]), entry[key + '_before'])
                record['backups'].append(row)
                persist(record)
        for entry in entries:
            for key in ['marker', 'fingerprint_json']:
                require_identity(Path(entry[key]), entry[key + '_before'])
                require_identity(Path(entry['backup_' + key]), entry[key + '_before'])
        record['status'] = 'backups_verified'
        persist(record)
        for entry in entries:
            marker = Path(entry['marker'])
            require_identity(marker, entry['marker_before'])
            require_identity(Path(entry['fingerprint_json']), entry['fingerprint_json_before'])
            require_identity(Path(entry['backup_marker']), entry['marker_before'])
            record.update(status='invalidating', pending_unlink=str(marker))
            persist(record)
            marker.unlink()
            sync_directory(marker.parent)
            record['removed'].append(str(marker))
            record['pending_unlink'] = None
            persist(record)
        for entry in entries:
            marker = Path(entry['marker'])
            if marker.exists() or marker.is_symlink():
                raise RuntimeError(f'marker still present or recreated: {marker}')
            require_identity(Path(entry['fingerprint_json']), entry['fingerprint_json_before'])
            require_identity(Path(entry['backup_marker']), entry['marker_before'])
            require_identity(Path(entry['backup_fingerprint_json']), entry['fingerprint_json_before'])
        record.update(status='completed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      retained_files=len(record['backups']), removed_markers=len(record['removed']),
                      source_commit_after=git('rev-parse', 'HEAD'), source_clean_after=not bool(git('status', '--porcelain')))
        if record['source_commit_after'] != record['source_commit_observed'] or not record['source_clean_after']:
            raise RuntimeError('source changed during invalidation; retained operation requires review')
        persist(record)
        code = 0
    except BaseException as error:
        record.update(status='failed', failure=f'{type(error).__name__}: {error}',
                      finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        persist(record)
        code = 1
    print(json.dumps({'status': record['status'], 'receipt': str(RECEIPT),
                      'receipt_sha256': hashlib.sha256(RECEIPT.read_bytes()).hexdigest(),
                      'retained_files': len(record['backups']), 'removed_markers': len(record['removed']),
                      'pending_unlink': record['pending_unlink'], 'failure': record.get('failure')}), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
