"""Execute an unchanged stdlib field-data fixture with a pinned ordinary CLI."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time

ROOT = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
VALIDATOR = Path('/private/tmp/verum-registry-stage22-type-boundaries.py')
VALIDATOR_SHA = 'f1d85bf7d7489f406a25802038cc91296776a5225bd835d5ef72bdd24815c77a'
FIXTURES = {
    'weft': ('vcs/specs/L2-standard/net/weft_request_data.vr', b'weft-request-data: ok\n'),
    'json': ('vcs/specs/L2-standard/encoding/json_error_data.vr', b'json-error-data: ok\n'),
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture', required=True, choices=FIXTURES)
    parser.add_argument('--build-manifest', required=True, type=Path)
    parser.add_argument('--expected-build-manifest-sha256', required=True)
    parser.add_argument('--expected-cli-sha256', required=True)
    parser.add_argument('--language-commit', required=True)
    parser.add_argument('--evidence-dir', required=True, type=Path)
    args = parser.parse_args()
    assert sha(VALIDATOR.read_bytes()) == VALIDATOR_SHA
    spec = importlib.util.spec_from_file_location('stage22_boundary_validator', VALIDATOR)
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    build, cli = validator.validate_build(args.build_manifest,
        args.expected_build_manifest_sha256, args.expected_cli_sha256, args.language_commit)
    relative, expected = FIXTURES[args.fixture]
    source = ROOT / relative
    committed = subprocess.check_output(['git', '-C', str(ROOT), 'show', args.language_commit + ':' + relative])
    assert source.read_bytes() == committed
    evidence = args.evidence_dir.resolve()
    evidence.mkdir(exist_ok=False)
    (evidence / 'source.vr').write_bytes(committed)
    state = {
        'task': 'T1724', 'fixture': args.fixture, 'language_commit': args.language_commit,
        'source_path': relative, 'source_sha256': sha(committed),
        'build_manifest': str(args.build_manifest.resolve()),
        'build_manifest_sha256': args.expected_build_manifest_sha256,
        'cli': str(cli), 'cli_sha256': args.expected_cli_sha256,
        'archive_schema': build['schema'], 'archive_artifacts': build['artifacts'],
        'runner_sha256': sha(Path(__file__).read_bytes()),
        'validator_sha256': VALIDATOR_SHA, 'deadline_seconds': 180,
        'expected_stdout_sha256': sha(expected),
        'scope': 'Interpreter execution of the exact committed fixture with the freshly built ordinary CLI and automatic archive. No HTTP server, registry admission or AOT claim.',
    }
    with tempfile.TemporaryDirectory(prefix='verum-stage22-stdlib-') as temporary:
        project = Path(temporary).resolve()
        entry = project / source.name
        entry.write_bytes(committed)
        command = [str(cli), 'run', '--interp', str(entry)]
        overrides = {'NO_COLOR': '1', 'VERUM_NO_OBJECT_CACHE': '1', 'TMPDIR': str(project.parent)}
        state.update(command=command, cwd=str(project), environment_overrides=overrides)
        write(evidence / 'started.json', state)
        started = time.monotonic()
        timed_out = interrupted = False
        with (evidence / 'stdout.log').open('xb') as stdout, (evidence / 'stderr.log').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=project, env={**os.environ, **overrides},
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                code = process.wait(timeout=180)
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                timed_out = isinstance(error, subprocess.TimeoutExpired)
                interrupted = not timed_out
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    code = process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    code = process.wait()
        checks = {'exit_zero': code == 0, 'within_deadline': not timed_out and not interrupted,
                  'exact_stdout': (evidence / 'stdout.log').read_bytes() == expected,
                  'source_unchanged': source.read_bytes() == committed,
                  'entry_unchanged': entry.read_bytes() == committed,
                  'cli_unchanged': validator.digest(cli) == args.expected_cli_sha256,
                  'manifest_unchanged': sha(args.build_manifest.read_bytes()) == args.expected_build_manifest_sha256}
        state.update(returncode=code, timed_out=timed_out, interrupted=interrupted,
                     seconds=round(time.monotonic() - started, 3), checks=checks,
                     logs={name: sha((evidence / name).read_bytes()) for name in ['stdout.log', 'stderr.log']},
                     status='passed' if all(checks.values()) else 'failed')
        write(evidence / 'result.json', state)
    print(json.dumps({'fixture': args.fixture, 'status': state['status'], 'returncode': code,
                      'seconds': state['seconds'], 'evidence': str(evidence)}), flush=True)
    return 0 if state['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
