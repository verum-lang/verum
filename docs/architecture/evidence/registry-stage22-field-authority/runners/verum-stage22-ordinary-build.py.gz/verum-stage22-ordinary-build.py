"""Build and identify one frozen ordinary CLI with automatic stdlib baking."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import time

ROOT = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target')
PLAN = Path('/private/tmp/verum-stage22-parser-invalidation-plan.json')
PLAN_SHA256 = '592f70beee3a22d38738e962bcff3faf268dc0084596c055b32c8591668a04e4'
ARTIFACT_NAMES = ['runtime.vbca', 'runtime.core_metadata', 'runtime.symbol_graph',
                  'runtime.vbca.checksum', 'runtime.vbca.schema']
FORBIDDEN_ENV = {'VERUM_NO_AUTO_PRECOMPILE', 'DOCS_RS', 'VERUM_ALLOW_STALE_STDLIB'}
EXPECTED_SCHEMA = 'v54-2026-10-10-declared-field-visibility'


def git(*parts):
    return subprocess.check_output(['git', '-C', str(ROOT), *parts], text=True).strip()


def info(path):
    before = path.stat()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError(f'file changed while hashing: {path}')
    return {'bytes': after.st_size, 'sha256': h.hexdigest()}


def identity(path):
    result = info(path)
    metadata = path.stat()
    return {**result, 'mode': oct(stat.S_IMODE(metadata.st_mode)),
            'mtime_ns': metadata.st_mtime_ns}


def retain(source, destination):
    expected = info(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise RuntimeError(f'refusing to overwrite retained evidence: {destination}')
    subprocess.run(['/bin/cp', '-c', '-p', str(source), str(destination)], check=True)
    if info(destination) != expected or info(source) != expected:
        raise RuntimeError(f'retention identity mismatch: {source}')
    return expected


def stop_owned_process(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        return process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return process.wait(timeout=10)


def write_json(path, data):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def snapshot_units(label, evidence, profiles):
    """Retain small metadata/logs; hash Rust outputs without copying whole caches."""
    snapshot = evidence / ('producer-' + label)
    snapshot.mkdir()
    producer = TARGET / 'precompile-bootstrap/release/verum_stdlib_precompiler'
    producer_record = {'source': str(producer), 'exists': producer.is_file()}
    if producer.is_file():
        producer_record.update(identity(producer))
        retained = snapshot / 'verum_stdlib_precompiler'
        retain(producer, retained)
        producer_record['retained'] = str(retained)
        producer_record['retained_sha256'] = info(retained)['sha256']
    units = []
    for profile in profiles:
        for package in profile['packages']:
            package_dir = TARGET / profile['profile'] / 'build' / package
            for unit in sorted(package_dir.glob('*')):
                fingerprint = unit / 'fingerprint'
                if not fingerprint.is_dir():
                    continue
                selectors = list(fingerprint.glob('lib-*.json')) + list(fingerprint.glob('bin-*.json'))
                # The compiler's successful build-script stderr contains the nested cargo run.
                if package == 'verum_compiler':
                    selectors += list(fingerprint.glob('*build-script*.json'))
                if not selectors:
                    continue
                record = {'unit': str(unit.relative_to(TARGET)),
                          'package': package, 'profile': profile['profile'],
                          'fingerprints': {}, 'outputs': {}, 'build_script_logs': {}}
                for path in sorted(fingerprint.iterdir()):
                    if path.is_file():
                        destination = snapshot / path.relative_to(TARGET)
                        retain(path, destination)
                        record['fingerprints'][path.name] = {**identity(path), 'retained': str(destination)}
                binary_names = {p.name[len('bin-'):-len('.json')] for p in selectors if p.name.startswith('bin-')}
                out = unit / 'out'
                if out.is_dir():
                    for path in sorted(out.iterdir()):
                        is_selected_binary = any(path.name == name or path.name == name + '-' + unit.name for name in binary_names)
                        if not path.is_file() or (path.suffix not in {'.rlib', '.rmeta', '.d'} and not is_selected_binary):
                            continue
                        output = identity(path)
                        if path.suffix == '.d':
                            destination = snapshot / path.relative_to(TARGET)
                            retain(path, destination)
                            output['retained'] = str(destination)
                        record['outputs'][path.name] = output
                run = unit / 'run'
                for name in ['output', 'stderr', 'root-output']:
                    path = run / name
                    if path.is_file():
                        destination = snapshot / path.relative_to(TARGET)
                        retain(path, destination)
                        record['build_script_logs'][name] = {**identity(path), 'retained': str(destination)}
                units.append(record)
    result = {'label': label, 'nested_precompiler': producer_record, 'units': units,
              'scope': 'Unit identities include cached feature/profile variants. Actual selection is recorded by Cargo -vv. Rust rlib/rmeta bytes are hashed, not duplicated; producer, fingerprints, dep-info and build-script logs are retained.'}
    path = snapshot / 'identity.json'
    write_json(path, result)
    return {'manifest': str(path), **info(path), 'nested_precompiler': producer_record,
            'unit_count': len(units)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    args = parser.parse_args()
    if len(args.revision) != 40 or any(c not in '0123456789abcdef' for c in args.revision):
        parser.error('--revision must be a full lowercase Git SHA')
    prohibited = sorted(FORBIDDEN_ENV & os.environ.keys())
    if prohibited:
        parser.error('ordinary build forbids inherited environment flags: ' + ', '.join(prohibited))
    if git('rev-parse', 'HEAD') != args.revision or git('status', '--porcelain'):
        parser.error('source must be the requested committed clean revision')
    if shutil.disk_usage(TARGET).free <= 12 * 1024**3:
        parser.error('insufficient build space')
    if info(PLAN)['sha256'] != PLAN_SHA256:
        parser.error('reviewed parser unit plan changed')
    plan = json.loads(PLAN.read_text())
    if plan['target'] != str(TARGET):
        parser.error('unexpected target in unit plan')
    evidence = args.evidence_dir.resolve()
    evidence.mkdir(exist_ok=False)
    tracked = git('ls-files', 'crates', 'core', 'grammar', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo').splitlines()
    source_paths = [p for p in tracked if (ROOT / p).is_file() and (ROOT / p).suffix in {'.rs', '.vr', '.toml', '.lock', '.ebnf', '.c', '.h', '.cpp'}]
    def source_hashes():
        return {name: info(ROOT / name)['sha256'] for name in source_paths}
    archive = TARGET / 'precompiled-stdlib'
    def artifact_hashes():
        return {name: info(archive / name) for name in ARTIFACT_NAMES if (archive / name).is_file()}
    command = ['cargo', '+nightly-2026-08-20', 'build', '-vv', '--locked', '--offline', '--manifest-path', str(ROOT / 'Cargo.toml'), '-p', 'verum_cli', '--bin', 'verum']
    overrides = {'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0', 'VERUM_LLVM_DIR': '/Users/taaliman/projects/oldman/verum-lang/verum/llvm/install'}
    record = {'engine_commit': args.revision, 'engine_tree': git('rev-parse', 'HEAD^{tree}'),
              'utc_started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'command': command, 'environment_overrides': overrides,
              'automatic_precompile': True, 'deadline_seconds': 3600,
              'free_bytes_before': shutil.disk_usage(TARGET).free,
              'source_paths': source_hashes(), 'artifacts_before': artifact_hashes(),
              'runner_sha256': info(Path(__file__))['sha256'], 'unit_plan_sha256': PLAN_SHA256,
              'inherited_flags': {name: os.environ.get(name) for name in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTUP_TOOLCHAIN', 'VERUM_NO_AUTO_PRECOMPILE', 'DOCS_RS', 'VERUM_ALLOW_STALE_STDLIB']},
              'scope': 'Ordinary CLI build with automatic standard-library baking from committed frozen source; stale fallback forbidden. Execution acceptance requires separate pinned CLI runs.'}
    final_path = evidence / 'build-failure.json'
    exit_code = 1
    try:
        record['producer_before'] = snapshot_units('before', evidence, plan['profiles'])
        log = evidence / 'cli-build.log'
        started = time.monotonic()
        with log.open('xb') as output:
            process = subprocess.Popen(command, cwd=ROOT, env={**os.environ, **overrides}, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
            timeout = interrupted = False
            try:
                write_json(evidence / 'started.json', {**record, 'pid': process.pid})
                code = process.wait(timeout=record['deadline_seconds'])
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                timeout = isinstance(error, subprocess.TimeoutExpired)
                interrupted = not timeout
                code = stop_owned_process(process)
            except BaseException:
                # A receipt/logging failure must not leave our build running unattended.
                stop_owned_process(process)
                raise
        record.update(free_bytes_after=shutil.disk_usage(TARGET).free, seconds=round(time.monotonic() - started, 3), exit_code=code, timed_out=timeout, interrupted=interrupted, log_sha256=info(log)['sha256'], source_unchanged=git('rev-parse', 'HEAD') == args.revision and not git('status', '--porcelain'))
        record.update(source_paths_unchanged=record['source_paths'] == source_hashes(), artifacts_after=artifact_hashes())
        record['producer_after'] = snapshot_units('after', evidence, plan['profiles'])
        if code or timeout or interrupted or not record['source_unchanged'] or not record['source_paths_unchanged']:
            raise RuntimeError('build failed, was interrupted, or source identity changed')
        if not record['producer_after']['nested_precompiler']['exists']:
            raise RuntimeError('nested precompiler executable is missing')
        record['schema'] = (archive / 'runtime.vbca.schema').read_text().strip()
        record['expected_schema'] = EXPECTED_SCHEMA
        if record['schema'] != EXPECTED_SCHEMA:
            raise RuntimeError('unexpected automatic archive schema')
        cli = evidence / ('verum-' + args.revision[:9])
        retain(TARGET / 'debug/verum', cli)
        cli.chmod(0o555)
        record['cli'] = {'path': str(cli), **info(cli)}
        record['source_fingerprint_blake3'] = (archive / 'runtime.vbca.checksum').read_text().strip()
        snapshot = evidence / 'artifacts'
        snapshot.mkdir()
        record['artifacts'] = {name: retain(archive / name, snapshot / name) for name in ARTIFACT_NAMES}
        record['artifact_snapshot'] = str(snapshot)
        record['status'] = 'passed'
        final_path = evidence / 'build-manifest.json'
        exit_code = 0
    except Exception as error:
        record.update(status='failed', failure=f'{type(error).__name__}: {error}')
    write_json(final_path, record)
    print(json.dumps({'status': record['status'], 'engine_commit': args.revision,
                      'manifest': str(final_path), 'manifest_sha256': info(final_path)['sha256'],
                      'exit_code': record.get('exit_code'), 'seconds': record.get('seconds'),
                      'cli': record.get('cli'), 'failure': record.get('failure')}), flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
