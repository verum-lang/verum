"""Retain the first ordinary stage22 build and component outcomes losslessly."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
COMMIT = 'e86f2abd77e041e2f29cdcbf30d9629435e64f7e'
BUILD = Path('/private/tmp/verum-registry-stage22-field-authority')
DEST = ROOT / 'docs/architecture/evidence/registry-stage22-field-authority'
MANIFEST_SHA = '91a90f9b3343732651ad8d8fd35f64363ededd7328e15f02d1da1fe99dc9ee72'

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(data)
    return result.hexdigest()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def main():
    assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
    assert not git('status', '--porcelain')
    assert digest(BUILD / 'build-manifest.json') == MANIFEST_SHA
    build = json.loads((BUILD / 'build-manifest.json').read_text())
    assert build['engine_commit'] == COMMIT and build['status'] == 'passed'
    assert build['exit_code'] == 0 and not build['timed_out'] and not build['interrupted']
    assert build['source_unchanged'] and build['source_paths_unchanged']
    assert build['automatic_precompile'] and build['schema'] == 'v54-2026-10-10-declared-field-visibility'
    assert build['cli']['sha256'] == digest(Path(build['cli']['path']))
    assert build['log_sha256'] == digest(BUILD / 'cli-build.log')
    for name, info in build['artifacts'].items():
        path = BUILD / 'artifacts' / name
        assert path.stat().st_size == info['bytes'] and digest(path) == info['sha256'], name

    # Verify all recorded source bytes against the immutable commit in one Git
    # batch; a mutable working-tree comparison alone would not bind the build.
    roster = build['source_paths']
    query = ''.join(f'{COMMIT}:{path}\n' for path in roster).encode()
    batch = subprocess.run(['git', '-C', str(ROOT), 'cat-file', '--batch'],
                           input=query, stdout=subprocess.PIPE, check=True).stdout
    stream = io.BytesIO(batch)
    for path, expected in roster.items():
        header = stream.readline().split()
        assert len(header) == 3 and header[1] == b'blob', path
        contents = stream.read(int(header[2]))
        assert stream.read(1) == b'\n' and sha(contents) == expected, path
    assert stream.read() == b''

    outcomes = {}
    selected = {
        'prepare': Path('/private/tmp/verum-registry-stage22-runtime-prepare'),
        'weft': Path('/private/tmp/verum-stage22-stdlib-weft'),
        'json': Path('/private/tmp/verum-stage22-stdlib-json'),
        'credentials-file': Path('/private/tmp/verum-registry-stage22-runtime-credentials-file'),
    }
    for name, directory in selected.items():
        receipt = json.loads((directory / 'result.json').read_text())
        assert receipt['language_commit'] == COMMIT
        assert receipt['build_manifest_sha256'] == MANIFEST_SHA
        inner_path = directory / 'component/result.json'
        if inner_path.exists():
            inner = json.loads(inner_path.read_text())
            assert receipt['component_receipt']['sha256'] == digest(inner_path)
            for log, expected in inner['logs'].items():
                assert digest(directory / 'component' / log) == expected
            outcomes[name] = {key: inner[key] for key in
                ['status', 'returncode', 'elapsed_seconds', 'timed_out', 'interrupted', 'checks']}
        else:
            for log, expected in receipt['logs'].items():
                assert digest(directory / log) == expected
            outcomes[name] = {key: receipt[key] for key in
                ['status', 'returncode', 'seconds', 'timed_out', 'interrupted', 'checks']}

    DEST.mkdir(exist_ok=False)
    retained = {}
    def retain(source, relative):
        assert source.is_file() and not source.is_symlink()
        raw = source.read_bytes()
        path = DEST / (str(relative) + '.gz')
        path.parent.mkdir(parents=True, exist_ok=True)
        compressed = gzip.compress(raw, mtime=0)
        assert gzip.decompress(compressed) == raw
        path.write_bytes(compressed)
        retained[str(path.relative_to(DEST))] = {
            'original_path': str(source), 'bytes': len(raw), 'sha256': sha(raw),
            'gzip_bytes': len(compressed), 'gzip_sha256': sha(compressed),
        }
    for name in ['started.json', 'build-manifest.json', 'cli-build.log']:
        retain(BUILD / name, Path('build') / name)
    for name in ['runtime.vbca.schema', 'runtime.vbca.checksum']:
        retain(BUILD / 'artifacts' / name, Path('build/artifacts') / name)
    for phase, directory in [
        ('producer-before', BUILD / 'producer-before'),
        ('producer-after', BUILD / 'producer-after'),
        ('parser-fingerprints-before', Path('/private/tmp/verum-stage22-parser-fingerprint-before')),
    ]:
        files = sorted(path for path in directory.rglob('*')
                       if path.is_file() and path.name != 'verum_stdlib_precompiler')
        members = {}
        contents = io.BytesIO()
        with tarfile.open(fileobj=contents, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path in files:
                assert not path.is_symlink()
                raw = path.read_bytes()
                name = str(path.relative_to(directory))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
                members[name] = {'bytes': len(raw), 'sha256': sha(raw)}
        data = gzip.compress(contents.getvalue(), mtime=0)
        (DEST / 'build' / (phase + '.tar.gz')).write_bytes(data)
        retained['build/' + phase + '.tar.gz'] = {
            'gzip_sha256': sha(data), 'gzip_bytes': len(data), 'members': members,
        }
    for name, directory in selected.items():
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                retain(path, Path(name) / path.relative_to(directory))
    for path in [Path(__file__), Path('/private/tmp/verum-stage22-ordinary-build.py'),
                 Path('/private/tmp/verum-stage22-invalidate-parser.py'),
                 Path('/private/tmp/verum-stage22-parser-invalidation-plan.json'),
                 Path('/private/tmp/verum-stage22-parser-invalidation-result.json'),
                 Path('/private/tmp/verum-stage22-stdlib-runtime.py')]:
        retain(path, Path('runners') / path.name)
    result = {
        'language_commit': COMMIT, 'language_tree': build['engine_tree'],
        'source_bindings_verified': len(roster), 'build_manifest_sha256': MANIFEST_SHA,
        'cli': build['cli'], 'schema': build['schema'], 'artifacts': build['artifacts'],
        'source_fingerprint_blake3': build['source_fingerprint_blake3'],
        'build_status': build['status'], 'build_seconds': build['seconds'],
        'outcomes': outcomes, 'retained': retained,
        'scope': 'Exact ordinary CLI and automatic-bake build; original component receipts and failures are unchanged. Source paths verified against immutable Git blobs. Archive/binary bytes remain at their hash-identified retained paths. No hosted registry, AOT or full VBC acceptance.',
    }
    (DEST / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'source_bindings': len(roster), 'retained_payloads': len(retained),
                      'outcomes': {key: value['status'] for key, value in outcomes.items()},
                      'destination': str(DEST)}))

if __name__ == '__main__':
    main()
