from pathlib import Path
import hashlib,json,subprocess
sha=lambda data:hashlib.sha256(data).hexdigest()
base=Path('/private/tmp/verum-T1750-website');raw=(base/'result.json').read_bytes()
assert sha(raw)=='7bedde597664ad4a89aa6f1948d700cc9ec9bf857028472950e6695783237658'
r=json.loads(raw);root=Path(r['worktree']);lang=Path('/Users/taaliman/projects/oldman/verum-lang/verum')
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args]).strip()
def verify_sources(root,revision,paths):
 p=subprocess.Popen(['git','-C',str(root),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for name,digest in paths.items():
   p.stdin.write((revision+':'+name+'\n').encode());p.stdin.flush();header=p.stdout.readline().split();assert len(header)==3 and header[1]==b'blob'
   data=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n'
   assert sha(data)==digest==sha((root/name).read_bytes()),name
 finally:p.stdin.close();assert p.wait()==0
assert git(root,'rev-parse','HEAD').decode()==r['website_commit'] and not git(root,'status','--porcelain')
assert git(root,'diff','--name-only',r['website_base'],r['website_commit']).decode().splitlines()==r['changed_paths']==['docs/stdlib/archive.md']
assert sha((root/'docs/stdlib/archive.md').read_bytes())==r['page_sha256']
roster=None;checks=[];bindings=0
for gate in r['gates']:
 data=Path(gate['receipt']).read_bytes();assert sha(data)==gate['receipt_sha256'];g=json.loads(data)
 assert g['exit_code']==0 and not g['timed_out'] and g['source_unchanged']
 assert g['command']==gate['command'] and g['website_base']==r['website_base']
 assert sha(Path(g['log']).read_bytes())==g['log_sha256']==gate['log_sha256']
 if roster is None:roster=g['source_sha256'];verify_sources(root,r['website_commit'],roster)
 assert g['source_sha256']==roster
 bindings+=len(roster);checks.append({'name':g['name'],'seconds':g['elapsed_seconds'],'exit_code':0})
assert len(checks)==5 and bindings==2015
source=Path(r['source_evidence']['path']);assert sha(source.read_bytes())==r['source_evidence']['sha256'];s=json.loads(source.read_bytes());verify_sources(lang,s['language_source'],s['source_sha256'])
render=Path(r['rendered_inspection']['path']);assert sha(render.read_bytes())==r['rendered_inspection']['sha256'];view=json.loads(render.read_bytes());assert len(view['checks'])==13 and all(view['checks'].values())
for page in view['pages'].values():assert sha(Path(page['path']).read_bytes())==page['sha256']
review={'task':'T1750','website_commit':r['website_commit'],'website_base':r['website_base'],'receipt_sha256':sha(raw),'website_source_bindings_verified':bindings,'unique_website_source_files':len(roster),'language_source':s['language_source'],'language_source_bindings_verified':len(s['source_sha256']),'gates':checks,'rendered_checks':13,'scope':'Independent source, receipt, log and rendered-output verification. Reference documentation only; no Verum execution, publishing, or deployment.'}
Path('/private/tmp/verum-T1750-parent-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review))
