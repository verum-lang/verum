from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

SOURCE = Path('/private/tmp/verum-registry-t1636-auth')
OUT = Path('/private/tmp/verum-registry-stage21-type-boundaries')
BUILD = Path('/private/tmp/verum-registry-stage21-array-storage/build-manifest.json')
build = json.loads(BUILD.read_text())
cli = Path(build['cli']['path'])


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert build['exit_code'] == 0 and build['source_unchanged'] and build['automatic_precompile']
assert digest(cli) == build['cli']['sha256']
for name, identity in build['artifacts'].items():
    assert digest(Path(build['artifact_snapshot']) / name) == identity['sha256']
assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == 'c02238261fee7cf7a0885886e5e3cf9928e7a73d'
assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain']).strip()
modules = [
    'src/protocol/authority.vr', 'src/protocol/publication.vr',
    'src/protocol/publication_metadata.vr', 'src/node/publication_auth.vr',
    'src/node/publication_prepare.vr',
]
names = [
    'publication_prepare_consume', 'publication_auth_private_store',
    'publication_auth_construct_store', 'publication_prepare_construct',
    'publication_prepare_private_field', 'publication_prepare_affine_reuse',
]
OUT.mkdir(exist_ok=False)
receipts = []
for name in names:
    destination = OUT / name
    project = destination / 'project'
    project.mkdir(parents=True)
    inputs = {}
    for item in modules:
        target = project / item
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / item, target)
        inputs[item] = digest(SOURCE / item)
    fixture = SOURCE / 'tests/language' / (name + '.vr')
    inputs[str(fixture.relative_to(SOURCE))] = digest(fixture)
    raw = fixture.read_bytes()
    header = ('module verum_registry.tests.' + name + ';').encode()
    assert raw.count(header) == 1
    (project / 'src/main.vr').write_bytes(raw.replace(header, b'module verum_registry.main;', 1))
    (project / 'verum.toml').write_bytes(b'[cog]\nname = "verum-registry"\nversion = "0.1.0"\nedition = "2026"\n')
    project_inputs = {str(p.relative_to(project)): digest(p) for p in sorted(project.rglob('*')) if p.is_file()}
    command = [str(cli), 'check']
    env = {'NO_COLOR': '1', 'VERUM_NO_OBJECT_CACHE': '1', 'TMPDIR': '/private/tmp'}
    record = {
        'task': 'T1636', 'case': name, 'command': command,
        'working_directory': str(project), 'environment_overrides': env,
        'language_commit': build['engine_commit'], 'cli': build['cli'],
        'build_manifest_sha256': digest(BUILD), 'schema': build['schema'],
        'registry_commit': 'c02238261fee7cf7a0885886e5e3cf9928e7a73d',
        'source_inputs': inputs, 'project_inputs': project_inputs,
        'entry_transformation': 'Replace only the fixture module header with verum_registry.main.',
        'expected': 'successful complete project check' if name == names[0] else 'specific visibility, construction or second-consumption refusal',
        'deadline_seconds': 600,
        'scope': 'Ordinary project type check of exact production modules. A negative exit requires diagnostic review; unrelated compile errors do not establish refusal. No runtime, HTTP, durability or AOT acceptance.',
    }
    (destination / 'started.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'case': name, 'state': 'started'}), flush=True)
    start = time.monotonic()
    with (destination / 'stdout.log').open('wb') as stdout, (destination / 'stderr.log').open('wb') as stderr:
        proc = subprocess.Popen(command, cwd=project, env={**os.environ, **env}, stdout=stdout, stderr=stderr, start_new_session=True)
        timed_out = False
        try:
            code = proc.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                code = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait()
    text = (destination / 'stdout.log').read_text(errors='replace') + (destination / 'stderr.log').read_text(errors='replace')
    record.update(
        returncode=code, elapsed_seconds=round(time.monotonic() - start, 3), timed_out=timed_out,
        source_unchanged=all(digest(SOURCE / key) == value for key, value in inputs.items()),
        project_unchanged=all(digest(project / key) == value for key, value in project_inputs.items()),
        executable_unchanged=digest(cli) == build['cli']['sha256'],
        logs={item: digest(destination / item) for item in ['stdout.log', 'stderr.log']},
        error_lines=[line for line in text.splitlines() if line.startswith('error')],
        complete_check_marker='checking verum-registry in ' in text and ' files checked,' in text,
    )
    if timed_out:
        record['verdict'] = 'inconclusive_timeout'
    elif not all(record[key] for key in ['source_unchanged', 'project_unchanged', 'executable_unchanged']):
        record['verdict'] = 'inconclusive_changed_inputs'
    elif name == names[0]:
        record['verdict'] = 'positive_check_passed' if code == 0 and record['complete_check_marker'] else 'positive_check_failed'
    else:
        record['verdict'] = 'unexpected_acceptance' if code == 0 else 'requires_specific_diagnostic_review'
    (destination / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    receipts.append({key: record[key] for key in ['case', 'returncode', 'elapsed_seconds', 'verdict', 'error_lines']})
    (OUT / 'summary.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps(receipts[-1]), flush=True)
