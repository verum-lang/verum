from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import subprocess

ROOT = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
REGISTRY = Path('/private/tmp/verum-registry-t1636-auth')
REV = 'c02238261fee7cf7a0885886e5e3cf9928e7a73d'
OUT = ROOT / 'docs/architecture/evidence/registry-stage21-publication'
BUILD = Path('/private/tmp/verum-registry-stage21-array-storage/build-manifest.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.DEVNULL)

dirty = git(ROOT, 'status', '--porcelain').decode().splitlines()
assert all(line[3:].startswith('docs/architecture/evidence/registry-stage21-publication/') for line in dirty), dirty
assert git(REGISTRY, 'rev-parse', 'HEAD').decode().strip() == REV
assert not git(REGISTRY, 'status', '--porcelain').strip()
build = read(BUILD)
assert build['exit_code'] == 0 and build['automatic_precompile'] and build['source_unchanged']
assert sha(Path(build['cli']['path']).read_bytes()) == build['cli']['sha256']
spec = importlib.util.spec_from_file_location('publication_runner', REGISTRY / 'tools/run_publication_envelope.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
OUT.mkdir(exist_ok=True)
files = {}
cases = {}

def retain(raw, name, compress=False):
    path = OUT / (name + ('.gz' if compress else ''))
    path.parent.mkdir(parents=True, exist_ok=True)
    stored = gzip.compress(raw, mtime=0) if compress else raw
    if path.exists():
        assert path.read_bytes() == stored, path
    else:
        path.write_bytes(stored)
    files[str(path.relative_to(OUT))] = {
        'raw_sha256': sha(raw), 'stored_sha256': sha(stored),
        'raw_bytes': len(raw), 'stored_bytes': len(stored), 'compressed': compress,
    }

def retain_file(path, name, compress=False):
    retain(Path(path).read_bytes(), name, compress)

def retain_inputs(inputs, expected, prefix):
    assert {str(k): sha(v) for k, v in inputs.items()} == expected
    for name, raw in inputs.items():
        retain(raw, prefix + '/' + str(name), True)

def logs(directory, result, prefix):
    for name, expected in result['logs'].items():
        raw = (directory / name).read_bytes()
        assert sha(raw) == expected
        retain(raw, prefix + '/' + name, True)
    retain_file(directory / 'result.json', prefix + '/result.json')

classifications = {
    'prepare': 'compile_failure: eight returned-public-method errors (T1711), plus one borrowed fixed-array versus List mismatch; no preparation runtime result',
    'credentials_file': 'compile_failure: return-inferred PublisherAttribution.principal_id is missing (T1711); file-loading runtime not reached',
    'auth_bounds': 'compile_failure: mounted core.text.builder.TextBuilder.new returns a foreign same-leaf owner (T1212); bound tests not reached',
    'auth_isolation': 'passed: exact private-state isolation fixture with an explicitly appended test helper; no external privacy conclusion',
}
for name, classification in classifications.items():
    directory = Path('/private/tmp/verum-registry-stage21-' + name)
    result = read(directory / 'result.json')
    assert result['cli_sha256'] == build['cli']['sha256']
    assert result['language_source_commit_supplied'] == build['engine_commit']
    for flag in ['within_deadline', 'source_unchanged', 'project_unchanged', 'executable_unchanged']:
        assert result['checks'][flag]
    assert (result['status'] == 'passed') == (name == 'auth_isolation')
    sources = {Path(p): git(REGISTRY, 'show', REV + ':' + p) for p in result['source_inputs']}
    retain_inputs(sources, result['source_inputs'], name + '/source')
    component = runner.COMPONENTS[name]
    inputs = {p: sources[p] for p in (*component['modules'], *component.get('assets', ()))}
    inputs[Path('src/main.vr')] = sources[component['fixture']].replace(component['header'], runner.NEW_HEADER, 1)
    inputs[Path('verum.toml')] = runner.MANIFEST
    for target, fragment in component.get('appended_fragments', {}).items():
        inputs[target] = sources[target] + b'\n' + sources[fragment]
    retain_inputs(inputs, result['project_inputs'], name + '/reconstructed-inputs')
    logs(directory, result, name)
    cases[name] = {'classification': classification, 'receipt': name + '/result.json',
                   'elapsed_seconds': result['elapsed_seconds'],
                   'input_retention': 'Reconstructed byte-for-byte from pinned source and recorded assembly; all original receipt hashes match.'}

boundary = Path('/private/tmp/verum-registry-stage21-type-boundaries')
for entry in read(boundary / 'summary.json'):
    name = entry['case']
    directory = boundary / name
    result = read(directory / 'result.json')
    assert result['cli']['sha256'] == build['cli']['sha256']
    assert result['language_commit'] == build['engine_commit'] and result['registry_commit'] == REV
    assert result['build_manifest_sha256'] == sha(BUILD.read_bytes())
    assert all(result[k] for k in ['source_unchanged', 'project_unchanged', 'executable_unchanged'])
    assert not result['timed_out']
    inputs = {p: (directory / 'project' / p).read_bytes() for p in result['project_inputs']}
    retain_inputs(inputs, result['project_inputs'], 'type-boundaries/' + name + '/inputs')
    prefix = 'type-boundaries/' + name
    logs(directory, result, prefix)
    if name == 'publication_prepare_consume':
        assert result['returncode'] == 0 and result['complete_check_marker'] and not result['error_lines']
        verdict = 'accepted: one public consuming into_parts call checks'
    elif name == 'publication_prepare_affine_reuse':
        assert result['returncode'] == 101
        assert result['error_lines'] == ['error<E310>: value `prepared` used after move', 'error: compilation failed with 1 error', 'error: compilation failed with 1 error']
        source = inputs['src/main.vr'].decode()
        assert source[237:].startswith('prepared.into_parts()') and source[277:].startswith('prepared.into_parts()')
        verdict = 'required refusal: E310 uses move offset 237 and second-use offset 277; displayed excerpt highlights first use'
    else:
        assert result['returncode'] == 0 and result['complete_check_marker'] and not result['error_lines']
        verdict = 'incorrectly accepted: external private-field access or construction (T1713)'
    cases[name] = {'classification': verdict, 'receipt': prefix + '/result.json',
                   'elapsed_seconds': result['elapsed_seconds'], 'input_retention': 'Original complete project snapshot.'}

for name in ['big_endian_u16_annotated', 'big_endian_u32_annotated']:
    directory = Path('/private/tmp/verum-registry-stage21-narrow-endian') / name
    result = read(directory / 'result.json')
    assert result['accepted'] and result['cli']['sha256'] == build['cli']['sha256']
    prefix = 'narrow-endian/' + name
    retain_file(directory / 'result.json', prefix + '/result.json')
    for stream in ['stdout', 'stderr']:
        raw = (directory / (stream + '.log')).read_bytes()
        assert sha(raw) == result[stream + '_sha256']
        retain(raw, prefix + '/' + stream + '.log', True)
    raw = Path(result['executed_fixture']).read_bytes()
    assert sha(raw) == result['fixture_sha256']
    assert Path(result['source_fixture']).read_bytes() == raw
    assert all(result[k] for k in ['cli_unchanged', 'inputs_unchanged', 'artifacts_unchanged'])
    retain(raw, prefix + '/inputs/' + name + '.vr', True)
    cases[name] = {'classification': 'passed: unchanged ordinary interpreter endian fixture', 'receipt': prefix + '/result.json'}

webdir = Path('/private/tmp/verum-stage21-runtime-website-gates')
web = read(webdir / 'result.json')
audit_path = Path('/private/tmp/verum-stage21-website-root-audit.json')
audit = read(audit_path)
assert audit['receipt_sha256'] == sha((webdir / 'result.json').read_bytes())
assert audit['candidate'] == '73390a4f0613f582820b59f4a81d1237b51a1120'
for gate in web['gates']:
    assert gate['returncode'] == 0 and not gate['timed_out']
    assert sha(Path(gate['log']).read_bytes()) == gate['log_sha256']
    retain_file(gate['log'], 'website/' + gate['name'] + '.log', True)
retain_file(webdir / 'result.json', 'website/result.json', True)
retain_file(audit_path, 'website/root-audit.json')
retain_file('/private/tmp/verum-registry-type-boundaries.py', 'runners/type-boundaries.py', True)
retain_file(__file__, 'runners/retain.py', True)
retain_file(REGISTRY / 'tests/language/publication_auth_boundary.md', 'type-boundaries/original-contract.md')
record = {'tasks': ['T1635', 'T1636', 'T1713'], 'language_commit': build['engine_commit'],
          'registry_candidate': REV, 'cli_sha256': build['cli']['sha256'],
          'build_manifest': '../registry-stage21-runtime/build/build-manifest.json',
          'build_manifest_sha256': sha(BUILD.read_bytes()), 'schema': build['schema'],
          'cases': cases, 'website_commit': audit['candidate'], 'files': files,
          'scope': 'Ordinary interpreter/component and complete-project type controls. Compiler ownership and privacy defects prevent authentication candidate integration. No HTTP, durable publication, deployed service or AOT acceptance.'}
(OUT / 'review.json').write_text(json.dumps(record, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Publication preparation and module boundaries

These controls use the captured ordinary CLI from `49559a042` and its automatic
standard-library bake. The [review](review.json) binds every case to exact
inputs and output, and retains the original failed receipts without rewriting
their verdicts. Component inputs whose temporary directories had been removed
are reconstructed from the pinned candidate and original assembly rules;
every byte matches the hashes captured during execution.

The public consuming `PreparedPublication.into_parts` API checks when its type
is explicitly mounted. Reusing the affine value is correctly refused with
E310 and the first/second call offsets. The diagnostic's displayed excerpt
points at the first call, so this record does not claim correct second-use
source highlighting.

Four negative controls incorrectly check successfully: reading the private
credential-store field, constructing that store through private fields,
constructing a prepared publication through private fields, and reading its
private publication field. T1713 tracks field visibility. The separate
private-state isolation runtime fixture passes, but deliberately appends a
test helper and cannot establish external privacy.

The credential-file fixture stops before runtime because a method on a
return-inferred public type is missing (T1711). Preparation has eight such
method errors plus a borrowed fixed-array versus List mismatch. Its runtime
and text-slicing behavior remain unmeasured. The bounds fixture also stops
before runtime: its mounted TextBuilder constructor resolves to a foreign
same-named type (T1212).

Two additional unchanged narrow-width endian fixtures pass. The website
receipt retains all five successful gates and the review of four rendered
pages at `73390a4`. These results do not establish general cryptography,
timing resistance, native AOT, bounded HTTP receive, durable publication or a
deployable registry. The authentication candidate remains separate from main.
''')
p = ROOT / 'docs/architecture/registry-language-acceptance.md'
with p.open('a') as f:
    f.write('''

### Publication preparation and external privacy

The same fresh `49559a042` product passes the public single-consumption project
control and refuses affine reuse with E310. Four external private-field read
and construction controls incorrectly succeed (T1713). The passing runtime
isolation fixture deliberately appends a private helper and does not validate
those visibility boundaries. Credential-file and preparation runtime checks
stop on returned public method lookup (T1711); preparation also reports a
borrowed fixed-array/List mismatch. The bounds fixture stops on a mounted
constructor selecting a foreign nominal owner (T1212).

The [publication boundary record](evidence/registry-stage21-publication/review.json)
retains all original receipts, exact source/project bytes, and specific
diagnostic review. It also retains the two passing narrow endian controls and
website validation at `73390a4`. Authentication candidate `c02238261` remains
unintegrated pending compiler visibility and runtime acceptance; passing its
standalone authentication fixture is insufficient for publication readiness.
''')
print(json.dumps({'path': str(OUT), 'retained_files': len(files), 'cases': len(cases)}))
