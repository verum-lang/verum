target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r1)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %ba_init8 = trunc i64 %r2 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r1, i1 false)
  store i64 0, ptr %r2_slot, align 8
  store i64 128, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %ba_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r21
  %ba_trunc = trunc i64 %r12 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 1, ptr %r1_slot, align 8
  store i64 255, ptr %r2_slot, align 8
  %r03 = load i64, ptr %r0_slot, align 8
  %ba_base4 = inttoptr i64 %r03 to ptr
  %r15 = load i64, ptr %r1_slot, align 8
  %r26 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr7 = getelementptr i8, ptr %ba_base4, i64 %r15
  %ba_trunc8 = trunc i64 %r26 to i8
  store i8 %ba_trunc8, ptr %ba_store_ptr7, align 1
  store i64 2, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r09 = load i64, ptr %r0_slot, align 8
  %ba_base10 = inttoptr i64 %r09 to ptr
  %r211 = load i64, ptr %r2_slot, align 8
  %r112 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr13 = getelementptr i8, ptr %ba_base10, i64 %r211
  %ba_trunc14 = trunc i64 %r112 to i8
  store i8 %ba_trunc14, ptr %ba_store_ptr13, align 1
  %r015 = load i64, ptr %r0_slot, align 8
  store i64 %r015, ptr %r3_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_base16 = inttoptr i64 %r3 to ptr
  %r117 = load i64, ptr %r1_slot, align 8
  %ba_load_ptr = getelementptr i8, ptr %ba_base16, i64 %r117
  %ba_byte = load i8, ptr %ba_load_ptr, align 1
  %ba_ext = zext i8 %ba_byte to i64
  store i64 %ba_ext, ptr %r2_slot, align 8
  %r218 = load i64, ptr %r2_slot, align 8
  store i64 %r218, ptr %r1_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r319 = load i64, ptr %r3_slot, align 8
  %ba_base20 = inttoptr i64 %r319 to ptr
  %r221 = load i64, ptr %r2_slot, align 8
  %ba_load_ptr22 = getelementptr i8, ptr %ba_base20, i64 %r221
  %ba_byte23 = load i8, ptr %ba_load_ptr22, align 1
  %ba_ext24 = zext i8 %ba_byte23 to i64
  store i64 %ba_ext24, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  store i64 %r4, ptr %r2_slot, align 8
  %r125 = load i64, ptr %r1_slot, align 8
  %r226 = load i64, ptr %r2_slot, align 8
  %add = add i64 %r125, %r226
  store i64 %add, ptr %r4_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  %r327 = load i64, ptr %r3_slot, align 8
  %ba_base28 = inttoptr i64 %r327 to ptr
  %r229 = load i64, ptr %r2_slot, align 8
  %ba_load_ptr30 = getelementptr i8, ptr %ba_base28, i64 %r229
  %ba_byte31 = load i8, ptr %ba_load_ptr30, align 1
  %ba_ext32 = zext i8 %ba_byte31 to i64
  store i64 %ba_ext32, ptr %r1_slot, align 8
  %r133 = load i64, ptr %r1_slot, align 8
  store i64 %r133, ptr %r2_slot, align 8
  %r434 = load i64, ptr %r4_slot, align 8
  %r235 = load i64, ptr %r2_slot, align 8
  %add36 = add i64 %r434, %r235
  store i64 %add36, ptr %r1_slot, align 8
  %r137 = load i64, ptr %r1_slot, align 8
  store i64 %r137, ptr %r2_slot, align 8
  %r338 = load i64, ptr %r3_slot, align 8
  %r239 = load i64, ptr %r2_slot, align 8
  %r240 = load i64, ptr %r2_slot, align 8
  ret i64 %r240
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

