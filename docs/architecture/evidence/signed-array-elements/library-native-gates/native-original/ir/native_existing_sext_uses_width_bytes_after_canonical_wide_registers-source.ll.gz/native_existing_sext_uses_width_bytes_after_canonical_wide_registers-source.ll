target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nounwind }
attributes #6 = { noinline }
attributes #7 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { returns_twice "verum.platform.extern" }
attributes #9 = { noreturn "verum.platform.extern" }
attributes #10 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #5 {
block_0:
  %r270_slot = alloca i64, align 8
  %r257_slot = alloca i64, align 8
  store i64 2147483648, ptr %r257_slot, align 8
  %r257 = load i64, ptr %r257_slot, align 8
  %sext_narrow = trunc i64 %r257 to i32
  %sext = sext i32 %sext_narrow to i64
  store i64 %sext, ptr %r270_slot, align 8
  %r270 = load i64, ptr %r270_slot, align 8
  %r2701 = load i64, ptr %r270_slot, align 8
  ret i64 %r2701
}

