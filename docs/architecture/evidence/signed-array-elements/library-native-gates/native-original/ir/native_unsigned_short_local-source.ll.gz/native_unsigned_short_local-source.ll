target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %ta_bytes = mul i64 %r1, 2
  %new_typed_array = call ptr @verum_cbgr_allocate(i64 %ta_bytes)
  %r0_ptr_to_i64 = ptrtoint ptr %new_typed_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  br label %ta_fill_check

ta_fill_check:                                    ; preds = %ta_fill_body, %block_0
  %ta_i = phi i64 [ 0, %block_0 ], [ %ta_next, %ta_fill_body ]
  %ta_more = icmp slt i64 %ta_i, %r1
  br i1 %ta_more, label %ta_fill_body, label %ta_fill_done

ta_fill_body:                                     ; preds = %ta_fill_check
  %ta_slot = getelementptr inbounds i16, ptr %new_typed_array, i64 %ta_i
  %ta_v = trunc i64 %r2 to i16
  store i16 %ta_v, ptr %ta_slot, align 2
  %ta_next = add i64 %ta_i, 1
  br label %ta_fill_check

ta_fill_done:                                     ; preds = %ta_fill_check
  store i64 0, ptr %r2_slot, align 8
  store i64 32768, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %tas_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %tas_off = mul i64 %r21, 2
  %tas_ptr = getelementptr i8, ptr %tas_base, i64 %tas_off
  switch i64 2, label %tas_sw8 [
    i64 1, label %tas_sw1
    i64 2, label %tas_sw2
    i64 4, label %tas_sw4
  ]

tas_sw1:                                          ; preds = %ta_fill_done
  %tas_st = trunc i64 %r12 to i8
  store i8 %tas_st, ptr %tas_ptr, align 1
  br label %tas_smerge

tas_sw2:                                          ; preds = %ta_fill_done
  %tas_st3 = trunc i64 %r12 to i16
  store i16 %tas_st3, ptr %tas_ptr, align 2
  br label %tas_smerge

tas_sw4:                                          ; preds = %ta_fill_done
  %tas_st4 = trunc i64 %r12 to i32
  store i32 %tas_st4, ptr %tas_ptr, align 4
  br label %tas_smerge

tas_sw8:                                          ; preds = %ta_fill_done
  store i64 %r12, ptr %tas_ptr, align 8
  br label %tas_smerge

tas_smerge:                                       ; preds = %tas_sw8, %tas_sw4, %tas_sw2, %tas_sw1
  store i64 1, ptr %r1_slot, align 8
  store i64 65535, ptr %r2_slot, align 8
  %r05 = load i64, ptr %r0_slot, align 8
  %tas_base6 = inttoptr i64 %r05 to ptr
  %r17 = load i64, ptr %r1_slot, align 8
  %r28 = load i64, ptr %r2_slot, align 8
  %tas_off9 = mul i64 %r17, 2
  %tas_ptr10 = getelementptr i8, ptr %tas_base6, i64 %tas_off9
  switch i64 2, label %tas_sw814 [
    i64 1, label %tas_sw111
    i64 2, label %tas_sw212
    i64 4, label %tas_sw413
  ]

tas_sw111:                                        ; preds = %tas_smerge
  %tas_st16 = trunc i64 %r28 to i8
  store i8 %tas_st16, ptr %tas_ptr10, align 1
  br label %tas_smerge15

tas_sw212:                                        ; preds = %tas_smerge
  %tas_st17 = trunc i64 %r28 to i16
  store i16 %tas_st17, ptr %tas_ptr10, align 2
  br label %tas_smerge15

tas_sw413:                                        ; preds = %tas_smerge
  %tas_st18 = trunc i64 %r28 to i32
  store i32 %tas_st18, ptr %tas_ptr10, align 4
  br label %tas_smerge15

tas_sw814:                                        ; preds = %tas_smerge
  store i64 %r28, ptr %tas_ptr10, align 8
  br label %tas_smerge15

tas_smerge15:                                     ; preds = %tas_sw814, %tas_sw413, %tas_sw212, %tas_sw111
  store i64 2, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r019 = load i64, ptr %r0_slot, align 8
  %tas_base20 = inttoptr i64 %r019 to ptr
  %r221 = load i64, ptr %r2_slot, align 8
  %r122 = load i64, ptr %r1_slot, align 8
  %tas_off23 = mul i64 %r221, 2
  %tas_ptr24 = getelementptr i8, ptr %tas_base20, i64 %tas_off23
  switch i64 2, label %tas_sw828 [
    i64 1, label %tas_sw125
    i64 2, label %tas_sw226
    i64 4, label %tas_sw427
  ]

tas_sw125:                                        ; preds = %tas_smerge15
  %tas_st30 = trunc i64 %r122 to i8
  store i8 %tas_st30, ptr %tas_ptr24, align 1
  br label %tas_smerge29

tas_sw226:                                        ; preds = %tas_smerge15
  %tas_st31 = trunc i64 %r122 to i16
  store i16 %tas_st31, ptr %tas_ptr24, align 2
  br label %tas_smerge29

tas_sw427:                                        ; preds = %tas_smerge15
  %tas_st32 = trunc i64 %r122 to i32
  store i32 %tas_st32, ptr %tas_ptr24, align 4
  br label %tas_smerge29

tas_sw828:                                        ; preds = %tas_smerge15
  store i64 %r122, ptr %tas_ptr24, align 8
  br label %tas_smerge29

tas_smerge29:                                     ; preds = %tas_sw828, %tas_sw427, %tas_sw226, %tas_sw125
  %r033 = load i64, ptr %r0_slot, align 8
  store i64 %r033, ptr %r3_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %tal_base = inttoptr i64 %r3 to ptr
  %r134 = load i64, ptr %r1_slot, align 8
  %tal_off = mul i64 %r134, 2
  %tal_ptr = getelementptr i8, ptr %tal_base, i64 %tal_off
  %tal_raw = load i16, ptr %tal_ptr, align 2
  %tal_zext = zext i16 %tal_raw to i64
  store i64 %tal_zext, ptr %r2_slot, align 8
  %r235 = load i64, ptr %r2_slot, align 8
  store i64 %r235, ptr %r1_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r336 = load i64, ptr %r3_slot, align 8
  %tal_base37 = inttoptr i64 %r336 to ptr
  %r238 = load i64, ptr %r2_slot, align 8
  %tal_off39 = mul i64 %r238, 2
  %tal_ptr40 = getelementptr i8, ptr %tal_base37, i64 %tal_off39
  %tal_raw41 = load i16, ptr %tal_ptr40, align 2
  %tal_zext42 = zext i16 %tal_raw41 to i64
  store i64 %tal_zext42, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  store i64 %r4, ptr %r2_slot, align 8
  %r143 = load i64, ptr %r1_slot, align 8
  %r244 = load i64, ptr %r2_slot, align 8
  %add = add i64 %r143, %r244
  store i64 %add, ptr %r4_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  %r345 = load i64, ptr %r3_slot, align 8
  %tal_base46 = inttoptr i64 %r345 to ptr
  %r247 = load i64, ptr %r2_slot, align 8
  %tal_off48 = mul i64 %r247, 2
  %tal_ptr49 = getelementptr i8, ptr %tal_base46, i64 %tal_off48
  %tal_raw50 = load i16, ptr %tal_ptr49, align 2
  %tal_zext51 = zext i16 %tal_raw50 to i64
  store i64 %tal_zext51, ptr %r1_slot, align 8
  %r152 = load i64, ptr %r1_slot, align 8
  store i64 %r152, ptr %r2_slot, align 8
  %r453 = load i64, ptr %r4_slot, align 8
  %r254 = load i64, ptr %r2_slot, align 8
  %add55 = add i64 %r453, %r254
  store i64 %add55, ptr %r1_slot, align 8
  %r156 = load i64, ptr %r1_slot, align 8
  store i64 %r156, ptr %r2_slot, align 8
  %r357 = load i64, ptr %r3_slot, align 8
  %r258 = load i64, ptr %r2_slot, align 8
  %r259 = load i64, ptr %r2_slot, align 8
  ret i64 %r259
}

