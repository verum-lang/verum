target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
declare ptr @verum_os_alloc(i64)
declare void @verum_dealloc(ptr, i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %list_obj = call ptr @verum_list_allocate_storage(i64 3, i32 512)
  %r0_ptr_to_i64 = ptrtoint ptr %list_obj to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  store i64 128, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %neg = sub i64 0, %r1
  store i64 %neg, ptr %r2_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %list_ptr = inttoptr i64 %r0 to ptr
  %r2 = load i64, ptr %r2_slot, align 8
  %len_slot = getelementptr inbounds i8, ptr %list_ptr, i64 24
  %len = load i64, ptr %len_slot, align 8
  %cap_slot = getelementptr inbounds i8, ptr %list_ptr, i64 32
  %cap = load i64, ptr %cap_slot, align 8
  %data_ptr_slot = getelementptr inbounds i8, ptr %list_ptr, i64 40
  %data_int = load i64, ptr %data_ptr_slot, align 8
  %data_ptr = inttoptr i64 %data_int to ptr
  %needs_grow = icmp uge i64 %len, %cap
  br i1 %needs_grow, label %list_grow, label %list_push_continue

list_grow:                                        ; preds = %block_0
  call void @verum_list_grow(ptr %list_ptr)
  br label %list_push_continue

list_push_continue:                               ; preds = %list_grow, %block_0
  %data_int_post = load i64, ptr %data_ptr_slot, align 8
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %list_ptr)
  %list_push_off = mul i64 %len, %list_storage_stride
  %list_push_addr = add i64 %data_int_post, %list_push_off
  %list_push_eptr = inttoptr i64 %list_push_addr to ptr
  switch i64 %list_storage_stride, label %list_push_sw8 [
    i64 1, label %list_push_sw1
    i64 2, label %list_push_sw2
    i64 4, label %list_push_sw4
  ]

list_push_sw1:                                    ; preds = %list_push_continue
  %list_push_st = trunc i64 %r2 to i8
  store i8 %list_push_st, ptr %list_push_eptr, align 1
  br label %list_push_smerge

list_push_sw2:                                    ; preds = %list_push_continue
  %list_push_st1 = trunc i64 %r2 to i16
  store i16 %list_push_st1, ptr %list_push_eptr, align 2
  br label %list_push_smerge

list_push_sw4:                                    ; preds = %list_push_continue
  %list_push_st2 = trunc i64 %r2 to i32
  store i32 %list_push_st2, ptr %list_push_eptr, align 4
  br label %list_push_smerge

list_push_sw8:                                    ; preds = %list_push_continue
  store i64 %r2, ptr %list_push_eptr, align 8
  br label %list_push_smerge

list_push_smerge:                                 ; preds = %list_push_sw8, %list_push_sw4, %list_push_sw2, %list_push_sw1
  %new_len = add i64 %len, 1
  store i64 %new_len, ptr %len_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r23 = load i64, ptr %r2_slot, align 8
  %neg4 = sub i64 0, %r23
  store i64 %neg4, ptr %r1_slot, align 8
  %r05 = load i64, ptr %r0_slot, align 8
  %list_ptr6 = inttoptr i64 %r05 to ptr
  %r17 = load i64, ptr %r1_slot, align 8
  %len_slot8 = getelementptr inbounds i8, ptr %list_ptr6, i64 24
  %len9 = load i64, ptr %len_slot8, align 8
  %cap_slot10 = getelementptr inbounds i8, ptr %list_ptr6, i64 32
  %cap11 = load i64, ptr %cap_slot10, align 8
  %data_ptr_slot12 = getelementptr inbounds i8, ptr %list_ptr6, i64 40
  %data_int13 = load i64, ptr %data_ptr_slot12, align 8
  %data_ptr14 = inttoptr i64 %data_int13 to ptr
  %needs_grow15 = icmp uge i64 %len9, %cap11
  br i1 %needs_grow15, label %list_grow16, label %list_push_continue17

list_grow16:                                      ; preds = %list_push_smerge
  call void @verum_list_grow(ptr %list_ptr6)
  br label %list_push_continue17

list_push_continue17:                             ; preds = %list_grow16, %list_push_smerge
  %data_int_post18 = load i64, ptr %data_ptr_slot12, align 8
  %list_storage_stride19 = call i64 @verum_list_storage_stride(ptr %list_ptr6)
  %list_push_off20 = mul i64 %len9, %list_storage_stride19
  %list_push_addr21 = add i64 %data_int_post18, %list_push_off20
  %list_push_eptr22 = inttoptr i64 %list_push_addr21 to ptr
  switch i64 %list_storage_stride19, label %list_push_sw826 [
    i64 1, label %list_push_sw123
    i64 2, label %list_push_sw224
    i64 4, label %list_push_sw425
  ]

list_push_sw123:                                  ; preds = %list_push_continue17
  %list_push_st28 = trunc i64 %r17 to i8
  store i8 %list_push_st28, ptr %list_push_eptr22, align 1
  br label %list_push_smerge27

list_push_sw224:                                  ; preds = %list_push_continue17
  %list_push_st29 = trunc i64 %r17 to i16
  store i16 %list_push_st29, ptr %list_push_eptr22, align 2
  br label %list_push_smerge27

list_push_sw425:                                  ; preds = %list_push_continue17
  %list_push_st30 = trunc i64 %r17 to i32
  store i32 %list_push_st30, ptr %list_push_eptr22, align 4
  br label %list_push_smerge27

list_push_sw826:                                  ; preds = %list_push_continue17
  store i64 %r17, ptr %list_push_eptr22, align 8
  br label %list_push_smerge27

list_push_smerge27:                               ; preds = %list_push_sw826, %list_push_sw425, %list_push_sw224, %list_push_sw123
  %new_len31 = add i64 %len9, 1
  store i64 %new_len31, ptr %len_slot8, align 8
  store i64 1, ptr %r1_slot, align 8
  %r032 = load i64, ptr %r0_slot, align 8
  %list_ptr33 = inttoptr i64 %r032 to ptr
  %r134 = load i64, ptr %r1_slot, align 8
  %len_slot35 = getelementptr inbounds i8, ptr %list_ptr33, i64 24
  %len36 = load i64, ptr %len_slot35, align 8
  %cap_slot37 = getelementptr inbounds i8, ptr %list_ptr33, i64 32
  %cap38 = load i64, ptr %cap_slot37, align 8
  %data_ptr_slot39 = getelementptr inbounds i8, ptr %list_ptr33, i64 40
  %data_int40 = load i64, ptr %data_ptr_slot39, align 8
  %data_ptr41 = inttoptr i64 %data_int40 to ptr
  %needs_grow42 = icmp uge i64 %len36, %cap38
  br i1 %needs_grow42, label %list_grow43, label %list_push_continue44

list_grow43:                                      ; preds = %list_push_smerge27
  call void @verum_list_grow(ptr %list_ptr33)
  br label %list_push_continue44

list_push_continue44:                             ; preds = %list_grow43, %list_push_smerge27
  %data_int_post45 = load i64, ptr %data_ptr_slot39, align 8
  %list_storage_stride46 = call i64 @verum_list_storage_stride(ptr %list_ptr33)
  %list_push_off47 = mul i64 %len36, %list_storage_stride46
  %list_push_addr48 = add i64 %data_int_post45, %list_push_off47
  %list_push_eptr49 = inttoptr i64 %list_push_addr48 to ptr
  switch i64 %list_storage_stride46, label %list_push_sw853 [
    i64 1, label %list_push_sw150
    i64 2, label %list_push_sw251
    i64 4, label %list_push_sw452
  ]

list_push_sw150:                                  ; preds = %list_push_continue44
  %list_push_st55 = trunc i64 %r134 to i8
  store i8 %list_push_st55, ptr %list_push_eptr49, align 1
  br label %list_push_smerge54

list_push_sw251:                                  ; preds = %list_push_continue44
  %list_push_st56 = trunc i64 %r134 to i16
  store i16 %list_push_st56, ptr %list_push_eptr49, align 2
  br label %list_push_smerge54

list_push_sw452:                                  ; preds = %list_push_continue44
  %list_push_st57 = trunc i64 %r134 to i32
  store i32 %list_push_st57, ptr %list_push_eptr49, align 4
  br label %list_push_smerge54

list_push_sw853:                                  ; preds = %list_push_continue44
  store i64 %r134, ptr %list_push_eptr49, align 8
  br label %list_push_smerge54

list_push_smerge54:                               ; preds = %list_push_sw853, %list_push_sw452, %list_push_sw251, %list_push_sw150
  %new_len58 = add i64 %len36, 1
  store i64 %new_len58, ptr %len_slot35, align 8
  %r059 = load i64, ptr %r0_slot, align 8
  store i64 %r059, ptr %r3_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %arr_ptr = inttoptr i64 %r3 to ptr
  %r160 = load i64, ptr %r1_slot, align 8
  %backing_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %backing_int = load i64, ptr %backing_slot, align 8
  %backing_ptr = inttoptr i64 %backing_int to ptr
  %geteu_w0 = load i64, ptr %arr_ptr, align 8
  %geteu_is_cell = icmp uge i64 %geteu_w0, 4294967296
  br i1 %geteu_is_cell, label %geteu_cv_cell, label %geteu_cv_obj

geteu_cv_cell:                                    ; preds = %list_push_smerge54
  %geteu_cv_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 8
  %geteu_cv_cell_len = load i64, ptr %geteu_cv_len_slot, align 8
  %geteu_cv_elem_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 16
  %geteu_cv_elem_raw = load i64, ptr %geteu_cv_elem_slot, align 8
  %geteu_cv_e1 = icmp eq i64 %geteu_cv_elem_raw, 1
  %geteu_cv_ew = icmp eq i64 %geteu_cv_elem_raw, 2
  %geteu_cv_edom = or i1 %geteu_cv_e1, %geteu_cv_ew
  %geteu_cv_ew61 = icmp eq i64 %geteu_cv_elem_raw, 4
  %geteu_cv_edom62 = or i1 %geteu_cv_edom, %geteu_cv_ew61
  %geteu_cv_ew63 = icmp eq i64 %geteu_cv_elem_raw, 8
  %geteu_cv_edom64 = or i1 %geteu_cv_edom62, %geteu_cv_ew63
  %geteu_cv_elem = select i1 %geteu_cv_edom64, i64 %geteu_cv_elem_raw, i64 8
  br label %geteu_cv_done

geteu_cv_obj:                                     ; preds = %list_push_smerge54
  %geteu_cv_tid = load i32, ptr %arr_ptr, align 4
  %geteu_cv_is_tuple = icmp eq i32 %geteu_cv_tid, 521
  %geteu_cv_is_bslice = icmp eq i32 %geteu_cv_tid, 528
  %geteu_cv_is_pack = or i1 %geteu_cv_is_tuple, %geteu_cv_is_bslice
  br i1 %geteu_cv_is_pack, label %geteu_cv_pack, label %geteu_cv_list

geteu_cv_pack:                                    ; preds = %geteu_cv_obj
  %geteu_cv_pk_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_pk_data = load i64, ptr %geteu_cv_pk_data_slot, align 8
  %geteu_cv_pk_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 32
  %geteu_cv_pk_len = load i64, ptr %geteu_cv_pk_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_list:                                    ; preds = %geteu_cv_obj
  %geteu_cv_ls_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %geteu_cv_ls_data = load i64, ptr %geteu_cv_ls_data_slot, align 8
  %geteu_cv_ls_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_ls_len = load i64, ptr %geteu_cv_ls_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_done:                                    ; preds = %geteu_cv_list, %geteu_cv_pack, %geteu_cv_cell
  %geteu_cv_data = phi i64 [ %geteu_w0, %geteu_cv_cell ], [ %geteu_cv_pk_data, %geteu_cv_pack ], [ %geteu_cv_ls_data, %geteu_cv_list ]
  %geteu_cv_len = phi i64 [ %geteu_cv_cell_len, %geteu_cv_cell ], [ %geteu_cv_pk_len, %geteu_cv_pack ], [ %geteu_cv_ls_len, %geteu_cv_list ]
  %geteu_cv_elem65 = phi i64 [ %geteu_cv_elem, %geteu_cv_cell ], [ 1, %geteu_cv_pack ], [ 8, %geteu_cv_list ]
  %geteu_off = mul i64 %r160, %geteu_cv_elem65
  %geteu_addr = add i64 %geteu_cv_data, %geteu_off
  %geteu_eptr = inttoptr i64 %geteu_addr to ptr
  switch i64 %geteu_cv_elem65, label %geteu_lw8 [
    i64 1, label %geteu_lw1
    i64 2, label %geteu_lw2
    i64 4, label %geteu_lw4
  ]

geteu_lw1:                                        ; preds = %geteu_cv_done
  %geteu_lv = load i8, ptr %geteu_eptr, align 1
  %geteu_lz = zext i8 %geteu_lv to i64
  br label %geteu_lmerge

geteu_lw2:                                        ; preds = %geteu_cv_done
  %geteu_lv66 = load i16, ptr %geteu_eptr, align 2
  %geteu_lz67 = zext i16 %geteu_lv66 to i64
  br label %geteu_lmerge

geteu_lw4:                                        ; preds = %geteu_cv_done
  %geteu_lv68 = load i32, ptr %geteu_eptr, align 4
  %geteu_lz69 = zext i32 %geteu_lv68 to i64
  br label %geteu_lmerge

geteu_lw8:                                        ; preds = %geteu_cv_done
  %geteu_lv8 = load i64, ptr %geteu_eptr, align 8
  br label %geteu_lmerge

geteu_lmerge:                                     ; preds = %geteu_lw8, %geteu_lw4, %geteu_lw2, %geteu_lw1
  %geteu_lval = phi i64 [ %geteu_lz, %geteu_lw1 ], [ %geteu_lz67, %geteu_lw2 ], [ %geteu_lz69, %geteu_lw4 ], [ %geteu_lv8, %geteu_lw8 ]
  store i64 %geteu_lval, ptr %r2_slot, align 8
  %r270 = load i64, ptr %r2_slot, align 8
  %sext_narrow = trunc i64 %r270 to i8
  %sext = sext i8 %sext_narrow to i64
  store i64 %sext, ptr %r2_slot, align 8
  %r271 = load i64, ptr %r2_slot, align 8
  store i64 %r271, ptr %r1_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r372 = load i64, ptr %r3_slot, align 8
  %arr_ptr73 = inttoptr i64 %r372 to ptr
  %r274 = load i64, ptr %r2_slot, align 8
  %backing_slot75 = getelementptr inbounds i8, ptr %arr_ptr73, i64 40
  %backing_int76 = load i64, ptr %backing_slot75, align 8
  %backing_ptr77 = inttoptr i64 %backing_int76 to ptr
  %geteu_w083 = load i64, ptr %arr_ptr73, align 8
  %geteu_is_cell84 = icmp uge i64 %geteu_w083, 4294967296
  br i1 %geteu_is_cell84, label %geteu_cv_cell78, label %geteu_cv_obj79

geteu_cv_cell78:                                  ; preds = %geteu_lmerge
  %geteu_cv_len_slot85 = getelementptr inbounds i8, ptr %arr_ptr73, i64 8
  %geteu_cv_cell_len86 = load i64, ptr %geteu_cv_len_slot85, align 8
  %geteu_cv_elem_slot87 = getelementptr inbounds i8, ptr %arr_ptr73, i64 16
  %geteu_cv_elem_raw88 = load i64, ptr %geteu_cv_elem_slot87, align 8
  %geteu_cv_e189 = icmp eq i64 %geteu_cv_elem_raw88, 1
  %geteu_cv_ew90 = icmp eq i64 %geteu_cv_elem_raw88, 2
  %geteu_cv_edom91 = or i1 %geteu_cv_e189, %geteu_cv_ew90
  %geteu_cv_ew92 = icmp eq i64 %geteu_cv_elem_raw88, 4
  %geteu_cv_edom93 = or i1 %geteu_cv_edom91, %geteu_cv_ew92
  %geteu_cv_ew94 = icmp eq i64 %geteu_cv_elem_raw88, 8
  %geteu_cv_edom95 = or i1 %geteu_cv_edom93, %geteu_cv_ew94
  %geteu_cv_elem96 = select i1 %geteu_cv_edom95, i64 %geteu_cv_elem_raw88, i64 8
  br label %geteu_cv_done82

geteu_cv_obj79:                                   ; preds = %geteu_lmerge
  %geteu_cv_tid97 = load i32, ptr %arr_ptr73, align 4
  %geteu_cv_is_tuple98 = icmp eq i32 %geteu_cv_tid97, 521
  %geteu_cv_is_bslice99 = icmp eq i32 %geteu_cv_tid97, 528
  %geteu_cv_is_pack100 = or i1 %geteu_cv_is_tuple98, %geteu_cv_is_bslice99
  br i1 %geteu_cv_is_pack100, label %geteu_cv_pack80, label %geteu_cv_list81

geteu_cv_pack80:                                  ; preds = %geteu_cv_obj79
  %geteu_cv_pk_data_slot101 = getelementptr inbounds i8, ptr %arr_ptr73, i64 24
  %geteu_cv_pk_data102 = load i64, ptr %geteu_cv_pk_data_slot101, align 8
  %geteu_cv_pk_len_slot103 = getelementptr inbounds i8, ptr %arr_ptr73, i64 32
  %geteu_cv_pk_len104 = load i64, ptr %geteu_cv_pk_len_slot103, align 8
  br label %geteu_cv_done82

geteu_cv_list81:                                  ; preds = %geteu_cv_obj79
  %geteu_cv_ls_data_slot105 = getelementptr inbounds i8, ptr %arr_ptr73, i64 40
  %geteu_cv_ls_data106 = load i64, ptr %geteu_cv_ls_data_slot105, align 8
  %geteu_cv_ls_len_slot107 = getelementptr inbounds i8, ptr %arr_ptr73, i64 24
  %geteu_cv_ls_len108 = load i64, ptr %geteu_cv_ls_len_slot107, align 8
  br label %geteu_cv_done82

geteu_cv_done82:                                  ; preds = %geteu_cv_list81, %geteu_cv_pack80, %geteu_cv_cell78
  %geteu_cv_data109 = phi i64 [ %geteu_w083, %geteu_cv_cell78 ], [ %geteu_cv_pk_data102, %geteu_cv_pack80 ], [ %geteu_cv_ls_data106, %geteu_cv_list81 ]
  %geteu_cv_len110 = phi i64 [ %geteu_cv_cell_len86, %geteu_cv_cell78 ], [ %geteu_cv_pk_len104, %geteu_cv_pack80 ], [ %geteu_cv_ls_len108, %geteu_cv_list81 ]
  %geteu_cv_elem111 = phi i64 [ %geteu_cv_elem96, %geteu_cv_cell78 ], [ 1, %geteu_cv_pack80 ], [ 8, %geteu_cv_list81 ]
  %geteu_off112 = mul i64 %r274, %geteu_cv_elem111
  %geteu_addr113 = add i64 %geteu_cv_data109, %geteu_off112
  %geteu_eptr114 = inttoptr i64 %geteu_addr113 to ptr
  switch i64 %geteu_cv_elem111, label %geteu_lw8118 [
    i64 1, label %geteu_lw1115
    i64 2, label %geteu_lw2116
    i64 4, label %geteu_lw4117
  ]

geteu_lw1115:                                     ; preds = %geteu_cv_done82
  %geteu_lv120 = load i8, ptr %geteu_eptr114, align 1
  %geteu_lz121 = zext i8 %geteu_lv120 to i64
  br label %geteu_lmerge119

geteu_lw2116:                                     ; preds = %geteu_cv_done82
  %geteu_lv122 = load i16, ptr %geteu_eptr114, align 2
  %geteu_lz123 = zext i16 %geteu_lv122 to i64
  br label %geteu_lmerge119

geteu_lw4117:                                     ; preds = %geteu_cv_done82
  %geteu_lv124 = load i32, ptr %geteu_eptr114, align 4
  %geteu_lz125 = zext i32 %geteu_lv124 to i64
  br label %geteu_lmerge119

geteu_lw8118:                                     ; preds = %geteu_cv_done82
  %geteu_lv8126 = load i64, ptr %geteu_eptr114, align 8
  br label %geteu_lmerge119

geteu_lmerge119:                                  ; preds = %geteu_lw8118, %geteu_lw4117, %geteu_lw2116, %geteu_lw1115
  %geteu_lval127 = phi i64 [ %geteu_lz121, %geteu_lw1115 ], [ %geteu_lz123, %geteu_lw2116 ], [ %geteu_lz125, %geteu_lw4117 ], [ %geteu_lv8126, %geteu_lw8118 ]
  store i64 %geteu_lval127, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %sext_narrow128 = trunc i64 %r4 to i8
  %sext129 = sext i8 %sext_narrow128 to i64
  store i64 %sext129, ptr %r4_slot, align 8
  %r4130 = load i64, ptr %r4_slot, align 8
  store i64 %r4130, ptr %r2_slot, align 8
  %r1131 = load i64, ptr %r1_slot, align 8
  %r2132 = load i64, ptr %r2_slot, align 8
  %add = add i64 %r1131, %r2132
  store i64 %add, ptr %r4_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  %r3133 = load i64, ptr %r3_slot, align 8
  %arr_ptr134 = inttoptr i64 %r3133 to ptr
  %r2135 = load i64, ptr %r2_slot, align 8
  %backing_slot136 = getelementptr inbounds i8, ptr %arr_ptr134, i64 40
  %backing_int137 = load i64, ptr %backing_slot136, align 8
  %backing_ptr138 = inttoptr i64 %backing_int137 to ptr
  %geteu_w0144 = load i64, ptr %arr_ptr134, align 8
  %geteu_is_cell145 = icmp uge i64 %geteu_w0144, 4294967296
  br i1 %geteu_is_cell145, label %geteu_cv_cell139, label %geteu_cv_obj140

geteu_cv_cell139:                                 ; preds = %geteu_lmerge119
  %geteu_cv_len_slot146 = getelementptr inbounds i8, ptr %arr_ptr134, i64 8
  %geteu_cv_cell_len147 = load i64, ptr %geteu_cv_len_slot146, align 8
  %geteu_cv_elem_slot148 = getelementptr inbounds i8, ptr %arr_ptr134, i64 16
  %geteu_cv_elem_raw149 = load i64, ptr %geteu_cv_elem_slot148, align 8
  %geteu_cv_e1150 = icmp eq i64 %geteu_cv_elem_raw149, 1
  %geteu_cv_ew151 = icmp eq i64 %geteu_cv_elem_raw149, 2
  %geteu_cv_edom152 = or i1 %geteu_cv_e1150, %geteu_cv_ew151
  %geteu_cv_ew153 = icmp eq i64 %geteu_cv_elem_raw149, 4
  %geteu_cv_edom154 = or i1 %geteu_cv_edom152, %geteu_cv_ew153
  %geteu_cv_ew155 = icmp eq i64 %geteu_cv_elem_raw149, 8
  %geteu_cv_edom156 = or i1 %geteu_cv_edom154, %geteu_cv_ew155
  %geteu_cv_elem157 = select i1 %geteu_cv_edom156, i64 %geteu_cv_elem_raw149, i64 8
  br label %geteu_cv_done143

geteu_cv_obj140:                                  ; preds = %geteu_lmerge119
  %geteu_cv_tid158 = load i32, ptr %arr_ptr134, align 4
  %geteu_cv_is_tuple159 = icmp eq i32 %geteu_cv_tid158, 521
  %geteu_cv_is_bslice160 = icmp eq i32 %geteu_cv_tid158, 528
  %geteu_cv_is_pack161 = or i1 %geteu_cv_is_tuple159, %geteu_cv_is_bslice160
  br i1 %geteu_cv_is_pack161, label %geteu_cv_pack141, label %geteu_cv_list142

geteu_cv_pack141:                                 ; preds = %geteu_cv_obj140
  %geteu_cv_pk_data_slot162 = getelementptr inbounds i8, ptr %arr_ptr134, i64 24
  %geteu_cv_pk_data163 = load i64, ptr %geteu_cv_pk_data_slot162, align 8
  %geteu_cv_pk_len_slot164 = getelementptr inbounds i8, ptr %arr_ptr134, i64 32
  %geteu_cv_pk_len165 = load i64, ptr %geteu_cv_pk_len_slot164, align 8
  br label %geteu_cv_done143

geteu_cv_list142:                                 ; preds = %geteu_cv_obj140
  %geteu_cv_ls_data_slot166 = getelementptr inbounds i8, ptr %arr_ptr134, i64 40
  %geteu_cv_ls_data167 = load i64, ptr %geteu_cv_ls_data_slot166, align 8
  %geteu_cv_ls_len_slot168 = getelementptr inbounds i8, ptr %arr_ptr134, i64 24
  %geteu_cv_ls_len169 = load i64, ptr %geteu_cv_ls_len_slot168, align 8
  br label %geteu_cv_done143

geteu_cv_done143:                                 ; preds = %geteu_cv_list142, %geteu_cv_pack141, %geteu_cv_cell139
  %geteu_cv_data170 = phi i64 [ %geteu_w0144, %geteu_cv_cell139 ], [ %geteu_cv_pk_data163, %geteu_cv_pack141 ], [ %geteu_cv_ls_data167, %geteu_cv_list142 ]
  %geteu_cv_len171 = phi i64 [ %geteu_cv_cell_len147, %geteu_cv_cell139 ], [ %geteu_cv_pk_len165, %geteu_cv_pack141 ], [ %geteu_cv_ls_len169, %geteu_cv_list142 ]
  %geteu_cv_elem172 = phi i64 [ %geteu_cv_elem157, %geteu_cv_cell139 ], [ 1, %geteu_cv_pack141 ], [ 8, %geteu_cv_list142 ]
  %geteu_off173 = mul i64 %r2135, %geteu_cv_elem172
  %geteu_addr174 = add i64 %geteu_cv_data170, %geteu_off173
  %geteu_eptr175 = inttoptr i64 %geteu_addr174 to ptr
  switch i64 %geteu_cv_elem172, label %geteu_lw8179 [
    i64 1, label %geteu_lw1176
    i64 2, label %geteu_lw2177
    i64 4, label %geteu_lw4178
  ]

geteu_lw1176:                                     ; preds = %geteu_cv_done143
  %geteu_lv181 = load i8, ptr %geteu_eptr175, align 1
  %geteu_lz182 = zext i8 %geteu_lv181 to i64
  br label %geteu_lmerge180

geteu_lw2177:                                     ; preds = %geteu_cv_done143
  %geteu_lv183 = load i16, ptr %geteu_eptr175, align 2
  %geteu_lz184 = zext i16 %geteu_lv183 to i64
  br label %geteu_lmerge180

geteu_lw4178:                                     ; preds = %geteu_cv_done143
  %geteu_lv185 = load i32, ptr %geteu_eptr175, align 4
  %geteu_lz186 = zext i32 %geteu_lv185 to i64
  br label %geteu_lmerge180

geteu_lw8179:                                     ; preds = %geteu_cv_done143
  %geteu_lv8187 = load i64, ptr %geteu_eptr175, align 8
  br label %geteu_lmerge180

geteu_lmerge180:                                  ; preds = %geteu_lw8179, %geteu_lw4178, %geteu_lw2177, %geteu_lw1176
  %geteu_lval188 = phi i64 [ %geteu_lz182, %geteu_lw1176 ], [ %geteu_lz184, %geteu_lw2177 ], [ %geteu_lz186, %geteu_lw4178 ], [ %geteu_lv8187, %geteu_lw8179 ]
  store i64 %geteu_lval188, ptr %r1_slot, align 8
  %r1189 = load i64, ptr %r1_slot, align 8
  %sext_narrow190 = trunc i64 %r1189 to i8
  %sext191 = sext i8 %sext_narrow190 to i64
  store i64 %sext191, ptr %r1_slot, align 8
  %r1192 = load i64, ptr %r1_slot, align 8
  store i64 %r1192, ptr %r2_slot, align 8
  %r4193 = load i64, ptr %r4_slot, align 8
  %r2194 = load i64, ptr %r2_slot, align 8
  %add195 = add i64 %r4193, %r2194
  store i64 %add195, ptr %r1_slot, align 8
  %r1196 = load i64, ptr %r1_slot, align 8
  store i64 %r1196, ptr %r2_slot, align 8
  %r3197 = load i64, ptr %r3_slot, align 8
  %r2198 = load i64, ptr %r2_slot, align 8
  %r2199 = load i64, ptr %r2_slot, align 8
  ret i64 %r2199
}

define internal i64 @verum_list_storage_stride(ptr %0) {
entry:
  %missing_list = icmp eq ptr %0, null
  br i1 %missing_list, label %invalid, label %read_tag

read_tag:                                         ; preds = %entry
  %list_storage_type = load i32, ptr %0, align 4
  switch i32 %list_storage_type, label %invalid [
    i32 512, label %storage
    i32 527, label %storage1
  ]

invalid:                                          ; preds = %read_tag, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

storage:                                          ; preds = %read_tag
  ret i64 8

storage1:                                         ; preds = %read_tag
  ret i64 1
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal void @verum_list_grow(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %grow

grow:                                             ; preds = %entry
  %cap_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_cap = load i64, ptr %cap_slot, align 8
  %cap_2x = mul i64 %old_cap, 2
  %use_min = icmp slt i64 %cap_2x, 32
  %new_cap = select i1 %use_min, i64 32, i64 %cap_2x
  call void @verum_list_resize_storage(ptr %0, i64 %new_cap)
  br label %ret

ret:                                              ; preds = %grow, %entry
  ret void
}

define internal void @verum_list_resize_storage(ptr %0, i64 %1) {
entry:
  %resized = call i64 @verum_list_try_resize_storage(ptr %0, i64 %1)
  %ok = icmp ne i64 %resized, 0
  br i1 %ok, label %ready, label %failed

ready:                                            ; preds = %entry
  ret void

failed:                                           ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal i64 @verum_list_try_resize_storage(ptr %0, i64 %1) {
entry:
  %validated_owner = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 0)
  %length_slot = getelementptr inbounds i8, ptr %0, i64 24
  %length = load i64, ptr %length_slot, align 8
  %initialized_prefix = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 %length)
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %capacity_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_capacity = load i64, ptr %capacity_slot, align 8
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %old_data = load i64, ptr %data_slot, align 8
  %old_pointer = inttoptr i64 %old_data to ptr
  %capacity_limit = udiv i64 4294967199, %list_storage_stride
  %fits = icmp ule i64 %1, %capacity_limit
  %retains_initialized = icmp uge i64 %1, %length
  %allowed = and i1 %fits, %retains_initialized
  br i1 %allowed, label %valid_capacity, label %failure

valid_capacity:                                   ; preds = %entry
  %unchanged = icmp eq i64 %1, %old_capacity
  br i1 %unchanged, label %success, label %change

change:                                           ; preds = %valid_capacity
  %release_storage = icmp eq i64 %1, 0
  br i1 %release_storage, label %release, label %allocate

release:                                          ; preds = %change
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  store i64 0, ptr %data_slot, align 8
  store i64 0, ptr %capacity_slot, align 8
  br label %success

allocate:                                         ; preds = %change
  %allocation_bytes = mul i64 %1, %list_storage_stride
  %new_backing = call ptr @verum_try_cbgr_allocate_aligned(i64 %allocation_bytes, i64 %list_storage_stride)
  %allocation_failed = icmp eq ptr %new_backing, null
  br i1 %allocation_failed, label %failure, label %allocated

copy:                                             ; preds = %allocated
  %initialized_bytes = mul i64 %length, %list_storage_stride
  %2 = call ptr @verum_internal_memcpy(ptr %new_backing, ptr %initialized_prefix, i64 %initialized_bytes)
  br label %publish

publish:                                          ; preds = %copy, %allocated
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  %new_backing_word = ptrtoint ptr %new_backing to i64
  store i64 %new_backing_word, ptr %data_slot, align 8
  store i64 %1, ptr %capacity_slot, align 8
  br label %success

success:                                          ; preds = %publish, %release, %valid_capacity
  ret i64 1

failure:                                          ; preds = %allocate, %entry
  ret i64 0

allocated:                                        ; preds = %allocate
  %has_initialized_prefix = icmp ne i64 %length, 0
  br i1 %has_initialized_prefix, label %copy, label %publish
}

define internal void @verum_cbgr_deallocate(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %do_dealloc

do_dealloc:                                       ; preds = %entry
  %header_ptr = getelementptr i8, ptr %0, i64 -32
  %gen_ptr = getelementptr i8, ptr %header_ptr, i64 8
  %1 = atomicrmw add ptr %gen_ptr, i32 1 acq_rel, align 4
  %new_gen = add i32 %1, 1
  %ge_max = icmp uge i32 %new_gen, -2
  %lt_old = icmp ult i32 %new_gen, %1
  %overflow = or i1 %ge_max, %lt_old
  br i1 %overflow, label %overflow1, label %set_ref

ret:                                              ; preds = %entry
  ret void

overflow1:                                        ; preds = %do_dealloc
  store i32 1, ptr %gen_ptr, align 4
  %epoch_ptr = getelementptr i8, ptr %header_ptr, i64 12
  %2 = atomicrmw add ptr %epoch_ptr, i16 1 release, align 2
  br label %set_ref

set_ref:                                          ; preds = %overflow1, %do_dealloc
  %rc_ptr = getelementptr i8, ptr %header_ptr, i64 24
  store i32 0, ptr %rc_ptr, align 4
  %hdr_total_ptr = getelementptr i8, ptr %header_ptr, i64 28
  %hdr_total = load i32, ptr %hdr_total_ptr, align 4
  %total = zext i32 %hdr_total to i64
  %hdr_base_off_ptr = getelementptr i8, ptr %header_ptr, i64 6
  %hdr_base_off = load i16, ptr %hdr_base_off_ptr, align 2
  %base_off64 = zext i16 %hdr_base_off to i64
  %header_int = ptrtoint ptr %header_ptr to i64
  %base_int = sub i64 %header_int, %base_off64
  %base = inttoptr i64 %base_int to ptr
  call void @verum_dealloc(ptr %base, i64 %total)
  ret void
}

define internal ptr @verum_internal_memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr %0, ptr %1, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

define internal ptr @verum_try_cbgr_allocate_aligned(i64 %0, i64 %1) {
entry:
  %lt32 = icmp ult i64 %1, 32
  %align = select i1 %lt32, i64 32, i64 %1
  %add31 = add i64 %0, 31
  %aligned = and i64 %add31, -32
  %with_hdr = add i64 %aligned, 32
  %total = add i64 %with_hdr, %align
  %raw = call ptr @verum_os_alloc(i64 %total)
  %is_null = icmp eq ptr %raw, null
  br i1 %is_null, label %null_ret, label %init

init:                                             ; preds = %entry
  %2 = call ptr @memset(ptr %raw, i32 0, i64 %total)
  %raw_int = ptrtoint ptr %raw to i64
  %user0 = add i64 %raw_int, 32
  %align_m1 = sub i64 %align, 1
  %bumped = add i64 %user0, %align_m1
  %align_mask = xor i64 %align_m1, -1
  %user_int = and i64 %bumped, %align_mask
  %header_int = sub i64 %user_int, 32
  %header = inttoptr i64 %header_int to ptr
  %gen_ptr = getelementptr i8, ptr %header, i64 8
  store i32 1, ptr %gen_ptr, align 4
  %size32 = trunc i64 %0 to i32
  %size_ptr = getelementptr i8, ptr %header, i64 0
  store i32 %size32, ptr %size_ptr, align 4
  %epoch64 = load i64, ptr @global_epoch, align 8
  %epoch16 = trunc i64 %epoch64 to i16
  %epoch_ptr = getelementptr i8, ptr %header, i64 12
  store i16 %epoch16, ptr %epoch_ptr, align 2
  %cap_ptr = getelementptr i8, ptr %header, i64 14
  store i16 255, ptr %cap_ptr, align 2
  %rc_ptr = getelementptr i8, ptr %header, i64 24
  store i32 1, ptr %rc_ptr, align 4
  %align16 = trunc i64 %1 to i16
  %align_ptr = getelementptr i8, ptr %header, i64 4
  store i16 %align16, ptr %align_ptr, align 2
  %base_off64 = sub i64 %header_int, %raw_int
  %base_off16 = trunc i64 %base_off64 to i16
  %base_off_ptr = getelementptr i8, ptr %header, i64 6
  store i16 %base_off16, ptr %base_off_ptr, align 2
  %total32 = trunc i64 %total to i32
  %total_ptr = getelementptr i8, ptr %header, i64 28
  store i32 %total32, ptr %total_ptr, align 4
  %user_ptr = inttoptr i64 %user_int to ptr
  ret ptr %user_ptr

null_ret:                                         ; preds = %entry
  ret ptr null
}

@global_epoch = global i64 0
declare ptr @memset(ptr, i32, i64)

define internal ptr @verum_list_storage_address(ptr %0, i64 %1, i64 %2) {
entry:
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %object_size_ptr = getelementptr inbounds i8, ptr %0, i64 12
  %object_size = load i32, ptr %object_size_ptr, align 4
  %valid_object_shape = icmp uge i32 %object_size, 48
  br i1 %valid_object_shape, label %shape, label %invalid

shape:                                            ; preds = %entry
  %capacity_ptr = getelementptr inbounds i8, ptr %0, i64 32
  %capacity = load i64, ptr %capacity_ptr, align 8
  %capacity_limit = udiv i64 4294967295, %list_storage_stride
  %valid_capacity = icmp ule i64 %capacity, %capacity_limit
  %valid_index = icmp ule i64 %1, %capacity
  %remaining_capacity = sub i64 %capacity, %1
  %valid_count = icmp ule i64 %2, %remaining_capacity
  %valid_owner_index = and i1 %valid_capacity, %valid_index
  %valid_range = and i1 %valid_owner_index, %valid_count
  br i1 %valid_range, label %range_ok, label %invalid

range_ok:                                         ; preds = %shape
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %data_word = load i64, ptr %data_slot, align 8
  %data = inttoptr i64 %data_word to ptr
  %missing_storage = icmp eq ptr %data, null
  br i1 %missing_storage, label %missing_backing, label %extent

empty:                                            ; preds = %ready, %missing_backing
  ret ptr null

nonempty_address:                                 ; preds = %ready
  %element_offset = mul i64 %1, %list_storage_stride
  %element_address = getelementptr inbounds i8, ptr %data, i64 %element_offset
  ret ptr %element_address

missing_backing:                                  ; preds = %range_ok
  %empty_owner = icmp eq i64 %capacity, 0
  br i1 %empty_owner, label %empty, label %invalid

extent:                                           ; preds = %range_ok
  %header_ptr = getelementptr i8, ptr %data, i64 -32
  %extent_ptr = getelementptr inbounds i8, ptr %header_ptr, i64 0
  %allocation_extent = load i32, ptr %extent_ptr, align 4
  %allocation_extent64 = zext i32 %allocation_extent to i64
  %capacity_bytes = mul i64 %capacity, %list_storage_stride
  %capacity_fits_allocation = icmp ule i64 %capacity_bytes, %allocation_extent64
  br i1 %capacity_fits_allocation, label %ready, label %invalid

ready:                                            ; preds = %extent
  %empty_range = icmp eq i64 %2, 0
  br i1 %empty_range, label %empty, label %nonempty_address

invalid:                                          ; preds = %extent, %missing_backing, %shape, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal ptr @verum_list_allocate_storage(i64 %0, i32 %1) {
entry:
  %slots = icmp eq i32 %1, 512
  %bytes = icmp eq i32 %1, 527
  %known_encoding = or i1 %slots, %bytes
  br i1 %known_encoding, label %valid_encoding, label %invalid

valid_encoding:                                   ; preds = %entry
  %width = select i1 %bytes, i64 1, i64 8
  %capacity_limit = udiv i64 4294967295, %width
  %capacity_fits = icmp ule i64 %0, %capacity_limit
  br i1 %capacity_fits, label %allocate, label %invalid

allocate:                                         ; preds = %valid_encoding
  %list_owner = call ptr @verum_checked_malloc(i64 48)
  %malloc_null = icmp eq ptr %list_owner, null
  br i1 %malloc_null, label %list_owner_oom, label %list_owner_ok

invalid:                                          ; preds = %valid_encoding, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_oom:                                   ; preds = %allocate
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_ok:                                    ; preds = %allocate
  %2 = call ptr @verum_internal_memset(ptr %list_owner, i32 0, i64 48)
  store i32 %1, ptr %list_owner, align 4
  %list_object_size = getelementptr inbounds i8, ptr %list_owner, i64 12
  store i32 48, ptr %list_object_size, align 4
  call void @verum_list_resize_storage(ptr %list_owner, i64 %0)
  ret ptr %list_owner
}

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

