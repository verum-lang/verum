target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
declare ptr @verum_os_alloc(i64)
declare void @verum_dealloc(ptr, i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %call_result = call i64 @make()
  store i64 %call_result, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %array_storage_in_bounds = icmp ult i64 %r2, 3
  br i1 %array_storage_in_bounds, label %array_storage_valid, label %array_storage_invalid

array_storage_valid:                              ; preds = %block_0
  %r1 = load i64, ptr %r1_slot, align 8
  %ba_base = inttoptr i64 %r1 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %ba_load_ptr = getelementptr i8, ptr %ba_base, i64 %r21
  %ba_byte = load i8, ptr %ba_load_ptr, align 1
  %ba_ext = zext i8 %ba_byte to i64
  store i64 %ba_ext, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %sext_narrow = trunc i64 %r3 to i8
  %sext = sext i8 %sext_narrow to i64
  store i64 %sext, ptr %r3_slot, align 8
  %r32 = load i64, ptr %r3_slot, align 8
  store i64 %r32, ptr %r2_slot, align 8
  store i64 1, ptr %r3_slot, align 8
  %r33 = load i64, ptr %r3_slot, align 8
  %array_storage_in_bounds4 = icmp ult i64 %r33, 3
  br i1 %array_storage_in_bounds4, label %array_storage_valid5, label %array_storage_invalid6

array_storage_invalid:                            ; preds = %block_0
  call void @verum_panic(ptr @array_storage_bounds, i64 25, ptr null, i32 0)
  unreachable

array_storage_valid5:                             ; preds = %array_storage_valid
  %r17 = load i64, ptr %r1_slot, align 8
  %ba_base8 = inttoptr i64 %r17 to ptr
  %r39 = load i64, ptr %r3_slot, align 8
  %ba_load_ptr10 = getelementptr i8, ptr %ba_base8, i64 %r39
  %ba_byte11 = load i8, ptr %ba_load_ptr10, align 1
  %ba_ext12 = zext i8 %ba_byte11 to i64
  store i64 %ba_ext12, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %sext_narrow13 = trunc i64 %r4 to i8
  %sext14 = sext i8 %sext_narrow13 to i64
  store i64 %sext14, ptr %r4_slot, align 8
  %r415 = load i64, ptr %r4_slot, align 8
  store i64 %r415, ptr %r3_slot, align 8
  %r216 = load i64, ptr %r2_slot, align 8
  %r317 = load i64, ptr %r3_slot, align 8
  %add = add i64 %r216, %r317
  store i64 %add, ptr %r4_slot, align 8
  store i64 2, ptr %r3_slot, align 8
  %r318 = load i64, ptr %r3_slot, align 8
  %array_storage_in_bounds19 = icmp ult i64 %r318, 3
  br i1 %array_storage_in_bounds19, label %array_storage_valid20, label %array_storage_invalid21

array_storage_invalid6:                           ; preds = %array_storage_valid
  call void @verum_panic(ptr @array_storage_bounds.1, i64 25, ptr null, i32 0)
  unreachable

array_storage_valid20:                            ; preds = %array_storage_valid5
  %r122 = load i64, ptr %r1_slot, align 8
  %ba_base23 = inttoptr i64 %r122 to ptr
  %r324 = load i64, ptr %r3_slot, align 8
  %ba_load_ptr25 = getelementptr i8, ptr %ba_base23, i64 %r324
  %ba_byte26 = load i8, ptr %ba_load_ptr25, align 1
  %ba_ext27 = zext i8 %ba_byte26 to i64
  store i64 %ba_ext27, ptr %r2_slot, align 8
  %r228 = load i64, ptr %r2_slot, align 8
  %sext_narrow29 = trunc i64 %r228 to i8
  %sext30 = sext i8 %sext_narrow29 to i64
  store i64 %sext30, ptr %r2_slot, align 8
  %r231 = load i64, ptr %r2_slot, align 8
  store i64 %r231, ptr %r3_slot, align 8
  %r432 = load i64, ptr %r4_slot, align 8
  %r333 = load i64, ptr %r3_slot, align 8
  %add34 = add i64 %r432, %r333
  store i64 %add34, ptr %r2_slot, align 8
  %r235 = load i64, ptr %r2_slot, align 8
  store i64 %r235, ptr %r3_slot, align 8
  %r136 = load i64, ptr %r1_slot, align 8
  %r337 = load i64, ptr %r3_slot, align 8
  %r338 = load i64, ptr %r3_slot, align 8
  ret i64 %r338

array_storage_invalid21:                          ; preds = %array_storage_valid5
  call void @verum_panic(ptr @array_storage_bounds.2, i64 25, ptr null, i32 0)
  unreachable
}

@array_storage_bounds.2 = private unnamed_addr constant [26 x i8] c"Array index out of bounds\00", align 1
define internal void @verum_panic(ptr %0, i64 %1, ptr %2, i32 %3) {
entry:
  %4 = call i64 @write(i64 2, ptr @panic_prefix, i64 7)
  %hm = icmp sgt i64 %1, 0
  %wl = select i1 %hm, i64 %1, i64 0
  %5 = call i64 @write(i64 2, ptr %0, i64 %wl)
  %6 = call i64 @write(i64 2, ptr @nl, i64 1)
  %panic_message = call i64 @verum_text_from_stride(ptr %0, i64 %wl, i64 1)
  %new_object = call ptr @verum_checked_malloc(i64 32)
  %malloc_null = icmp eq ptr %new_object, null
  br i1 %malloc_null, label %new_object_oom, label %new_object_ok

new_object_oom:                                   ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

new_object_ok:                                    ; preds = %entry
  %clear_object = call ptr @verum_internal_memset(ptr %new_object, i32 0, i64 32)
  store i32 36864, ptr %new_object, align 4
  %panic_size = getelementptr i8, ptr %new_object, i64 12
  %panic_message_slot = getelementptr i8, ptr %new_object, i64 24
  store i32 32, ptr %panic_size, align 4
  store i64 %panic_message, ptr %panic_message_slot, align 8
  %panic_packet = ptrtoint ptr %new_object to i64
  call void @verum_exception_throw(i64 %panic_packet)
  unreachable
}

define internal void @verum_exception_throw(i64 %0) #3 {
entry:
  %ctx = call ptr @get_or_create_context()
  %cnt_p = getelementptr i8, ptr %ctx, i64 222768
  %cnt = load i64, ptr %cnt_p, align 8
  %hh = icmp sgt i64 %cnt, 0
  br i1 %hh, label %do_throw, label %no_handler

do_throw:                                         ; preds = %entry
  %nc = sub i64 %cnt, 1
  store i64 %nc, ptr %cnt_p, align 8
  %eo = mul i64 %nc, 208
  %bo = add i64 %eo, 9776
  %ddo = add i64 %bo, 200
  %ddp = getelementptr i8, ptr %ctx, i64 %ddo
  %sd = load i64, ptr %ddp, align 8
  call void @verum_defer_run_to(i64 %sd)
  %vo = add i64 %bo, 192
  %vp = getelementptr i8, ptr %ctx, i64 %vo
  store i64 %0, ptr %vp, align 8
  %jb = getelementptr i8, ptr %ctx, i64 %bo
  call void @longjmp(ptr %jb, i32 1)
  unreachable

no_handler:                                       ; preds = %entry
  call void @_exit(i32 134)
  unreachable
}

declare void @_exit(i32)

; Function Attrs: noreturn
declare void @longjmp(ptr, i32) #10

define internal void @verum_defer_run_to(i64 %0) {
entry:
  %ctx = call ptr @get_or_create_context()
  %cnt_p = getelementptr i8, ptr %ctx, i64 239160
  br label %loop_check

loop_check:                                       ; preds = %loop_body, %entry
  %cnt = load i64, ptr %cnt_p, align 8
  %above = icmp ugt i64 %cnt, %0
  br i1 %above, label %loop_body, label %done

loop_body:                                        ; preds = %loop_check
  %nc = sub i64 %cnt, 1
  store i64 %nc, ptr %cnt_p, align 8
  %eo = mul i64 %nc, 16
  %fo = add i64 %eo, 222776
  %fnp = getelementptr i8, ptr %ctx, i64 %fo
  %cfn = load ptr, ptr %fnp, align 8
  %ao = add i64 %fo, 8
  %ap = getelementptr i8, ptr %ctx, i64 %ao
  %arg = load i64, ptr %ap, align 8
  call void %cfn(i64 %arg)
  br label %loop_check

done:                                             ; preds = %loop_check
  ret void
}

define internal ptr @get_or_create_context() {
entry:
  call void @tls_init()
  %key_i64 = load i64, ptr @__verum_tls_key, align 8
  %existing = call i64 @pthread_getspecific(i64 %key_i64)
  %ctx_ptr = inttoptr i64 %existing to ptr
  %is_null = icmp eq ptr %ctx_ptr, null
  br i1 %is_null, label %create_ctx, label %have_ctx

have_ctx:                                         ; preds = %entry
  ret ptr %ctx_ptr

create_ctx:                                       ; preds = %entry
  %new_ctx = call ptr @verum_alloc(i64 239168)
  %tier_p = getelementptr i8, ptr %new_ctx, i64 8
  store i8 3, ptr %tier_p, align 1
  %key2_i64 = load i64, ptr @__verum_tls_key, align 8
  %0 = call i64 @pthread_setspecific(i64 %key2_i64, ptr %new_ctx)
  ret ptr %new_ctx
}

declare i64 @pthread_setspecific(i64, ptr)

@__verum_tls_key = internal global i64 0
define ptr @verum_alloc(i64 %0) {
entry:
  %is_large = icmp ugt i64 %0, 4096
  br i1 %is_large, label %large_path, label %small_path

large_path:                                       ; preds = %entry
  %large_plus_page = add i64 %0, 4095
  %large_page_size = and i64 %large_plus_page, -4096
  %large_block = call ptr @verum_os_alloc(i64 %large_page_size)
  %large_blk_i64 = ptrtoint ptr %large_block to i64
  %lb_ok = icmp ne i64 %large_blk_i64, 0
  br i1 %lb_ok, label %large_ok, label %large_fail

large_ok:                                         ; preds = %large_path
  call void @llvm.memset.p0.i64(ptr align 1 %large_block, i8 0, i64 %large_page_size, i1 false)
  ret ptr %large_block

large_fail:                                       ; preds = %large_path
  ret ptr null

small_path:                                       ; preds = %entry
  %size_minus_one = sub i64 %0, 1
  %ctlz = call i64 @llvm.ctlz.i64(i64 %size_minus_one, i1 false)
  %shift = sub i64 64, %ctlz
  %class_signed = sub i64 %shift, 4
  %is_neg = icmp slt i64 %class_signed, 0
  %class = select i1 %is_neg, i64 0, i64 %class_signed
  %small_alloc_size = shl i64 16, %class
  br label %acquire_lock

acquire_lock:                                     ; preds = %acquire_lock, %small_path
  %1 = cmpxchg ptr @__verum_alloc_lock, i32 0, i32 1 acquire monotonic, align 4
  %cas_ok = extractvalue { i32, i1 } %1, 1
  br i1 %cas_ok, label %lock_acquired, label %acquire_lock

lock_acquired:                                    ; preds = %acquire_lock
  br label %try_freelist

try_freelist:                                     ; preds = %lock_acquired
  %head_slot = getelementptr inbounds [9 x ptr], ptr @__verum_freelist_heads, i64 0, i64 %class
  %head_node = load ptr, ptr %head_slot, align 8
  %head_i64 = ptrtoint ptr %head_node to i64
  %head_null = icmp eq i64 %head_i64, 0
  br i1 %head_null, label %try_bump, label %freelist_hit

freelist_hit:                                     ; preds = %try_freelist
  %next_node = load ptr, ptr %head_node, align 8
  store ptr %next_node, ptr %head_slot, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  call void @llvm.memset.p0.i64(ptr align 1 %head_node, i8 0, i64 %small_alloc_size, i1 false)
  ret ptr %head_node

try_bump:                                         ; preds = %new_arena_ok, %try_freelist
  %cur_ptr = load ptr, ptr @__verum_arena_ptr, align 8
  %cur_end = load ptr, ptr @__verum_arena_end, align 8
  %new_ptr = getelementptr inbounds i8, ptr %cur_ptr, i64 %small_alloc_size
  %cur_i64 = ptrtoint ptr %cur_ptr to i64
  %not_null = icmp ne i64 %cur_i64, 0
  %new_i64 = ptrtoint ptr %new_ptr to i64
  %end_i64 = ptrtoint ptr %cur_end to i64
  %fits = icmp ule i64 %new_i64, %end_i64
  %can_bump = and i1 %not_null, %fits
  br i1 %can_bump, label %bump_ok, label %need_new_arena

bump_ok:                                          ; preds = %try_bump
  store ptr %new_ptr, ptr @__verum_arena_ptr, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  call void @llvm.memset.p0.i64(ptr align 1 %cur_ptr, i8 0, i64 %small_alloc_size, i1 false)
  ret ptr %cur_ptr

need_new_arena:                                   ; preds = %try_bump
  %new_block = call ptr @verum_os_alloc(i64 2097152)
  %blk_i64 = ptrtoint ptr %new_block to i64
  %blk_ok = icmp ne i64 %blk_i64, 0
  br i1 %blk_ok, label %new_arena_ok, label %alloc_fail

new_arena_ok:                                     ; preds = %need_new_arena
  store ptr %new_block, ptr @__verum_arena_base, align 8
  store ptr %new_block, ptr @__verum_arena_ptr, align 8
  %new_end = getelementptr inbounds i8, ptr %new_block, i64 2097152
  store ptr %new_end, ptr @__verum_arena_end, align 8
  br label %try_bump

alloc_fail:                                       ; preds = %need_new_arena
  store i32 0, ptr @__verum_alloc_lock, align 4
  ret ptr null
}

@__verum_alloc_lock = internal global i32 0
@__verum_arena_end = internal global ptr null
@__verum_arena_ptr = internal global ptr null
@__verum_arena_base = internal global ptr null
; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

@__verum_freelist_heads = internal global [9 x ptr] zeroinitializer
; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #8

declare i64 @pthread_getspecific(i64)

define internal void @tls_init() {
entry:
  %inited = load i64, ptr @__verum_tls_initialized, align 8
  %ii = icmp ne i64 %inited, 0
  br i1 %ii, label %done, label %do_init

do_init:                                          ; preds = %entry
  %0 = call i64 @pthread_key_create(ptr @__verum_tls_key, ptr null)
  store i64 1, ptr @__verum_tls_initialized, align 8
  br label %done

done:                                             ; preds = %do_init, %entry
  ret void
}

@__verum_tls_initialized = internal global i64 0
declare i64 @pthread_key_create(ptr, ptr)

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal i64 @verum_text_from_stride(ptr %0, i64 %1, i64 %2) {
entry:
  %buf_size = add i64 %1, 1
  %stride_buf = call ptr @verum_alloc(i64 %buf_size)
  %malloc_null = icmp eq ptr %stride_buf, null
  br i1 %malloc_null, label %stride_buf_oom, label %stride_buf_ok

loop_head:                                        ; preds = %loop_body, %stride_buf_ok
  %i = phi i64 [ 0, %stride_buf_ok ], [ %i_next, %loop_body ]
  %more = icmp slt i64 %i, %1
  br i1 %more, label %loop_body, label %finish

loop_body:                                        ; preds = %loop_head
  %src_off = mul i64 %i, %2
  %src_ptr = getelementptr inbounds i8, ptr %0, i64 %src_off
  %src_byte = load i8, ptr %src_ptr, align 1
  %dst_ptr = getelementptr inbounds i8, ptr %stride_buf, i64 %i
  store i8 %src_byte, ptr %dst_ptr, align 1
  %i_next = add i64 %i, 1
  br label %loop_head

finish:                                           ; preds = %loop_head
  %term_ptr = getelementptr inbounds i8, ptr %stride_buf, i64 %1
  store i8 0, ptr %term_ptr, align 1
  %stride_text = call i64 @verum_text_alloc(ptr %stride_buf, i64 %1, i64 %1)
  ret i64 %stride_text

stride_buf_oom:                                   ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

stride_buf_ok:                                    ; preds = %entry
  br label %loop_head
}

define internal i64 @verum_text_alloc(ptr %0, i64 %1, i64 %2) {
entry:
  %text_obj = call ptr @verum_alloc(i64 24)
  %malloc_null = icmp eq ptr %text_obj, null
  br i1 %malloc_null, label %text_obj_oom, label %text_obj_ok

text_obj_oom:                                     ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

text_obj_ok:                                      ; preds = %entry
  %ptr_i64 = ptrtoint ptr %0 to i64
  store i64 %ptr_i64, ptr %text_obj, align 8
  %len_ptr = getelementptr i64, ptr %text_obj, i64 1
  store i64 %1, ptr %len_ptr, align 8
  %cap_ptr = getelementptr i64, ptr %text_obj, i64 2
  store i64 %2, ptr %cap_ptr, align 8
  %result = ptrtoint ptr %text_obj to i64
  ret i64 %result
}

@nl = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
declare i64 @write(i64, ptr, i64)

@panic_prefix = private unnamed_addr constant [8 x i8] c"PANIC: \00", align 1
@array_storage_bounds.1 = private unnamed_addr constant [26 x i8] c"Array index out of bounds\00", align 1
@array_storage_bounds = private unnamed_addr constant [26 x i8] c"Array index out of bounds\00", align 1
; Function Attrs: nounwind
define internal i64 @make() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r1)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %ba_init8 = trunc i64 %r2 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r1, i1 false)
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r3_slot, align 8
  store i64 128, ptr %r2_slot, align 8
  %r21 = load i64, ptr %r2_slot, align 8
  %neg = sub i64 0, %r21
  store i64 %neg, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_base = inttoptr i64 %r3 to ptr
  %r22 = load i64, ptr %r2_slot, align 8
  %r13 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r22
  %ba_trunc = trunc i64 %r13 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 1, ptr %r1_slot, align 8
  %r14 = load i64, ptr %r1_slot, align 8
  %neg5 = sub i64 0, %r14
  store i64 %neg5, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r36 = load i64, ptr %r3_slot, align 8
  %ba_base7 = inttoptr i64 %r36 to ptr
  %r18 = load i64, ptr %r1_slot, align 8
  %r29 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr10 = getelementptr i8, ptr %ba_base7, i64 %r18
  %ba_trunc11 = trunc i64 %r29 to i8
  store i8 %ba_trunc11, ptr %ba_store_ptr10, align 1
  store i64 1, ptr %r2_slot, align 8
  store i64 2, ptr %r1_slot, align 8
  %r312 = load i64, ptr %r3_slot, align 8
  %ba_base13 = inttoptr i64 %r312 to ptr
  %r114 = load i64, ptr %r1_slot, align 8
  %r215 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr16 = getelementptr i8, ptr %ba_base13, i64 %r114
  %ba_trunc17 = trunc i64 %r215 to i8
  store i8 %ba_trunc17, ptr %ba_store_ptr16, align 1
  %r318 = load i64, ptr %r3_slot, align 8
  store i64 %r318, ptr %r2_slot, align 8
  %r219 = load i64, ptr %r2_slot, align 8
  %r220 = load i64, ptr %r2_slot, align 8
  ret i64 %r220
}

