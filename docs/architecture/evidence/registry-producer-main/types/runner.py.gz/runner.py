from pathlib import Path
import hashlib, json, os, re, signal, subprocess, sys, time

root = Path('/Users/taaliman/.codex/worktrees/registry-record-map-keys/verum')
target = Path('/Users/taaliman/.tmp/verum-codex-01a10248-types/checker-target')
out = Path(sys.argv[1])
out.mkdir()
tests = sys.argv[2:] or ['record_field_visibility']

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.DEVNULL).decode().strip()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

paths = git('ls-files', 'crates/verum_types', 'crates/verum_modules', 'crates/verum_ast', 'crates/verum_fast_parser', 'crates/verum_lexer', 'crates/verum_common', 'grammar/verum.ebnf', 'Cargo.lock', 'Cargo.toml').splitlines()
def inputs():
    return {p: sha(root / p) for p in paths if p.endswith(('.rs', '.toml', '.lock', '.ebnf'))}

assert git('status', '--porcelain') == ''
environment = {'CARGO_TARGET_DIR': str(target), 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
               'VERUM_NO_AUTO_PRECOMPILE': '1', 'RUST_MIN_STACK': '16777216'}
env = os.environ.copy()
env.update(environment)
command = ['cargo', '+nightly-2026-08-20', 'test', '--offline', '--locked', '--no-fail-fast', '--manifest-path', str(root / 'Cargo.toml'), '-p', 'verum_types']
if tests == ['--all']:
    command += ['--tests']
else:
    for test in tests:
        command += ['--test', test]
command += ['--', '--test-threads=1', '--nocapture']
state = {'task': 'T1635, T1714', 'source_commit': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
         'source_paths': inputs(), 'command': command, 'cwd': str(root), 'environment': environment, 'deadline_seconds': 600}
(out / 'started.json').write_text(json.dumps(state, indent=2) + '\n')
start = time.monotonic()
with (out / 'gate.log').open('wb') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=600)
        timed_out = False
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        code = process.wait()
        timed_out = True
state.update(returncode=code, elapsed_seconds=round(time.monotonic()-start, 3), timed_out=timed_out,
             source_unchanged=git('rev-parse', 'HEAD') == state['source_commit'] and git('status', '--porcelain') == '',
             source_paths_unchanged=state['source_paths'] == inputs(), log_sha256=sha(out / 'gate.log'))
log = (out / 'gate.log').read_text(errors='replace')
state['test_results'] = re.findall(r'^test result:.*$', log, re.M)
state['executables'] = []
for location in re.findall(r'Running [^\n]*\(([^\n)]+)\)', log):
    p = Path(location)
    if not p.is_absolute():
        p = root / p
    if p.is_file():
        saved = out / p.name
        subprocess.run(['/bin/cp', '-c', str(p), str(saved)], check=True)
        state['executables'].append({'path': str(p), 'retained': str(saved), 'sha256': sha(saved), 'bytes': saved.stat().st_size})
(out / 'result.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({k: state[k] for k in ['source_commit', 'returncode', 'elapsed_seconds', 'timed_out', 'source_unchanged', 'source_paths_unchanged', 'test_results']}, indent=2))
