"""Replay immutable SHA or whole-registry inputs with an identified fresh CLI."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


parser = argparse.ArgumentParser()
parser.add_argument('--build-dir', type=Path, required=True)
parser.add_argument('--case', choices=['sha', 'whole-project', 'big_endian_inferred', 'big_endian_annotated', 'little_endian_annotated', 'literal_bytes'], required=True)
parser.add_argument('--evidence-dir', type=Path, required=True)
args = parser.parse_args()
plan_path = Path('/private/tmp/verum-registry-fresh-replay-inputs.json')
plan = json.loads(plan_path.read_text())
manifest_path = args.build_dir / 'build-manifest.json'
build = json.loads(manifest_path.read_text())
cli = Path(build['cli']['path'])
assert build['exit_code'] == 0 and build['source_unchanged']
assert build['automatic_precompile'] and build['schema'].startswith('v53-')
assert digest(cli) == build['cli']['sha256']
assert cli.stat().st_size == build['cli']['bytes']
for name, identity in build['artifacts'].items():
    assert digest(Path(build['artifact_snapshot']) / name) == identity['sha256']
args.evidence_dir.mkdir(exist_ok=False)
project = args.evidence_dir / 'project'
project.mkdir()
record = {
    'case': args.case, 'engine_commit': build['engine_commit'],
    'cli': build['cli'], 'schema': build['schema'],
    'artifact_identities': build['artifacts'],
    'source_fingerprint_blake3': build['source_fingerprint_blake3'],
    'build_manifest_sha256': digest(manifest_path),
    'input_plan_sha256': digest(plan_path), 'deadline_seconds': 600,
}
if args.case in ('sha', 'big_endian_inferred', 'big_endian_annotated', 'little_endian_annotated', 'literal_bytes'):
    if args.case == 'sha':
        case = plan['sha']
    else:
        old_path = Path('/private/tmp/verum-T1698-ordinary-summary.json')
        old = json.loads(old_path.read_text())['cases'][args.case]
        fixture = Path(old['result']).parent / (args.case + '.vr')
        case = {
            'source_fixture': str(fixture), 'source_sha256': old['fixture_sha256'],
            'expected_stdout': args.case + ':passed\n',
        }
        record['baseline_result_sha256'] = old['result_sha256']
        record['baseline_summary_sha256'] = digest(old_path)
    source = Path(case['source_fixture'])
    assert digest(source) == case['source_sha256']
    shutil.copy2(source, project / source.name)
    command = [str(cli), 'run', '--tier', 'interpret', str(project / source.name)]
    record['expected_stdout'] = case['expected_stdout']
    record['scope'] = 'Unchanged single-vector SHA-256 or endian/byte fixture through the ordinary interpreter; no general crypto, AOT or service verdict.'
else:
    case = plan['whole_project']
    registry = Path(plan['registry_candidate']['path'])
    revision = plan['registry_candidate']['commit']
    assert git(registry, 'rev-parse', revision + '^{tree}').decode().strip() == plan['registry_candidate']['tree']
    archive = git(registry, 'archive', '--format=tar', revision)
    with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
        for member in bundle.getmembers():
            path = Path(member.name)
            assert not path.is_absolute() and '..' not in path.parts
            assert member.isdir() or member.isfile(), member.name
        bundle.extractall(project)
    for name, expected in case['current_project_inputs'].items():
        assert digest(project / name) == expected, name
    command = [str(cli), 'check']
    record.update(registry_commit=revision, registry_tree=plan['registry_candidate']['tree'],
                  compilation_source_count=len(list((project / 'src').rglob('*.vr'))),
                  scope=case['scope'], discovery_boundary=case['discovery_boundary'])
inputs = {str(p.relative_to(project)): digest(p) for p in sorted(project.rglob('*')) if p.is_file()}
env = {'NO_COLOR': '1', 'VERUM_NO_OBJECT_CACHE': '1', 'TMPDIR': '/private/tmp'}
record.update(command=command, working_directory=str(project), environment_overrides=env, project_inputs=inputs)
(args.evidence_dir / 'started.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (args.evidence_dir / 'stdout.log').open('wb') as stdout, (args.evidence_dir / 'stderr.log').open('wb') as stderr:
    proc = subprocess.Popen(command, cwd=project, env={**os.environ, **env}, stdout=stdout, stderr=stderr, start_new_session=True)
    timed_out = False
    try:
        code = proc.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            code = proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait()
record.update(elapsed_seconds=round(time.monotonic() - start, 3), exit_code=code, timed_out=timed_out,
              cli_unchanged=digest(cli) == build['cli']['sha256'],
              inputs_unchanged=all((project / name).is_file() and digest(project / name) == h for name, h in inputs.items()),
              stdout_sha256=digest(args.evidence_dir / 'stdout.log'), stderr_sha256=digest(args.evidence_dir / 'stderr.log'))
stdout = (args.evidence_dir / 'stdout.log').read_text(errors='replace')
stderr = (args.evidence_dir / 'stderr.log').read_text(errors='replace')
if args.case != 'whole-project':
    record['output_matches'] = stdout == record['expected_stdout']
else:
    output = stdout + stderr
    record['normal_completion_marker'] = 'checking verum-registry in '
    record['output_matches'] = code == 0 and record['normal_completion_marker'] in output and ' files checked,' in output and not any(term in output for term in ['compilation failed', 'Compilation failed', 'error[E'])
record['accepted'] = code == 0 and not timed_out and record['cli_unchanged'] and record['inputs_unchanged'] and record['output_matches']
(args.evidence_dir / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['case', 'engine_commit', 'elapsed_seconds', 'exit_code', 'timed_out', 'accepted', 'cli_unchanged', 'inputs_unchanged']}, indent=2), flush=True)
raise SystemExit(0 if record['accepted'] else 1)
