target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
declare ptr @verum_os_alloc(i64)
declare void @verum_dealloc(ptr, i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r1)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %ba_init8 = trunc i64 %r2 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r1, i1 false)
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r3_slot, align 8
  store i64 128, ptr %r2_slot, align 8
  %r21 = load i64, ptr %r2_slot, align 8
  %neg = sub i64 0, %r21
  store i64 %neg, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_base = inttoptr i64 %r3 to ptr
  %r22 = load i64, ptr %r2_slot, align 8
  %r13 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r22
  %ba_trunc = trunc i64 %r13 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 1, ptr %r1_slot, align 8
  %r14 = load i64, ptr %r1_slot, align 8
  %neg5 = sub i64 0, %r14
  store i64 %neg5, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r36 = load i64, ptr %r3_slot, align 8
  %ba_base7 = inttoptr i64 %r36 to ptr
  %r18 = load i64, ptr %r1_slot, align 8
  %r29 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr10 = getelementptr i8, ptr %ba_base7, i64 %r18
  %ba_trunc11 = trunc i64 %r29 to i8
  store i8 %ba_trunc11, ptr %ba_store_ptr10, align 1
  store i64 1, ptr %r2_slot, align 8
  store i64 2, ptr %r1_slot, align 8
  %r312 = load i64, ptr %r3_slot, align 8
  %ba_base13 = inttoptr i64 %r312 to ptr
  %r114 = load i64, ptr %r1_slot, align 8
  %r215 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr16 = getelementptr i8, ptr %ba_base13, i64 %r114
  %ba_trunc17 = trunc i64 %r215 to i8
  store i8 %ba_trunc17, ptr %ba_store_ptr16, align 1
  store i64 0, ptr %r2_slot, align 8
  %r318 = load i64, ptr %r3_slot, align 8
  %ba_base19 = inttoptr i64 %r318 to ptr
  %r220 = load i64, ptr %r2_slot, align 8
  %ba_load_ptr = getelementptr i8, ptr %ba_base19, i64 %r220
  %ba_byte = load i8, ptr %ba_load_ptr, align 1
  %ba_ext = zext i8 %ba_byte to i64
  store i64 %ba_ext, ptr %r1_slot, align 8
  %r121 = load i64, ptr %r1_slot, align 8
  %sext_narrow = trunc i64 %r121 to i8
  %sext = sext i8 %sext_narrow to i64
  store i64 %sext, ptr %r1_slot, align 8
  %r122 = load i64, ptr %r1_slot, align 8
  store i64 %r122, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r323 = load i64, ptr %r3_slot, align 8
  %ba_base24 = inttoptr i64 %r323 to ptr
  %r125 = load i64, ptr %r1_slot, align 8
  %ba_load_ptr26 = getelementptr i8, ptr %ba_base24, i64 %r125
  %ba_byte27 = load i8, ptr %ba_load_ptr26, align 1
  %ba_ext28 = zext i8 %ba_byte27 to i64
  store i64 %ba_ext28, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %sext_narrow29 = trunc i64 %r4 to i8
  %sext30 = sext i8 %sext_narrow29 to i64
  store i64 %sext30, ptr %r4_slot, align 8
  %r431 = load i64, ptr %r4_slot, align 8
  store i64 %r431, ptr %r1_slot, align 8
  %r232 = load i64, ptr %r2_slot, align 8
  %r133 = load i64, ptr %r1_slot, align 8
  %add = add i64 %r232, %r133
  store i64 %add, ptr %r4_slot, align 8
  store i64 2, ptr %r1_slot, align 8
  %r334 = load i64, ptr %r3_slot, align 8
  %ba_base35 = inttoptr i64 %r334 to ptr
  %r136 = load i64, ptr %r1_slot, align 8
  %ba_load_ptr37 = getelementptr i8, ptr %ba_base35, i64 %r136
  %ba_byte38 = load i8, ptr %ba_load_ptr37, align 1
  %ba_ext39 = zext i8 %ba_byte38 to i64
  store i64 %ba_ext39, ptr %r2_slot, align 8
  %r240 = load i64, ptr %r2_slot, align 8
  %sext_narrow41 = trunc i64 %r240 to i8
  %sext42 = sext i8 %sext_narrow41 to i64
  store i64 %sext42, ptr %r2_slot, align 8
  %r243 = load i64, ptr %r2_slot, align 8
  store i64 %r243, ptr %r1_slot, align 8
  %r444 = load i64, ptr %r4_slot, align 8
  %r145 = load i64, ptr %r1_slot, align 8
  %add46 = add i64 %r444, %r145
  store i64 %add46, ptr %r2_slot, align 8
  %r247 = load i64, ptr %r2_slot, align 8
  store i64 %r247, ptr %r1_slot, align 8
  %r348 = load i64, ptr %r3_slot, align 8
  %r149 = load i64, ptr %r1_slot, align 8
  %r150 = load i64, ptr %r1_slot, align 8
  ret i64 %r150
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

