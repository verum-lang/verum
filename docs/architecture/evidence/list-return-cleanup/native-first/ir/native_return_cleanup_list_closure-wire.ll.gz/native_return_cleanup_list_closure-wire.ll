target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
declare ptr @verum_os_alloc(i64)
declare void @verum_dealloc(ptr, i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %closure = call ptr @verum_checked_malloc(i64 16)
  %malloc_null = icmp eq ptr %closure, null
  br i1 %malloc_null, label %closure_oom, label %closure_ok

closure_oom:                                      ; preds = %block_0
  call void @verum_internal_exit_i64(i64 1)
  unreachable

closure_ok:                                       ; preds = %block_0
  store ptr @"probe$closure$0", ptr %closure, align 8
  %env_slot = getelementptr inbounds i8, ptr %closure, i64 8
  store ptr null, ptr %env_slot, align 8
  %r0_ptr_to_i64 = ptrtoint ptr %closure to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %closure_from_int = inttoptr i64 %r1 to ptr
  %closure_fn = load ptr, ptr %closure_from_int, align 8
  %env_slot1 = getelementptr inbounds i8, ptr %closure_from_int, i64 8
  %closure_env = load ptr, ptr %env_slot1, align 8
  %closure_call = call i64 %closure_fn(ptr %closure_env)
  store i64 %closure_call, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  store i64 %r2, ptr %r3_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %r33 = load i64, ptr %r3_slot, align 8
  ret i64 %r33
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

