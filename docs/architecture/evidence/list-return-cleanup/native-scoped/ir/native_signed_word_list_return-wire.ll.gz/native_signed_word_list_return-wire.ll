target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
declare ptr @verum_os_alloc(i64)
declare void @verum_dealloc(ptr, i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %call_result = call i64 @make()
  store i64 %call_result, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %arr_ptr = inttoptr i64 %r1 to ptr
  %r2 = load i64, ptr %r2_slot, align 8
  %backing_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %backing_int = load i64, ptr %backing_slot, align 8
  %backing_ptr = inttoptr i64 %backing_int to ptr
  %geteu_w0 = load i64, ptr %arr_ptr, align 8
  %geteu_is_cell = icmp uge i64 %geteu_w0, 4294967296
  br i1 %geteu_is_cell, label %geteu_cv_cell, label %geteu_cv_obj

geteu_cv_cell:                                    ; preds = %block_0
  %geteu_cv_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 8
  %geteu_cv_cell_len = load i64, ptr %geteu_cv_len_slot, align 8
  %geteu_cv_elem_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 16
  %geteu_cv_elem_raw = load i64, ptr %geteu_cv_elem_slot, align 8
  %geteu_cv_e1 = icmp eq i64 %geteu_cv_elem_raw, 1
  %geteu_cv_ew = icmp eq i64 %geteu_cv_elem_raw, 2
  %geteu_cv_edom = or i1 %geteu_cv_e1, %geteu_cv_ew
  %geteu_cv_ew1 = icmp eq i64 %geteu_cv_elem_raw, 4
  %geteu_cv_edom2 = or i1 %geteu_cv_edom, %geteu_cv_ew1
  %geteu_cv_ew3 = icmp eq i64 %geteu_cv_elem_raw, 8
  %geteu_cv_edom4 = or i1 %geteu_cv_edom2, %geteu_cv_ew3
  %geteu_cv_elem = select i1 %geteu_cv_edom4, i64 %geteu_cv_elem_raw, i64 8
  br label %geteu_cv_done

geteu_cv_obj:                                     ; preds = %block_0
  %geteu_cv_tid = load i32, ptr %arr_ptr, align 4
  %geteu_cv_is_tuple = icmp eq i32 %geteu_cv_tid, 521
  %geteu_cv_is_bslice = icmp eq i32 %geteu_cv_tid, 528
  %geteu_cv_is_pack = or i1 %geteu_cv_is_tuple, %geteu_cv_is_bslice
  br i1 %geteu_cv_is_pack, label %geteu_cv_pack, label %geteu_cv_list

geteu_cv_pack:                                    ; preds = %geteu_cv_obj
  %geteu_cv_pk_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_pk_data = load i64, ptr %geteu_cv_pk_data_slot, align 8
  %geteu_cv_pk_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 32
  %geteu_cv_pk_len = load i64, ptr %geteu_cv_pk_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_list:                                    ; preds = %geteu_cv_obj
  %geteu_cv_ls_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %geteu_cv_ls_data = load i64, ptr %geteu_cv_ls_data_slot, align 8
  %geteu_cv_ls_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_ls_len = load i64, ptr %geteu_cv_ls_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_done:                                    ; preds = %geteu_cv_list, %geteu_cv_pack, %geteu_cv_cell
  %geteu_cv_data = phi i64 [ %geteu_w0, %geteu_cv_cell ], [ %geteu_cv_pk_data, %geteu_cv_pack ], [ %geteu_cv_ls_data, %geteu_cv_list ]
  %geteu_cv_len = phi i64 [ %geteu_cv_cell_len, %geteu_cv_cell ], [ %geteu_cv_pk_len, %geteu_cv_pack ], [ %geteu_cv_ls_len, %geteu_cv_list ]
  %geteu_cv_elem5 = phi i64 [ %geteu_cv_elem, %geteu_cv_cell ], [ 1, %geteu_cv_pack ], [ 8, %geteu_cv_list ]
  %geteu_off = mul i64 %r2, %geteu_cv_elem5
  %geteu_addr = add i64 %geteu_cv_data, %geteu_off
  %geteu_eptr = inttoptr i64 %geteu_addr to ptr
  switch i64 %geteu_cv_elem5, label %geteu_lw8 [
    i64 1, label %geteu_lw1
    i64 2, label %geteu_lw2
    i64 4, label %geteu_lw4
  ]

geteu_lw1:                                        ; preds = %geteu_cv_done
  %geteu_lv = load i8, ptr %geteu_eptr, align 1
  %geteu_lz = zext i8 %geteu_lv to i64
  br label %geteu_lmerge

geteu_lw2:                                        ; preds = %geteu_cv_done
  %geteu_lv6 = load i16, ptr %geteu_eptr, align 2
  %geteu_lz7 = zext i16 %geteu_lv6 to i64
  br label %geteu_lmerge

geteu_lw4:                                        ; preds = %geteu_cv_done
  %geteu_lv8 = load i32, ptr %geteu_eptr, align 4
  %geteu_lz9 = zext i32 %geteu_lv8 to i64
  br label %geteu_lmerge

geteu_lw8:                                        ; preds = %geteu_cv_done
  %geteu_lv810 = load i64, ptr %geteu_eptr, align 8
  br label %geteu_lmerge

geteu_lmerge:                                     ; preds = %geteu_lw8, %geteu_lw4, %geteu_lw2, %geteu_lw1
  %geteu_lval = phi i64 [ %geteu_lz, %geteu_lw1 ], [ %geteu_lz7, %geteu_lw2 ], [ %geteu_lz9, %geteu_lw4 ], [ %geteu_lv810, %geteu_lw8 ]
  store i64 %geteu_lval, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %sext_narrow = trunc i64 %r3 to i32
  %sext = sext i32 %sext_narrow to i64
  store i64 %sext, ptr %r3_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r111 = load i64, ptr %r1_slot, align 8
  %arr_ptr12 = inttoptr i64 %r111 to ptr
  %r213 = load i64, ptr %r2_slot, align 8
  %backing_slot14 = getelementptr inbounds i8, ptr %arr_ptr12, i64 40
  %backing_int15 = load i64, ptr %backing_slot14, align 8
  %backing_ptr16 = inttoptr i64 %backing_int15 to ptr
  %geteu_w022 = load i64, ptr %arr_ptr12, align 8
  %geteu_is_cell23 = icmp uge i64 %geteu_w022, 4294967296
  br i1 %geteu_is_cell23, label %geteu_cv_cell17, label %geteu_cv_obj18

geteu_cv_cell17:                                  ; preds = %geteu_lmerge
  %geteu_cv_len_slot24 = getelementptr inbounds i8, ptr %arr_ptr12, i64 8
  %geteu_cv_cell_len25 = load i64, ptr %geteu_cv_len_slot24, align 8
  %geteu_cv_elem_slot26 = getelementptr inbounds i8, ptr %arr_ptr12, i64 16
  %geteu_cv_elem_raw27 = load i64, ptr %geteu_cv_elem_slot26, align 8
  %geteu_cv_e128 = icmp eq i64 %geteu_cv_elem_raw27, 1
  %geteu_cv_ew29 = icmp eq i64 %geteu_cv_elem_raw27, 2
  %geteu_cv_edom30 = or i1 %geteu_cv_e128, %geteu_cv_ew29
  %geteu_cv_ew31 = icmp eq i64 %geteu_cv_elem_raw27, 4
  %geteu_cv_edom32 = or i1 %geteu_cv_edom30, %geteu_cv_ew31
  %geteu_cv_ew33 = icmp eq i64 %geteu_cv_elem_raw27, 8
  %geteu_cv_edom34 = or i1 %geteu_cv_edom32, %geteu_cv_ew33
  %geteu_cv_elem35 = select i1 %geteu_cv_edom34, i64 %geteu_cv_elem_raw27, i64 8
  br label %geteu_cv_done21

geteu_cv_obj18:                                   ; preds = %geteu_lmerge
  %geteu_cv_tid36 = load i32, ptr %arr_ptr12, align 4
  %geteu_cv_is_tuple37 = icmp eq i32 %geteu_cv_tid36, 521
  %geteu_cv_is_bslice38 = icmp eq i32 %geteu_cv_tid36, 528
  %geteu_cv_is_pack39 = or i1 %geteu_cv_is_tuple37, %geteu_cv_is_bslice38
  br i1 %geteu_cv_is_pack39, label %geteu_cv_pack19, label %geteu_cv_list20

geteu_cv_pack19:                                  ; preds = %geteu_cv_obj18
  %geteu_cv_pk_data_slot40 = getelementptr inbounds i8, ptr %arr_ptr12, i64 24
  %geteu_cv_pk_data41 = load i64, ptr %geteu_cv_pk_data_slot40, align 8
  %geteu_cv_pk_len_slot42 = getelementptr inbounds i8, ptr %arr_ptr12, i64 32
  %geteu_cv_pk_len43 = load i64, ptr %geteu_cv_pk_len_slot42, align 8
  br label %geteu_cv_done21

geteu_cv_list20:                                  ; preds = %geteu_cv_obj18
  %geteu_cv_ls_data_slot44 = getelementptr inbounds i8, ptr %arr_ptr12, i64 40
  %geteu_cv_ls_data45 = load i64, ptr %geteu_cv_ls_data_slot44, align 8
  %geteu_cv_ls_len_slot46 = getelementptr inbounds i8, ptr %arr_ptr12, i64 24
  %geteu_cv_ls_len47 = load i64, ptr %geteu_cv_ls_len_slot46, align 8
  br label %geteu_cv_done21

geteu_cv_done21:                                  ; preds = %geteu_cv_list20, %geteu_cv_pack19, %geteu_cv_cell17
  %geteu_cv_data48 = phi i64 [ %geteu_w022, %geteu_cv_cell17 ], [ %geteu_cv_pk_data41, %geteu_cv_pack19 ], [ %geteu_cv_ls_data45, %geteu_cv_list20 ]
  %geteu_cv_len49 = phi i64 [ %geteu_cv_cell_len25, %geteu_cv_cell17 ], [ %geteu_cv_pk_len43, %geteu_cv_pack19 ], [ %geteu_cv_ls_len47, %geteu_cv_list20 ]
  %geteu_cv_elem50 = phi i64 [ %geteu_cv_elem35, %geteu_cv_cell17 ], [ 1, %geteu_cv_pack19 ], [ 8, %geteu_cv_list20 ]
  %geteu_off51 = mul i64 %r213, %geteu_cv_elem50
  %geteu_addr52 = add i64 %geteu_cv_data48, %geteu_off51
  %geteu_eptr53 = inttoptr i64 %geteu_addr52 to ptr
  switch i64 %geteu_cv_elem50, label %geteu_lw857 [
    i64 1, label %geteu_lw154
    i64 2, label %geteu_lw255
    i64 4, label %geteu_lw456
  ]

geteu_lw154:                                      ; preds = %geteu_cv_done21
  %geteu_lv59 = load i8, ptr %geteu_eptr53, align 1
  %geteu_lz60 = zext i8 %geteu_lv59 to i64
  br label %geteu_lmerge58

geteu_lw255:                                      ; preds = %geteu_cv_done21
  %geteu_lv61 = load i16, ptr %geteu_eptr53, align 2
  %geteu_lz62 = zext i16 %geteu_lv61 to i64
  br label %geteu_lmerge58

geteu_lw456:                                      ; preds = %geteu_cv_done21
  %geteu_lv63 = load i32, ptr %geteu_eptr53, align 4
  %geteu_lz64 = zext i32 %geteu_lv63 to i64
  br label %geteu_lmerge58

geteu_lw857:                                      ; preds = %geteu_cv_done21
  %geteu_lv865 = load i64, ptr %geteu_eptr53, align 8
  br label %geteu_lmerge58

geteu_lmerge58:                                   ; preds = %geteu_lw857, %geteu_lw456, %geteu_lw255, %geteu_lw154
  %geteu_lval66 = phi i64 [ %geteu_lz60, %geteu_lw154 ], [ %geteu_lz62, %geteu_lw255 ], [ %geteu_lz64, %geteu_lw456 ], [ %geteu_lv865, %geteu_lw857 ]
  store i64 %geteu_lval66, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %sext_narrow67 = trunc i64 %r4 to i32
  %sext68 = sext i32 %sext_narrow67 to i64
  store i64 %sext68, ptr %r4_slot, align 8
  %r369 = load i64, ptr %r3_slot, align 8
  %r470 = load i64, ptr %r4_slot, align 8
  %add = add i64 %r369, %r470
  store i64 %add, ptr %r2_slot, align 8
  store i64 2, ptr %r4_slot, align 8
  %r171 = load i64, ptr %r1_slot, align 8
  %arr_ptr72 = inttoptr i64 %r171 to ptr
  %r473 = load i64, ptr %r4_slot, align 8
  %backing_slot74 = getelementptr inbounds i8, ptr %arr_ptr72, i64 40
  %backing_int75 = load i64, ptr %backing_slot74, align 8
  %backing_ptr76 = inttoptr i64 %backing_int75 to ptr
  %geteu_w082 = load i64, ptr %arr_ptr72, align 8
  %geteu_is_cell83 = icmp uge i64 %geteu_w082, 4294967296
  br i1 %geteu_is_cell83, label %geteu_cv_cell77, label %geteu_cv_obj78

geteu_cv_cell77:                                  ; preds = %geteu_lmerge58
  %geteu_cv_len_slot84 = getelementptr inbounds i8, ptr %arr_ptr72, i64 8
  %geteu_cv_cell_len85 = load i64, ptr %geteu_cv_len_slot84, align 8
  %geteu_cv_elem_slot86 = getelementptr inbounds i8, ptr %arr_ptr72, i64 16
  %geteu_cv_elem_raw87 = load i64, ptr %geteu_cv_elem_slot86, align 8
  %geteu_cv_e188 = icmp eq i64 %geteu_cv_elem_raw87, 1
  %geteu_cv_ew89 = icmp eq i64 %geteu_cv_elem_raw87, 2
  %geteu_cv_edom90 = or i1 %geteu_cv_e188, %geteu_cv_ew89
  %geteu_cv_ew91 = icmp eq i64 %geteu_cv_elem_raw87, 4
  %geteu_cv_edom92 = or i1 %geteu_cv_edom90, %geteu_cv_ew91
  %geteu_cv_ew93 = icmp eq i64 %geteu_cv_elem_raw87, 8
  %geteu_cv_edom94 = or i1 %geteu_cv_edom92, %geteu_cv_ew93
  %geteu_cv_elem95 = select i1 %geteu_cv_edom94, i64 %geteu_cv_elem_raw87, i64 8
  br label %geteu_cv_done81

geteu_cv_obj78:                                   ; preds = %geteu_lmerge58
  %geteu_cv_tid96 = load i32, ptr %arr_ptr72, align 4
  %geteu_cv_is_tuple97 = icmp eq i32 %geteu_cv_tid96, 521
  %geteu_cv_is_bslice98 = icmp eq i32 %geteu_cv_tid96, 528
  %geteu_cv_is_pack99 = or i1 %geteu_cv_is_tuple97, %geteu_cv_is_bslice98
  br i1 %geteu_cv_is_pack99, label %geteu_cv_pack79, label %geteu_cv_list80

geteu_cv_pack79:                                  ; preds = %geteu_cv_obj78
  %geteu_cv_pk_data_slot100 = getelementptr inbounds i8, ptr %arr_ptr72, i64 24
  %geteu_cv_pk_data101 = load i64, ptr %geteu_cv_pk_data_slot100, align 8
  %geteu_cv_pk_len_slot102 = getelementptr inbounds i8, ptr %arr_ptr72, i64 32
  %geteu_cv_pk_len103 = load i64, ptr %geteu_cv_pk_len_slot102, align 8
  br label %geteu_cv_done81

geteu_cv_list80:                                  ; preds = %geteu_cv_obj78
  %geteu_cv_ls_data_slot104 = getelementptr inbounds i8, ptr %arr_ptr72, i64 40
  %geteu_cv_ls_data105 = load i64, ptr %geteu_cv_ls_data_slot104, align 8
  %geteu_cv_ls_len_slot106 = getelementptr inbounds i8, ptr %arr_ptr72, i64 24
  %geteu_cv_ls_len107 = load i64, ptr %geteu_cv_ls_len_slot106, align 8
  br label %geteu_cv_done81

geteu_cv_done81:                                  ; preds = %geteu_cv_list80, %geteu_cv_pack79, %geteu_cv_cell77
  %geteu_cv_data108 = phi i64 [ %geteu_w082, %geteu_cv_cell77 ], [ %geteu_cv_pk_data101, %geteu_cv_pack79 ], [ %geteu_cv_ls_data105, %geteu_cv_list80 ]
  %geteu_cv_len109 = phi i64 [ %geteu_cv_cell_len85, %geteu_cv_cell77 ], [ %geteu_cv_pk_len103, %geteu_cv_pack79 ], [ %geteu_cv_ls_len107, %geteu_cv_list80 ]
  %geteu_cv_elem110 = phi i64 [ %geteu_cv_elem95, %geteu_cv_cell77 ], [ 1, %geteu_cv_pack79 ], [ 8, %geteu_cv_list80 ]
  %geteu_off111 = mul i64 %r473, %geteu_cv_elem110
  %geteu_addr112 = add i64 %geteu_cv_data108, %geteu_off111
  %geteu_eptr113 = inttoptr i64 %geteu_addr112 to ptr
  switch i64 %geteu_cv_elem110, label %geteu_lw8117 [
    i64 1, label %geteu_lw1114
    i64 2, label %geteu_lw2115
    i64 4, label %geteu_lw4116
  ]

geteu_lw1114:                                     ; preds = %geteu_cv_done81
  %geteu_lv119 = load i8, ptr %geteu_eptr113, align 1
  %geteu_lz120 = zext i8 %geteu_lv119 to i64
  br label %geteu_lmerge118

geteu_lw2115:                                     ; preds = %geteu_cv_done81
  %geteu_lv121 = load i16, ptr %geteu_eptr113, align 2
  %geteu_lz122 = zext i16 %geteu_lv121 to i64
  br label %geteu_lmerge118

geteu_lw4116:                                     ; preds = %geteu_cv_done81
  %geteu_lv123 = load i32, ptr %geteu_eptr113, align 4
  %geteu_lz124 = zext i32 %geteu_lv123 to i64
  br label %geteu_lmerge118

geteu_lw8117:                                     ; preds = %geteu_cv_done81
  %geteu_lv8125 = load i64, ptr %geteu_eptr113, align 8
  br label %geteu_lmerge118

geteu_lmerge118:                                  ; preds = %geteu_lw8117, %geteu_lw4116, %geteu_lw2115, %geteu_lw1114
  %geteu_lval126 = phi i64 [ %geteu_lz120, %geteu_lw1114 ], [ %geteu_lz122, %geteu_lw2115 ], [ %geteu_lz124, %geteu_lw4116 ], [ %geteu_lv8125, %geteu_lw8117 ]
  store i64 %geteu_lval126, ptr %r3_slot, align 8
  %r3127 = load i64, ptr %r3_slot, align 8
  %sext_narrow128 = trunc i64 %r3127 to i32
  %sext129 = sext i32 %sext_narrow128 to i64
  store i64 %sext129, ptr %r3_slot, align 8
  %r2130 = load i64, ptr %r2_slot, align 8
  %r3131 = load i64, ptr %r3_slot, align 8
  %add132 = add i64 %r2130, %r3131
  store i64 %add132, ptr %r4_slot, align 8
  %r4133 = load i64, ptr %r4_slot, align 8
  store i64 %r4133, ptr %r3_slot, align 8
  %r1134 = load i64, ptr %r1_slot, align 8
  %r3135 = load i64, ptr %r3_slot, align 8
  %r3136 = load i64, ptr %r3_slot, align 8
  ret i64 %r3136
}

; Function Attrs: nounwind
define internal i64 @make() #6 {
block_0:
  %r5_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %ta_bytes = mul i64 %r1, 4
  %new_typed_array = call ptr @verum_cbgr_allocate(i64 %ta_bytes)
  %r0_ptr_to_i64 = ptrtoint ptr %new_typed_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  br label %ta_fill_check

block_1:                                          ; preds = %list_push_smerge, %tas_smerge29
  %r4 = load i64, ptr %r4_slot, align 8
  %r234 = load i64, ptr %r2_slot, align 8
  %icmp = icmp slt i64 %r4, %r234
  %r5_widen = zext i1 %icmp to i64
  store i64 %r5_widen, ptr %r5_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %jmpnot_cond = trunc i64 %r5 to i1
  br i1 %jmpnot_cond, label %block_2, label %block_3

block_2:                                          ; preds = %block_1
  %r3 = load i64, ptr %r3_slot, align 8
  %tal_base = inttoptr i64 %r3 to ptr
  %r435 = load i64, ptr %r4_slot, align 8
  %tal_off = mul i64 %r435, 4
  %tal_ptr = getelementptr i8, ptr %tal_base, i64 %tal_off
  %tal_raw = load i32, ptr %tal_ptr, align 4
  %tal_zext = zext i32 %tal_raw to i64
  store i64 %tal_zext, ptr %r5_slot, align 8
  %r536 = load i64, ptr %r5_slot, align 8
  %sext_narrow = trunc i64 %r536 to i32
  %sext = sext i32 %sext_narrow to i64
  store i64 %sext, ptr %r5_slot, align 8
  %r137 = load i64, ptr %r1_slot, align 8
  %list_ptr = inttoptr i64 %r137 to ptr
  %r538 = load i64, ptr %r5_slot, align 8
  %len_slot = getelementptr inbounds i8, ptr %list_ptr, i64 24
  %len = load i64, ptr %len_slot, align 8
  %cap_slot = getelementptr inbounds i8, ptr %list_ptr, i64 32
  %cap = load i64, ptr %cap_slot, align 8
  %data_ptr_slot = getelementptr inbounds i8, ptr %list_ptr, i64 40
  %data_int = load i64, ptr %data_ptr_slot, align 8
  %data_ptr = inttoptr i64 %data_int to ptr
  %needs_grow = icmp uge i64 %len, %cap
  br i1 %needs_grow, label %list_grow, label %list_push_continue

block_3:                                          ; preds = %block_1
  %r142 = load i64, ptr %r1_slot, align 8
  store i64 %r142, ptr %r2_slot, align 8
  %r343 = load i64, ptr %r3_slot, align 8
  %r244 = load i64, ptr %r2_slot, align 8
  %r245 = load i64, ptr %r2_slot, align 8
  ret i64 %r245

ta_fill_check:                                    ; preds = %ta_fill_body, %block_0
  %ta_i = phi i64 [ 0, %block_0 ], [ %ta_next, %ta_fill_body ]
  %ta_more = icmp slt i64 %ta_i, %r1
  br i1 %ta_more, label %ta_fill_body, label %ta_fill_done

ta_fill_body:                                     ; preds = %ta_fill_check
  %ta_slot = getelementptr inbounds i32, ptr %new_typed_array, i64 %ta_i
  %ta_v = trunc i64 %r2 to i32
  store i32 %ta_v, ptr %ta_slot, align 4
  %ta_next = add i64 %ta_i, 1
  br label %ta_fill_check

ta_fill_done:                                     ; preds = %ta_fill_check
  store i64 0, ptr %r2_slot, align 8
  store i64 -2147483648, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %tas_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %tas_off = mul i64 %r21, 4
  %tas_ptr = getelementptr i8, ptr %tas_base, i64 %tas_off
  switch i64 4, label %tas_sw8 [
    i64 1, label %tas_sw1
    i64 2, label %tas_sw2
    i64 4, label %tas_sw4
  ]

tas_sw1:                                          ; preds = %ta_fill_done
  %tas_st = trunc i64 %r12 to i8
  store i8 %tas_st, ptr %tas_ptr, align 1
  br label %tas_smerge

tas_sw2:                                          ; preds = %ta_fill_done
  %tas_st3 = trunc i64 %r12 to i16
  store i16 %tas_st3, ptr %tas_ptr, align 2
  br label %tas_smerge

tas_sw4:                                          ; preds = %ta_fill_done
  %tas_st4 = trunc i64 %r12 to i32
  store i32 %tas_st4, ptr %tas_ptr, align 4
  br label %tas_smerge

tas_sw8:                                          ; preds = %ta_fill_done
  store i64 %r12, ptr %tas_ptr, align 8
  br label %tas_smerge

tas_smerge:                                       ; preds = %tas_sw8, %tas_sw4, %tas_sw2, %tas_sw1
  store i64 1, ptr %r1_slot, align 8
  store i64 -1, ptr %r2_slot, align 8
  %r05 = load i64, ptr %r0_slot, align 8
  %tas_base6 = inttoptr i64 %r05 to ptr
  %r17 = load i64, ptr %r1_slot, align 8
  %r28 = load i64, ptr %r2_slot, align 8
  %tas_off9 = mul i64 %r17, 4
  %tas_ptr10 = getelementptr i8, ptr %tas_base6, i64 %tas_off9
  switch i64 4, label %tas_sw814 [
    i64 1, label %tas_sw111
    i64 2, label %tas_sw212
    i64 4, label %tas_sw413
  ]

tas_sw111:                                        ; preds = %tas_smerge
  %tas_st16 = trunc i64 %r28 to i8
  store i8 %tas_st16, ptr %tas_ptr10, align 1
  br label %tas_smerge15

tas_sw212:                                        ; preds = %tas_smerge
  %tas_st17 = trunc i64 %r28 to i16
  store i16 %tas_st17, ptr %tas_ptr10, align 2
  br label %tas_smerge15

tas_sw413:                                        ; preds = %tas_smerge
  %tas_st18 = trunc i64 %r28 to i32
  store i32 %tas_st18, ptr %tas_ptr10, align 4
  br label %tas_smerge15

tas_sw814:                                        ; preds = %tas_smerge
  store i64 %r28, ptr %tas_ptr10, align 8
  br label %tas_smerge15

tas_smerge15:                                     ; preds = %tas_sw814, %tas_sw413, %tas_sw212, %tas_sw111
  store i64 2, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r019 = load i64, ptr %r0_slot, align 8
  %tas_base20 = inttoptr i64 %r019 to ptr
  %r221 = load i64, ptr %r2_slot, align 8
  %r122 = load i64, ptr %r1_slot, align 8
  %tas_off23 = mul i64 %r221, 4
  %tas_ptr24 = getelementptr i8, ptr %tas_base20, i64 %tas_off23
  switch i64 4, label %tas_sw828 [
    i64 1, label %tas_sw125
    i64 2, label %tas_sw226
    i64 4, label %tas_sw427
  ]

tas_sw125:                                        ; preds = %tas_smerge15
  %tas_st30 = trunc i64 %r122 to i8
  store i8 %tas_st30, ptr %tas_ptr24, align 1
  br label %tas_smerge29

tas_sw226:                                        ; preds = %tas_smerge15
  %tas_st31 = trunc i64 %r122 to i16
  store i16 %tas_st31, ptr %tas_ptr24, align 2
  br label %tas_smerge29

tas_sw427:                                        ; preds = %tas_smerge15
  %tas_st32 = trunc i64 %r122 to i32
  store i32 %tas_st32, ptr %tas_ptr24, align 4
  br label %tas_smerge29

tas_sw828:                                        ; preds = %tas_smerge15
  store i64 %r122, ptr %tas_ptr24, align 8
  br label %tas_smerge29

tas_smerge29:                                     ; preds = %tas_sw828, %tas_sw427, %tas_sw226, %tas_sw125
  %r033 = load i64, ptr %r0_slot, align 8
  store i64 %r033, ptr %r3_slot, align 8
  %list_obj = call ptr @verum_list_allocate_storage(i64 3, i32 512)
  %r1_ptr_to_i64 = ptrtoint ptr %list_obj to i64
  store i64 %r1_ptr_to_i64, ptr %r1_slot, align 8
  store i64 3, ptr %r2_slot, align 8
  store i64 0, ptr %r4_slot, align 8
  br label %block_1

list_grow:                                        ; preds = %block_2
  call void @verum_list_grow(ptr %list_ptr)
  br label %list_push_continue

list_push_continue:                               ; preds = %list_grow, %block_2
  %data_int_post = load i64, ptr %data_ptr_slot, align 8
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %list_ptr)
  %list_push_off = mul i64 %len, %list_storage_stride
  %list_push_addr = add i64 %data_int_post, %list_push_off
  %list_push_eptr = inttoptr i64 %list_push_addr to ptr
  switch i64 %list_storage_stride, label %list_push_sw8 [
    i64 1, label %list_push_sw1
    i64 2, label %list_push_sw2
    i64 4, label %list_push_sw4
  ]

list_push_sw1:                                    ; preds = %list_push_continue
  %list_push_st = trunc i64 %r538 to i8
  store i8 %list_push_st, ptr %list_push_eptr, align 1
  br label %list_push_smerge

list_push_sw2:                                    ; preds = %list_push_continue
  %list_push_st39 = trunc i64 %r538 to i16
  store i16 %list_push_st39, ptr %list_push_eptr, align 2
  br label %list_push_smerge

list_push_sw4:                                    ; preds = %list_push_continue
  %list_push_st40 = trunc i64 %r538 to i32
  store i32 %list_push_st40, ptr %list_push_eptr, align 4
  br label %list_push_smerge

list_push_sw8:                                    ; preds = %list_push_continue
  store i64 %r538, ptr %list_push_eptr, align 8
  br label %list_push_smerge

list_push_smerge:                                 ; preds = %list_push_sw8, %list_push_sw4, %list_push_sw2, %list_push_sw1
  %new_len = add i64 %len, 1
  store i64 %new_len, ptr %len_slot, align 8
  %r441 = load i64, ptr %r4_slot, align 8
  %inc = add i64 %r441, 1
  store i64 %inc, ptr %r4_slot, align 8
  br label %block_1
}

define internal i64 @verum_list_storage_stride(ptr %0) {
entry:
  %missing_list = icmp eq ptr %0, null
  br i1 %missing_list, label %invalid, label %read_tag

read_tag:                                         ; preds = %entry
  %list_storage_type = load i32, ptr %0, align 4
  switch i32 %list_storage_type, label %invalid [
    i32 512, label %storage
    i32 527, label %storage1
  ]

invalid:                                          ; preds = %read_tag, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

storage:                                          ; preds = %read_tag
  ret i64 8

storage1:                                         ; preds = %read_tag
  ret i64 1
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal void @verum_list_grow(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %grow

grow:                                             ; preds = %entry
  %cap_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_cap = load i64, ptr %cap_slot, align 8
  %cap_2x = mul i64 %old_cap, 2
  %use_min = icmp slt i64 %cap_2x, 32
  %new_cap = select i1 %use_min, i64 32, i64 %cap_2x
  call void @verum_list_resize_storage(ptr %0, i64 %new_cap)
  br label %ret

ret:                                              ; preds = %grow, %entry
  ret void
}

define internal void @verum_list_resize_storage(ptr %0, i64 %1) {
entry:
  %resized = call i64 @verum_list_try_resize_storage(ptr %0, i64 %1)
  %ok = icmp ne i64 %resized, 0
  br i1 %ok, label %ready, label %failed

ready:                                            ; preds = %entry
  ret void

failed:                                           ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal i64 @verum_list_try_resize_storage(ptr %0, i64 %1) {
entry:
  %validated_owner = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 0)
  %length_slot = getelementptr inbounds i8, ptr %0, i64 24
  %length = load i64, ptr %length_slot, align 8
  %initialized_prefix = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 %length)
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %capacity_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_capacity = load i64, ptr %capacity_slot, align 8
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %old_data = load i64, ptr %data_slot, align 8
  %old_pointer = inttoptr i64 %old_data to ptr
  %capacity_limit = udiv i64 4294967199, %list_storage_stride
  %fits = icmp ule i64 %1, %capacity_limit
  %retains_initialized = icmp uge i64 %1, %length
  %allowed = and i1 %fits, %retains_initialized
  br i1 %allowed, label %valid_capacity, label %failure

valid_capacity:                                   ; preds = %entry
  %unchanged = icmp eq i64 %1, %old_capacity
  br i1 %unchanged, label %success, label %change

change:                                           ; preds = %valid_capacity
  %release_storage = icmp eq i64 %1, 0
  br i1 %release_storage, label %release, label %allocate

release:                                          ; preds = %change
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  store i64 0, ptr %data_slot, align 8
  store i64 0, ptr %capacity_slot, align 8
  br label %success

allocate:                                         ; preds = %change
  %allocation_bytes = mul i64 %1, %list_storage_stride
  %new_backing = call ptr @verum_try_cbgr_allocate_aligned(i64 %allocation_bytes, i64 %list_storage_stride)
  %allocation_failed = icmp eq ptr %new_backing, null
  br i1 %allocation_failed, label %failure, label %allocated

copy:                                             ; preds = %allocated
  %initialized_bytes = mul i64 %length, %list_storage_stride
  %2 = call ptr @verum_internal_memcpy(ptr %new_backing, ptr %initialized_prefix, i64 %initialized_bytes)
  br label %publish

publish:                                          ; preds = %copy, %allocated
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  %new_backing_word = ptrtoint ptr %new_backing to i64
  store i64 %new_backing_word, ptr %data_slot, align 8
  store i64 %1, ptr %capacity_slot, align 8
  br label %success

success:                                          ; preds = %publish, %release, %valid_capacity
  ret i64 1

failure:                                          ; preds = %allocate, %entry
  ret i64 0

allocated:                                        ; preds = %allocate
  %has_initialized_prefix = icmp ne i64 %length, 0
  br i1 %has_initialized_prefix, label %copy, label %publish
}

define internal void @verum_cbgr_deallocate(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %do_dealloc

do_dealloc:                                       ; preds = %entry
  %header_ptr = getelementptr i8, ptr %0, i64 -32
  %gen_ptr = getelementptr i8, ptr %header_ptr, i64 8
  %1 = atomicrmw add ptr %gen_ptr, i32 1 acq_rel, align 4
  %new_gen = add i32 %1, 1
  %ge_max = icmp uge i32 %new_gen, -2
  %lt_old = icmp ult i32 %new_gen, %1
  %overflow = or i1 %ge_max, %lt_old
  br i1 %overflow, label %overflow1, label %set_ref

ret:                                              ; preds = %entry
  ret void

overflow1:                                        ; preds = %do_dealloc
  store i32 1, ptr %gen_ptr, align 4
  %epoch_ptr = getelementptr i8, ptr %header_ptr, i64 12
  %2 = atomicrmw add ptr %epoch_ptr, i16 1 release, align 2
  br label %set_ref

set_ref:                                          ; preds = %overflow1, %do_dealloc
  %rc_ptr = getelementptr i8, ptr %header_ptr, i64 24
  store i32 0, ptr %rc_ptr, align 4
  %hdr_total_ptr = getelementptr i8, ptr %header_ptr, i64 28
  %hdr_total = load i32, ptr %hdr_total_ptr, align 4
  %total = zext i32 %hdr_total to i64
  %hdr_base_off_ptr = getelementptr i8, ptr %header_ptr, i64 6
  %hdr_base_off = load i16, ptr %hdr_base_off_ptr, align 2
  %base_off64 = zext i16 %hdr_base_off to i64
  %header_int = ptrtoint ptr %header_ptr to i64
  %base_int = sub i64 %header_int, %base_off64
  %base = inttoptr i64 %base_int to ptr
  call void @verum_dealloc(ptr %base, i64 %total)
  ret void
}

define internal ptr @verum_internal_memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr %0, ptr %1, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

define internal ptr @verum_try_cbgr_allocate_aligned(i64 %0, i64 %1) {
entry:
  %lt32 = icmp ult i64 %1, 32
  %align = select i1 %lt32, i64 32, i64 %1
  %add31 = add i64 %0, 31
  %aligned = and i64 %add31, -32
  %with_hdr = add i64 %aligned, 32
  %total = add i64 %with_hdr, %align
  %raw = call ptr @verum_os_alloc(i64 %total)
  %is_null = icmp eq ptr %raw, null
  br i1 %is_null, label %null_ret, label %init

init:                                             ; preds = %entry
  %2 = call ptr @memset(ptr %raw, i32 0, i64 %total)
  %raw_int = ptrtoint ptr %raw to i64
  %user0 = add i64 %raw_int, 32
  %align_m1 = sub i64 %align, 1
  %bumped = add i64 %user0, %align_m1
  %align_mask = xor i64 %align_m1, -1
  %user_int = and i64 %bumped, %align_mask
  %header_int = sub i64 %user_int, 32
  %header = inttoptr i64 %header_int to ptr
  %gen_ptr = getelementptr i8, ptr %header, i64 8
  store i32 1, ptr %gen_ptr, align 4
  %size32 = trunc i64 %0 to i32
  %size_ptr = getelementptr i8, ptr %header, i64 0
  store i32 %size32, ptr %size_ptr, align 4
  %epoch64 = load i64, ptr @global_epoch, align 8
  %epoch16 = trunc i64 %epoch64 to i16
  %epoch_ptr = getelementptr i8, ptr %header, i64 12
  store i16 %epoch16, ptr %epoch_ptr, align 2
  %cap_ptr = getelementptr i8, ptr %header, i64 14
  store i16 255, ptr %cap_ptr, align 2
  %rc_ptr = getelementptr i8, ptr %header, i64 24
  store i32 1, ptr %rc_ptr, align 4
  %align16 = trunc i64 %1 to i16
  %align_ptr = getelementptr i8, ptr %header, i64 4
  store i16 %align16, ptr %align_ptr, align 2
  %base_off64 = sub i64 %header_int, %raw_int
  %base_off16 = trunc i64 %base_off64 to i16
  %base_off_ptr = getelementptr i8, ptr %header, i64 6
  store i16 %base_off16, ptr %base_off_ptr, align 2
  %total32 = trunc i64 %total to i32
  %total_ptr = getelementptr i8, ptr %header, i64 28
  store i32 %total32, ptr %total_ptr, align 4
  %user_ptr = inttoptr i64 %user_int to ptr
  ret ptr %user_ptr

null_ret:                                         ; preds = %entry
  ret ptr null
}

@global_epoch = global i64 0
declare ptr @memset(ptr, i32, i64)

define internal ptr @verum_list_storage_address(ptr %0, i64 %1, i64 %2) {
entry:
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %object_size_ptr = getelementptr inbounds i8, ptr %0, i64 12
  %object_size = load i32, ptr %object_size_ptr, align 4
  %valid_object_shape = icmp uge i32 %object_size, 48
  br i1 %valid_object_shape, label %shape, label %invalid

shape:                                            ; preds = %entry
  %capacity_ptr = getelementptr inbounds i8, ptr %0, i64 32
  %capacity = load i64, ptr %capacity_ptr, align 8
  %capacity_limit = udiv i64 4294967295, %list_storage_stride
  %valid_capacity = icmp ule i64 %capacity, %capacity_limit
  %valid_index = icmp ule i64 %1, %capacity
  %remaining_capacity = sub i64 %capacity, %1
  %valid_count = icmp ule i64 %2, %remaining_capacity
  %valid_owner_index = and i1 %valid_capacity, %valid_index
  %valid_range = and i1 %valid_owner_index, %valid_count
  br i1 %valid_range, label %range_ok, label %invalid

range_ok:                                         ; preds = %shape
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %data_word = load i64, ptr %data_slot, align 8
  %data = inttoptr i64 %data_word to ptr
  %missing_storage = icmp eq ptr %data, null
  br i1 %missing_storage, label %missing_backing, label %extent

empty:                                            ; preds = %ready, %missing_backing
  ret ptr null

nonempty_address:                                 ; preds = %ready
  %element_offset = mul i64 %1, %list_storage_stride
  %element_address = getelementptr inbounds i8, ptr %data, i64 %element_offset
  ret ptr %element_address

missing_backing:                                  ; preds = %range_ok
  %empty_owner = icmp eq i64 %capacity, 0
  br i1 %empty_owner, label %empty, label %invalid

extent:                                           ; preds = %range_ok
  %header_ptr = getelementptr i8, ptr %data, i64 -32
  %extent_ptr = getelementptr inbounds i8, ptr %header_ptr, i64 0
  %allocation_extent = load i32, ptr %extent_ptr, align 4
  %allocation_extent64 = zext i32 %allocation_extent to i64
  %capacity_bytes = mul i64 %capacity, %list_storage_stride
  %capacity_fits_allocation = icmp ule i64 %capacity_bytes, %allocation_extent64
  br i1 %capacity_fits_allocation, label %ready, label %invalid

ready:                                            ; preds = %extent
  %empty_range = icmp eq i64 %2, 0
  br i1 %empty_range, label %empty, label %nonempty_address

invalid:                                          ; preds = %extent, %missing_backing, %shape, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal ptr @verum_list_allocate_storage(i64 %0, i32 %1) {
entry:
  %slots = icmp eq i32 %1, 512
  %bytes = icmp eq i32 %1, 527
  %known_encoding = or i1 %slots, %bytes
  br i1 %known_encoding, label %valid_encoding, label %invalid

valid_encoding:                                   ; preds = %entry
  %width = select i1 %bytes, i64 1, i64 8
  %capacity_limit = udiv i64 4294967295, %width
  %capacity_fits = icmp ule i64 %0, %capacity_limit
  br i1 %capacity_fits, label %allocate, label %invalid

allocate:                                         ; preds = %valid_encoding
  %list_owner = call ptr @verum_checked_malloc(i64 48)
  %malloc_null = icmp eq ptr %list_owner, null
  br i1 %malloc_null, label %list_owner_oom, label %list_owner_ok

invalid:                                          ; preds = %valid_encoding, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_oom:                                   ; preds = %allocate
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_ok:                                    ; preds = %allocate
  %2 = call ptr @verum_internal_memset(ptr %list_owner, i32 0, i64 48)
  store i32 %1, ptr %list_owner, align 4
  %list_object_size = getelementptr inbounds i8, ptr %list_owner, i64 12
  store i32 48, ptr %list_object_size, align 4
  call void @verum_list_resize_storage(ptr %list_owner, i64 %0)
  ret ptr %list_owner
}

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

