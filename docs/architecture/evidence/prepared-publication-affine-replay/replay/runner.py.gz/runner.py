from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path('/private/tmp/verum-T1635-affine-consumer-replay')
PRIOR = Path('/private/tmp/verum-registry-stage23-boundaries/publication_prepare_affine_reuse')
CLASSIFIER = Path('/private/tmp/verum-registry-stage23-type-boundaries.py')
VALIDATOR = Path('/private/tmp/replay-verum-map-prepare-copy.py')
BUILD = Path('/private/tmp/verum-T1196-consumer-cli/build-manifest.json')
BUILD_SHA = '289d4a18670f67a014ccc6ad12315f2c4dbe15cad8addbc1ba3d03aea3e63ffa'
CLI_SHA = '2da19e172e64584c4063974f2eb2038d3ec0e6360776b84fc1333adf0cc63d57'
COMMIT = '6a0bf542b9a2a3158d78b4015cf1b533eecfd13e'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert sha(VALIDATOR) == '4efe2be40eb352efe4bd01bf3eec7a7f501d0efd645894d857f8531a96fe1f69'
validator = load('retained_consumer_validator', VALIDATOR)
validator.LANGUAGE_COMMIT = COMMIT
boundary = load('retained_boundary_classifier', CLASSIFIER)
classifier_sha = sha(CLASSIFIER)
build, cli = validator.validate_build(BUILD, BUILD_SHA, CLI_SHA)
validator.registry_identity()
prior = json.loads((PRIOR / 'result.json').read_text())
name = 'publication_prepare_affine_reuse'
assert prior['case'] == name and prior['accepted'] is False
assert prior['oracle']['code'] == 'E310'
fixture_path = Path('tests/language') / (name + '.vr')
fixture = (validator.REGISTRY / fixture_path).read_bytes()
header = f'module verum_registry.tests.{name};\n'.encode()
assert fixture.count(header) == 1
entry = fixture.replace(header, b'module verum_registry.main;\n', 1)
inputs = {path: (validator.REGISTRY / path).read_bytes() for path in boundary.MODULES}
inputs.update({'src/main.vr': entry, 'verum.toml': boundary.MANIFEST})
input_hashes = {path: hashlib.sha256(data).hexdigest() for path, data in inputs.items()}
assert input_hashes == prior['project_inputs']
oracle = boundary.fixture_oracle(name, entry)
assert oracle == prior['oracle']
for path in (*boundary.MODULES, str(fixture_path)):
    data = (validator.REGISTRY / path).read_bytes()
    assert data == validator.git('show', f'{validator.REGISTRY_COMMIT}:{path}')
    assert hashlib.sha256(data).hexdigest() == prior['source_inputs'][path]
OUT.mkdir(exist_ok=False)
project = OUT / 'project'
for path, data in inputs.items():
    dest = project / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
for path, relative in ((BUILD, 'build-manifest.json'), (CLASSIFIER, 'classifier.py'),
        (VALIDATOR, 'build-validator.py'), (Path(__file__), 'runner.py'),
        (PRIOR / 'result.json', 'prior-result.json'),
        (PRIOR / 'stdout.log', 'prior-stdout.log'), (PRIOR / 'stderr.log', 'prior-stderr.log')):
    shutil.copyfile(path, OUT / relative)
command = [str(cli), 'check']
overrides = {'NO_COLOR': '1', 'VERUM_NO_OBJECT_CACHE': '1', 'TMPDIR': '/private/tmp'}
environment = {k: v for k, v in os.environ.items() if not k.startswith('VERUM_')}
environment.update(overrides)
record = {'task': 'T1635', 'related_tasks': ['T1713', 'T1722'], 'case': name,
    'consumer_commit': COMMIT, 'cli': build['cli'], 'build_manifest_sha256': BUILD_SHA,
    'stdlib_producer_commit': validator.STDLIB_COMMIT, 'automatic_precompile': False,
    'registry_commit': validator.REGISTRY_COMMIT, 'registry_tree': validator.REGISTRY_TREE,
    'prior_receipt_sha256': sha(PRIOR / 'result.json'), 'oracle': oracle,
    'project_inputs': input_hashes, 'source_inputs': prior['source_inputs'],
    'classifier_sha256': classifier_sha, 'validator_sha256': sha(VALIDATOR),
    'runner_sha256': sha(__file__), 'deadline_seconds': 600, 'command': command,
    'environment_overrides': overrides, 'removed_environment_keys': sorted(k for k in os.environ if k.startswith('VERUM_')),
    'scope': 'One unchanged previously inconclusive affine project control, preserving the exact diagnostic oracle. Explicit reused Stage23 archives; no runtime, fresh bake, snapshot isolation, AOT or service acceptance.'}
write(OUT / 'started.json', record)
print(json.dumps({'state': 'running', 'case': name, 'consumer': COMMIT, 'deadline_seconds': 600}), flush=True)
start = time.monotonic()
stop_reason = None
with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
    process = subprocess.Popen(command, cwd=project, env=environment, stdout=stdout,
        stderr=stderr, start_new_session=True)
    while process.poll() is None:
        if time.monotonic() - start > 600:
            stop_reason = 'deadline'
        elif sum((OUT / name).stat().st_size for name in ('stdout.log', 'stderr.log')) > 16 * 1024 * 1024:
            stop_reason = 'log_limit'
        if stop_reason:
            boundary.stop(process)
            break
        time.sleep(0.2)
elapsed = round(time.monotonic() - start, 3)
identity_errors = {}
try:
    validator.validate_build(BUILD, BUILD_SHA, CLI_SHA)
    validator.registry_identity()
    assert boundary.snapshot(project) == input_hashes
    assert sha(CLASSIFIER) == sha(OUT / 'classifier.py') == classifier_sha
    assert sha(VALIDATOR) == sha(OUT / 'build-validator.py') == record['validator_sha256']
    assert sha(__file__) == sha(OUT / 'runner.py') == record['runner_sha256']
    assert sha(BUILD) == sha(OUT / 'build-manifest.json') == BUILD_SHA
    for path in (*boundary.MODULES, str(fixture_path)):
        assert sha(validator.REGISTRY / path) == prior['source_inputs'][path]
except Exception as error:
    identity_errors['inputs_or_artifacts'] = repr(error)
verdict = boundary.classify(oracle, project, (OUT / 'stdout.log').read_bytes(),
    (OUT / 'stderr.log').read_bytes(), process.returncode,
    timed_out=stop_reason == 'deadline', unchanged=not identity_errors)
record.update(verdict)
record.update(elapsed_seconds=elapsed, returncode=process.returncode, stop_reason=stop_reason,
    identity_errors=identity_errors, logs={name: sha(OUT / name) for name in ('stdout.log', 'stderr.log')})
if stop_reason:
    record['accepted'] = False
record['status'] = 'passed' if record['accepted'] and not identity_errors else 'failed'
write(OUT / 'result.json', record)
print(json.dumps({key: record[key] for key in ('status', 'verdict', 'elapsed_seconds', 'returncode', 'stop_reason', 'identity_errors', 'diagnostics')}, indent=2))
raise SystemExit(0 if record['status'] == 'passed' else 1)
