from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path('/Users/taaliman/.codex/worktrees/source-archive-main/verum')
SOURCE = Path('/private/tmp/verum-T1635-affine-consumer-replay')
REGISTRY = Path('/private/tmp/verum-registry-t1636-auth')
OUT = ROOT / 'docs/architecture/evidence/prepared-publication-affine-replay'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain']) == b''
record = json.loads((SOURCE / 'result.json').read_text())
prior = json.loads((SOURCE / 'prior-result.json').read_text())
assert record['status'] == 'failed' and record['accepted'] is False
assert record['verdict'] == 'inconclusive_unexpected_diagnostics'
assert record['identity_errors'] == {} and record['stop_reason'] is None
assert record['returncode'] == 101 and record['elapsed_seconds'] == 263.481
assert record['oracle'] == prior['oracle']
assert [item['code'] for item in record['diagnostics']] == ['E103', 'E310']
assert record['project_inputs'] == prior['project_inputs']
for path, digest in record['project_inputs'].items():
    assert sha((SOURCE / 'project' / path).read_bytes()) == digest
for path, digest in record['source_inputs'].items():
    data = (REGISTRY / path).read_bytes()
    assert sha(data) == digest
    assert data == subprocess.check_output(['git', '-C', str(REGISTRY), 'show', record['registry_commit'] + ':' + path])
for name, digest in record['logs'].items():
    assert sha((SOURCE / name).read_bytes()) == digest
assert sha((SOURCE / 'prior-result.json').read_bytes()) == record['prior_receipt_sha256']
assert sha((SOURCE / 'runner.py').read_bytes()) == record['runner_sha256']
assert sha((SOURCE / 'classifier.py').read_bytes()) == record['classifier_sha256']
assert sha((SOURCE / 'build-validator.py').read_bytes()) == record['validator_sha256']
OUT.mkdir(exist_ok=False)
manifest = {'task': 'T1635', 'related_tasks': ['T1713', 'T1722'],
    'status': 'inconclusive_unexpected_diagnostics', 'case': record['case'],
    'consumer_commit': record['consumer_commit'], 'registry_commit': record['registry_commit'],
    'seconds': record['elapsed_seconds'], 'returncode': 101,
    'original_project_and_oracle_unchanged': True,
    'diagnostics': record['diagnostics'], 'files': [],
    'scope': record['scope']}

def retain(path, relative):
    raw = Path(path).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    dest = OUT / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(packed)
    manifest['files'].append({'path': relative, 'original_bytes': len(raw),
        'original_sha256': sha(raw), 'stored_bytes': len(packed), 'stored_sha256': sha(packed)})

for path in sorted(SOURCE.rglob('*')):
    if path.is_file(): retain(path, 'replay/' + str(path.relative_to(SOURCE)) + '.gz')
for path in record['source_inputs']:
    retain(REGISTRY / path, 'prior-source-roster/' + path + '.gz')
retain(__file__, 'retain-and-verify.py.gz')
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Unchanged prepared-publication affine boundary

The original `publication_prepare_affine_reuse` project still has an
inconclusive strict refusal result on consumer `6a0bf542b` (263.481 seconds,
exit 101). It emits the expected E310 use-after-move diagnostic with the
original moved/used offsets, plus an unlocated E103 for unresolved `archive`
field access. The extra error is not accepted as proof of the desired
boundary, and its cause is not assigned by this replay.

The prior Stage23 run produced the same two diagnostic categories. All seven
project inputs and the exact oracle are unchanged. The retained prior source
roster includes other boundary fixtures for provenance; only the affine
project was executed in this replay. No previous passing checks were rerun.

The [manifest](manifest.json) binds the current and prior receipts, raw logs,
project files, original source roster, unchanged diagnostic classifier and
consumer-build validator. Source identities match the frozen registry commit.
The [consumer build](../map-mutable-slots/consumer-replay/README.md) explicitly
reuses Stage23 stdlib artifacts. There is no fresh bake, runtime isolation,
native or registry-service acceptance here.

The separate registry snapshot API work changes the public inspection API.
Its new fixtures require their own acceptance and cannot retroactively turn
this unchanged original control into a pass.
''')
with (ROOT / 'docs/architecture/registry-language-acceptance.md').open('a') as stream:
    stream.write('''
The [unchanged affine-reuse project replay](evidence/prepared-publication-affine-replay/README.md)
remains inconclusive on the same consumer: expected E310 accompanies an
unlocated E103 for unresolved `archive` access (263.481 seconds, exit 101).
The exact input and diagnostic oracle are preserved; the unrelated error
is not counted as the required specific refusal.
''')
print(json.dumps({'packet': str(OUT), 'retained_files': len(manifest['files']), 'status': manifest['status']}))
