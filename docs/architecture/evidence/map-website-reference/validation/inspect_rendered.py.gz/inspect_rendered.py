from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import re

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.path = path
        self.ids = set()
        self.links = set()
        self.data = []
        self.code = []
        self.current_code = None
        self.feed(path.read_text())
        self.text = re.sub(r'\s+', ' ', ''.join(self.data))
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'): self.ids.add(attrs['id'])
        if attrs.get('href'): self.links.add(attrs['href'])
        if tag == 'code': self.current_code = []
        if tag == 'br' and self.current_code is not None: self.current_code.append('\n')
    def handle_data(self, data):
        self.data.append(data)
        if self.current_code is not None: self.current_code.append(data)
    def handle_endtag(self, tag):
        if tag == 'code' and self.current_code is not None:
            self.code.append(''.join(self.current_code))
            self.current_code = None

root = Path('/private/tmp/verum-website-cog-archive-profile/build')
reference = Page(root / 'docs/stdlib/collections.html')
cookbook = Page(root / 'docs/cookbook/collections.html')
fixture = Path('/private/tmp/verum-T1751-map-docs/map_access.vr').read_text()
checks = {
    'reference_owned_get': 'm.get(key) -> Maybe<V>' in reference.text,
    'reference_mutable_get': 'm.get_mut(&key) -> Maybe<&mut V>' in reference.text,
    'clone_bound': 'requires K: Clone' in reference.text,
    'partial_interpreter_scope': 'Focused interpreter checks cover present and missing keys' in reference.text,
    'nested_mutation_scope': 'mutation inside nested variant values' in reference.text,
    'entry_limit': 'The entry API and other methods that access the source layout' in reference.text,
    'native_limit': 'do not establish native AOT support' in reference.text,
    'lifetime_limit': 'not a claim that every stale-reference use is currently detected' in reference.text,
    'drain_ownership': 'yields owned (K, V) pairs and removes them from the map' in reference.text,
    'map_support_anchor': 'map-support' in reference.ids,
    'example_anchor': 'map-values-and-mutable-access' in cookbook.ids,
    'example_link': '/docs/cookbook/collections#map-values-and-mutable-access' in reference.links,
    'support_link': '/docs/stdlib/collections#map-support' in cookbook.links,
    'exact_executed_example': any(code.strip() == fixture.strip() for code in cookbook.code),
    'expected_stdout': any(code.strip() == 'map-access: ok' for code in cookbook.code),
    'reference_excerpts_labeled': 'reference excerpts, not standalone programs' in reference.text,
    'unsupported_entry_sketches_labeled': 'they are not supported recipes' in cookbook.text,
}
result = {
    'checks': checks,
    'pages': {str(page.path.relative_to(root)): {'path': str(page.path), 'sha256': hashlib.sha256(page.path.read_bytes()).hexdigest()} for page in [reference, cookbook]},
    'fixture_sha256': hashlib.sha256(fixture.encode()).hexdigest(),
    'scope': 'Rendered HTML signatures, code, caveats, anchors and links; no layout/navigation change. Runtime acceptance comes from the retained parent interpreter receipts.'
}
Path('/private/tmp/verum-T1751-website/rendered-inspection.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
assert all(checks.values()), {name: value for name, value in checks.items() if not value}
