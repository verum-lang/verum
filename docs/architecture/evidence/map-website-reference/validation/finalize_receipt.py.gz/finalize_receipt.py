from pathlib import Path
import hashlib
import json
import subprocess

out=Path('/private/tmp/verum-T1751-website')
repo=Path('/private/tmp/verum-website-cog-archive-profile')
language=Path('/Users/taaliman/projects/oldman/verum-lang/verum')
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args, root=repo): return subprocess.check_output(['git','-C',str(root),*args])
def record(p): return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
head=git('rev-parse','HEAD').decode().strip()
assert head=='a30a1f176b72a85ee8d3e4efc6f0e813fadf8bf5'
assert not git('status','--porcelain').strip()
subprocess.run(['git','-C',str(repo),'diff','--check',head+'^',head],check=True)
gate_records=[]
all_sources=None
for path in sorted((out/'gates').glob('*.json')):
    d=json.loads(path.read_text())
    assert d['exit_code']==0 and not d['timed_out'] and d['source_unchanged']
    assert sha(Path(d['log']).read_bytes())==d['log_sha256']
    if all_sources is None: all_sources=d['source_sha256']
    assert d['source_sha256']==all_sources
    gate_records.append({**record(path),'name':d['name'],'command':d['command'],'seconds':d['elapsed_seconds'],'source_binding_count':len(d['source_sha256']),'log':record(Path(d['log']))})
assert len(gate_records)==5
paths=list(all_sources)
proc=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for path in paths:
    proc.stdin.write((head+':'+path+'\n').encode()); proc.stdin.flush()
    header=proc.stdout.readline().split(); assert len(header)==3 and header[1]==b'blob',header
    b=proc.stdout.read(int(header[2])); assert proc.stdout.read(1)==b'\n'
    assert sha(b)==all_sources[path],path
proc.stdin.close(); assert proc.wait()==0
source=json.loads((out/'source-evidence.json').read_text())
for p,h in source['source_sha256'].items():
    assert sha(git('show',source['language_source']+':'+p,root=language))==h,p
rendered=json.loads((out/'rendered-inspection.json').read_text())
assert all(rendered['checks'].values())
for p in rendered['pages'].values(): assert sha(Path(p['path']).read_bytes())==p['sha256']
cookbook=git('show',head+':docs/cookbook/collections.md').decode()
block=next(b for b in cookbook.split('```verum\n')[1:] if 'map-access: ok' in b).split('```')[0]
fixture=Path('/private/tmp/verum-T1751-map-docs/map_access.vr')
assert block.encode()==fixture.read_bytes()
assert sha(block.encode())=='c48149b7371e14eb681ba1eda8943777afba3846791693201f97b6004cf46807'
result={
    'task':'T1751','status':'ready for parent review and local main integration',
    'website':{'worktree':str(repo),'branch':git('branch','--show-current').decode().strip(),'base':git('rev-parse',head+'^').decode().strip(),'commit':head,'tree':git('rev-parse',head+'^{tree}').decode().strip(),'clean':True,'source_bindings_per_gate':len(all_sources),'verified_gate_source_bindings':len(all_sources)*len(gate_records),'changed_files':[{'path':p,'sha256':sha(git('show',head+':'+p))} for p in ['docs/stdlib/collections.md','docs/cookbook/collections.md']]},
    'gates':gate_records,
    'rendered_inspection':{**record(out/'rendered-inspection.json'),'passed':len(rendered['checks'])},
    'source_evidence':record(out/'source-evidence.json'),
    'runtime_review':record(out/'runtime-review.json'),
    'executed_example':record(fixture),
    'harness_correction':{'initial_result':record(out/'rendered-inspection.initial.json'),'initial_inspector':record(out/'inspect_rendered.initial.py'),'final_inspector':record(out/'inspect_rendered.py'),'classification':'Initial HTML inspector discarded Docusaurus br line separators, making exact code comparison fail. Corrected parser reconstructs emitted line breaks; same unchanged HTML then matches the executed fixture byte-for-byte. All other initial content checks passed; no website source change or runtime failure was inferred.'},
    'notes':['Five required website gates passed on the committed source with Node 22.19.0.','Build emitted nonfatal shared node_modules cache/update notices; no dependencies installed or updated.','Parent executed the unchanged complete example using rebuilt interpreter and existing Stage23 standard-library artifacts.','No new language build, CLI execution, AOT, deployment or push by this documentation task.'],
    'retained_limits':source['no_acceptance'],
}
path=out/'result.json'; path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(path),'sha256':sha(path.read_bytes()),'commit':head,'source_bindings':result['website']['verified_gate_source_bindings'],'rendered_checks':len(rendered['checks']),'clean':True}))
