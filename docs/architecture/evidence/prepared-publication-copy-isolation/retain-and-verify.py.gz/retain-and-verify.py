from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path('/Users/taaliman/.codex/worktrees/source-archive-main/verum')
REGISTRY = Path('/private/tmp/verum-registry-t1636-auth')
CURRENT = Path('/private/tmp/verum-T1722-map-prepare-copy')
PRIOR = Path('/private/tmp/verum-T1722-prepare-copy-runtime')
OUT = ROOT / 'docs/architecture/evidence/prepared-publication-copy-isolation'
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda root, *args: subprocess.check_output(['git', '-C', str(root), *args])
assert git(ROOT, 'status', '--porcelain') == b''
assert git(REGISTRY, 'status', '--porcelain') == b''
record = json.loads((CURRENT / 'result.json').read_text())
component = json.loads((CURRENT / 'component/result.json').read_text())
prior = json.loads((PRIOR / 'result.json').read_text())
prior_component = json.loads((PRIOR / 'component/result.json').read_text())
assert record['status'] == component['status'] == 'failed'
assert record['errors'] == {} and record['failure'] is None
assert component['returncode'] == 1 and not component['timed_out']
assert component['elapsed_seconds'] == 396.2
assert git(REGISTRY, 'rev-parse', 'HEAD').decode().strip() == record['registry_commit']
assert git(REGISTRY, 'rev-parse', 'HEAD^{tree}').decode().strip() == record['registry_tree']
assert sha((CURRENT / 'component/result.json').read_bytes()) == record['component_result']['sha256']
for name, accepted in record['checks'].items():
    assert accepted == (name != 'original_component_accepted'), name
assert record['source_inputs'] == prior['source_inputs'] == component['source_inputs_after']
assert record['project_inputs'] == prior['project_inputs'] == component['project_inputs_after']
assert len(record['source_inputs']) == 8 and len(record['project_inputs']) == 7
for path, digest in record['source_inputs'].items():
    assert sha((CURRENT / 'inputs/source' / path).read_bytes()) == digest
    assert sha(git(REGISTRY, 'show', record['registry_commit'] + ':' + path)) == digest
for path, digest in record['project_inputs'].items():
    assert sha((CURRENT / 'inputs/project' / path).read_bytes()) == digest
for directory, receipt in ((CURRENT, component), (PRIOR, prior_component)):
    for name, digest in receipt['logs'].items():
        assert sha((directory / 'component' / name).read_bytes()) == digest
expected_lines = [
    'copied name changed retained contents or attribution',
    'copied authors changed retained contents or attribution',
    'copied archive changed retained contents or attribution',
    'copied feature members changed retained contents or attribution',
    'copied dependency features changed retained contents or attribution',
]
assert (CURRENT / 'component/stdout.log').read_text().splitlines() == expected_lines
assert 'Assertion failed at pc 181' in (CURRENT / 'component/stderr.log').read_text()
assert 'variant field receiver payload exceeds allocation' not in (CURRENT / 'component/stderr.log').read_text()
assert (PRIOR / 'component/stdout.log').read_bytes() == b''
assert 'variant field receiver payload exceeds allocation' in (PRIOR / 'component/stderr.log').read_text()
assert sha((CURRENT / 'wrapper.py').read_bytes()) == record['wrapper_sha256']
assert sha((CURRENT / 'runtime-build-manifest.json').read_bytes()) == record['runtime_build_manifest_sha256']
assert sha((CURRENT / 'stage23-build-manifest.json').read_bytes()) == record['stdlib_origin_manifest_sha256']
with Path(record['cli']['path']).open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == record['cli']['sha256']
OUT.mkdir(exist_ok=False)
manifest = {'tasks': ['T1635', 'T1722', 'T1753'], 'status': 'isolation-failed',
    'registry_commit': record['registry_commit'], 'registry_tree': record['registry_tree'],
    'consumer_commit': record['runtime_source_commit'], 'cli': record['cli'],
    'stdlib_producer_commit': record['stdlib_producer_commit'], 'automatic_precompile': False,
    'seconds': component['elapsed_seconds'], 'returncode': 1,
    'completed_mutation_cases': 5, 'failed_retained_isolation_cases': 5,
    'verified_original_source_inputs': 8, 'verified_project_inputs': 7,
    'source_and_project_identical_to_prior': True, 'files': [],
    'scope': 'Original domain copy-isolation oracle fails after all mutation paths complete. No deep-copy language guarantee, broad allocation-guard closure, fresh bake, AOT or registry service acceptance.'}

def retain(path, relative):
    raw = Path(path).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    dest = OUT / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(packed)
    manifest['files'].append({'path': relative, 'original_bytes': len(raw),
        'original_sha256': sha(raw), 'stored_bytes': len(packed), 'stored_sha256': sha(packed)})

for path in sorted(CURRENT.rglob('*')):
    if path.is_file():
        retain(path, 'current/' + str(path.relative_to(CURRENT)) + '.gz')
for name in ('result.json', 'component/result.json', 'component/stdout.log', 'component/stderr.log'):
    retain(PRIOR / name, 'prior/' + name + '.gz')
retain(ROOT / 'docs/architecture/value-copy-contract.md', 'reviewed-value-copy-contract.md.gz')
retain(__file__, 'retain-and-verify.py.gz')
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Prepared publication projection isolation

The unchanged registry `prepare_copy` component fails its original isolation
oracle on consumer `6a0bf542b9a2a3158d78b4015cf1b533eecfd13e`. All five
mutation paths complete: name, authors, archive bytes, feature members and
dependency feature members. Each mutation's own assertions pass, but every
subsequent retained-input check returns false. The final assertion fails
at pc 181 after 396.2 seconds, exit 1, within the original 600-second deadline.

This is a meaningful domain isolation failure. A mutable projection must
not change the publication retained with authenticated attribution. No
successful publication or admission guarantee follows from the earlier
preparation result. The candidate remains unintegrated.

The [manifest](manifest.json) retains the exact runner, all eight source
inputs, all seven assembled project inputs, raw logs and receipts. All
inputs are byte-identical to the earlier 470.86-second run, which stopped
at `variant field receiver payload exceeds allocation` before producing
stdout. That guard failure is absent in this replay; this observation does
not assign its cause to one patch or close a general allocation audit.

The consumer uses the five explicitly retained Stage23 artifacts. Its
[build and ordinary Map acceptance](../map-mutable-slots/consumer-replay/README.md)
are recorded separately. This is not a fresh automatic bake or a main
distribution build.

## Copy semantics and domain isolation

The [language contract](../../value-copy-contract.md) defines a one-level
copy: an outer record gets fresh slots, while nested values remain bitwise
shared. References remain references; Shared preserves cell identity.
Consequently, copying only the outer DecodedPublication cannot establish
this fixture's stronger snapshot requirement, even after missing explicit
dereference-place copy emission is repaired (T1753).

T1722 must provide an explicit domain snapshot boundary or an equivalently
closed API that cannot expose retained mutable DTO storage. Its acceptance
must preserve the original mutation and retained-state requirements.
The original failed candidate and fixture stay unchanged as evidence.
Private-field, affine, admission, durable storage, HTTP and native AOT
acceptance remain separate requirements.
''')
with (ROOT / 'docs/architecture/registry-language-acceptance.md').open('a') as stream:
    stream.write('''
### Prepared publication copies still alias retained input

The [unchanged preparation-copy replay](evidence/prepared-publication-copy-isolation/README.md)
now completes all five mutation paths, then fails all five retained-input
isolation checks. It exits 1 in 396.2 seconds with the original source,
assembled project, runner and output oracle unchanged. The previous variant
allocation-guard failure is absent on this consumer; snapshot isolation is
still unaccepted.

The one-level language copy contract does not recursively isolate nested
records and containers. Explicit dereference-place copy emission (T1753)
and the registry's stronger domain snapshot boundary (T1722) are distinct
obligations. The authentication/preparation candidate remains unintegrated
until its required runtime and visibility controls pass.
''')
print(json.dumps({'packet': str(OUT), 'retained_files': len(manifest['files']),
    'status': manifest['status'], 'completed_mutations': 5}))
