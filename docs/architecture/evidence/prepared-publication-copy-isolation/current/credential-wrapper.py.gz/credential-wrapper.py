#!/usr/bin/env python3
"""Replay unchanged credentials with a runtime-only CLI and explicitly reused stdlib."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
REGISTRY = Path('/private/tmp/verum-registry-t1636-auth')
REGISTRY_COMMIT = '6c055769bab8deca3787b55e782e7ca61a7ce2c4'
REGISTRY_TREE = '0a8e4d476bfbef99df285b3d5b34640494816cf3'
LANGUAGE_COMMIT = '643ed5ca983b61c73f73834f7cb2e446c44a398c'
STDLIB_COMMIT = '7a8c86f90a493a3b7352359314fc5f0d628aaa1b'
STDLIB_MANIFEST = Path('/private/tmp/verum-registry-stage23-canonical-owners/build-manifest.json')
STDLIB_MANIFEST_SHA = '3df266cba9190c9d201e03cb51404b28a1d1864f784d32e18421d6fb2083faef'
BASELINE = Path('/private/tmp/verum-registry-stage23-credentials_file/component/result.json')
RUNNER = Path('tools/run_publication_envelope.py')
ARCHIVE = Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target/precompiled-stdlib')
CHECKS = {'exit_zero', 'within_deadline', 'exact_stdout', 'source_unchanged',
          'project_unchanged', 'executable_unchanged'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def byte_sha(value):
    return hashlib.sha256(value).hexdigest()


def identity(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def git(*args):
    return subprocess.check_output(['git', '-C', str(REGISTRY), *args])


def require(condition, message):
    if not condition:
        raise ValueError(message)


def registry_identity():
    require(git('rev-parse', 'HEAD').decode().strip() == REGISTRY_COMMIT, 'registry commit changed')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == REGISTRY_TREE, 'registry tree changed')
    require(not git('status', '--porcelain').strip(), 'registry is dirty')
    return True


def validate_build(path, expected_manifest, expected_cli):
    require(sha(path) == expected_manifest, 'runtime build manifest pin changed')
    build = json.loads(path.read_text())
    require(build['status'] == 'passed' and build['exit_code'] == 0 and not build['stop_reason']
            and not build['timed_out'] and not build['errors'], 'runtime build did not pass')
    require(build['build_kind'] == 'runtime-only-with-explicit-reused-stdlib'
            and build['automatic_precompile'] is False, 'wrong build-provenance boundary')
    require(build['engine_commit'] == LANGUAGE_COMMIT and build['stdlib_producer_commit'] == STDLIB_COMMIT,
            'wrong runtime or stdlib source identity')
    for key in ('selected_vbc_recompiled', 'selected_cli_recompiled', 'source_unchanged',
                'source_paths_unchanged', 'artifacts_unchanged', 'origin_manifest_unchanged',
                'original_cli_unchanged', 'precompiler_unchanged'):
        require(build.get(key) is True, 'runtime build check missing/failed: '+key)
    require(sha(STDLIB_MANIFEST) == STDLIB_MANIFEST_SHA == build['origin_manifest_sha256'],
            'Stage23 stdlib origin changed')
    origin = json.loads(STDLIB_MANIFEST.read_text())
    require(origin['status'] == 'passed' and origin['automatic_precompile'] is True
            and origin['engine_commit'] == STDLIB_COMMIT, 'invalid Stage23 producer evidence')
    require(build['schema'] == origin['schema'] == 'v54-2026-10-10-declared-field-visibility',
            'wrong stdlib schema')
    for directory in (ARCHIVE, Path(origin['artifact_snapshot']), Path(build['retained_artifacts'])):
        require({name: identity(directory/name) for name in origin['artifacts']} == origin['artifacts'],
                'reused artifact bytes changed: '+str(directory))
    require(build['artifacts_before'] == build['artifacts_after'] == origin['artifacts'],
            'runtime build altered archived inputs')
    cli = Path(build['cli']['path']).resolve(strict=True)
    require(identity(cli) == {key: build['cli'][key] for key in ('bytes', 'sha256')}
            and sha(cli) == expected_cli, 'runtime CLI identity changed')
    return build, cli


def load_runner():
    require((REGISTRY/RUNNER).read_bytes() == git('show', f'{REGISTRY_COMMIT}:{RUNNER}'),
            'committed original component runner changed')
    spec = importlib.util.spec_from_file_location('unchanged_credentials_component', REGISTRY/RUNNER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inputs(runner):
    selected = runner.COMPONENTS['credentials_file']
    require(not selected.get('appended_fragments'), 'unexpected module assembly')
    sources = {}
    for path in (*selected['modules'], *selected.get('assets', ()), selected['fixture'], selected['expected'], RUNNER):
        value = (REGISTRY/path).read_bytes()
        require(value == git('show', f'{REGISTRY_COMMIT}:{path}'), 'source differs from frozen commit: '+str(path))
        sources[path] = value
    fixture = sources[selected['fixture']]
    require(fixture.count(selected['header']) == 1, 'entry header is not unique')
    project = {**{p: sources[p] for p in (*selected['modules'], *selected.get('assets', ()))},
               Path('src/main.vr'): fixture.replace(selected['header'], runner.NEW_HEADER, 1),
               Path('verum.toml'): runner.MANIFEST}
    return sources, project


def hashes(contents):
    return {str(path): byte_sha(value) for path, value in contents.items()}


def retain_inputs(directory, contents):
    for path, value in contents.items():
        destination = directory/path
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(value)


def run(args):
    build, cli = validate_build(args.build_manifest, args.expected_build_manifest_sha256, args.expected_cli_sha256)
    registry_identity()
    runner = load_runner()
    sources, project = inputs(runner)
    source_hashes, project_hashes = hashes(sources), hashes(project)
    baseline = json.loads(BASELINE.read_text())
    require(baseline['status'] == 'timed_out' and baseline['deadline_seconds'] == 600,
            'unexpected original credential baseline')
    require(source_hashes == baseline['source_inputs'] == baseline['source_inputs_after']
            and project_hashes == baseline['project_inputs'] == baseline['project_inputs_after'],
            'credential source/project differs from the original timeout')
    if args.preflight_only:
        print(json.dumps({'status': 'ready-not-executed', 'source_inputs': source_hashes,
                          'project_inputs': project_hashes, 'cli': str(cli), 'deadline_seconds': 600}))
        return 0
    evidence = args.evidence_dir.resolve()
    evidence.mkdir(exist_ok=False)
    retain_inputs(evidence/'inputs/source', sources)
    retain_inputs(evidence/'inputs/project', project)
    retain_inputs(evidence, {Path('runtime-build-manifest.json'): args.build_manifest.read_bytes(),
                            Path('stage23-build-manifest.json'): STDLIB_MANIFEST.read_bytes(),
                            Path('original-timeout-result.json'): BASELINE.read_bytes(),
                            Path('wrapper.py'): Path(__file__).read_bytes()})
    wrapper_hash = sha(__file__)
    record = {'task': 'T1743', 'registry_commit': REGISTRY_COMMIT, 'registry_tree': REGISTRY_TREE,
              'runtime_source_commit': LANGUAGE_COMMIT, 'stdlib_producer_commit': STDLIB_COMMIT,
              'automatic_precompile': False, 'cli': build['cli'], 'artifacts': build['artifacts_after'],
              'runtime_build_manifest': str(args.build_manifest),
              'runtime_build_manifest_sha256': args.expected_build_manifest_sha256,
              'stdlib_origin_manifest_sha256': STDLIB_MANIFEST_SHA,
              'baseline_receipt_sha256': sha(BASELINE), 'component': 'credentials_file',
              'deadline_seconds': 600, 'source_inputs': source_hashes, 'project_inputs': project_hashes,
              'wrapper_sha256': wrapper_hash,
              'scope': 'Unchanged credential component under the original 600-second deadline, using a runtime-only '
                       'CLI with explicit Stage23 archive reuse. No automatic bake, full service, durability or AOT claim.'}
    (evidence/'started.json').write_text(json.dumps(record, indent=2)+'\n')
    original_environment = dict(os.environ)
    selected = {key: value for key, value in original_environment.items() if not key.startswith('VERUM_')}
    selected['TMPDIR'] = '/private/tmp'
    record['removed_environment_keys'] = sorted(set(original_environment)-set(selected))
    failure = None
    code = None
    try:
        os.environ.clear()
        os.environ.update(selected)
        code = runner.run(argparse.Namespace(verum=str(cli), component='credentials_file',
            language_commit=LANGUAGE_COMMIT, expected_cli_sha256=args.expected_cli_sha256,
            evidence_dir=str(evidence/'component'), timeout=600))
    except (Exception, KeyboardInterrupt) as error:
        failure = repr(error)
    finally:
        os.environ.clear()
        os.environ.update(original_environment)
    checked = {}
    errors = {}
    try:
        checked['registry_unchanged'] = registry_identity()
        checked['build_and_artifacts_unchanged'] = validate_build(args.build_manifest,
            args.expected_build_manifest_sha256, args.expected_cli_sha256)[1] == cli
        checked['original_source_and_project_unchanged'] = tuple(map(hashes, inputs(runner))) == (source_hashes, project_hashes)
        checked['retained_inputs_unchanged'] = all(sha(evidence/'inputs/source'/p) == source_hashes[str(p)] for p in sources) and all(sha(evidence/'inputs/project'/p) == project_hashes[str(p)] for p in project)
        checked['wrapper_unchanged'] = sha(__file__) == sha(evidence/'wrapper.py') == wrapper_hash
        checked['retained_receipts_unchanged'] = (sha(evidence/'runtime-build-manifest.json') == args.expected_build_manifest_sha256
            and sha(evidence/'stage23-build-manifest.json') == STDLIB_MANIFEST_SHA
            and sha(BASELINE) == sha(evidence/'original-timeout-result.json') == record['baseline_receipt_sha256'])
        result_path = evidence/'component/result.json'
        receipt = json.loads(result_path.read_text())
        original = receipt.get('checks', {})
        checked['original_component_accepted'] = (code == 0 and receipt['status'] == 'passed'
            and receipt['returncode'] == 0 and receipt['timed_out'] is False and receipt['interrupted'] is False
            and receipt['runner_error'] is None and set(original) == CHECKS and all(v is True for v in original.values())
            and receipt['component'] == 'credentials_file' and receipt['deadline_seconds'] == 600
            and receipt['command'] == [str(cli), 'run', '--tier', 'interpret']
            and receipt['language_source_commit_supplied'] == LANGUAGE_COMMIT
            and receipt['cli_sha256'] == receipt['expected_cli_sha256'] == receipt['cli_sha256_after'] == args.expected_cli_sha256
            and receipt['source_inputs'] == receipt['source_inputs_after'] == source_hashes
            and receipt['project_inputs'] == receipt['project_inputs_after'] == project_hashes
            and receipt['module_assemblies'] == [])
        checked['original_logs_unchanged'] = all(sha(evidence/'component'/name) == receipt['logs'][name] for name in ('stdout.log', 'stderr.log'))
        record['component_result'] = {'status': receipt['status'], 'elapsed_seconds': receipt['elapsed_seconds'],
                                      'returncode': receipt['returncode'], 'sha256': sha(result_path)}
    except Exception as error:
        errors['identity_or_receipt'] = repr(error)
    record.update(status='passed' if failure is None and not errors and checked and all(checked.values()) else 'failed',
                  failure=failure, returncode=code, checks=checked, errors=errors)
    (evidence/'result.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'failure', 'returncode', 'component_result', 'checks', 'errors')}))
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-manifest', type=Path, required=True)
    parser.add_argument('--expected-build-manifest-sha256', required=True)
    parser.add_argument('--expected-cli-sha256', required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    parser.add_argument('--preflight-only', action='store_true')
    raise SystemExit(run(parser.parse_args()))
