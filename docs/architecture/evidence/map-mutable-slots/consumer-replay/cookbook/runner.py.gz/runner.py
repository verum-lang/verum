"""Run the exact complete Map cookbook example against a pinned consumer CLI."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--manifest', type=Path, required=True)
p.add_argument('--manifest-sha', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
fixture = Path('/private/tmp/verum-T1751-map-docs/map_access.vr')
fixture_sha = 'c48149b7371e14eb681ba1eda8943777afba3846791693201f97b6004cf46807'
website = Path('/private/tmp/verum-website-cog-archive-profile/docs/cookbook/collections.md')
origin = Path('/private/tmp/verum-registry-stage23-canonical-owners/build-manifest.json')
origin_sha = '3df266cba9190c9d201e03cb51404b28a1d1864f784d32e18421d6fb2083faef'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(path):
    return {'bytes': Path(path).stat().st_size, 'sha256': sha(path)}

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()

def validate():
    assert sha(a.manifest) == a.manifest_sha
    build = json.loads(a.manifest.read_bytes())
    assert build['status'] == 'passed' and build['exit_code'] == 0
    assert not build['errors'] and build['stop_reason'] is None and not build['timed_out']
    assert build['build_kind'] == 'consumer-cli-with-explicit-reused-stdlib'
    assert build['automatic_precompile'] is False
    for key in ('selected_types_present', 'types_inputs_unchanged_from_prior_consumer',
                'selected_compiler_recompiled', 'selected_vbc_recompiled', 'selected_cli_recompiled',
                'source_unchanged', 'source_paths_unchanged', 'artifacts_unchanged',
                'origin_manifest_unchanged', 'original_cli_unchanged', 'precompiler_unchanged'):
        assert build[key] is True, key
    assert git('rev-parse', 'HEAD') == build['engine_commit']
    assert not git('status', '--porcelain')
    assert identity(build['cli']['path']) == {k: build['cli'][k] for k in ('bytes', 'sha256')}
    assert sha(origin) == origin_sha == build['origin_manifest_sha256']
    producer = json.loads(origin.read_bytes())
    assert producer['status'] == 'passed' and producer['automatic_precompile'] is True
    assert producer['engine_commit'] == build['stdlib_producer_commit'] == '7a8c86f90a493a3b7352359314fc5f0d628aaa1b'
    for directory in (Path(producer['artifact_snapshot']), Path(build['retained_artifacts']),
                      Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target/precompiled-stdlib')):
        assert {name: identity(directory/name) for name in producer['artifacts']} == producer['artifacts']
    assert sha(fixture) == fixture_sha
    assert '\n```verum\n'+fixture.read_text().rstrip()+'\n```\n' in website.read_text()
    return build

build = validate()
out = a.output.resolve()
out.mkdir(exist_ok=False)
(out/'runtime').mkdir()
entry = out/'runtime/map_access.vr'
entry.write_bytes(fixture.read_bytes())
expected = b'map-access: ok\n'
for path, name in ((Path(__file__), 'runner.py'), (a.manifest, 'consumer-build-manifest.json'),
                   (origin, 'stdlib-build-manifest.json'), (website, 'cookbook-collections.md')):
    (out/name).write_bytes(path.read_bytes())
(out/'expected.stdout').write_bytes(expected)
overrides = {'TMPDIR': '/private/tmp', 'NO_COLOR': '1', 'VERUM_NO_OBJECT_CACHE': '1'}
environment = {k: v for k, v in os.environ.items() if not k.startswith('VERUM_')}
environment.update(overrides)
command = [build['cli']['path'], 'run', '--tier', 'interpret', str(entry)]
record = {'tasks': ['T1196', 'T1751', 'T1752'], 'engine_commit': build['engine_commit'],
          'stdlib_producer_commit': build['stdlib_producer_commit'], 'automatic_precompile': False,
          'cli': build['cli'], 'build_manifest_sha256': a.manifest_sha,
          'source_sha256': fixture_sha, 'website_source_sha256': sha(website),
          'expected_stdout': expected.decode(), 'command': command, 'cwd': str(entry.parent),
          'environment_overrides': overrides, 'deadline_seconds': 180, 'maximum_log_bytes': 2*1024**2,
          'scope': 'Exact complete cookbook Map example: owned scalar lookup, absent keys, stored-slot mutation and fresh lookup. Interpreter only, explicitly reused Stage23 stdlib; no native, entry API, stale-reference enforcement or registry publication acceptance.'}
(out/'started.json').write_text(json.dumps(record, indent=2)+'\n')
start = time.monotonic()
stop_reason = None
with (out/'stdout.log').open('xb') as stdout, (out/'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=entry.parent, env=environment, stdout=stdout,
                               stderr=stderr, start_new_session=True)
    (out/'process.json').write_text(json.dumps({'pid': process.pid, 'runner_pid': os.getpid()})+'\n')
    while process.poll() is None:
        time.sleep(.25)
        if time.monotonic()-start > record['deadline_seconds']:
            stop_reason = 'deadline'
        elif any((out/name).stat().st_size > record['maximum_log_bytes'] for name in ('stdout.log', 'stderr.log')):
            stop_reason = 'log bound'
        if stop_reason:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
            break
record.update(returncode=process.returncode, seconds=round(time.monotonic()-start, 3), stop_reason=stop_reason)
errors = []
try:
    validate()
    assert sha(entry) == fixture_sha
    assert sha(website) == sha(out/'cookbook-collections.md') == record['website_source_sha256']
except Exception as error:
    errors.append(repr(error))
record['identity_errors'] = errors
record['exact_stdout'] = (out/'stdout.log').read_bytes() == expected
record['logs'] = {name: sha(out/name) for name in ('stdout.log', 'stderr.log')}
record['status'] = 'passed' if process.returncode == 0 and stop_reason is None and not errors and record['exact_stdout'] else 'failed'
(out/'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k: record[k] for k in ('status', 'returncode', 'seconds', 'stop_reason', 'exact_stdout', 'identity_errors')}))
raise SystemExit(0 if record['status'] == 'passed' else 1)
