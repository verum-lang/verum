target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 2, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %neg = sub i64 0, %r0
  store i64 %neg, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  store i64 %r1, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %siv_bytes = call ptr @verum_cbgr_allocate(i64 4)
  %siv_byte_shift = lshr i64 %r2, 0
  %siv_byte = trunc i64 %siv_byte_shift to i8
  %siv_byte_slot = getelementptr inbounds i8, ptr %siv_bytes, i64 0
  store i8 %siv_byte, ptr %siv_byte_slot, align 1
  %siv_byte_shift1 = lshr i64 %r2, 8
  %siv_byte2 = trunc i64 %siv_byte_shift1 to i8
  %siv_byte_slot3 = getelementptr inbounds i8, ptr %siv_bytes, i64 1
  store i8 %siv_byte2, ptr %siv_byte_slot3, align 1
  %siv_byte_shift4 = lshr i64 %r2, 16
  %siv_byte5 = trunc i64 %siv_byte_shift4 to i8
  %siv_byte_slot6 = getelementptr inbounds i8, ptr %siv_bytes, i64 2
  store i8 %siv_byte5, ptr %siv_byte_slot6, align 1
  %siv_byte_shift7 = lshr i64 %r2, 24
  %siv_byte8 = trunc i64 %siv_byte_shift7 to i8
  %siv_byte_slot9 = getelementptr inbounds i8, ptr %siv_bytes, i64 3
  store i8 %siv_byte8, ptr %siv_byte_slot9, align 1
  %r0_ptr_to_i64 = ptrtoint ptr %siv_bytes to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r010 = load i64, ptr %r0_slot, align 8
  store i64 %r010, ptr %r3_slot, align 8
  %r211 = load i64, ptr %r2_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %r312 = load i64, ptr %r3_slot, align 8
  ret i64 %r312
}

