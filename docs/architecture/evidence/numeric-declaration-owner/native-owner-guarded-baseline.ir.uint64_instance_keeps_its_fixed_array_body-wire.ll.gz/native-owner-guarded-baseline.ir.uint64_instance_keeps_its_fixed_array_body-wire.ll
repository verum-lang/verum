target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r6_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 1, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %method_call = call i64 @UInt64.to_be_bytes(i64 %r1)
  store i64 %method_call, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  store i64 %r2, ptr %r3_slot, align 8
  store i64 0, ptr %r4_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %arr_ptr = inttoptr i64 %r3 to ptr
  %r4 = load i64, ptr %r4_slot, align 8
  %backing_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %backing_int = load i64, ptr %backing_slot, align 8
  %backing_ptr = inttoptr i64 %backing_int to ptr
  %geteu_w0 = load i64, ptr %arr_ptr, align 8
  %geteu_is_cell = icmp uge i64 %geteu_w0, 4294967296
  br i1 %geteu_is_cell, label %geteu_cv_cell, label %geteu_cv_obj

geteu_cv_cell:                                    ; preds = %block_0
  %geteu_cv_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 8
  %geteu_cv_cell_len = load i64, ptr %geteu_cv_len_slot, align 8
  %geteu_cv_elem_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 16
  %geteu_cv_elem_raw = load i64, ptr %geteu_cv_elem_slot, align 8
  %geteu_cv_e1 = icmp eq i64 %geteu_cv_elem_raw, 1
  %geteu_cv_ew = icmp eq i64 %geteu_cv_elem_raw, 2
  %geteu_cv_edom = or i1 %geteu_cv_e1, %geteu_cv_ew
  %geteu_cv_ew1 = icmp eq i64 %geteu_cv_elem_raw, 4
  %geteu_cv_edom2 = or i1 %geteu_cv_edom, %geteu_cv_ew1
  %geteu_cv_ew3 = icmp eq i64 %geteu_cv_elem_raw, 8
  %geteu_cv_edom4 = or i1 %geteu_cv_edom2, %geteu_cv_ew3
  %geteu_cv_elem = select i1 %geteu_cv_edom4, i64 %geteu_cv_elem_raw, i64 8
  br label %geteu_cv_done

geteu_cv_obj:                                     ; preds = %block_0
  %geteu_cv_tid = load i32, ptr %arr_ptr, align 4
  %geteu_cv_is_tuple = icmp eq i32 %geteu_cv_tid, 521
  %geteu_cv_is_bslice = icmp eq i32 %geteu_cv_tid, 528
  %geteu_cv_is_pack = or i1 %geteu_cv_is_tuple, %geteu_cv_is_bslice
  br i1 %geteu_cv_is_pack, label %geteu_cv_pack, label %geteu_cv_list

geteu_cv_pack:                                    ; preds = %geteu_cv_obj
  %geteu_cv_pk_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_pk_data = load i64, ptr %geteu_cv_pk_data_slot, align 8
  %geteu_cv_pk_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 32
  %geteu_cv_pk_len = load i64, ptr %geteu_cv_pk_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_list:                                    ; preds = %geteu_cv_obj
  %geteu_cv_ls_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %geteu_cv_ls_data = load i64, ptr %geteu_cv_ls_data_slot, align 8
  %geteu_cv_ls_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_ls_len = load i64, ptr %geteu_cv_ls_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_done:                                    ; preds = %geteu_cv_list, %geteu_cv_pack, %geteu_cv_cell
  %geteu_cv_data = phi i64 [ %geteu_w0, %geteu_cv_cell ], [ %geteu_cv_pk_data, %geteu_cv_pack ], [ %geteu_cv_ls_data, %geteu_cv_list ]
  %geteu_cv_len = phi i64 [ %geteu_cv_cell_len, %geteu_cv_cell ], [ %geteu_cv_pk_len, %geteu_cv_pack ], [ %geteu_cv_ls_len, %geteu_cv_list ]
  %geteu_cv_elem5 = phi i64 [ %geteu_cv_elem, %geteu_cv_cell ], [ 1, %geteu_cv_pack ], [ 8, %geteu_cv_list ]
  %geteu_off = mul i64 %r4, %geteu_cv_elem5
  %geteu_addr = add i64 %geteu_cv_data, %geteu_off
  %geteu_eptr = inttoptr i64 %geteu_addr to ptr
  switch i64 %geteu_cv_elem5, label %geteu_lw8 [
    i64 1, label %geteu_lw1
    i64 2, label %geteu_lw2
    i64 4, label %geteu_lw4
  ]

geteu_lw1:                                        ; preds = %geteu_cv_done
  %geteu_lv = load i8, ptr %geteu_eptr, align 1
  %geteu_lz = zext i8 %geteu_lv to i64
  br label %geteu_lmerge

geteu_lw2:                                        ; preds = %geteu_cv_done
  %geteu_lv6 = load i16, ptr %geteu_eptr, align 2
  %geteu_lz7 = zext i16 %geteu_lv6 to i64
  br label %geteu_lmerge

geteu_lw4:                                        ; preds = %geteu_cv_done
  %geteu_lv8 = load i32, ptr %geteu_eptr, align 4
  %geteu_lz9 = zext i32 %geteu_lv8 to i64
  br label %geteu_lmerge

geteu_lw8:                                        ; preds = %geteu_cv_done
  %geteu_lv810 = load i64, ptr %geteu_eptr, align 8
  br label %geteu_lmerge

geteu_lmerge:                                     ; preds = %geteu_lw8, %geteu_lw4, %geteu_lw2, %geteu_lw1
  %geteu_lval = phi i64 [ %geteu_lz, %geteu_lw1 ], [ %geteu_lz7, %geteu_lw2 ], [ %geteu_lz9, %geteu_lw4 ], [ %geteu_lv810, %geteu_lw8 ]
  store i64 %geteu_lval, ptr %r5_slot, align 8
  store i64 100, ptr %r4_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %r411 = load i64, ptr %r4_slot, align 8
  %mul = mul i64 %r5, %r411
  store i64 %mul, ptr %r6_slot, align 8
  %r312 = load i64, ptr %r3_slot, align 8
  %listv_ptr = inttoptr i64 %r312 to ptr
  %lenlv_w0 = load i64, ptr %listv_ptr, align 8
  %lenlv_is_cell = icmp uge i64 %lenlv_w0, 4294967296
  br i1 %lenlv_is_cell, label %lenlv_cv_cell, label %lenlv_cv_obj

lenlv_cv_cell:                                    ; preds = %geteu_lmerge
  %lenlv_cv_len_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 8
  %lenlv_cv_cell_len = load i64, ptr %lenlv_cv_len_slot, align 8
  %lenlv_cv_elem_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 16
  %lenlv_cv_elem_raw = load i64, ptr %lenlv_cv_elem_slot, align 8
  %lenlv_cv_e1 = icmp eq i64 %lenlv_cv_elem_raw, 1
  %lenlv_cv_ew = icmp eq i64 %lenlv_cv_elem_raw, 2
  %lenlv_cv_edom = or i1 %lenlv_cv_e1, %lenlv_cv_ew
  %lenlv_cv_ew13 = icmp eq i64 %lenlv_cv_elem_raw, 4
  %lenlv_cv_edom14 = or i1 %lenlv_cv_edom, %lenlv_cv_ew13
  %lenlv_cv_ew15 = icmp eq i64 %lenlv_cv_elem_raw, 8
  %lenlv_cv_edom16 = or i1 %lenlv_cv_edom14, %lenlv_cv_ew15
  %lenlv_cv_elem = select i1 %lenlv_cv_edom16, i64 %lenlv_cv_elem_raw, i64 8
  br label %lenlv_cv_done

lenlv_cv_obj:                                     ; preds = %geteu_lmerge
  %lenlv_cv_tid = load i32, ptr %listv_ptr, align 4
  %lenlv_cv_is_tuple = icmp eq i32 %lenlv_cv_tid, 521
  %lenlv_cv_is_bslice = icmp eq i32 %lenlv_cv_tid, 528
  %lenlv_cv_is_pack = or i1 %lenlv_cv_is_tuple, %lenlv_cv_is_bslice
  br i1 %lenlv_cv_is_pack, label %lenlv_cv_pack, label %lenlv_cv_list

lenlv_cv_pack:                                    ; preds = %lenlv_cv_obj
  %lenlv_cv_pk_data_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 24
  %lenlv_cv_pk_data = load i64, ptr %lenlv_cv_pk_data_slot, align 8
  %lenlv_cv_pk_len_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 32
  %lenlv_cv_pk_len = load i64, ptr %lenlv_cv_pk_len_slot, align 8
  br label %lenlv_cv_done

lenlv_cv_list:                                    ; preds = %lenlv_cv_obj
  %lenlv_cv_ls_data_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 40
  %lenlv_cv_ls_data = load i64, ptr %lenlv_cv_ls_data_slot, align 8
  %lenlv_cv_ls_len_slot = getelementptr inbounds i8, ptr %listv_ptr, i64 24
  %lenlv_cv_ls_len = load i64, ptr %lenlv_cv_ls_len_slot, align 8
  br label %lenlv_cv_done

lenlv_cv_done:                                    ; preds = %lenlv_cv_list, %lenlv_cv_pack, %lenlv_cv_cell
  %lenlv_cv_data = phi i64 [ %lenlv_w0, %lenlv_cv_cell ], [ %lenlv_cv_pk_data, %lenlv_cv_pack ], [ %lenlv_cv_ls_data, %lenlv_cv_list ]
  %lenlv_cv_len = phi i64 [ %lenlv_cv_cell_len, %lenlv_cv_cell ], [ %lenlv_cv_pk_len, %lenlv_cv_pack ], [ %lenlv_cv_ls_len, %lenlv_cv_list ]
  %lenlv_cv_elem17 = phi i64 [ %lenlv_cv_elem, %lenlv_cv_cell ], [ 1, %lenlv_cv_pack ], [ 8, %lenlv_cv_list ]
  store i64 %lenlv_cv_len, ptr %r4_slot, align 8
  %r6 = load i64, ptr %r6_slot, align 8
  %r418 = load i64, ptr %r4_slot, align 8
  %add = add i64 %r6, %r418
  store i64 %add, ptr %r5_slot, align 8
  %r519 = load i64, ptr %r5_slot, align 8
  store i64 %r519, ptr %r4_slot, align 8
  %r320 = load i64, ptr %r3_slot, align 8
  %r121 = load i64, ptr %r1_slot, align 8
  %r422 = load i64, ptr %r4_slot, align 8
  %r423 = load i64, ptr %r4_slot, align 8
  ret i64 %r423
}

; Function Attrs: noinline nounwind optnone
define internal i64 @UInt64.to_be_bytes(i64 %0) #5 {
block_0:
  %r4_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 %0, ptr %r0_slot, align 8
  store i64 8, ptr %r2_slot, align 8
  store i64 17, ptr %r3_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r2)
  %r1_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r1_ptr_to_i64, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_init8 = trunc i64 %r3 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r2, i1 false)
  %r1 = load i64, ptr %r1_slot, align 8
  store i64 %r1, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  store i64 %r4, ptr %r3_slot, align 8
  %r31 = load i64, ptr %r3_slot, align 8
  %r32 = load i64, ptr %r3_slot, align 8
  ret i64 %r32
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

