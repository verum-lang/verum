target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r543_slot = alloca i64, align 8
  %r542_slot = alloca i64, align 8
  %r541_slot = alloca i64, align 8
  %r540_slot = alloca i64, align 8
  %r539_slot = alloca i64, align 8
  %r538_slot = alloca i64, align 8
  %r537_slot = alloca i64, align 8
  %r536_slot = alloca i64, align 8
  %r535_slot = alloca i64, align 8
  %r534_slot = alloca i64, align 8
  %r533_slot = alloca i64, align 8
  %r532_slot = alloca i64, align 8
  %r531_slot = alloca i64, align 8
  %r530_slot = alloca i64, align 8
  %r529_slot = alloca i64, align 8
  %r528_slot = alloca i64, align 8
  %r527_slot = alloca i64, align 8
  %r526_slot = alloca i64, align 8
  %r525_slot = alloca i64, align 8
  %r524_slot = alloca i64, align 8
  %r523_slot = alloca i64, align 8
  %r522_slot = alloca i64, align 8
  %r521_slot = alloca i64, align 8
  %r520_slot = alloca i64, align 8
  %r519_slot = alloca i64, align 8
  %r518_slot = alloca i64, align 8
  %r517_slot = alloca i64, align 8
  %r516_slot = alloca i64, align 8
  %r515_slot = alloca i64, align 8
  %r514_slot = alloca i64, align 8
  %r513_slot = alloca i64, align 8
  %r512_slot = alloca i64, align 8
  %r511_slot = alloca i64, align 8
  %r510_slot = alloca i64, align 8
  %r509_slot = alloca i64, align 8
  %r508_slot = alloca i64, align 8
  %r507_slot = alloca i64, align 8
  %r506_slot = alloca i64, align 8
  %r505_slot = alloca i64, align 8
  %r504_slot = alloca i64, align 8
  %r503_slot = alloca i64, align 8
  %r502_slot = alloca i64, align 8
  %r501_slot = alloca i64, align 8
  %r500_slot = alloca i64, align 8
  %r499_slot = alloca i64, align 8
  %r498_slot = alloca i64, align 8
  %r497_slot = alloca i64, align 8
  %r496_slot = alloca i64, align 8
  %r495_slot = alloca i64, align 8
  %r494_slot = alloca i64, align 8
  %r493_slot = alloca i64, align 8
  %r492_slot = alloca i64, align 8
  %r491_slot = alloca i64, align 8
  %r490_slot = alloca i64, align 8
  %r489_slot = alloca i64, align 8
  %r488_slot = alloca i64, align 8
  %r487_slot = alloca i64, align 8
  %r486_slot = alloca i64, align 8
  %r485_slot = alloca i64, align 8
  %r484_slot = alloca i64, align 8
  %r483_slot = alloca i64, align 8
  %r482_slot = alloca i64, align 8
  %r481_slot = alloca i64, align 8
  %r480_slot = alloca i64, align 8
  %r479_slot = alloca i64, align 8
  %r478_slot = alloca i64, align 8
  %r477_slot = alloca i64, align 8
  %r476_slot = alloca i64, align 8
  %r475_slot = alloca i64, align 8
  %r474_slot = alloca i64, align 8
  %r473_slot = alloca i64, align 8
  %r472_slot = alloca i64, align 8
  %r471_slot = alloca i64, align 8
  %r470_slot = alloca i64, align 8
  %r469_slot = alloca i64, align 8
  %r468_slot = alloca i64, align 8
  %r467_slot = alloca i64, align 8
  %r466_slot = alloca i64, align 8
  %r465_slot = alloca i64, align 8
  %r464_slot = alloca i64, align 8
  %r463_slot = alloca i64, align 8
  %r462_slot = alloca i64, align 8
  %r461_slot = alloca i64, align 8
  %r460_slot = alloca i64, align 8
  %r459_slot = alloca i64, align 8
  %r458_slot = alloca i64, align 8
  %r457_slot = alloca i64, align 8
  %r456_slot = alloca i64, align 8
  %r455_slot = alloca i64, align 8
  %r454_slot = alloca i64, align 8
  %r453_slot = alloca i64, align 8
  %r452_slot = alloca i64, align 8
  %r451_slot = alloca i64, align 8
  %r450_slot = alloca i64, align 8
  %r449_slot = alloca i64, align 8
  %r448_slot = alloca i64, align 8
  %r447_slot = alloca i64, align 8
  %r446_slot = alloca i64, align 8
  %r445_slot = alloca i64, align 8
  %r444_slot = alloca i64, align 8
  %r443_slot = alloca i64, align 8
  %r442_slot = alloca i64, align 8
  %r441_slot = alloca i64, align 8
  %r440_slot = alloca i64, align 8
  %r439_slot = alloca i64, align 8
  %r438_slot = alloca i64, align 8
  %r437_slot = alloca i64, align 8
  %r436_slot = alloca i64, align 8
  %r435_slot = alloca i64, align 8
  %r434_slot = alloca i64, align 8
  %r433_slot = alloca i64, align 8
  %r432_slot = alloca i64, align 8
  %r431_slot = alloca i64, align 8
  %r430_slot = alloca i64, align 8
  %r429_slot = alloca i64, align 8
  %r428_slot = alloca i64, align 8
  %r427_slot = alloca i64, align 8
  %r426_slot = alloca i64, align 8
  %r425_slot = alloca i64, align 8
  %r424_slot = alloca i64, align 8
  %r423_slot = alloca i64, align 8
  %r422_slot = alloca i64, align 8
  %r421_slot = alloca i64, align 8
  %r420_slot = alloca i64, align 8
  %r419_slot = alloca i64, align 8
  %r418_slot = alloca i64, align 8
  %r417_slot = alloca i64, align 8
  %r416_slot = alloca i64, align 8
  %r415_slot = alloca i64, align 8
  %r414_slot = alloca i64, align 8
  %r413_slot = alloca i64, align 8
  %r412_slot = alloca i64, align 8
  %r411_slot = alloca i64, align 8
  %r410_slot = alloca i64, align 8
  %r409_slot = alloca i64, align 8
  %r408_slot = alloca i64, align 8
  %r407_slot = alloca i64, align 8
  %r406_slot = alloca i64, align 8
  %r405_slot = alloca i64, align 8
  %r404_slot = alloca i64, align 8
  %r403_slot = alloca i64, align 8
  %r402_slot = alloca i64, align 8
  %r401_slot = alloca i64, align 8
  %r400_slot = alloca i64, align 8
  %r399_slot = alloca i64, align 8
  %r398_slot = alloca i64, align 8
  %r397_slot = alloca i64, align 8
  %r396_slot = alloca i64, align 8
  %r395_slot = alloca i64, align 8
  %r394_slot = alloca i64, align 8
  %r393_slot = alloca i64, align 8
  %r392_slot = alloca i64, align 8
  %r391_slot = alloca i64, align 8
  %r390_slot = alloca i64, align 8
  %r389_slot = alloca i64, align 8
  %r388_slot = alloca i64, align 8
  %r387_slot = alloca i64, align 8
  %r386_slot = alloca i64, align 8
  %r385_slot = alloca i64, align 8
  %r384_slot = alloca i64, align 8
  %r383_slot = alloca i64, align 8
  %r382_slot = alloca i64, align 8
  %r381_slot = alloca i64, align 8
  %r380_slot = alloca i64, align 8
  %r379_slot = alloca i64, align 8
  %r378_slot = alloca i64, align 8
  %r377_slot = alloca i64, align 8
  %r376_slot = alloca i64, align 8
  %r375_slot = alloca i64, align 8
  %r374_slot = alloca i64, align 8
  %r373_slot = alloca i64, align 8
  %r372_slot = alloca i64, align 8
  %r371_slot = alloca i64, align 8
  %r370_slot = alloca i64, align 8
  %r369_slot = alloca i64, align 8
  %r368_slot = alloca i64, align 8
  %r367_slot = alloca i64, align 8
  %r366_slot = alloca i64, align 8
  %r365_slot = alloca i64, align 8
  %r364_slot = alloca i64, align 8
  %r363_slot = alloca i64, align 8
  %r362_slot = alloca i64, align 8
  %r361_slot = alloca i64, align 8
  %r360_slot = alloca i64, align 8
  %r359_slot = alloca i64, align 8
  %r358_slot = alloca i64, align 8
  %r357_slot = alloca i64, align 8
  %r356_slot = alloca i64, align 8
  %r355_slot = alloca i64, align 8
  %r354_slot = alloca i64, align 8
  %r353_slot = alloca i64, align 8
  %r352_slot = alloca i64, align 8
  %r351_slot = alloca i64, align 8
  %r350_slot = alloca i64, align 8
  %r349_slot = alloca i64, align 8
  %r348_slot = alloca i64, align 8
  %r347_slot = alloca i64, align 8
  %r346_slot = alloca i64, align 8
  %r345_slot = alloca i64, align 8
  %r344_slot = alloca i64, align 8
  %r343_slot = alloca i64, align 8
  %r342_slot = alloca i64, align 8
  %r341_slot = alloca i64, align 8
  %r340_slot = alloca i64, align 8
  %r339_slot = alloca i64, align 8
  %r338_slot = alloca i64, align 8
  %r337_slot = alloca i64, align 8
  %r336_slot = alloca i64, align 8
  %r335_slot = alloca i64, align 8
  %r334_slot = alloca i64, align 8
  %r333_slot = alloca i64, align 8
  %r332_slot = alloca i64, align 8
  %r331_slot = alloca i64, align 8
  %r330_slot = alloca i64, align 8
  %r329_slot = alloca i64, align 8
  %r328_slot = alloca i64, align 8
  %r327_slot = alloca i64, align 8
  %r326_slot = alloca i64, align 8
  %r325_slot = alloca i64, align 8
  %r324_slot = alloca i64, align 8
  %r323_slot = alloca i64, align 8
  %r322_slot = alloca i64, align 8
  %r321_slot = alloca i64, align 8
  %r320_slot = alloca i64, align 8
  %r319_slot = alloca i64, align 8
  %r318_slot = alloca i64, align 8
  %r317_slot = alloca i64, align 8
  %r316_slot = alloca i64, align 8
  %r315_slot = alloca i64, align 8
  %r314_slot = alloca i64, align 8
  %r313_slot = alloca i64, align 8
  %r312_slot = alloca i64, align 8
  %r311_slot = alloca i64, align 8
  %r310_slot = alloca i64, align 8
  %r309_slot = alloca i64, align 8
  %r308_slot = alloca i64, align 8
  %r307_slot = alloca i64, align 8
  %r306_slot = alloca i64, align 8
  %r305_slot = alloca i64, align 8
  %r304_slot = alloca i64, align 8
  %r303_slot = alloca i64, align 8
  %r302_slot = alloca i64, align 8
  %r301_slot = alloca i64, align 8
  %r300_slot = alloca i64, align 8
  %r299_slot = alloca i64, align 8
  %r298_slot = alloca i64, align 8
  %r297_slot = alloca i64, align 8
  %r296_slot = alloca i64, align 8
  %r295_slot = alloca i64, align 8
  %r294_slot = alloca i64, align 8
  %r293_slot = alloca i64, align 8
  %r292_slot = alloca i64, align 8
  %r291_slot = alloca i64, align 8
  %r290_slot = alloca i64, align 8
  %r289_slot = alloca i64, align 8
  %r288_slot = alloca i64, align 8
  %r287_slot = alloca i64, align 8
  %r286_slot = alloca i64, align 8
  %r285_slot = alloca i64, align 8
  %r284_slot = alloca i64, align 8
  %r283_slot = alloca i64, align 8
  %r282_slot = alloca i64, align 8
  %r281_slot = alloca i64, align 8
  %r280_slot = alloca i64, align 8
  %r279_slot = alloca i64, align 8
  %r278_slot = alloca i64, align 8
  %r277_slot = alloca i64, align 8
  %r276_slot = alloca i64, align 8
  %r275_slot = alloca i64, align 8
  %r274_slot = alloca i64, align 8
  %r273_slot = alloca i64, align 8
  %r272_slot = alloca i64, align 8
  %r271_slot = alloca i64, align 8
  %r270_slot = alloca i64, align 8
  %r269_slot = alloca i64, align 8
  %r268_slot = alloca i64, align 8
  %r267_slot = alloca i64, align 8
  %r266_slot = alloca i64, align 8
  %r265_slot = alloca i64, align 8
  %r264_slot = alloca i64, align 8
  %r263_slot = alloca i64, align 8
  %r262_slot = alloca i64, align 8
  %r261_slot = alloca i64, align 8
  %r260_slot = alloca i64, align 8
  %r259_slot = alloca i64, align 8
  %r258_slot = alloca i64, align 8
  %r257_slot = alloca i64, align 8
  %r256_slot = alloca i64, align 8
  %r255_slot = alloca i64, align 8
  %r254_slot = alloca i64, align 8
  %r253_slot = alloca i64, align 8
  %r252_slot = alloca i64, align 8
  %r251_slot = alloca i64, align 8
  %r250_slot = alloca i64, align 8
  %r249_slot = alloca i64, align 8
  %r248_slot = alloca i64, align 8
  %r247_slot = alloca i64, align 8
  %r246_slot = alloca i64, align 8
  %r245_slot = alloca i64, align 8
  %r244_slot = alloca i64, align 8
  %r243_slot = alloca i64, align 8
  %r242_slot = alloca i64, align 8
  %r241_slot = alloca i64, align 8
  %r240_slot = alloca i64, align 8
  %r239_slot = alloca i64, align 8
  %r238_slot = alloca i64, align 8
  %r237_slot = alloca i64, align 8
  %r236_slot = alloca i64, align 8
  %r235_slot = alloca i64, align 8
  %r234_slot = alloca i64, align 8
  %r233_slot = alloca i64, align 8
  %r232_slot = alloca i64, align 8
  %r231_slot = alloca i64, align 8
  %r230_slot = alloca i64, align 8
  %r229_slot = alloca i64, align 8
  %r228_slot = alloca i64, align 8
  %r227_slot = alloca i64, align 8
  %r226_slot = alloca i64, align 8
  %r225_slot = alloca i64, align 8
  %r224_slot = alloca i64, align 8
  %r223_slot = alloca i64, align 8
  %r222_slot = alloca i64, align 8
  %r221_slot = alloca i64, align 8
  %r220_slot = alloca i64, align 8
  %r219_slot = alloca i64, align 8
  %r218_slot = alloca i64, align 8
  %r217_slot = alloca i64, align 8
  %r216_slot = alloca i64, align 8
  %r215_slot = alloca i64, align 8
  %r214_slot = alloca i64, align 8
  %r213_slot = alloca i64, align 8
  %r212_slot = alloca i64, align 8
  %r211_slot = alloca i64, align 8
  %r210_slot = alloca i64, align 8
  %r209_slot = alloca i64, align 8
  %r208_slot = alloca i64, align 8
  %r207_slot = alloca i64, align 8
  %r206_slot = alloca i64, align 8
  %r205_slot = alloca i64, align 8
  %r204_slot = alloca i64, align 8
  %r203_slot = alloca i64, align 8
  %r202_slot = alloca i64, align 8
  %r201_slot = alloca i64, align 8
  %r200_slot = alloca i64, align 8
  %r199_slot = alloca i64, align 8
  %r198_slot = alloca i64, align 8
  %r197_slot = alloca i64, align 8
  %r196_slot = alloca i64, align 8
  %r195_slot = alloca i64, align 8
  %r194_slot = alloca i64, align 8
  %r193_slot = alloca i64, align 8
  %r192_slot = alloca i64, align 8
  %r191_slot = alloca i64, align 8
  %r190_slot = alloca i64, align 8
  %r189_slot = alloca i64, align 8
  %r188_slot = alloca i64, align 8
  %r187_slot = alloca i64, align 8
  %r186_slot = alloca i64, align 8
  %r185_slot = alloca i64, align 8
  %r184_slot = alloca i64, align 8
  %r183_slot = alloca i64, align 8
  %r182_slot = alloca i64, align 8
  %r181_slot = alloca i64, align 8
  %r180_slot = alloca i64, align 8
  %r179_slot = alloca i64, align 8
  %r178_slot = alloca i64, align 8
  %r177_slot = alloca i64, align 8
  %r176_slot = alloca i64, align 8
  %r175_slot = alloca i64, align 8
  %r174_slot = alloca i64, align 8
  %r173_slot = alloca i64, align 8
  %r172_slot = alloca i64, align 8
  %r171_slot = alloca i64, align 8
  %r170_slot = alloca i64, align 8
  %r169_slot = alloca i64, align 8
  %r168_slot = alloca i64, align 8
  %r167_slot = alloca i64, align 8
  %r166_slot = alloca i64, align 8
  %r165_slot = alloca i64, align 8
  %r164_slot = alloca i64, align 8
  %r163_slot = alloca i64, align 8
  %r162_slot = alloca i64, align 8
  %r161_slot = alloca i64, align 8
  %r160_slot = alloca i64, align 8
  %r159_slot = alloca i64, align 8
  %r158_slot = alloca i64, align 8
  %r157_slot = alloca i64, align 8
  %r156_slot = alloca i64, align 8
  %r155_slot = alloca i64, align 8
  %r154_slot = alloca i64, align 8
  %r153_slot = alloca i64, align 8
  %r152_slot = alloca i64, align 8
  %r151_slot = alloca i64, align 8
  %r150_slot = alloca i64, align 8
  %r149_slot = alloca i64, align 8
  %r148_slot = alloca i64, align 8
  %r147_slot = alloca i64, align 8
  %r146_slot = alloca i64, align 8
  %r145_slot = alloca i64, align 8
  %r144_slot = alloca i64, align 8
  %r143_slot = alloca i64, align 8
  %r142_slot = alloca i64, align 8
  %r141_slot = alloca i64, align 8
  %r140_slot = alloca i64, align 8
  %r139_slot = alloca i64, align 8
  %r138_slot = alloca i64, align 8
  %r137_slot = alloca i64, align 8
  %r136_slot = alloca i64, align 8
  %r135_slot = alloca i64, align 8
  %r134_slot = alloca i64, align 8
  %r133_slot = alloca i64, align 8
  %r132_slot = alloca i64, align 8
  %r131_slot = alloca i64, align 8
  %r130_slot = alloca i64, align 8
  %r129_slot = alloca i64, align 8
  %r128_slot = alloca i64, align 8
  %r127_slot = alloca i64, align 8
  %r126_slot = alloca i64, align 8
  %r125_slot = alloca i64, align 8
  %r124_slot = alloca i64, align 8
  %r123_slot = alloca i64, align 8
  %r122_slot = alloca i64, align 8
  %r121_slot = alloca i64, align 8
  %r120_slot = alloca i64, align 8
  %r119_slot = alloca i64, align 8
  %r118_slot = alloca i64, align 8
  %r117_slot = alloca i64, align 8
  %r116_slot = alloca i64, align 8
  %r115_slot = alloca i64, align 8
  %r114_slot = alloca i64, align 8
  %r113_slot = alloca i64, align 8
  %r112_slot = alloca i64, align 8
  %r111_slot = alloca i64, align 8
  %r110_slot = alloca i64, align 8
  %r109_slot = alloca i64, align 8
  %r108_slot = alloca i64, align 8
  %r107_slot = alloca i64, align 8
  %r106_slot = alloca i64, align 8
  %r105_slot = alloca i64, align 8
  %r104_slot = alloca i64, align 8
  %r103_slot = alloca i64, align 8
  %r102_slot = alloca i64, align 8
  %r101_slot = alloca i64, align 8
  %r100_slot = alloca i64, align 8
  %r99_slot = alloca i64, align 8
  %r98_slot = alloca i64, align 8
  %r97_slot = alloca i64, align 8
  %r96_slot = alloca i64, align 8
  %r95_slot = alloca i64, align 8
  %r94_slot = alloca i64, align 8
  %r93_slot = alloca i64, align 8
  %r92_slot = alloca i64, align 8
  %r91_slot = alloca i64, align 8
  %r90_slot = alloca i64, align 8
  %r89_slot = alloca i64, align 8
  %r88_slot = alloca i64, align 8
  %r87_slot = alloca i64, align 8
  %r86_slot = alloca i64, align 8
  %r85_slot = alloca i64, align 8
  %r84_slot = alloca i64, align 8
  %r83_slot = alloca i64, align 8
  %r82_slot = alloca i64, align 8
  %r81_slot = alloca i64, align 8
  %r80_slot = alloca i64, align 8
  %r79_slot = alloca i64, align 8
  %r78_slot = alloca i64, align 8
  %r77_slot = alloca i64, align 8
  %r76_slot = alloca i64, align 8
  %r75_slot = alloca i64, align 8
  %r74_slot = alloca i64, align 8
  %r73_slot = alloca i64, align 8
  %r72_slot = alloca i64, align 8
  %r71_slot = alloca i64, align 8
  %r70_slot = alloca i64, align 8
  %r69_slot = alloca i64, align 8
  %r68_slot = alloca i64, align 8
  %r67_slot = alloca i64, align 8
  %r66_slot = alloca i64, align 8
  %r65_slot = alloca i64, align 8
  %r64_slot = alloca i64, align 8
  %r63_slot = alloca i64, align 8
  %r62_slot = alloca i64, align 8
  %r61_slot = alloca i64, align 8
  %r60_slot = alloca i64, align 8
  %r59_slot = alloca i64, align 8
  %r58_slot = alloca i64, align 8
  %r57_slot = alloca i64, align 8
  %r56_slot = alloca i64, align 8
  %r55_slot = alloca i64, align 8
  %r54_slot = alloca i64, align 8
  %r53_slot = alloca i64, align 8
  %r52_slot = alloca i64, align 8
  %r51_slot = alloca i64, align 8
  %r50_slot = alloca i64, align 8
  %r49_slot = alloca i64, align 8
  %r48_slot = alloca i64, align 8
  %r47_slot = alloca i64, align 8
  %r46_slot = alloca i64, align 8
  %r45_slot = alloca i64, align 8
  %r44_slot = alloca i64, align 8
  %r43_slot = alloca i64, align 8
  %r42_slot = alloca i64, align 8
  %r41_slot = alloca i64, align 8
  %r40_slot = alloca i64, align 8
  %r39_slot = alloca i64, align 8
  %r38_slot = alloca i64, align 8
  %r37_slot = alloca i64, align 8
  %r36_slot = alloca i64, align 8
  %r35_slot = alloca i64, align 8
  %r34_slot = alloca i64, align 8
  %r33_slot = alloca i64, align 8
  %r32_slot = alloca i64, align 8
  %r31_slot = alloca i64, align 8
  %r30_slot = alloca i64, align 8
  %r29_slot = alloca i64, align 8
  %r28_slot = alloca i64, align 8
  %r27_slot = alloca i64, align 8
  %r26_slot = alloca i64, align 8
  %r25_slot = alloca i64, align 8
  %r24_slot = alloca i64, align 8
  %r23_slot = alloca i64, align 8
  %r22_slot = alloca i64, align 8
  %r21_slot = alloca i64, align 8
  %r20_slot = alloca i64, align 8
  %r19_slot = alloca i64, align 8
  %r18_slot = alloca i64, align 8
  %r17_slot = alloca i64, align 8
  %r16_slot = alloca i64, align 8
  %r15_slot = alloca i64, align 8
  %r14_slot = alloca i64, align 8
  %r13_slot = alloca i64, align 8
  %r12_slot = alloca i64, align 8
  %r11_slot = alloca i64, align 8
  %r10_slot = alloca i64, align 8
  %r9_slot = alloca i64, align 8
  %r8_slot = alloca i64, align 8
  %r7_slot = alloca i64, align 8
  %r6_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 0, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  store i64 %r2, ptr %r3_slot, align 8
  store i64 2, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  store i64 %r4, ptr %r5_slot, align 8
  store i64 3, ptr %r6_slot, align 8
  %r6 = load i64, ptr %r6_slot, align 8
  store i64 %r6, ptr %r7_slot, align 8
  store i64 4, ptr %r8_slot, align 8
  %r8 = load i64, ptr %r8_slot, align 8
  store i64 %r8, ptr %r9_slot, align 8
  store i64 5, ptr %r10_slot, align 8
  %r10 = load i64, ptr %r10_slot, align 8
  store i64 %r10, ptr %r11_slot, align 8
  store i64 6, ptr %r12_slot, align 8
  %r12 = load i64, ptr %r12_slot, align 8
  store i64 %r12, ptr %r13_slot, align 8
  store i64 7, ptr %r14_slot, align 8
  %r14 = load i64, ptr %r14_slot, align 8
  store i64 %r14, ptr %r15_slot, align 8
  store i64 8, ptr %r16_slot, align 8
  %r16 = load i64, ptr %r16_slot, align 8
  store i64 %r16, ptr %r17_slot, align 8
  store i64 9, ptr %r18_slot, align 8
  %r18 = load i64, ptr %r18_slot, align 8
  store i64 %r18, ptr %r19_slot, align 8
  store i64 10, ptr %r20_slot, align 8
  %r20 = load i64, ptr %r20_slot, align 8
  store i64 %r20, ptr %r21_slot, align 8
  store i64 11, ptr %r22_slot, align 8
  %r22 = load i64, ptr %r22_slot, align 8
  store i64 %r22, ptr %r23_slot, align 8
  store i64 12, ptr %r24_slot, align 8
  %r24 = load i64, ptr %r24_slot, align 8
  store i64 %r24, ptr %r25_slot, align 8
  store i64 13, ptr %r26_slot, align 8
  %r26 = load i64, ptr %r26_slot, align 8
  store i64 %r26, ptr %r27_slot, align 8
  store i64 14, ptr %r28_slot, align 8
  %r28 = load i64, ptr %r28_slot, align 8
  store i64 %r28, ptr %r29_slot, align 8
  store i64 15, ptr %r30_slot, align 8
  %r30 = load i64, ptr %r30_slot, align 8
  store i64 %r30, ptr %r31_slot, align 8
  store i64 16, ptr %r32_slot, align 8
  %r32 = load i64, ptr %r32_slot, align 8
  store i64 %r32, ptr %r33_slot, align 8
  store i64 17, ptr %r34_slot, align 8
  %r34 = load i64, ptr %r34_slot, align 8
  store i64 %r34, ptr %r35_slot, align 8
  store i64 18, ptr %r36_slot, align 8
  %r36 = load i64, ptr %r36_slot, align 8
  store i64 %r36, ptr %r37_slot, align 8
  store i64 19, ptr %r38_slot, align 8
  %r38 = load i64, ptr %r38_slot, align 8
  store i64 %r38, ptr %r39_slot, align 8
  store i64 20, ptr %r40_slot, align 8
  %r40 = load i64, ptr %r40_slot, align 8
  store i64 %r40, ptr %r41_slot, align 8
  store i64 21, ptr %r42_slot, align 8
  %r42 = load i64, ptr %r42_slot, align 8
  store i64 %r42, ptr %r43_slot, align 8
  store i64 22, ptr %r44_slot, align 8
  %r44 = load i64, ptr %r44_slot, align 8
  store i64 %r44, ptr %r45_slot, align 8
  store i64 23, ptr %r46_slot, align 8
  %r46 = load i64, ptr %r46_slot, align 8
  store i64 %r46, ptr %r47_slot, align 8
  store i64 24, ptr %r48_slot, align 8
  %r48 = load i64, ptr %r48_slot, align 8
  store i64 %r48, ptr %r49_slot, align 8
  store i64 25, ptr %r50_slot, align 8
  %r50 = load i64, ptr %r50_slot, align 8
  store i64 %r50, ptr %r51_slot, align 8
  store i64 26, ptr %r52_slot, align 8
  %r52 = load i64, ptr %r52_slot, align 8
  store i64 %r52, ptr %r53_slot, align 8
  store i64 27, ptr %r54_slot, align 8
  %r54 = load i64, ptr %r54_slot, align 8
  store i64 %r54, ptr %r55_slot, align 8
  store i64 28, ptr %r56_slot, align 8
  %r56 = load i64, ptr %r56_slot, align 8
  store i64 %r56, ptr %r57_slot, align 8
  store i64 29, ptr %r58_slot, align 8
  %r58 = load i64, ptr %r58_slot, align 8
  store i64 %r58, ptr %r59_slot, align 8
  store i64 30, ptr %r60_slot, align 8
  %r60 = load i64, ptr %r60_slot, align 8
  store i64 %r60, ptr %r61_slot, align 8
  store i64 31, ptr %r62_slot, align 8
  %r62 = load i64, ptr %r62_slot, align 8
  store i64 %r62, ptr %r63_slot, align 8
  store i64 32, ptr %r64_slot, align 8
  %r64 = load i64, ptr %r64_slot, align 8
  store i64 %r64, ptr %r65_slot, align 8
  store i64 33, ptr %r66_slot, align 8
  %r66 = load i64, ptr %r66_slot, align 8
  store i64 %r66, ptr %r67_slot, align 8
  store i64 34, ptr %r68_slot, align 8
  %r68 = load i64, ptr %r68_slot, align 8
  store i64 %r68, ptr %r69_slot, align 8
  store i64 35, ptr %r70_slot, align 8
  %r70 = load i64, ptr %r70_slot, align 8
  store i64 %r70, ptr %r71_slot, align 8
  store i64 36, ptr %r72_slot, align 8
  %r72 = load i64, ptr %r72_slot, align 8
  store i64 %r72, ptr %r73_slot, align 8
  store i64 37, ptr %r74_slot, align 8
  %r74 = load i64, ptr %r74_slot, align 8
  store i64 %r74, ptr %r75_slot, align 8
  store i64 38, ptr %r76_slot, align 8
  %r76 = load i64, ptr %r76_slot, align 8
  store i64 %r76, ptr %r77_slot, align 8
  store i64 39, ptr %r78_slot, align 8
  %r78 = load i64, ptr %r78_slot, align 8
  store i64 %r78, ptr %r79_slot, align 8
  store i64 40, ptr %r80_slot, align 8
  %r80 = load i64, ptr %r80_slot, align 8
  store i64 %r80, ptr %r81_slot, align 8
  store i64 41, ptr %r82_slot, align 8
  %r82 = load i64, ptr %r82_slot, align 8
  store i64 %r82, ptr %r83_slot, align 8
  store i64 42, ptr %r84_slot, align 8
  %r84 = load i64, ptr %r84_slot, align 8
  store i64 %r84, ptr %r85_slot, align 8
  store i64 43, ptr %r86_slot, align 8
  %r86 = load i64, ptr %r86_slot, align 8
  store i64 %r86, ptr %r87_slot, align 8
  store i64 44, ptr %r88_slot, align 8
  %r88 = load i64, ptr %r88_slot, align 8
  store i64 %r88, ptr %r89_slot, align 8
  store i64 45, ptr %r90_slot, align 8
  %r90 = load i64, ptr %r90_slot, align 8
  store i64 %r90, ptr %r91_slot, align 8
  store i64 46, ptr %r92_slot, align 8
  %r92 = load i64, ptr %r92_slot, align 8
  store i64 %r92, ptr %r93_slot, align 8
  store i64 47, ptr %r94_slot, align 8
  %r94 = load i64, ptr %r94_slot, align 8
  store i64 %r94, ptr %r95_slot, align 8
  store i64 48, ptr %r96_slot, align 8
  %r96 = load i64, ptr %r96_slot, align 8
  store i64 %r96, ptr %r97_slot, align 8
  store i64 49, ptr %r98_slot, align 8
  %r98 = load i64, ptr %r98_slot, align 8
  store i64 %r98, ptr %r99_slot, align 8
  store i64 50, ptr %r100_slot, align 8
  %r100 = load i64, ptr %r100_slot, align 8
  store i64 %r100, ptr %r101_slot, align 8
  store i64 51, ptr %r102_slot, align 8
  %r102 = load i64, ptr %r102_slot, align 8
  store i64 %r102, ptr %r103_slot, align 8
  store i64 52, ptr %r104_slot, align 8
  %r104 = load i64, ptr %r104_slot, align 8
  store i64 %r104, ptr %r105_slot, align 8
  store i64 53, ptr %r106_slot, align 8
  %r106 = load i64, ptr %r106_slot, align 8
  store i64 %r106, ptr %r107_slot, align 8
  store i64 54, ptr %r108_slot, align 8
  %r108 = load i64, ptr %r108_slot, align 8
  store i64 %r108, ptr %r109_slot, align 8
  store i64 55, ptr %r110_slot, align 8
  %r110 = load i64, ptr %r110_slot, align 8
  store i64 %r110, ptr %r111_slot, align 8
  store i64 56, ptr %r112_slot, align 8
  %r112 = load i64, ptr %r112_slot, align 8
  store i64 %r112, ptr %r113_slot, align 8
  store i64 57, ptr %r114_slot, align 8
  %r114 = load i64, ptr %r114_slot, align 8
  store i64 %r114, ptr %r115_slot, align 8
  store i64 58, ptr %r116_slot, align 8
  %r116 = load i64, ptr %r116_slot, align 8
  store i64 %r116, ptr %r117_slot, align 8
  store i64 59, ptr %r118_slot, align 8
  %r118 = load i64, ptr %r118_slot, align 8
  store i64 %r118, ptr %r119_slot, align 8
  store i64 60, ptr %r120_slot, align 8
  %r120 = load i64, ptr %r120_slot, align 8
  store i64 %r120, ptr %r121_slot, align 8
  store i64 61, ptr %r122_slot, align 8
  %r122 = load i64, ptr %r122_slot, align 8
  store i64 %r122, ptr %r123_slot, align 8
  store i64 62, ptr %r124_slot, align 8
  %r124 = load i64, ptr %r124_slot, align 8
  store i64 %r124, ptr %r125_slot, align 8
  store i64 63, ptr %r126_slot, align 8
  %r126 = load i64, ptr %r126_slot, align 8
  store i64 %r126, ptr %r127_slot, align 8
  store i64 64, ptr %r128_slot, align 8
  %r128 = load i64, ptr %r128_slot, align 8
  store i64 %r128, ptr %r129_slot, align 8
  store i64 65, ptr %r130_slot, align 8
  %r130 = load i64, ptr %r130_slot, align 8
  store i64 %r130, ptr %r131_slot, align 8
  store i64 66, ptr %r132_slot, align 8
  %r132 = load i64, ptr %r132_slot, align 8
  store i64 %r132, ptr %r133_slot, align 8
  store i64 67, ptr %r134_slot, align 8
  %r134 = load i64, ptr %r134_slot, align 8
  store i64 %r134, ptr %r135_slot, align 8
  store i64 68, ptr %r136_slot, align 8
  %r136 = load i64, ptr %r136_slot, align 8
  store i64 %r136, ptr %r137_slot, align 8
  store i64 69, ptr %r138_slot, align 8
  %r138 = load i64, ptr %r138_slot, align 8
  store i64 %r138, ptr %r139_slot, align 8
  store i64 70, ptr %r140_slot, align 8
  %r140 = load i64, ptr %r140_slot, align 8
  store i64 %r140, ptr %r141_slot, align 8
  store i64 71, ptr %r142_slot, align 8
  %r142 = load i64, ptr %r142_slot, align 8
  store i64 %r142, ptr %r143_slot, align 8
  store i64 72, ptr %r144_slot, align 8
  %r144 = load i64, ptr %r144_slot, align 8
  store i64 %r144, ptr %r145_slot, align 8
  store i64 73, ptr %r146_slot, align 8
  %r146 = load i64, ptr %r146_slot, align 8
  store i64 %r146, ptr %r147_slot, align 8
  store i64 74, ptr %r148_slot, align 8
  %r148 = load i64, ptr %r148_slot, align 8
  store i64 %r148, ptr %r149_slot, align 8
  store i64 75, ptr %r150_slot, align 8
  %r150 = load i64, ptr %r150_slot, align 8
  store i64 %r150, ptr %r151_slot, align 8
  store i64 76, ptr %r152_slot, align 8
  %r152 = load i64, ptr %r152_slot, align 8
  store i64 %r152, ptr %r153_slot, align 8
  store i64 77, ptr %r154_slot, align 8
  %r154 = load i64, ptr %r154_slot, align 8
  store i64 %r154, ptr %r155_slot, align 8
  store i64 78, ptr %r156_slot, align 8
  %r156 = load i64, ptr %r156_slot, align 8
  store i64 %r156, ptr %r157_slot, align 8
  store i64 79, ptr %r158_slot, align 8
  %r158 = load i64, ptr %r158_slot, align 8
  store i64 %r158, ptr %r159_slot, align 8
  store i64 80, ptr %r160_slot, align 8
  %r160 = load i64, ptr %r160_slot, align 8
  store i64 %r160, ptr %r161_slot, align 8
  store i64 81, ptr %r162_slot, align 8
  %r162 = load i64, ptr %r162_slot, align 8
  store i64 %r162, ptr %r163_slot, align 8
  store i64 82, ptr %r164_slot, align 8
  %r164 = load i64, ptr %r164_slot, align 8
  store i64 %r164, ptr %r165_slot, align 8
  store i64 83, ptr %r166_slot, align 8
  %r166 = load i64, ptr %r166_slot, align 8
  store i64 %r166, ptr %r167_slot, align 8
  store i64 84, ptr %r168_slot, align 8
  %r168 = load i64, ptr %r168_slot, align 8
  store i64 %r168, ptr %r169_slot, align 8
  store i64 85, ptr %r170_slot, align 8
  %r170 = load i64, ptr %r170_slot, align 8
  store i64 %r170, ptr %r171_slot, align 8
  store i64 86, ptr %r172_slot, align 8
  %r172 = load i64, ptr %r172_slot, align 8
  store i64 %r172, ptr %r173_slot, align 8
  store i64 87, ptr %r174_slot, align 8
  %r174 = load i64, ptr %r174_slot, align 8
  store i64 %r174, ptr %r175_slot, align 8
  store i64 88, ptr %r176_slot, align 8
  %r176 = load i64, ptr %r176_slot, align 8
  store i64 %r176, ptr %r177_slot, align 8
  store i64 89, ptr %r178_slot, align 8
  %r178 = load i64, ptr %r178_slot, align 8
  store i64 %r178, ptr %r179_slot, align 8
  store i64 90, ptr %r180_slot, align 8
  %r180 = load i64, ptr %r180_slot, align 8
  store i64 %r180, ptr %r181_slot, align 8
  store i64 91, ptr %r182_slot, align 8
  %r182 = load i64, ptr %r182_slot, align 8
  store i64 %r182, ptr %r183_slot, align 8
  store i64 92, ptr %r184_slot, align 8
  %r184 = load i64, ptr %r184_slot, align 8
  store i64 %r184, ptr %r185_slot, align 8
  store i64 93, ptr %r186_slot, align 8
  %r186 = load i64, ptr %r186_slot, align 8
  store i64 %r186, ptr %r187_slot, align 8
  store i64 94, ptr %r188_slot, align 8
  %r188 = load i64, ptr %r188_slot, align 8
  store i64 %r188, ptr %r189_slot, align 8
  store i64 95, ptr %r190_slot, align 8
  %r190 = load i64, ptr %r190_slot, align 8
  store i64 %r190, ptr %r191_slot, align 8
  store i64 96, ptr %r192_slot, align 8
  %r192 = load i64, ptr %r192_slot, align 8
  store i64 %r192, ptr %r193_slot, align 8
  store i64 97, ptr %r194_slot, align 8
  %r194 = load i64, ptr %r194_slot, align 8
  store i64 %r194, ptr %r195_slot, align 8
  store i64 98, ptr %r196_slot, align 8
  %r196 = load i64, ptr %r196_slot, align 8
  store i64 %r196, ptr %r197_slot, align 8
  store i64 99, ptr %r198_slot, align 8
  %r198 = load i64, ptr %r198_slot, align 8
  store i64 %r198, ptr %r199_slot, align 8
  store i64 100, ptr %r200_slot, align 8
  %r200 = load i64, ptr %r200_slot, align 8
  store i64 %r200, ptr %r201_slot, align 8
  store i64 101, ptr %r202_slot, align 8
  %r202 = load i64, ptr %r202_slot, align 8
  store i64 %r202, ptr %r203_slot, align 8
  store i64 102, ptr %r204_slot, align 8
  %r204 = load i64, ptr %r204_slot, align 8
  store i64 %r204, ptr %r205_slot, align 8
  store i64 103, ptr %r206_slot, align 8
  %r206 = load i64, ptr %r206_slot, align 8
  store i64 %r206, ptr %r207_slot, align 8
  store i64 104, ptr %r208_slot, align 8
  %r208 = load i64, ptr %r208_slot, align 8
  store i64 %r208, ptr %r209_slot, align 8
  store i64 105, ptr %r210_slot, align 8
  %r210 = load i64, ptr %r210_slot, align 8
  store i64 %r210, ptr %r211_slot, align 8
  store i64 106, ptr %r212_slot, align 8
  %r212 = load i64, ptr %r212_slot, align 8
  store i64 %r212, ptr %r213_slot, align 8
  store i64 107, ptr %r214_slot, align 8
  %r214 = load i64, ptr %r214_slot, align 8
  store i64 %r214, ptr %r215_slot, align 8
  store i64 108, ptr %r216_slot, align 8
  %r216 = load i64, ptr %r216_slot, align 8
  store i64 %r216, ptr %r217_slot, align 8
  store i64 109, ptr %r218_slot, align 8
  %r218 = load i64, ptr %r218_slot, align 8
  store i64 %r218, ptr %r219_slot, align 8
  store i64 110, ptr %r220_slot, align 8
  %r220 = load i64, ptr %r220_slot, align 8
  store i64 %r220, ptr %r221_slot, align 8
  store i64 111, ptr %r222_slot, align 8
  %r222 = load i64, ptr %r222_slot, align 8
  store i64 %r222, ptr %r223_slot, align 8
  store i64 112, ptr %r224_slot, align 8
  %r224 = load i64, ptr %r224_slot, align 8
  store i64 %r224, ptr %r225_slot, align 8
  store i64 113, ptr %r226_slot, align 8
  %r226 = load i64, ptr %r226_slot, align 8
  store i64 %r226, ptr %r227_slot, align 8
  store i64 114, ptr %r228_slot, align 8
  %r228 = load i64, ptr %r228_slot, align 8
  store i64 %r228, ptr %r229_slot, align 8
  store i64 115, ptr %r230_slot, align 8
  %r230 = load i64, ptr %r230_slot, align 8
  store i64 %r230, ptr %r231_slot, align 8
  store i64 116, ptr %r232_slot, align 8
  %r232 = load i64, ptr %r232_slot, align 8
  store i64 %r232, ptr %r233_slot, align 8
  store i64 117, ptr %r234_slot, align 8
  %r234 = load i64, ptr %r234_slot, align 8
  store i64 %r234, ptr %r235_slot, align 8
  store i64 118, ptr %r236_slot, align 8
  %r236 = load i64, ptr %r236_slot, align 8
  store i64 %r236, ptr %r237_slot, align 8
  store i64 119, ptr %r238_slot, align 8
  %r238 = load i64, ptr %r238_slot, align 8
  store i64 %r238, ptr %r239_slot, align 8
  store i64 120, ptr %r240_slot, align 8
  %r240 = load i64, ptr %r240_slot, align 8
  store i64 %r240, ptr %r241_slot, align 8
  store i64 121, ptr %r242_slot, align 8
  %r242 = load i64, ptr %r242_slot, align 8
  store i64 %r242, ptr %r243_slot, align 8
  store i64 122, ptr %r244_slot, align 8
  %r244 = load i64, ptr %r244_slot, align 8
  store i64 %r244, ptr %r245_slot, align 8
  store i64 123, ptr %r246_slot, align 8
  %r246 = load i64, ptr %r246_slot, align 8
  store i64 %r246, ptr %r247_slot, align 8
  store i64 124, ptr %r248_slot, align 8
  %r248 = load i64, ptr %r248_slot, align 8
  store i64 %r248, ptr %r249_slot, align 8
  store i64 125, ptr %r250_slot, align 8
  %r250 = load i64, ptr %r250_slot, align 8
  store i64 %r250, ptr %r251_slot, align 8
  store i64 126, ptr %r252_slot, align 8
  %r252 = load i64, ptr %r252_slot, align 8
  store i64 %r252, ptr %r253_slot, align 8
  store i64 127, ptr %r254_slot, align 8
  %r254 = load i64, ptr %r254_slot, align 8
  store i64 %r254, ptr %r255_slot, align 8
  store i64 128, ptr %r256_slot, align 8
  %r256 = load i64, ptr %r256_slot, align 8
  store i64 %r256, ptr %r257_slot, align 8
  store i64 129, ptr %r258_slot, align 8
  %r258 = load i64, ptr %r258_slot, align 8
  store i64 %r258, ptr %r259_slot, align 8
  store i64 130, ptr %r260_slot, align 8
  %r260 = load i64, ptr %r260_slot, align 8
  store i64 %r260, ptr %r261_slot, align 8
  store i64 131, ptr %r262_slot, align 8
  %r262 = load i64, ptr %r262_slot, align 8
  store i64 %r262, ptr %r263_slot, align 8
  store i64 132, ptr %r264_slot, align 8
  %r264 = load i64, ptr %r264_slot, align 8
  store i64 %r264, ptr %r265_slot, align 8
  store i64 133, ptr %r266_slot, align 8
  %r266 = load i64, ptr %r266_slot, align 8
  store i64 %r266, ptr %r267_slot, align 8
  store i64 134, ptr %r268_slot, align 8
  %r268 = load i64, ptr %r268_slot, align 8
  store i64 %r268, ptr %r269_slot, align 8
  store i64 135, ptr %r270_slot, align 8
  %r270 = load i64, ptr %r270_slot, align 8
  store i64 %r270, ptr %r271_slot, align 8
  store i64 136, ptr %r272_slot, align 8
  %r272 = load i64, ptr %r272_slot, align 8
  store i64 %r272, ptr %r273_slot, align 8
  store i64 137, ptr %r274_slot, align 8
  %r274 = load i64, ptr %r274_slot, align 8
  store i64 %r274, ptr %r275_slot, align 8
  store i64 138, ptr %r276_slot, align 8
  %r276 = load i64, ptr %r276_slot, align 8
  store i64 %r276, ptr %r277_slot, align 8
  store i64 139, ptr %r278_slot, align 8
  %r278 = load i64, ptr %r278_slot, align 8
  store i64 %r278, ptr %r279_slot, align 8
  store i64 140, ptr %r280_slot, align 8
  %r280 = load i64, ptr %r280_slot, align 8
  store i64 %r280, ptr %r281_slot, align 8
  store i64 141, ptr %r282_slot, align 8
  %r282 = load i64, ptr %r282_slot, align 8
  store i64 %r282, ptr %r283_slot, align 8
  store i64 142, ptr %r284_slot, align 8
  %r284 = load i64, ptr %r284_slot, align 8
  store i64 %r284, ptr %r285_slot, align 8
  store i64 143, ptr %r286_slot, align 8
  %r286 = load i64, ptr %r286_slot, align 8
  store i64 %r286, ptr %r287_slot, align 8
  store i64 144, ptr %r288_slot, align 8
  %r288 = load i64, ptr %r288_slot, align 8
  store i64 %r288, ptr %r289_slot, align 8
  store i64 145, ptr %r290_slot, align 8
  %r290 = load i64, ptr %r290_slot, align 8
  store i64 %r290, ptr %r291_slot, align 8
  store i64 146, ptr %r292_slot, align 8
  %r292 = load i64, ptr %r292_slot, align 8
  store i64 %r292, ptr %r293_slot, align 8
  store i64 147, ptr %r294_slot, align 8
  %r294 = load i64, ptr %r294_slot, align 8
  store i64 %r294, ptr %r295_slot, align 8
  store i64 148, ptr %r296_slot, align 8
  %r296 = load i64, ptr %r296_slot, align 8
  store i64 %r296, ptr %r297_slot, align 8
  store i64 149, ptr %r298_slot, align 8
  %r298 = load i64, ptr %r298_slot, align 8
  store i64 %r298, ptr %r299_slot, align 8
  store i64 150, ptr %r300_slot, align 8
  %r300 = load i64, ptr %r300_slot, align 8
  store i64 %r300, ptr %r301_slot, align 8
  store i64 151, ptr %r302_slot, align 8
  %r302 = load i64, ptr %r302_slot, align 8
  store i64 %r302, ptr %r303_slot, align 8
  store i64 152, ptr %r304_slot, align 8
  %r304 = load i64, ptr %r304_slot, align 8
  store i64 %r304, ptr %r305_slot, align 8
  store i64 153, ptr %r306_slot, align 8
  %r306 = load i64, ptr %r306_slot, align 8
  store i64 %r306, ptr %r307_slot, align 8
  store i64 154, ptr %r308_slot, align 8
  %r308 = load i64, ptr %r308_slot, align 8
  store i64 %r308, ptr %r309_slot, align 8
  store i64 155, ptr %r310_slot, align 8
  %r310 = load i64, ptr %r310_slot, align 8
  store i64 %r310, ptr %r311_slot, align 8
  store i64 156, ptr %r312_slot, align 8
  %r312 = load i64, ptr %r312_slot, align 8
  store i64 %r312, ptr %r313_slot, align 8
  store i64 157, ptr %r314_slot, align 8
  %r314 = load i64, ptr %r314_slot, align 8
  store i64 %r314, ptr %r315_slot, align 8
  store i64 158, ptr %r316_slot, align 8
  %r316 = load i64, ptr %r316_slot, align 8
  store i64 %r316, ptr %r317_slot, align 8
  store i64 159, ptr %r318_slot, align 8
  %r318 = load i64, ptr %r318_slot, align 8
  store i64 %r318, ptr %r319_slot, align 8
  store i64 160, ptr %r320_slot, align 8
  %r320 = load i64, ptr %r320_slot, align 8
  store i64 %r320, ptr %r321_slot, align 8
  store i64 161, ptr %r322_slot, align 8
  %r322 = load i64, ptr %r322_slot, align 8
  store i64 %r322, ptr %r323_slot, align 8
  store i64 162, ptr %r324_slot, align 8
  %r324 = load i64, ptr %r324_slot, align 8
  store i64 %r324, ptr %r325_slot, align 8
  store i64 163, ptr %r326_slot, align 8
  %r326 = load i64, ptr %r326_slot, align 8
  store i64 %r326, ptr %r327_slot, align 8
  store i64 164, ptr %r328_slot, align 8
  %r328 = load i64, ptr %r328_slot, align 8
  store i64 %r328, ptr %r329_slot, align 8
  store i64 165, ptr %r330_slot, align 8
  %r330 = load i64, ptr %r330_slot, align 8
  store i64 %r330, ptr %r331_slot, align 8
  store i64 166, ptr %r332_slot, align 8
  %r332 = load i64, ptr %r332_slot, align 8
  store i64 %r332, ptr %r333_slot, align 8
  store i64 167, ptr %r334_slot, align 8
  %r334 = load i64, ptr %r334_slot, align 8
  store i64 %r334, ptr %r335_slot, align 8
  store i64 168, ptr %r336_slot, align 8
  %r336 = load i64, ptr %r336_slot, align 8
  store i64 %r336, ptr %r337_slot, align 8
  store i64 169, ptr %r338_slot, align 8
  %r338 = load i64, ptr %r338_slot, align 8
  store i64 %r338, ptr %r339_slot, align 8
  store i64 170, ptr %r340_slot, align 8
  %r340 = load i64, ptr %r340_slot, align 8
  store i64 %r340, ptr %r341_slot, align 8
  store i64 171, ptr %r342_slot, align 8
  %r342 = load i64, ptr %r342_slot, align 8
  store i64 %r342, ptr %r343_slot, align 8
  store i64 172, ptr %r344_slot, align 8
  %r344 = load i64, ptr %r344_slot, align 8
  store i64 %r344, ptr %r345_slot, align 8
  store i64 173, ptr %r346_slot, align 8
  %r346 = load i64, ptr %r346_slot, align 8
  store i64 %r346, ptr %r347_slot, align 8
  store i64 174, ptr %r348_slot, align 8
  %r348 = load i64, ptr %r348_slot, align 8
  store i64 %r348, ptr %r349_slot, align 8
  store i64 175, ptr %r350_slot, align 8
  %r350 = load i64, ptr %r350_slot, align 8
  store i64 %r350, ptr %r351_slot, align 8
  store i64 176, ptr %r352_slot, align 8
  %r352 = load i64, ptr %r352_slot, align 8
  store i64 %r352, ptr %r353_slot, align 8
  store i64 177, ptr %r354_slot, align 8
  %r354 = load i64, ptr %r354_slot, align 8
  store i64 %r354, ptr %r355_slot, align 8
  store i64 178, ptr %r356_slot, align 8
  %r356 = load i64, ptr %r356_slot, align 8
  store i64 %r356, ptr %r357_slot, align 8
  store i64 179, ptr %r358_slot, align 8
  %r358 = load i64, ptr %r358_slot, align 8
  store i64 %r358, ptr %r359_slot, align 8
  store i64 180, ptr %r360_slot, align 8
  %r360 = load i64, ptr %r360_slot, align 8
  store i64 %r360, ptr %r361_slot, align 8
  store i64 181, ptr %r362_slot, align 8
  %r362 = load i64, ptr %r362_slot, align 8
  store i64 %r362, ptr %r363_slot, align 8
  store i64 182, ptr %r364_slot, align 8
  %r364 = load i64, ptr %r364_slot, align 8
  store i64 %r364, ptr %r365_slot, align 8
  store i64 183, ptr %r366_slot, align 8
  %r366 = load i64, ptr %r366_slot, align 8
  store i64 %r366, ptr %r367_slot, align 8
  store i64 184, ptr %r368_slot, align 8
  %r368 = load i64, ptr %r368_slot, align 8
  store i64 %r368, ptr %r369_slot, align 8
  store i64 185, ptr %r370_slot, align 8
  %r370 = load i64, ptr %r370_slot, align 8
  store i64 %r370, ptr %r371_slot, align 8
  store i64 186, ptr %r372_slot, align 8
  %r372 = load i64, ptr %r372_slot, align 8
  store i64 %r372, ptr %r373_slot, align 8
  store i64 187, ptr %r374_slot, align 8
  %r374 = load i64, ptr %r374_slot, align 8
  store i64 %r374, ptr %r375_slot, align 8
  store i64 188, ptr %r376_slot, align 8
  %r376 = load i64, ptr %r376_slot, align 8
  store i64 %r376, ptr %r377_slot, align 8
  store i64 189, ptr %r378_slot, align 8
  %r378 = load i64, ptr %r378_slot, align 8
  store i64 %r378, ptr %r379_slot, align 8
  store i64 190, ptr %r380_slot, align 8
  %r380 = load i64, ptr %r380_slot, align 8
  store i64 %r380, ptr %r381_slot, align 8
  store i64 191, ptr %r382_slot, align 8
  %r382 = load i64, ptr %r382_slot, align 8
  store i64 %r382, ptr %r383_slot, align 8
  store i64 192, ptr %r384_slot, align 8
  %r384 = load i64, ptr %r384_slot, align 8
  store i64 %r384, ptr %r385_slot, align 8
  store i64 193, ptr %r386_slot, align 8
  %r386 = load i64, ptr %r386_slot, align 8
  store i64 %r386, ptr %r387_slot, align 8
  store i64 194, ptr %r388_slot, align 8
  %r388 = load i64, ptr %r388_slot, align 8
  store i64 %r388, ptr %r389_slot, align 8
  store i64 195, ptr %r390_slot, align 8
  %r390 = load i64, ptr %r390_slot, align 8
  store i64 %r390, ptr %r391_slot, align 8
  store i64 196, ptr %r392_slot, align 8
  %r392 = load i64, ptr %r392_slot, align 8
  store i64 %r392, ptr %r393_slot, align 8
  store i64 197, ptr %r394_slot, align 8
  %r394 = load i64, ptr %r394_slot, align 8
  store i64 %r394, ptr %r395_slot, align 8
  store i64 198, ptr %r396_slot, align 8
  %r396 = load i64, ptr %r396_slot, align 8
  store i64 %r396, ptr %r397_slot, align 8
  store i64 199, ptr %r398_slot, align 8
  %r398 = load i64, ptr %r398_slot, align 8
  store i64 %r398, ptr %r399_slot, align 8
  store i64 200, ptr %r400_slot, align 8
  %r400 = load i64, ptr %r400_slot, align 8
  store i64 %r400, ptr %r401_slot, align 8
  store i64 201, ptr %r402_slot, align 8
  %r402 = load i64, ptr %r402_slot, align 8
  store i64 %r402, ptr %r403_slot, align 8
  store i64 202, ptr %r404_slot, align 8
  %r404 = load i64, ptr %r404_slot, align 8
  store i64 %r404, ptr %r405_slot, align 8
  store i64 203, ptr %r406_slot, align 8
  %r406 = load i64, ptr %r406_slot, align 8
  store i64 %r406, ptr %r407_slot, align 8
  store i64 204, ptr %r408_slot, align 8
  %r408 = load i64, ptr %r408_slot, align 8
  store i64 %r408, ptr %r409_slot, align 8
  store i64 205, ptr %r410_slot, align 8
  %r410 = load i64, ptr %r410_slot, align 8
  store i64 %r410, ptr %r411_slot, align 8
  store i64 206, ptr %r412_slot, align 8
  %r412 = load i64, ptr %r412_slot, align 8
  store i64 %r412, ptr %r413_slot, align 8
  store i64 207, ptr %r414_slot, align 8
  %r414 = load i64, ptr %r414_slot, align 8
  store i64 %r414, ptr %r415_slot, align 8
  store i64 208, ptr %r416_slot, align 8
  %r416 = load i64, ptr %r416_slot, align 8
  store i64 %r416, ptr %r417_slot, align 8
  store i64 209, ptr %r418_slot, align 8
  %r418 = load i64, ptr %r418_slot, align 8
  store i64 %r418, ptr %r419_slot, align 8
  store i64 210, ptr %r420_slot, align 8
  %r420 = load i64, ptr %r420_slot, align 8
  store i64 %r420, ptr %r421_slot, align 8
  store i64 211, ptr %r422_slot, align 8
  %r422 = load i64, ptr %r422_slot, align 8
  store i64 %r422, ptr %r423_slot, align 8
  store i64 212, ptr %r424_slot, align 8
  %r424 = load i64, ptr %r424_slot, align 8
  store i64 %r424, ptr %r425_slot, align 8
  store i64 213, ptr %r426_slot, align 8
  %r426 = load i64, ptr %r426_slot, align 8
  store i64 %r426, ptr %r427_slot, align 8
  store i64 214, ptr %r428_slot, align 8
  %r428 = load i64, ptr %r428_slot, align 8
  store i64 %r428, ptr %r429_slot, align 8
  store i64 215, ptr %r430_slot, align 8
  %r430 = load i64, ptr %r430_slot, align 8
  store i64 %r430, ptr %r431_slot, align 8
  store i64 216, ptr %r432_slot, align 8
  %r432 = load i64, ptr %r432_slot, align 8
  store i64 %r432, ptr %r433_slot, align 8
  store i64 217, ptr %r434_slot, align 8
  %r434 = load i64, ptr %r434_slot, align 8
  store i64 %r434, ptr %r435_slot, align 8
  store i64 218, ptr %r436_slot, align 8
  %r436 = load i64, ptr %r436_slot, align 8
  store i64 %r436, ptr %r437_slot, align 8
  store i64 219, ptr %r438_slot, align 8
  %r438 = load i64, ptr %r438_slot, align 8
  store i64 %r438, ptr %r439_slot, align 8
  store i64 220, ptr %r440_slot, align 8
  %r440 = load i64, ptr %r440_slot, align 8
  store i64 %r440, ptr %r441_slot, align 8
  store i64 221, ptr %r442_slot, align 8
  %r442 = load i64, ptr %r442_slot, align 8
  store i64 %r442, ptr %r443_slot, align 8
  store i64 222, ptr %r444_slot, align 8
  %r444 = load i64, ptr %r444_slot, align 8
  store i64 %r444, ptr %r445_slot, align 8
  store i64 223, ptr %r446_slot, align 8
  %r446 = load i64, ptr %r446_slot, align 8
  store i64 %r446, ptr %r447_slot, align 8
  store i64 224, ptr %r448_slot, align 8
  %r448 = load i64, ptr %r448_slot, align 8
  store i64 %r448, ptr %r449_slot, align 8
  store i64 225, ptr %r450_slot, align 8
  %r450 = load i64, ptr %r450_slot, align 8
  store i64 %r450, ptr %r451_slot, align 8
  store i64 226, ptr %r452_slot, align 8
  %r452 = load i64, ptr %r452_slot, align 8
  store i64 %r452, ptr %r453_slot, align 8
  store i64 227, ptr %r454_slot, align 8
  %r454 = load i64, ptr %r454_slot, align 8
  store i64 %r454, ptr %r455_slot, align 8
  store i64 228, ptr %r456_slot, align 8
  %r456 = load i64, ptr %r456_slot, align 8
  store i64 %r456, ptr %r457_slot, align 8
  store i64 229, ptr %r458_slot, align 8
  %r458 = load i64, ptr %r458_slot, align 8
  store i64 %r458, ptr %r459_slot, align 8
  store i64 230, ptr %r460_slot, align 8
  %r460 = load i64, ptr %r460_slot, align 8
  store i64 %r460, ptr %r461_slot, align 8
  store i64 231, ptr %r462_slot, align 8
  %r462 = load i64, ptr %r462_slot, align 8
  store i64 %r462, ptr %r463_slot, align 8
  store i64 232, ptr %r464_slot, align 8
  %r464 = load i64, ptr %r464_slot, align 8
  store i64 %r464, ptr %r465_slot, align 8
  store i64 233, ptr %r466_slot, align 8
  %r466 = load i64, ptr %r466_slot, align 8
  store i64 %r466, ptr %r467_slot, align 8
  store i64 234, ptr %r468_slot, align 8
  %r468 = load i64, ptr %r468_slot, align 8
  store i64 %r468, ptr %r469_slot, align 8
  store i64 235, ptr %r470_slot, align 8
  %r470 = load i64, ptr %r470_slot, align 8
  store i64 %r470, ptr %r471_slot, align 8
  store i64 236, ptr %r472_slot, align 8
  %r472 = load i64, ptr %r472_slot, align 8
  store i64 %r472, ptr %r473_slot, align 8
  store i64 237, ptr %r474_slot, align 8
  %r474 = load i64, ptr %r474_slot, align 8
  store i64 %r474, ptr %r475_slot, align 8
  store i64 238, ptr %r476_slot, align 8
  %r476 = load i64, ptr %r476_slot, align 8
  store i64 %r476, ptr %r477_slot, align 8
  store i64 239, ptr %r478_slot, align 8
  %r478 = load i64, ptr %r478_slot, align 8
  store i64 %r478, ptr %r479_slot, align 8
  store i64 240, ptr %r480_slot, align 8
  %r480 = load i64, ptr %r480_slot, align 8
  store i64 %r480, ptr %r481_slot, align 8
  store i64 241, ptr %r482_slot, align 8
  %r482 = load i64, ptr %r482_slot, align 8
  store i64 %r482, ptr %r483_slot, align 8
  store i64 242, ptr %r484_slot, align 8
  %r484 = load i64, ptr %r484_slot, align 8
  store i64 %r484, ptr %r485_slot, align 8
  store i64 243, ptr %r486_slot, align 8
  %r486 = load i64, ptr %r486_slot, align 8
  store i64 %r486, ptr %r487_slot, align 8
  store i64 244, ptr %r488_slot, align 8
  %r488 = load i64, ptr %r488_slot, align 8
  store i64 %r488, ptr %r489_slot, align 8
  store i64 245, ptr %r490_slot, align 8
  %r490 = load i64, ptr %r490_slot, align 8
  store i64 %r490, ptr %r491_slot, align 8
  store i64 246, ptr %r492_slot, align 8
  %r492 = load i64, ptr %r492_slot, align 8
  store i64 %r492, ptr %r493_slot, align 8
  store i64 247, ptr %r494_slot, align 8
  %r494 = load i64, ptr %r494_slot, align 8
  store i64 %r494, ptr %r495_slot, align 8
  store i64 248, ptr %r496_slot, align 8
  %r496 = load i64, ptr %r496_slot, align 8
  store i64 %r496, ptr %r497_slot, align 8
  store i64 249, ptr %r498_slot, align 8
  %r498 = load i64, ptr %r498_slot, align 8
  store i64 %r498, ptr %r499_slot, align 8
  store i64 250, ptr %r500_slot, align 8
  %r500 = load i64, ptr %r500_slot, align 8
  store i64 %r500, ptr %r501_slot, align 8
  store i64 251, ptr %r502_slot, align 8
  %r502 = load i64, ptr %r502_slot, align 8
  store i64 %r502, ptr %r503_slot, align 8
  store i64 252, ptr %r504_slot, align 8
  %r504 = load i64, ptr %r504_slot, align 8
  store i64 %r504, ptr %r505_slot, align 8
  store i64 253, ptr %r506_slot, align 8
  %r506 = load i64, ptr %r506_slot, align 8
  store i64 %r506, ptr %r507_slot, align 8
  store i64 254, ptr %r508_slot, align 8
  %r508 = load i64, ptr %r508_slot, align 8
  store i64 %r508, ptr %r509_slot, align 8
  store i64 255, ptr %r510_slot, align 8
  %r510 = load i64, ptr %r510_slot, align 8
  store i64 %r510, ptr %r511_slot, align 8
  store i64 256, ptr %r512_slot, align 8
  %r512 = load i64, ptr %r512_slot, align 8
  store i64 %r512, ptr %r513_slot, align 8
  store i64 257, ptr %r514_slot, align 8
  %r514 = load i64, ptr %r514_slot, align 8
  store i64 %r514, ptr %r515_slot, align 8
  store i64 258, ptr %r516_slot, align 8
  %r516 = load i64, ptr %r516_slot, align 8
  store i64 %r516, ptr %r517_slot, align 8
  store i64 259, ptr %r518_slot, align 8
  %r518 = load i64, ptr %r518_slot, align 8
  store i64 %r518, ptr %r519_slot, align 8
  store i64 260, ptr %r520_slot, align 8
  %r520 = load i64, ptr %r520_slot, align 8
  store i64 %r520, ptr %r521_slot, align 8
  store i64 261, ptr %r522_slot, align 8
  %r522 = load i64, ptr %r522_slot, align 8
  store i64 %r522, ptr %r523_slot, align 8
  store i64 262, ptr %r524_slot, align 8
  %r524 = load i64, ptr %r524_slot, align 8
  store i64 %r524, ptr %r525_slot, align 8
  store i64 263, ptr %r526_slot, align 8
  %r526 = load i64, ptr %r526_slot, align 8
  store i64 %r526, ptr %r527_slot, align 8
  store i64 264, ptr %r528_slot, align 8
  %r528 = load i64, ptr %r528_slot, align 8
  store i64 %r528, ptr %r529_slot, align 8
  store i64 265, ptr %r530_slot, align 8
  %r530 = load i64, ptr %r530_slot, align 8
  store i64 %r530, ptr %r531_slot, align 8
  store i64 266, ptr %r532_slot, align 8
  %r532 = load i64, ptr %r532_slot, align 8
  store i64 %r532, ptr %r533_slot, align 8
  store i64 267, ptr %r534_slot, align 8
  %r534 = load i64, ptr %r534_slot, align 8
  store i64 %r534, ptr %r535_slot, align 8
  store i64 268, ptr %r536_slot, align 8
  %r536 = load i64, ptr %r536_slot, align 8
  store i64 %r536, ptr %r537_slot, align 8
  store i64 269, ptr %r538_slot, align 8
  %r538 = load i64, ptr %r538_slot, align 8
  store i64 %r538, ptr %r539_slot, align 8
  %call_result = call i64 @selected()
  store i64 %call_result, ptr %r540_slot, align 8
  %r540 = load i64, ptr %r540_slot, align 8
  store i64 %r540, ptr %r541_slot, align 8
  store i64 1, ptr %r542_slot, align 8
  %r542 = load i64, ptr %r542_slot, align 8
  %array_storage_in_bounds = icmp ult i64 %r542, 2
  br i1 %array_storage_in_bounds, label %array_storage_valid, label %array_storage_invalid

array_storage_valid:                              ; preds = %block_0
  %r541 = load i64, ptr %r541_slot, align 8
  %ba_base = inttoptr i64 %r541 to ptr
  %r5421 = load i64, ptr %r542_slot, align 8
  %ba_load_ptr = getelementptr i8, ptr %ba_base, i64 %r5421
  %ba_byte = load i8, ptr %ba_load_ptr, align 1
  %ba_ext = zext i8 %ba_byte to i64
  store i64 %ba_ext, ptr %r543_slot, align 8
  %r543 = load i64, ptr %r543_slot, align 8
  store i64 %r543, ptr %r542_slot, align 8
  %r5412 = load i64, ptr %r541_slot, align 8
  %r539 = load i64, ptr %r539_slot, align 8
  %r537 = load i64, ptr %r537_slot, align 8
  %r535 = load i64, ptr %r535_slot, align 8
  %r533 = load i64, ptr %r533_slot, align 8
  %r531 = load i64, ptr %r531_slot, align 8
  %r529 = load i64, ptr %r529_slot, align 8
  %r527 = load i64, ptr %r527_slot, align 8
  %r525 = load i64, ptr %r525_slot, align 8
  %r523 = load i64, ptr %r523_slot, align 8
  %r521 = load i64, ptr %r521_slot, align 8
  %r519 = load i64, ptr %r519_slot, align 8
  %r517 = load i64, ptr %r517_slot, align 8
  %r515 = load i64, ptr %r515_slot, align 8
  %r513 = load i64, ptr %r513_slot, align 8
  %r511 = load i64, ptr %r511_slot, align 8
  %r509 = load i64, ptr %r509_slot, align 8
  %r507 = load i64, ptr %r507_slot, align 8
  %r505 = load i64, ptr %r505_slot, align 8
  %r503 = load i64, ptr %r503_slot, align 8
  %r501 = load i64, ptr %r501_slot, align 8
  %r499 = load i64, ptr %r499_slot, align 8
  %r497 = load i64, ptr %r497_slot, align 8
  %r495 = load i64, ptr %r495_slot, align 8
  %r493 = load i64, ptr %r493_slot, align 8
  %r491 = load i64, ptr %r491_slot, align 8
  %r489 = load i64, ptr %r489_slot, align 8
  %r487 = load i64, ptr %r487_slot, align 8
  %r485 = load i64, ptr %r485_slot, align 8
  %r483 = load i64, ptr %r483_slot, align 8
  %r481 = load i64, ptr %r481_slot, align 8
  %r479 = load i64, ptr %r479_slot, align 8
  %r477 = load i64, ptr %r477_slot, align 8
  %r475 = load i64, ptr %r475_slot, align 8
  %r473 = load i64, ptr %r473_slot, align 8
  %r471 = load i64, ptr %r471_slot, align 8
  %r469 = load i64, ptr %r469_slot, align 8
  %r467 = load i64, ptr %r467_slot, align 8
  %r465 = load i64, ptr %r465_slot, align 8
  %r463 = load i64, ptr %r463_slot, align 8
  %r461 = load i64, ptr %r461_slot, align 8
  %r459 = load i64, ptr %r459_slot, align 8
  %r457 = load i64, ptr %r457_slot, align 8
  %r455 = load i64, ptr %r455_slot, align 8
  %r453 = load i64, ptr %r453_slot, align 8
  %r451 = load i64, ptr %r451_slot, align 8
  %r449 = load i64, ptr %r449_slot, align 8
  %r447 = load i64, ptr %r447_slot, align 8
  %r445 = load i64, ptr %r445_slot, align 8
  %r443 = load i64, ptr %r443_slot, align 8
  %r441 = load i64, ptr %r441_slot, align 8
  %r439 = load i64, ptr %r439_slot, align 8
  %r437 = load i64, ptr %r437_slot, align 8
  %r435 = load i64, ptr %r435_slot, align 8
  %r433 = load i64, ptr %r433_slot, align 8
  %r431 = load i64, ptr %r431_slot, align 8
  %r429 = load i64, ptr %r429_slot, align 8
  %r427 = load i64, ptr %r427_slot, align 8
  %r425 = load i64, ptr %r425_slot, align 8
  %r423 = load i64, ptr %r423_slot, align 8
  %r421 = load i64, ptr %r421_slot, align 8
  %r419 = load i64, ptr %r419_slot, align 8
  %r417 = load i64, ptr %r417_slot, align 8
  %r415 = load i64, ptr %r415_slot, align 8
  %r413 = load i64, ptr %r413_slot, align 8
  %r411 = load i64, ptr %r411_slot, align 8
  %r409 = load i64, ptr %r409_slot, align 8
  %r407 = load i64, ptr %r407_slot, align 8
  %r405 = load i64, ptr %r405_slot, align 8
  %r403 = load i64, ptr %r403_slot, align 8
  %r401 = load i64, ptr %r401_slot, align 8
  %r399 = load i64, ptr %r399_slot, align 8
  %r397 = load i64, ptr %r397_slot, align 8
  %r395 = load i64, ptr %r395_slot, align 8
  %r393 = load i64, ptr %r393_slot, align 8
  %r391 = load i64, ptr %r391_slot, align 8
  %r389 = load i64, ptr %r389_slot, align 8
  %r387 = load i64, ptr %r387_slot, align 8
  %r385 = load i64, ptr %r385_slot, align 8
  %r383 = load i64, ptr %r383_slot, align 8
  %r381 = load i64, ptr %r381_slot, align 8
  %r379 = load i64, ptr %r379_slot, align 8
  %r377 = load i64, ptr %r377_slot, align 8
  %r375 = load i64, ptr %r375_slot, align 8
  %r373 = load i64, ptr %r373_slot, align 8
  %r371 = load i64, ptr %r371_slot, align 8
  %r369 = load i64, ptr %r369_slot, align 8
  %r367 = load i64, ptr %r367_slot, align 8
  %r365 = load i64, ptr %r365_slot, align 8
  %r363 = load i64, ptr %r363_slot, align 8
  %r361 = load i64, ptr %r361_slot, align 8
  %r359 = load i64, ptr %r359_slot, align 8
  %r357 = load i64, ptr %r357_slot, align 8
  %r355 = load i64, ptr %r355_slot, align 8
  %r353 = load i64, ptr %r353_slot, align 8
  %r351 = load i64, ptr %r351_slot, align 8
  %r349 = load i64, ptr %r349_slot, align 8
  %r347 = load i64, ptr %r347_slot, align 8
  %r345 = load i64, ptr %r345_slot, align 8
  %r343 = load i64, ptr %r343_slot, align 8
  %r341 = load i64, ptr %r341_slot, align 8
  %r339 = load i64, ptr %r339_slot, align 8
  %r337 = load i64, ptr %r337_slot, align 8
  %r335 = load i64, ptr %r335_slot, align 8
  %r333 = load i64, ptr %r333_slot, align 8
  %r331 = load i64, ptr %r331_slot, align 8
  %r329 = load i64, ptr %r329_slot, align 8
  %r327 = load i64, ptr %r327_slot, align 8
  %r325 = load i64, ptr %r325_slot, align 8
  %r323 = load i64, ptr %r323_slot, align 8
  %r321 = load i64, ptr %r321_slot, align 8
  %r319 = load i64, ptr %r319_slot, align 8
  %r317 = load i64, ptr %r317_slot, align 8
  %r315 = load i64, ptr %r315_slot, align 8
  %r313 = load i64, ptr %r313_slot, align 8
  %r311 = load i64, ptr %r311_slot, align 8
  %r309 = load i64, ptr %r309_slot, align 8
  %r307 = load i64, ptr %r307_slot, align 8
  %r305 = load i64, ptr %r305_slot, align 8
  %r303 = load i64, ptr %r303_slot, align 8
  %r301 = load i64, ptr %r301_slot, align 8
  %r299 = load i64, ptr %r299_slot, align 8
  %r297 = load i64, ptr %r297_slot, align 8
  %r295 = load i64, ptr %r295_slot, align 8
  %r293 = load i64, ptr %r293_slot, align 8
  %r291 = load i64, ptr %r291_slot, align 8
  %r289 = load i64, ptr %r289_slot, align 8
  %r287 = load i64, ptr %r287_slot, align 8
  %r285 = load i64, ptr %r285_slot, align 8
  %r283 = load i64, ptr %r283_slot, align 8
  %r281 = load i64, ptr %r281_slot, align 8
  %r279 = load i64, ptr %r279_slot, align 8
  %r277 = load i64, ptr %r277_slot, align 8
  %r275 = load i64, ptr %r275_slot, align 8
  %r273 = load i64, ptr %r273_slot, align 8
  %r271 = load i64, ptr %r271_slot, align 8
  %r269 = load i64, ptr %r269_slot, align 8
  %r267 = load i64, ptr %r267_slot, align 8
  %r265 = load i64, ptr %r265_slot, align 8
  %r263 = load i64, ptr %r263_slot, align 8
  %r261 = load i64, ptr %r261_slot, align 8
  %r259 = load i64, ptr %r259_slot, align 8
  %r257 = load i64, ptr %r257_slot, align 8
  %r255 = load i64, ptr %r255_slot, align 8
  %r253 = load i64, ptr %r253_slot, align 8
  %r251 = load i64, ptr %r251_slot, align 8
  %r249 = load i64, ptr %r249_slot, align 8
  %r247 = load i64, ptr %r247_slot, align 8
  %r245 = load i64, ptr %r245_slot, align 8
  %r243 = load i64, ptr %r243_slot, align 8
  %r241 = load i64, ptr %r241_slot, align 8
  %r239 = load i64, ptr %r239_slot, align 8
  %r237 = load i64, ptr %r237_slot, align 8
  %r235 = load i64, ptr %r235_slot, align 8
  %r233 = load i64, ptr %r233_slot, align 8
  %r231 = load i64, ptr %r231_slot, align 8
  %r229 = load i64, ptr %r229_slot, align 8
  %r227 = load i64, ptr %r227_slot, align 8
  %r225 = load i64, ptr %r225_slot, align 8
  %r223 = load i64, ptr %r223_slot, align 8
  %r221 = load i64, ptr %r221_slot, align 8
  %r219 = load i64, ptr %r219_slot, align 8
  %r217 = load i64, ptr %r217_slot, align 8
  %r215 = load i64, ptr %r215_slot, align 8
  %r213 = load i64, ptr %r213_slot, align 8
  %r211 = load i64, ptr %r211_slot, align 8
  %r209 = load i64, ptr %r209_slot, align 8
  %r207 = load i64, ptr %r207_slot, align 8
  %r205 = load i64, ptr %r205_slot, align 8
  %r203 = load i64, ptr %r203_slot, align 8
  %r201 = load i64, ptr %r201_slot, align 8
  %r199 = load i64, ptr %r199_slot, align 8
  %r197 = load i64, ptr %r197_slot, align 8
  %r195 = load i64, ptr %r195_slot, align 8
  %r193 = load i64, ptr %r193_slot, align 8
  %r191 = load i64, ptr %r191_slot, align 8
  %r189 = load i64, ptr %r189_slot, align 8
  %r187 = load i64, ptr %r187_slot, align 8
  %r185 = load i64, ptr %r185_slot, align 8
  %r183 = load i64, ptr %r183_slot, align 8
  %r181 = load i64, ptr %r181_slot, align 8
  %r179 = load i64, ptr %r179_slot, align 8
  %r177 = load i64, ptr %r177_slot, align 8
  %r175 = load i64, ptr %r175_slot, align 8
  %r173 = load i64, ptr %r173_slot, align 8
  %r171 = load i64, ptr %r171_slot, align 8
  %r169 = load i64, ptr %r169_slot, align 8
  %r167 = load i64, ptr %r167_slot, align 8
  %r165 = load i64, ptr %r165_slot, align 8
  %r163 = load i64, ptr %r163_slot, align 8
  %r161 = load i64, ptr %r161_slot, align 8
  %r159 = load i64, ptr %r159_slot, align 8
  %r157 = load i64, ptr %r157_slot, align 8
  %r155 = load i64, ptr %r155_slot, align 8
  %r153 = load i64, ptr %r153_slot, align 8
  %r151 = load i64, ptr %r151_slot, align 8
  %r149 = load i64, ptr %r149_slot, align 8
  %r147 = load i64, ptr %r147_slot, align 8
  %r145 = load i64, ptr %r145_slot, align 8
  %r143 = load i64, ptr %r143_slot, align 8
  %r141 = load i64, ptr %r141_slot, align 8
  %r139 = load i64, ptr %r139_slot, align 8
  %r137 = load i64, ptr %r137_slot, align 8
  %r135 = load i64, ptr %r135_slot, align 8
  %r133 = load i64, ptr %r133_slot, align 8
  %r131 = load i64, ptr %r131_slot, align 8
  %r129 = load i64, ptr %r129_slot, align 8
  %r127 = load i64, ptr %r127_slot, align 8
  %r125 = load i64, ptr %r125_slot, align 8
  %r123 = load i64, ptr %r123_slot, align 8
  %r121 = load i64, ptr %r121_slot, align 8
  %r119 = load i64, ptr %r119_slot, align 8
  %r117 = load i64, ptr %r117_slot, align 8
  %r115 = load i64, ptr %r115_slot, align 8
  %r113 = load i64, ptr %r113_slot, align 8
  %r111 = load i64, ptr %r111_slot, align 8
  %r109 = load i64, ptr %r109_slot, align 8
  %r107 = load i64, ptr %r107_slot, align 8
  %r105 = load i64, ptr %r105_slot, align 8
  %r103 = load i64, ptr %r103_slot, align 8
  %r101 = load i64, ptr %r101_slot, align 8
  %r99 = load i64, ptr %r99_slot, align 8
  %r97 = load i64, ptr %r97_slot, align 8
  %r95 = load i64, ptr %r95_slot, align 8
  %r93 = load i64, ptr %r93_slot, align 8
  %r91 = load i64, ptr %r91_slot, align 8
  %r89 = load i64, ptr %r89_slot, align 8
  %r87 = load i64, ptr %r87_slot, align 8
  %r85 = load i64, ptr %r85_slot, align 8
  %r83 = load i64, ptr %r83_slot, align 8
  %r81 = load i64, ptr %r81_slot, align 8
  %r79 = load i64, ptr %r79_slot, align 8
  %r77 = load i64, ptr %r77_slot, align 8
  %r75 = load i64, ptr %r75_slot, align 8
  %r73 = load i64, ptr %r73_slot, align 8
  %r71 = load i64, ptr %r71_slot, align 8
  %r69 = load i64, ptr %r69_slot, align 8
  %r67 = load i64, ptr %r67_slot, align 8
  %r65 = load i64, ptr %r65_slot, align 8
  %r63 = load i64, ptr %r63_slot, align 8
  %r61 = load i64, ptr %r61_slot, align 8
  %r59 = load i64, ptr %r59_slot, align 8
  %r57 = load i64, ptr %r57_slot, align 8
  %r55 = load i64, ptr %r55_slot, align 8
  %r53 = load i64, ptr %r53_slot, align 8
  %r51 = load i64, ptr %r51_slot, align 8
  %r49 = load i64, ptr %r49_slot, align 8
  %r47 = load i64, ptr %r47_slot, align 8
  %r45 = load i64, ptr %r45_slot, align 8
  %r43 = load i64, ptr %r43_slot, align 8
  %r41 = load i64, ptr %r41_slot, align 8
  %r39 = load i64, ptr %r39_slot, align 8
  %r37 = load i64, ptr %r37_slot, align 8
  %r35 = load i64, ptr %r35_slot, align 8
  %r33 = load i64, ptr %r33_slot, align 8
  %r31 = load i64, ptr %r31_slot, align 8
  %r29 = load i64, ptr %r29_slot, align 8
  %r27 = load i64, ptr %r27_slot, align 8
  %r25 = load i64, ptr %r25_slot, align 8
  %r23 = load i64, ptr %r23_slot, align 8
  %r21 = load i64, ptr %r21_slot, align 8
  %r19 = load i64, ptr %r19_slot, align 8
  %r17 = load i64, ptr %r17_slot, align 8
  %r15 = load i64, ptr %r15_slot, align 8
  %r13 = load i64, ptr %r13_slot, align 8
  %r11 = load i64, ptr %r11_slot, align 8
  %r9 = load i64, ptr %r9_slot, align 8
  %r7 = load i64, ptr %r7_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r5423 = load i64, ptr %r542_slot, align 8
  %r5424 = load i64, ptr %r542_slot, align 8
  ret i64 %r5424

array_storage_invalid:                            ; preds = %block_0
  call void @verum_panic(ptr @array_storage_bounds, i64 25, ptr null, i32 0)
  unreachable
}

@array_storage_bounds = private unnamed_addr constant [26 x i8] c"Array index out of bounds\00", align 1
define internal void @verum_panic(ptr %0, i64 %1, ptr %2, i32 %3) {
entry:
  %4 = call i64 @write(i64 2, ptr @panic_prefix, i64 7)
  %hm = icmp sgt i64 %1, 0
  %wl = select i1 %hm, i64 %1, i64 0
  %5 = call i64 @write(i64 2, ptr %0, i64 %wl)
  %6 = call i64 @write(i64 2, ptr @nl, i64 1)
  %panic_message = call i64 @verum_text_from_stride(ptr %0, i64 %wl, i64 1)
  %new_object = call ptr @verum_checked_malloc(i64 32)
  %malloc_null = icmp eq ptr %new_object, null
  br i1 %malloc_null, label %new_object_oom, label %new_object_ok

new_object_oom:                                   ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

new_object_ok:                                    ; preds = %entry
  %clear_object = call ptr @verum_internal_memset(ptr %new_object, i32 0, i64 32)
  store i32 36864, ptr %new_object, align 4
  %panic_size = getelementptr i8, ptr %new_object, i64 12
  %panic_message_slot = getelementptr i8, ptr %new_object, i64 24
  store i32 32, ptr %panic_size, align 4
  store i64 %panic_message, ptr %panic_message_slot, align 8
  %panic_packet = ptrtoint ptr %new_object to i64
  call void @verum_exception_throw(i64 %panic_packet)
  unreachable
}

define internal void @verum_exception_throw(i64 %0) #3 {
entry:
  %ctx = call ptr @get_or_create_context()
  %cnt_p = getelementptr i8, ptr %ctx, i64 222768
  %cnt = load i64, ptr %cnt_p, align 8
  %hh = icmp sgt i64 %cnt, 0
  br i1 %hh, label %do_throw, label %no_handler

do_throw:                                         ; preds = %entry
  %nc = sub i64 %cnt, 1
  store i64 %nc, ptr %cnt_p, align 8
  %eo = mul i64 %nc, 208
  %bo = add i64 %eo, 9776
  %ddo = add i64 %bo, 200
  %ddp = getelementptr i8, ptr %ctx, i64 %ddo
  %sd = load i64, ptr %ddp, align 8
  call void @verum_defer_run_to(i64 %sd)
  %vo = add i64 %bo, 192
  %vp = getelementptr i8, ptr %ctx, i64 %vo
  store i64 %0, ptr %vp, align 8
  %jb = getelementptr i8, ptr %ctx, i64 %bo
  call void @longjmp(ptr %jb, i32 1)
  unreachable

no_handler:                                       ; preds = %entry
  call void @_exit(i32 134)
  unreachable
}

declare void @_exit(i32)

; Function Attrs: noreturn
declare void @longjmp(ptr, i32) #10

define internal void @verum_defer_run_to(i64 %0) {
entry:
  %ctx = call ptr @get_or_create_context()
  %cnt_p = getelementptr i8, ptr %ctx, i64 239160
  br label %loop_check

loop_check:                                       ; preds = %loop_body, %entry
  %cnt = load i64, ptr %cnt_p, align 8
  %above = icmp ugt i64 %cnt, %0
  br i1 %above, label %loop_body, label %done

loop_body:                                        ; preds = %loop_check
  %nc = sub i64 %cnt, 1
  store i64 %nc, ptr %cnt_p, align 8
  %eo = mul i64 %nc, 16
  %fo = add i64 %eo, 222776
  %fnp = getelementptr i8, ptr %ctx, i64 %fo
  %cfn = load ptr, ptr %fnp, align 8
  %ao = add i64 %fo, 8
  %ap = getelementptr i8, ptr %ctx, i64 %ao
  %arg = load i64, ptr %ap, align 8
  call void %cfn(i64 %arg)
  br label %loop_check

done:                                             ; preds = %loop_check
  ret void
}

define internal ptr @get_or_create_context() {
entry:
  call void @tls_init()
  %key_i64 = load i64, ptr @__verum_tls_key, align 8
  %existing = call i64 @pthread_getspecific(i64 %key_i64)
  %ctx_ptr = inttoptr i64 %existing to ptr
  %is_null = icmp eq ptr %ctx_ptr, null
  br i1 %is_null, label %create_ctx, label %have_ctx

have_ctx:                                         ; preds = %entry
  ret ptr %ctx_ptr

create_ctx:                                       ; preds = %entry
  %new_ctx = call ptr @verum_alloc(i64 239168)
  %tier_p = getelementptr i8, ptr %new_ctx, i64 8
  store i8 3, ptr %tier_p, align 1
  %key2_i64 = load i64, ptr @__verum_tls_key, align 8
  %0 = call i64 @pthread_setspecific(i64 %key2_i64, ptr %new_ctx)
  ret ptr %new_ctx
}

declare i64 @pthread_setspecific(i64, ptr)

@__verum_tls_key = internal global i64 0
define ptr @verum_alloc(i64 %0) {
entry:
  %is_large = icmp ugt i64 %0, 4096
  br i1 %is_large, label %large_path, label %small_path

large_path:                                       ; preds = %entry
  %large_plus_page = add i64 %0, 4095
  %large_page_size = and i64 %large_plus_page, -4096
  %large_block = call ptr @verum_os_alloc(i64 %large_page_size)
  %large_blk_i64 = ptrtoint ptr %large_block to i64
  %lb_ok = icmp ne i64 %large_blk_i64, 0
  br i1 %lb_ok, label %large_ok, label %large_fail

large_ok:                                         ; preds = %large_path
  call void @llvm.memset.p0.i64(ptr align 1 %large_block, i8 0, i64 %large_page_size, i1 false)
  ret ptr %large_block

large_fail:                                       ; preds = %large_path
  ret ptr null

small_path:                                       ; preds = %entry
  %size_minus_one = sub i64 %0, 1
  %ctlz = call i64 @llvm.ctlz.i64(i64 %size_minus_one, i1 false)
  %shift = sub i64 64, %ctlz
  %class_signed = sub i64 %shift, 4
  %is_neg = icmp slt i64 %class_signed, 0
  %class = select i1 %is_neg, i64 0, i64 %class_signed
  %small_alloc_size = shl i64 16, %class
  br label %acquire_lock

acquire_lock:                                     ; preds = %acquire_lock, %small_path
  %1 = cmpxchg ptr @__verum_alloc_lock, i32 0, i32 1 acquire monotonic, align 4
  %cas_ok = extractvalue { i32, i1 } %1, 1
  br i1 %cas_ok, label %lock_acquired, label %acquire_lock

lock_acquired:                                    ; preds = %acquire_lock
  br label %try_freelist

try_freelist:                                     ; preds = %lock_acquired
  %head_slot = getelementptr inbounds [9 x ptr], ptr @__verum_freelist_heads, i64 0, i64 %class
  %head_node = load ptr, ptr %head_slot, align 8
  %head_i64 = ptrtoint ptr %head_node to i64
  %head_null = icmp eq i64 %head_i64, 0
  br i1 %head_null, label %try_bump, label %freelist_hit

freelist_hit:                                     ; preds = %try_freelist
  %next_node = load ptr, ptr %head_node, align 8
  store ptr %next_node, ptr %head_slot, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  call void @llvm.memset.p0.i64(ptr align 1 %head_node, i8 0, i64 %small_alloc_size, i1 false)
  ret ptr %head_node

try_bump:                                         ; preds = %new_arena_ok, %try_freelist
  %cur_ptr = load ptr, ptr @__verum_arena_ptr, align 8
  %cur_end = load ptr, ptr @__verum_arena_end, align 8
  %new_ptr = getelementptr inbounds i8, ptr %cur_ptr, i64 %small_alloc_size
  %cur_i64 = ptrtoint ptr %cur_ptr to i64
  %not_null = icmp ne i64 %cur_i64, 0
  %new_i64 = ptrtoint ptr %new_ptr to i64
  %end_i64 = ptrtoint ptr %cur_end to i64
  %fits = icmp ule i64 %new_i64, %end_i64
  %can_bump = and i1 %not_null, %fits
  br i1 %can_bump, label %bump_ok, label %need_new_arena

bump_ok:                                          ; preds = %try_bump
  store ptr %new_ptr, ptr @__verum_arena_ptr, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  call void @llvm.memset.p0.i64(ptr align 1 %cur_ptr, i8 0, i64 %small_alloc_size, i1 false)
  ret ptr %cur_ptr

need_new_arena:                                   ; preds = %try_bump
  %new_block = call ptr @verum_os_alloc(i64 2097152)
  %blk_i64 = ptrtoint ptr %new_block to i64
  %blk_ok = icmp ne i64 %blk_i64, 0
  br i1 %blk_ok, label %new_arena_ok, label %alloc_fail

new_arena_ok:                                     ; preds = %need_new_arena
  store ptr %new_block, ptr @__verum_arena_base, align 8
  store ptr %new_block, ptr @__verum_arena_ptr, align 8
  %new_end = getelementptr inbounds i8, ptr %new_block, i64 2097152
  store ptr %new_end, ptr @__verum_arena_end, align 8
  br label %try_bump

alloc_fail:                                       ; preds = %need_new_arena
  store i32 0, ptr @__verum_alloc_lock, align 4
  ret ptr null
}

@__verum_alloc_lock = internal global i32 0
@__verum_arena_end = internal global ptr null
@__verum_arena_ptr = internal global ptr null
@__verum_arena_base = internal global ptr null
define ptr @verum_os_alloc(i64 %0) {
entry:
  %mmap_result = call i64 @mmap(i64 0, i64 %0, i64 3, i64 4098, i64 -1, i64 0)
  %mmap_ptr = inttoptr i64 %mmap_result to ptr
  ret ptr %mmap_ptr
}

declare i64 @mmap(i64, i64, i64, i64, i64, i64)

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

@__verum_freelist_heads = internal global [9 x ptr] zeroinitializer
; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #8

declare i64 @pthread_getspecific(i64)

define internal void @tls_init() {
entry:
  %inited = load i64, ptr @__verum_tls_initialized, align 8
  %ii = icmp ne i64 %inited, 0
  br i1 %ii, label %done, label %do_init

do_init:                                          ; preds = %entry
  %0 = call i64 @pthread_key_create(ptr @__verum_tls_key, ptr null)
  store i64 1, ptr @__verum_tls_initialized, align 8
  br label %done

done:                                             ; preds = %do_init, %entry
  ret void
}

@__verum_tls_initialized = internal global i64 0
declare i64 @pthread_key_create(ptr, ptr)

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal i64 @verum_text_from_stride(ptr %0, i64 %1, i64 %2) {
entry:
  %buf_size = add i64 %1, 1
  %stride_buf = call ptr @verum_alloc(i64 %buf_size)
  %malloc_null = icmp eq ptr %stride_buf, null
  br i1 %malloc_null, label %stride_buf_oom, label %stride_buf_ok

loop_head:                                        ; preds = %loop_body, %stride_buf_ok
  %i = phi i64 [ 0, %stride_buf_ok ], [ %i_next, %loop_body ]
  %more = icmp slt i64 %i, %1
  br i1 %more, label %loop_body, label %finish

loop_body:                                        ; preds = %loop_head
  %src_off = mul i64 %i, %2
  %src_ptr = getelementptr inbounds i8, ptr %0, i64 %src_off
  %src_byte = load i8, ptr %src_ptr, align 1
  %dst_ptr = getelementptr inbounds i8, ptr %stride_buf, i64 %i
  store i8 %src_byte, ptr %dst_ptr, align 1
  %i_next = add i64 %i, 1
  br label %loop_head

finish:                                           ; preds = %loop_head
  %term_ptr = getelementptr inbounds i8, ptr %stride_buf, i64 %1
  store i8 0, ptr %term_ptr, align 1
  %stride_text = call i64 @verum_text_alloc(ptr %stride_buf, i64 %1, i64 %1)
  ret i64 %stride_text

stride_buf_oom:                                   ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

stride_buf_ok:                                    ; preds = %entry
  br label %loop_head
}

define internal i64 @verum_text_alloc(ptr %0, i64 %1, i64 %2) {
entry:
  %text_obj = call ptr @verum_alloc(i64 24)
  %malloc_null = icmp eq ptr %text_obj, null
  br i1 %malloc_null, label %text_obj_oom, label %text_obj_ok

text_obj_oom:                                     ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

text_obj_ok:                                      ; preds = %entry
  %ptr_i64 = ptrtoint ptr %0 to i64
  store i64 %ptr_i64, ptr %text_obj, align 8
  %len_ptr = getelementptr i64, ptr %text_obj, i64 1
  store i64 %1, ptr %len_ptr, align 8
  %cap_ptr = getelementptr i64, ptr %text_obj, i64 2
  store i64 %2, ptr %cap_ptr, align 8
  %result = ptrtoint ptr %text_obj to i64
  ret i64 %result
}

@nl = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
declare i64 @write(i64, ptr, i64)

@panic_prefix = private unnamed_addr constant [8 x i8] c"PANIC: \00", align 1
; Function Attrs: nounwind
define internal i64 @selected() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 2, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r1)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %ba_init8 = trunc i64 %r2 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r1, i1 false)
  store i64 0, ptr %r2_slot, align 8
  store i64 7, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %ba_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r21
  %ba_trunc = trunc i64 %r12 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 1, ptr %r1_slot, align 8
  store i64 9, ptr %r2_slot, align 8
  %r03 = load i64, ptr %r0_slot, align 8
  %ba_base4 = inttoptr i64 %r03 to ptr
  %r15 = load i64, ptr %r1_slot, align 8
  %r26 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr7 = getelementptr i8, ptr %ba_base4, i64 %r15
  %ba_trunc8 = trunc i64 %r26 to i8
  store i8 %ba_trunc8, ptr %ba_store_ptr7, align 1
  %r09 = load i64, ptr %r0_slot, align 8
  store i64 %r09, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  store i64 %r3, ptr %r2_slot, align 8
  %r210 = load i64, ptr %r2_slot, align 8
  %r211 = load i64, ptr %r2_slot, align 8
  ret i64 %r211
}

