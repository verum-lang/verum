target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 7, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %marg_0 = inttoptr i64 %r1 to ptr
  %method_call = call i64 @USize.count_ones(ptr %marg_0)
  store i64 %method_call, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  store i64 %r2, ptr %r3_slot, align 8
  %r11 = load i64, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %r32 = load i64, ptr %r3_slot, align 8
  ret i64 %r32
}

; Function Attrs: noinline nounwind optnone
define internal i64 @USize.count_ones(ptr %0) #5 {
block_0:
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r0_ptr_to_i64 = ptrtoint ptr %0 to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  store i64 37, ptr %r1_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  store i64 %r1, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %r21 = load i64, ptr %r2_slot, align 8
  ret i64 %r21
}

