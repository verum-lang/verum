#!/usr/bin/env python3
import argparse, hashlib, json, os, selectors, shutil, signal, subprocess, time
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--source',required=True)
p.add_argument('--commit',required=True)
p.add_argument('--evidence',required=True)
args=p.parse_args()
root=Path(args.source).resolve()
out=Path(args.evidence).resolve()
out.mkdir(exist_ok=False)
def git(*parts):
    return subprocess.check_output(['git',*parts],cwd=root).decode().strip()
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
assert git('rev-parse','HEAD')==args.commit
assert not git('status','--porcelain'), 'source is not clean'
graph=Path('/private/tmp/verum-T1743-main-unit-graph.json')
graph_env=os.environ.copy()
for name in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','VERUM_LLVM_DIR','DOCS_RS'):
    graph_env.pop(name,None)
graph_env.update(CARGO_TARGET_DIR='/Users/taaliman/.tmp/verum-codex-01a10248-types/checker-target',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',VERUM_NO_AUTO_PRECOMPILE='1',RUST_MIN_STACK='16777216')
graph_cmd=['cargo','+nightly-2026-08-20','test','--offline','--locked','-Z','unstable-options','--unit-graph','-p','verum_vbc','--lib','--no-default-features','--features','table_dispatch']
with graph.open('xb') as destination:
    subprocess.run(graph_cmd,cwd=root,env=graph_env,stdout=destination,check=True,timeout=60)
data=json.loads(graph.read_text())
assert not any(any(n in u['pkg_id'] for n in ('verum_mlir','verum_llvm','llvm-sys','verum_compiler')) for u in data['units'])
packages=set()
for u in data['units']:
    path=Path(u['target']['src_path'])
    try: relative=path.relative_to(root)
    except ValueError: continue
    packages.add('/'.join(relative.parts[:2]))
tracked=git('ls-files').splitlines()
paths=[s for s in tracked if any(s.startswith(pkg+'/') for pkg in packages) or s in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml')]
def source_hashes():return {s:sha(root/s) for s in paths}
before=source_hashes()
assert len(before)>=800, 'local dependency sources missing from graph binding'
shutil.copy2(__file__,out/'runner.py')
(out/'source-hashes.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
shutil.copy2(graph,out/'unit-graph.json')
env=os.environ.copy()
for name in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','VERUM_LLVM_DIR','DOCS_RS'):
    env.pop(name,None)
overrides={'CARGO_TARGET_DIR':'/Users/taaliman/.tmp/verum-codex-01a10248-types/checker-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','VERUM_NO_AUTO_PRECOMPILE':'1','RUST_MIN_STACK':'16777216'}
env.update(overrides)
cmd=['cargo','+nightly-2026-08-20','test','--offline','--locked','-p','verum_vbc','--lib','--no-default-features','--features','table_dispatch','--message-format=json-render-diagnostics','record_probe_tests','--','--test-threads=1','--nocapture']
start=time.monotonic()
proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
sel=selectors.DefaultSelector()
for stream,name in ((proc.stdout,'stdout'),(proc.stderr,'stderr')):sel.register(stream,selectors.EVENT_READ,name)
logs={name:open(out/(name+'.log'),'wb') for name in ('stdout','stderr')}
buffers={'stdout':b'','stderr':b''}
artifact=None
stop_reason=None
def stop(reason):
    global stop_reason
    if stop_reason is None:
        stop_reason=reason
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
while sel.get_map():
    if time.monotonic()-start>600:stop('deadline600s')
    if shutil.disk_usage(out).free<2*1024**3:stop('disk headroom below2GiB')
    for key,_ in sel.select(0.2):
        chunk=os.read(key.fileobj.fileno(),65536)
        if not chunk:
            sel.unregister(key.fileobj);continue
        name=key.data
        logs[name].write(chunk);logs[name].flush()
        buffers[name]+=chunk
        while b'\n' in buffers[name]:
            line,buffers[name]=buffers[name].split(b'\n',1)
            if name=='stderr':
                text=line.decode(errors='replace')
                if any(token in text for token in ('Compiling z3-sys','Compiling z3-src','Compiling llvm-sys','Compiling verum_mlir','Compiling verum_compiler')):
                    stop('unexpected bootstrap: '+text.strip())
            else:
                try:item=json.loads(line)
                except ValueError:continue
                if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('target',{}).get('name')=='verum_vbc':
                    artifact=Path(item['executable'])
code=proc.wait()
for log in logs.values():log.close()
elapsed=time.monotonic()-start
binary=None
if artifact is not None:
    retained=out/'verum_vbc-libtest'
    shutil.copy2(artifact,retained)
    binary={'original':str(artifact),'retained':str(retained),'sha256':sha(retained),'size':retained.stat().st_size}
result={'source':str(root),'commit':args.commit,'command':cmd,'environment':overrides,'exit_code':code,'elapsed_seconds':elapsed,'stop_reason':stop_reason,'source_unchanged':before==source_hashes() and git('rev-parse','HEAD')==args.commit and not git('status','--porcelain'),'source_paths':len(before),'executable':binary,'hashes':{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='verum_vbc-libtest'}}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
