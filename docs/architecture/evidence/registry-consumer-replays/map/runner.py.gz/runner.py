"""Replay an unchanged regression against an identified consumer-only CLI."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time

p=argparse.ArgumentParser()
p.add_argument('--build-manifest',type=Path,required=True)
p.add_argument('--manifest-sha256',required=True)
p.add_argument('--fixture',choices=('options','map'),required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
root=Path('/Users/taaliman/.codex/worktrees/returned-reference-summary/verum')
origin_path=Path('/private/tmp/verum-registry-stage23-canonical-owners/build-manifest.json')
origin_sha='3df266cba9190c9d201e03cb51404b28a1d1864f784d32e18421d6fb2083faef'
archive=Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target/precompiled-stdlib')
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def identity(path):return {'bytes':Path(path).stat().st_size,'sha256':sha(path)}
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
def validate():
    assert sha(a.build_manifest)==a.manifest_sha256
    build=json.loads(a.build_manifest.read_bytes())
    assert build['status']=='passed' and build['exit_code']==0
    assert not build['errors'] and build['stop_reason'] is None and not build['timed_out']
    assert build['build_kind']=='consumer-cli-with-explicit-reused-stdlib' and build['automatic_precompile'] is False
    for key in ('selected_types_recompiled','selected_compiler_recompiled','selected_vbc_recompiled','selected_cli_recompiled',
                'source_unchanged','source_paths_unchanged','artifacts_unchanged',
                'origin_manifest_unchanged','original_cli_unchanged','precompiler_unchanged'):
        assert build[key] is True,key
    assert sha(origin_path)==origin_sha==build['origin_manifest_sha256']
    origin=json.loads(origin_path.read_bytes())
    assert origin['engine_commit']==build['stdlib_producer_commit']=='7a8c86f90a493a3b7352359314fc5f0d628aaa1b'
    assert origin['status']=='passed' and origin['automatic_precompile'] is True
    for directory in (archive,Path(origin['artifact_snapshot']),Path(build['retained_artifacts'])):
        assert {name:identity(directory/name) for name in origin['artifacts']}==origin['artifacts']
    assert build['artifacts_before']==build['artifacts_after']==origin['artifacts']
    assert identity(build['cli']['path'])=={key:build['cli'][key] for key in ('bytes','sha256')}
    assert git('rev-parse','HEAD').decode().strip()==build['engine_commit']
    assert not git('status','--porcelain').strip()
    return build

build=validate()
if a.fixture=='options':
    baseline_path=Path('/private/tmp/verum-stage23-semver-options/result.json')
    baseline=json.loads(baseline_path.read_bytes())
    original=Path('/private/tmp/verum-stage23-semver-options/inputs/options.vr')
    expected='semver-options: 14 passed\n'
    expected_sha='56efdfde59d863414287e0b72e8bc322119237c7bf269145b9b0a01959b96666'
    deadline=600
    tracked='core-tests/base/semver_constraint/contract_options_test.vr'
    assert original.read_bytes()==git('show',build['engine_commit']+':'+tracked)==(root/tracked).read_bytes()
    assert baseline['selected_fixture']['expected_stdout']==expected
    assert baseline['selected_fixture']['sha256']==expected_sha
else:
    baseline_path=Path('/private/tmp/verum-T1746-real-map-runtime/result.json')
    baseline=json.loads(baseline_path.read_bytes())
    original=Path('/private/tmp/verum-T1746-map-probe.vr')
    expected='map-read: ok\nmap-mutate: ok\n'
    expected_sha='1e8d82f8bf49013bc97d1579234acbb225b951fdc8709e614d808cfe514e4d0b'
    deadline=120
assert sha(original)==expected_sha
out=a.output.resolve();out.mkdir(exist_ok=False)
(out/'runtime').mkdir()
entry=out/'runtime'/f'{a.fixture}.vr'
entry.write_bytes(original.read_bytes())
(out/'expected.stdout').write_text(expected)
for path,name in ((a.build_manifest,'consumer-build-manifest.json'),(origin_path,'stdlib-build-manifest.json'),
                  (baseline_path,'baseline-result.json'),(Path(__file__),'runner.py')):
    (out/name).write_bytes(path.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('VERUM_')}
overrides={'TMPDIR':'/private/tmp','NO_COLOR':'1','VERUM_NO_OBJECT_CACHE':'1'}
env.update(overrides)
cmd=[build['cli']['path'],'run','--tier','interpret',str(entry)]
record={'tasks':['T1663','T1744','T1745'] if a.fixture=='options' else ['T1747','T1746'],
    'fixture':a.fixture,'engine_commit':build['engine_commit'],'stdlib_producer_commit':build['stdlib_producer_commit'],
    'automatic_precompile':False,'cli':build['cli'],'build_manifest_sha256':a.manifest_sha256,
    'baseline_receipt_sha256':sha(baseline_path),'source_sha256':expected_sha,'expected_stdout':expected,
    'command':cmd,'cwd':str(entry.parent),'environment_overrides':overrides,'deadline_seconds':deadline,
    'scope':'Unchanged source and stdout oracle against a rebuilt consumer CLI with retained Stage23 archives. No fresh automatic bake, full registry, durable publication or AOT acceptance.'}
(out/'started.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic();reason=None
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    proc=subprocess.Popen(cmd,cwd=entry.parent,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    (out/'process.json').write_text(json.dumps({'runner_pid':os.getpid(),'pid':proc.pid})+'\n')
    while proc.poll() is None:
        time.sleep(.25)
        if time.monotonic()-start>deadline:reason='deadline'
        elif any((out/name).stat().st_size>2*1024**2 for name in ('stdout.log','stderr.log')):reason='log bound'
        if reason:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
            break
record.update(returncode=proc.returncode,seconds=round(time.monotonic()-start,3),stop_reason=reason)
errors=[]
try:
    validate()
    assert sha(original)==sha(entry)==expected_sha
    assert sha(out/'consumer-build-manifest.json')==a.manifest_sha256
    assert sha(out/'baseline-result.json')==record['baseline_receipt_sha256']
except Exception as error:errors.append(repr(error))
record['identity_errors']=errors
record['exact_stdout']=(out/'stdout.log').read_bytes()==expected.encode()
record['logs']={name:sha(out/name) for name in ('stdout.log','stderr.log')}
record['status']='passed' if proc.returncode==0 and reason is None and not errors and record['exact_stdout'] else 'failed'
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('fixture','status','returncode','seconds','stop_reason','exact_stdout','identity_errors')}))
raise SystemExit(0 if record['status']=='passed' else 1)
