#!/usr/bin/env python3
"""Build an identified consumer CLI against explicitly retained Stage23 stdlib files."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--plan', type=Path, required=True)
args = parser.parse_args()
PLAN = json.loads(args.plan.read_text())
ROOT = Path(PLAN['source']).resolve()
REVISION = PLAN['commit']
BASE = '7a8c86f90a493a3b7352359314fc5f0d628aaa1b'
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target')
OUT = Path(PLAN['evidence']).resolve()
ORIGIN = Path('/private/tmp/verum-registry-stage23-canonical-owners/build-manifest.json')
ORIGIN_SHA = '3df266cba9190c9d201e03cb51404b28a1d1864f784d32e18421d6fb2083faef'
CHANGED = set(PLAN['changed_existing_inputs'])
ADDED = set(PLAN['added_inputs'])
ARTIFACTS = ('runtime.vbca', 'runtime.core_metadata', 'runtime.symbol_graph',
             'runtime.vbca.checksum', 'runtime.vbca.schema')
SCHEMA = 'v54-2026-10-10-declared-field-visibility'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def identity(path):
    path = Path(path)
    before = path.stat()
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), path
    return {'bytes': after.st_size, 'sha256': sha}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def retain(source, destination):
    before = identity(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists(), destination
    subprocess.run(['/bin/cp', '-c', '-p', str(source), str(destination)], check=True)
    assert identity(destination) == before == identity(source)
    return before


def source_roster():
    names = git('ls-files', 'crates', 'core', 'grammar', 'Cargo.toml', 'Cargo.lock',
                'rust-toolchain.toml', '.cargo').splitlines()
    return [n for n in names if (ROOT/n).is_file() and (ROOT/n).suffix in
            {'.rs', '.vr', '.toml', '.lock', '.ebnf', '.c', '.h', '.cpp'}]


def source_hashes():
    return {name: identity(ROOT/name)['sha256'] for name in source_roster()}


def archives(directory):
    return {name: identity(directory/name) for name in ARTIFACTS}


def stop(process):
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


def main():
    assert identity(ORIGIN)['sha256'] == ORIGIN_SHA
    origin = json.loads(ORIGIN.read_text())
    assert origin['status'] == 'passed' and origin['engine_commit'] == BASE
    assert origin['automatic_precompile'] is True and origin['exit_code'] == 0
    assert origin['source_unchanged'] and origin['source_paths_unchanged'] and not origin['timed_out']
    assert origin['schema'] == SCHEMA
    assert git('rev-parse', 'HEAD') == REVISION and not git('status', '--porcelain')
    assert shutil.disk_usage(TARGET).free >= 2*1024**3
    hashes = source_hashes()
    assert set(hashes) == set(origin['source_paths']) | ADDED
    assert not git('diff', '--name-only', BASE, 'HEAD', '--', 'core', 'grammar', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo'), 'stdlib and build configuration must match Stage23'
    deltas = {name: {'original_sha256': old, 'runtime_sha256': hashes[name]}
              for name, old in origin['source_paths'].items() if hashes[name] != old}
    assert set(deltas) == CHANGED, deltas
    assert set(git('diff', '--name-only', BASE, 'HEAD', '--', 'crates', 'core', 'grammar',
                   'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo').splitlines()) == CHANGED | ADDED
    archive = TARGET/'precompiled-stdlib'
    assert archives(archive) == origin['artifacts'] == archives(Path(origin['artifact_snapshot']))
    old_cli = Path(origin['cli']['path'])
    assert identity(old_cli) == {k: origin['cli'][k] for k in ('bytes', 'sha256')}
    precompiler = TARGET/'precompile-bootstrap/release/verum_stdlib_precompiler'
    producer_before = identity(precompiler)
    OUT.mkdir(exist_ok=False)
    retain(Path(__file__), OUT/'runner.py')
    retain(args.plan, OUT/'reviewed-plan.json')
    retain(ORIGIN, OUT/'stage23-build-manifest.json')
    for name in ARTIFACTS:
        retain(archive/name, OUT/'artifacts'/name)
    write_json(OUT/'source-hashes.json', hashes)
    environment = os.environ.copy()
    for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTUP_TOOLCHAIN', 'CVC5_ROOT'):
        assert not environment.get(key), key
    for key in ('DOCS_RS', 'VERUM_ALLOW_STALE_STDLIB'):
        environment.pop(key, None)
    overrides = {'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '1',
                 'CARGO_INCREMENTAL': '0', 'VERUM_NO_AUTO_PRECOMPILE': '1',
                 'VERUM_LLVM_DIR': '/Users/taaliman/projects/oldman/verum-lang/verum/llvm/install',
                 'CARGO_LOG': 'cargo::core::compiler::fingerprint=info'}
    environment.update(overrides)
    command = ['cargo', '+nightly-2026-08-20', 'build', '-vv', '--offline', '--locked',
               '--message-format=json-render-diagnostics', '--manifest-path', str(ROOT/'Cargo.toml'),
               '-p', 'verum_cli', '--bin', 'verum']
    record = {'tasks': PLAN['tasks'], 'build_kind': 'consumer-cli-with-explicit-reused-stdlib',
              'engine_commit': REVISION, 'engine_tree': git('rev-parse', 'HEAD^{tree}'),
              'stdlib_producer_commit': BASE, 'automatic_precompile': False,
              'scope': 'Consumer CLI rebuilt from the reviewed compiler/type/runtime changes. The five unchanged '
                       'standard-library artifacts were automatically baked by Stage23 from the recorded base. '
                       'This is not a fresh automatic bake, ordinary distribution build, AOT gate or runtime acceptance.',
              'origin_manifest': str(ORIGIN), 'origin_manifest_sha256': ORIGIN_SHA,
              'schema': SCHEMA, 'changed_existing_inputs': deltas, 'additional_inputs': {name: hashes[name] for name in sorted(ADDED)},
              'source_paths': hashes, 'artifacts_before': archives(archive),
              'retained_artifacts': str(OUT/'artifacts'),
              'original_cli': origin['cli'], 'precompiler_before': producer_before,
              'command': command, 'environment_overrides': overrides,
              'deadline_seconds': 900, 'minimum_free_bytes': 2*1024**3,
              'maximum_log_bytes': 16*1024**2,
              'free_bytes_before': shutil.disk_usage(TARGET).free,
              'utc_started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'runner_sha256': identity(Path(__file__))['sha256']}
    write_json(OUT/'started.json', record)
    proc = None
    stop_reason = None
    errors = []
    start = time.monotonic()
    try:
        with (OUT/'stdout.log').open('xb') as stdout, (OUT/'stderr.log').open('xb') as stderr:
            proc = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stdout,
                                    stderr=stderr, start_new_session=True)
            write_json(OUT/'process.json', {'runner_pid': os.getpid(), 'cargo_pid': proc.pid})
            while proc.poll() is None:
                time.sleep(1)
                content = (OUT/'stderr.log').read_text(errors='replace')
                if re.search(r'Compiling (?:z3-sys|z3-src|verum_stdlib_precompiler) ', content):
                    stop_reason = 'fresh solver or nested stdlib producer build selected'
                elif any('crates/cvc5-sys/build.rs' in line and any(
                        ('feature="'+feature+'"') in line or ('CARGO_FEATURE_'+feature.upper()+'=') in line
                        for feature in ('vendored', 'static', 'system')) for line in content.splitlines()):
                    stop_reason = 'non-stub CVC5 native features selected'
                elif any(token in content for token in ('cvc5-sys: building CVC5 from source',
                        'cvc5-sys: using CVC5 source at', 'Refreshing stdlib precompile artefacts',
                        'Building LLVM from source', 'Building MLIR from source', 'cmake --build', 'ninja -C')):
                    stop_reason = 'automatic bake or native bootstrap selected'
                elif shutil.disk_usage(TARGET).free < record['minimum_free_bytes']:
                    stop_reason = 'disk headroom below 2 GiB'
                elif any((OUT/name).stat().st_size > record['maximum_log_bytes']
                         for name in ('stdout.log', 'stderr.log')):
                    stop_reason = '16 MiB log bound'
                elif time.monotonic()-start > record['deadline_seconds']:
                    stop_reason = '900-second deadline'
                if stop_reason:
                    stop(proc)
                    break
    except BaseException as error:
        errors.append(repr(error))
        if proc is not None:
            stop(proc)
    record.update(exit_code=proc.returncode if proc else None,
                  seconds=round(time.monotonic()-start, 3), stop_reason=stop_reason,
                  timed_out=stop_reason == '900-second deadline', errors=errors)
    try:
        events = []
        for line in (OUT/'stdout.log').read_text(errors='replace').splitlines():
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get('reason') == 'compiler-artifact':
                events.append(event)
        local = [e for e in events if e.get('target', {}).get('src_path', '').startswith(str(ROOT)+'/')]
        write_json(OUT/'local-cargo-artifacts.json', local)
        vbc = [e for e in local if e['target']['name'] == 'verum_vbc' and 'lib' in e['target']['kind']]
        cli = [e for e in local if e['target']['name'] == 'verum' and e.get('executable')]
        compiler = [e for e in local if e['target']['name'] == 'verum_compiler' and 'lib' in e['target']['kind']]
        types = [e for e in local if e['target']['name'] == 'verum_types' and 'lib' in e['target']['kind']]
        record['selected_types_recompiled'] = len(types) == 1 and types[0]['fresh'] is False
        record['selected_compiler_recompiled'] = len(compiler) == 1 and compiler[0]['fresh'] is False
        record['selected_vbc_recompiled'] = len(vbc) == 1 and vbc[0]['fresh'] is False
        record['selected_cli_recompiled'] = len(cli) == 1 and cli[0]['fresh'] is False
        record['source_unchanged'] = git('rev-parse', 'HEAD') == REVISION and not git('status', '--porcelain')
        record['source_paths_unchanged'] = hashes == source_hashes()
        record['artifacts_after'] = archives(archive)
        record['artifacts_unchanged'] = (record['artifacts_after'] == origin['artifacts']
            == archives(Path(origin['artifact_snapshot'])) == archives(OUT/'artifacts'))
        record['origin_manifest_unchanged'] = identity(ORIGIN)['sha256'] == ORIGIN_SHA
        record['original_cli_unchanged'] = identity(old_cli) == {k: origin['cli'][k] for k in ('bytes', 'sha256')}
        record['precompiler_after'] = identity(precompiler)
        record['precompiler_unchanged'] = record['precompiler_after'] == producer_before
        record['logs'] = {n: identity(OUT/n) for n in ('stdout.log', 'stderr.log')}
        record['free_bytes_after'] = shutil.disk_usage(TARGET).free
        if cli:
            destination = OUT/('verum-consumer-'+REVISION[:9])
            measured = retain(Path(cli[0]['executable']), destination)
            destination.chmod(0o555)
            record['cli'] = {'path': str(destination), **measured}
        checks = ('selected_types_recompiled', 'selected_compiler_recompiled', 'selected_vbc_recompiled', 'selected_cli_recompiled', 'source_unchanged',
                  'source_paths_unchanged', 'artifacts_unchanged', 'origin_manifest_unchanged',
                  'original_cli_unchanged', 'precompiler_unchanged')
        record['status'] = ('passed' if record['exit_code'] == 0 and not stop_reason and not errors
                            and all(record.get(k) is True for k in checks) else 'failed')
    except BaseException as error:
        record['errors'].append(repr(error))
        record['status'] = 'failed'
    write_json(OUT/'build-manifest.json', record)
    print(json.dumps({k: record.get(k) for k in ('status', 'seconds', 'exit_code', 'stop_reason',
          'errors', 'selected_types_recompiled', 'selected_compiler_recompiled', 'selected_vbc_recompiled', 'selected_cli_recompiled', 'artifacts_unchanged', 'cli')}), flush=True)
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
