from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
REGISTRY = Path('/private/tmp/verum-registry-t1722-snapshot')
REGISTRY_COMMIT = '962f416b5c0f55f04cc38219eed8cb473720a213'
REGISTRY_TREE = '003bd20ca50c11e173dc42f1864af174e0f66375'
CONSUMER = '6a0bf542b9a2a3158d78b4015cf1b533eecfd13e'
VALIDATOR = Path('/private/tmp/replay-verum-map-prepare-copy.py')
VALIDATOR_SHA = '4efe2be40eb352efe4bd01bf3eec7a7f501d0efd645894d857f8531a96fe1f69'
BUILD = Path('/private/tmp/verum-T1196-consumer-cli/build-manifest.json')
BUILD_SHA = '289d4a18670f67a014ccc6ad12315f2c4dbe15cad8addbc1ba3d03aea3e63ffa'
CLI_SHA = '2da19e172e64584c4063974f2eb2038d3ec0e6360776b84fc1333adf0cc63d57'
ORIGINAL = Path('/private/tmp/verum-registry-t1636-auth')
ORIGINAL_COMMIT = '6c055769bab8deca3787b55e782e7ca61a7ce2c4'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def git(*args):
    return subprocess.check_output(['git', '-C', str(REGISTRY), *args])

def registry_identity():
    assert git('rev-parse', 'HEAD').decode().strip() == REGISTRY_COMMIT
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == REGISTRY_TREE
    assert git('status', '--porcelain') == b''

def retain(directory, contents):
    for path, data in contents.items():
        dest = directory / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as stream:
            stream.write(data)

def hashes(contents):
    return {str(path): hashlib.sha256(data).hexdigest() for path, data in contents.items()}

def run(args):
    assert sha(VALIDATOR) == VALIDATOR_SHA
    validator = load('original_consumer_provenance', VALIDATOR)
    validator.LANGUAGE_COMMIT = CONSUMER
    build, cli = validator.validate_build(BUILD, BUILD_SHA, CLI_SHA)
    registry_identity()
    runner_path = Path('tools/run_publication_envelope.py')
    runner = load('frozen_snapshot_component_runner', REGISTRY / runner_path)
    selected = runner.COMPONENTS[args.component]
    assert not selected.get('appended_fragments')
    sources = {path: (REGISTRY / path).read_bytes() for path in
        (*selected['modules'], *selected.get('assets', ()), selected['fixture'], selected['expected'], runner_path)}
    for path, data in sources.items():
        assert data == git('show', REGISTRY_COMMIT + ':' + str(path)), str(path)
    fixture = sources[selected['fixture']]
    assert fixture.count(selected['header']) == 1
    project = {**{path: sources[path] for path in (*selected['modules'], *selected.get('assets', ()))},
        Path('src/main.vr'): fixture.replace(selected['header'], runner.NEW_HEADER, 1),
        Path('verum.toml'): runner.MANIFEST}
    if args.component == 'prepare_copy':
        assert sources[selected['expected']] == (ORIGINAL / selected['expected']).read_bytes()
    source_hashes, project_hashes = hashes(sources), hashes(project)
    if args.preflight_only:
        print(json.dumps({'status': 'ready-not-executed', 'component': args.component,
            'source_inputs': len(sources), 'project_inputs': len(project), 'registry_commit': REGISTRY_COMMIT,
            'consumer_commit': CONSUMER, 'deadline_seconds': 600}))
        return 0
    out = args.evidence_dir.resolve()
    out.mkdir(exist_ok=False)
    retain(out / 'inputs/source', sources)
    retain(out / 'inputs/project', project)
    retain(out, {Path('build-manifest.json'): BUILD.read_bytes(), Path('build-validator.py'): VALIDATOR.read_bytes(),
        Path('stdlib-origin-manifest.json'): validator.STDLIB_MANIFEST.read_bytes(),
        Path('wrapper.py'): Path(__file__).read_bytes(),
        Path('registry-api-and-fixture-delta.patch'): git('diff', ORIGINAL_COMMIT, REGISTRY_COMMIT, '--',
            'src/node/publication_prepare.vr', str(selected['fixture']), str(selected['expected']), str(runner_path))})
    if args.component == 'prepare_copy':
        retain(out / 'original-failing-source', {selected['fixture']: (ORIGINAL / selected['fixture']).read_bytes(),
            selected['expected']: (ORIGINAL / selected['expected']).read_bytes()})
    record = {'task': 'T1722', 'related_task': 'T1635', 'component': args.component,
        'registry_commit': REGISTRY_COMMIT, 'registry_tree': REGISTRY_TREE,
        'consumer_commit': CONSUMER, 'cli': build['cli'], 'build_manifest_sha256': BUILD_SHA,
        'stdlib_producer_commit': validator.STDLIB_COMMIT, 'automatic_precompile': False,
        'stdlib_origin_manifest_sha256': validator.STDLIB_MANIFEST_SHA,
        'source_inputs': source_hashes, 'project_inputs': project_hashes,
        'wrapper_sha256': sha(__file__), 'validator_sha256': VALIDATOR_SHA,
        'deadline_seconds': 600, 'scope': selected['scope'],
        'comparison_scope': 'Production snapshot API and its declared callers changed. Original prepare_copy mutation/readback requirements and output oracle remain; this is a new candidate, not relabeled unchanged-source acceptance.'}
    (out / 'started.json').write_text(json.dumps(record, indent=2) + '\n')
    environment = dict(os.environ)
    selected_env = {k: v for k, v in environment.items() if not k.startswith('VERUM_')}
    selected_env['TMPDIR'] = '/private/tmp'
    record['removed_environment_keys'] = sorted(set(environment) - set(selected_env))
    code, failure = None, None
    try:
        os.environ.clear()
        os.environ.update(selected_env)
        code = runner.run(argparse.Namespace(verum=str(cli), component=args.component,
            language_commit=CONSUMER, expected_cli_sha256=CLI_SHA, evidence_dir=str(out / 'component'), timeout=600))
    except (Exception, KeyboardInterrupt) as error:
        failure = repr(error)
    finally:
        os.environ.clear()
        os.environ.update(environment)
    errors, checks = {}, {}
    try:
        registry_identity()
        validator.validate_build(BUILD, BUILD_SHA, CLI_SHA)
        checks['source_and_build_unchanged'] = True
        checks['retained_inputs_unchanged'] = all(sha(out / 'inputs/source' / path) == digest for path, digest in source_hashes.items()) and all(sha(out / 'inputs/project' / path) == digest for path, digest in project_hashes.items())
        checks['wrappers_unchanged'] = sha(__file__) == sha(out / 'wrapper.py') == record['wrapper_sha256'] and sha(VALIDATOR) == sha(out / 'build-validator.py') == VALIDATOR_SHA
        checks['build_receipts_unchanged'] = sha(out / 'build-manifest.json') == BUILD_SHA and sha(out / 'stdlib-origin-manifest.json') == validator.STDLIB_MANIFEST_SHA
        receipt = json.loads((out / 'component/result.json').read_text())
        checks['original_component_oracle_accepted'] = (code == 0 and receipt['status'] == 'passed'
            and receipt['returncode'] == 0 and not receipt['timed_out'] and not receipt['interrupted']
            and receipt['runner_error'] is None and set(receipt['checks']) == validator.CHECKS and all(receipt['checks'].values())
            and receipt['component'] == args.component and receipt['deadline_seconds'] == 600
            and receipt['source_inputs'] == receipt['source_inputs_after'] == source_hashes
            and receipt['project_inputs'] == receipt['project_inputs_after'] == project_hashes
            and receipt['language_source_commit_supplied'] == CONSUMER
            and receipt['cli_sha256'] == receipt['cli_sha256_after'] == receipt['expected_cli_sha256'] == CLI_SHA
            and receipt['module_assemblies'] == [])
        checks['logs_unchanged'] = all(sha(out / 'component' / name) == digest for name, digest in receipt['logs'].items())
        record['component_result'] = {'status': receipt['status'], 'elapsed_seconds': receipt['elapsed_seconds'],
            'returncode': receipt['returncode'], 'sha256': sha(out / 'component/result.json')}
    except Exception as error:
        errors['identity_or_receipt'] = repr(error)
    record.update(status='passed' if failure is None and not errors and checks and all(checks.values()) else 'failed',
        failure=failure, returncode=code, checks=checks, errors=errors)
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'component', 'component_result', 'checks', 'failure', 'errors')}))
    return 0 if record['status'] == 'passed' else 1

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--component', choices=('prepare_copy', 'prepare_snapshot', 'prepare'), required=True)
    parser.add_argument('--evidence-dir', type=Path, required=True)
    parser.add_argument('--preflight-only', action='store_true')
    raise SystemExit(run(parser.parse_args()))
