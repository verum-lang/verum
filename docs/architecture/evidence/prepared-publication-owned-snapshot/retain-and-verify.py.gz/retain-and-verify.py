from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path('/Users/taaliman/.codex/worktrees/source-archive-main/verum')
REGISTRY = Path('/private/tmp/verum-registry-t1722-snapshot')
SOURCE = Path('/private/tmp/verum-T1722-owned-snapshot-copy')
OUT = ROOT / 'docs/architecture/evidence/prepared-publication-owned-snapshot'
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda root, *args: subprocess.check_output(['git', '-C', str(root), *args])
assert git(ROOT, 'status', '--porcelain') == b''
assert git(REGISTRY, 'status', '--porcelain') == b''
record = json.loads((SOURCE / 'result.json').read_text())
component = json.loads((SOURCE / 'component/result.json').read_text())
assert record['status'] == component['status'] == 'failed'
assert record['failure'] is None and record['errors'] == {}
assert component['returncode'] == 1 and not component['timed_out']
assert component['elapsed_seconds'] == 369.01
assert git(REGISTRY, 'rev-parse', 'HEAD').decode().strip() == record['registry_commit']
assert git(REGISTRY, 'rev-parse', 'HEAD^{tree}').decode().strip() == record['registry_tree']
assert sha((SOURCE / 'component/result.json').read_bytes()) == record['component_result']['sha256']
assert set(record['checks']) == {'source_and_build_unchanged', 'retained_inputs_unchanged',
    'wrappers_unchanged', 'build_receipts_unchanged', 'original_component_oracle_accepted', 'logs_unchanged'}
assert all(value == (name != 'original_component_oracle_accepted') for name, value in record['checks'].items())
assert record['source_inputs'] == component['source_inputs'] == component['source_inputs_after']
assert record['project_inputs'] == component['project_inputs'] == component['project_inputs_after']
assert len(record['source_inputs']) == 8 and len(record['project_inputs']) == 7
for path, digest in record['source_inputs'].items():
    assert sha((SOURCE / 'inputs/source' / path).read_bytes()) == digest
    assert sha(git(REGISTRY, 'show', record['registry_commit'] + ':' + path)) == digest
for path, digest in record['project_inputs'].items():
    assert sha((SOURCE / 'inputs/project' / path).read_bytes()) == digest
for name, digest in component['logs'].items():
    assert sha((SOURCE / 'component' / name).read_bytes()) == digest
assert (SOURCE / 'component/stdout.log').read_bytes() == b''
assert 'Assertion failed at pc 28: assertion failed' in (SOURCE / 'component/stderr.log').read_text()
for name, key in [('wrapper.py', 'wrapper_sha256'), ('build-validator.py', 'validator_sha256'),
        ('build-manifest.json', 'build_manifest_sha256'), ('stdlib-origin-manifest.json', 'stdlib_origin_manifest_sha256')]:
    assert sha((SOURCE / name).read_bytes()) == record[key]
OUT.mkdir(exist_ok=False)
manifest = {'tasks': ['T1635', 'T1722'], 'status': 'runtime-assertion-failed',
    'registry_commit': record['registry_commit'], 'registry_tree': record['registry_tree'],
    'consumer_commit': record['consumer_commit'], 'cli': record['cli'],
    'stdlib_producer_commit': record['stdlib_producer_commit'], 'automatic_precompile': False,
    'elapsed_seconds': 369.01, 'returncode': 1, 'deadline_seconds': 600,
    'verified_source_inputs': 8, 'verified_project_inputs': 7,
    'assertion_pc': 28, 'function_and_source_site': None,
    'mutation_case_completion': 'unknown', 'files': [],
    'scope': 'New explicit owned-snapshot candidate fails the original five-case component with unchanged mutation and output requirements. No isolation, privacy, affine, service or AOT acceptance.'}

def retain(path, relative):
    raw = Path(path).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    dest = OUT / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(packed)
    manifest['files'].append({'path': relative, 'original_bytes': len(raw),
        'original_sha256': sha(raw), 'stored_bytes': len(packed), 'stored_sha256': sha(packed)})

for path in sorted(SOURCE.rglob('*')):
    if path.is_file():
        retain(path, 'runtime/' + str(path.relative_to(SOURCE)) + '.gz')
retain('/private/tmp/verum-T1722-snapshot-source/parent-review.json', 'source-parent-review.json.gz')
retain(REGISTRY / 'tests/evidence/publication-snapshot-source/result.json', 'source-gates.json.gz')
retain(__file__, 'retain-and-verify.py.gz')
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Owned publication snapshot runtime boundary

Registry candidate `962f416b5c0f55f04cc38219eed8cb473720a213` replaces borrowed
publication and attribution projections with explicitly reconstructed owned
snapshots and scalar reads. The original five mutation/readback/isolation
requirements and output marker are preserved through mechanical API migration.
Separate full-shape and two-snapshot controls are prepared but have not run.

The first ordinary `prepare_copy` run fails after 369.01 seconds, exit 1,
within the unchanged 600-second deadline. Standard output is empty; standard
error reports `Assertion failed at pc 28: assertion failed`. This receipt
does not identify the failing function, source assertion or snapshot field,
and it does not establish that any mutation case completed. Cause remains
unassigned pending a separate diagnostic control. The candidate is unmerged.

All eight source inputs, seven assembled project inputs, runner, CLI and
reused standard-library identities remain unchanged. The [manifest](manifest.json)
retains complete inputs, raw logs, provenance, the old fixture and API delta.
The same consumer uses explicit Stage23 archive reuse; this is not a fresh
automatic standard-library build or a main distribution build.

Source review, grammar acceptance of 20 files and 173 passing Python tooling
tests establish only source and runner properties. They do not supersede this
runtime failure. The earlier [borrowed-projection failure](../prepared-publication-copy-isolation/README.md)
remains distinct: all five mutations completed there and all five retained
isolation checks failed. Neither result closes the separate language
dereference-copy obligation, privacy/affine checks, durable admission or AOT.
''')
with (ROOT / 'docs/architecture/registry-language-acceptance.md').open('a') as stream:
    stream.write('''
### Explicit owned snapshot candidate requires runtime repair

The [owned-snapshot candidate](evidence/prepared-publication-owned-snapshot/README.md)
reconstructs the publication's mutable layers and removes borrowed projections.
Its first ordinary five-case run fails an assertion at pc 28 after 369.01 seconds,
with no standard output and all source/project/CLI/artifact identities unchanged.
The failing function and source site are not recorded by this diagnostic;
no completed mutation or isolation property is inferred. The original mutation
requirements and marker remain intact, and the candidate stays unintegrated.
Separate diagnostic localization is required before further acceptance runs.
''')
for item in manifest['files']:
    packed = (OUT / item['path']).read_bytes()
    assert sha(packed) == item['stored_sha256']
    assert sha(gzip.decompress(packed)) == item['original_sha256']
print(json.dumps({'packet': str(OUT), 'retained_files': len(manifest['files']), 'status': manifest['status']}))
