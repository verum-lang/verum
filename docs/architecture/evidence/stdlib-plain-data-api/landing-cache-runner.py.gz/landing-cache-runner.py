from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess

PLAN = Path('/private/tmp/verum-T1724-landing-cache-plan.json')
PLAN_SHA = 'ca53f90bc666f22380fbb5a242dedd35d8cf8781ebf455d7648295e558d8f29f'
OUT = Path('/private/tmp/verum-T1724-landing-cache')
ROOT = Path('/Users/taaliman/.codex/worktrees/configured-registry-downloads/verum')
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248-registry-client/target')
SOURCE = '41be1f4679357179fb1ddf56cda91d2118a5a563'
PREVIOUS = 'e770047ec39605d6497d772aedc1e0e61f669a4d'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def identity(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and path.resolve() == path, path
    digest = sha(path)
    after = path.lstat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode), path
    return {'sha256': digest, 'bytes': after.st_size, 'mode': oct(stat.S_IMODE(after.st_mode)), 'mtime_ns': after.st_mtime_ns}


def git(*parts):
    return subprocess.check_output(['git', '-C', str(ROOT), *parts], text=True).strip()


def persist(data):
    tmp = OUT / 'result.json.tmp'
    with tmp.open('x') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, OUT / 'result.json')


assert sha(PLAN) == PLAN_SHA
plan = json.loads(PLAN.read_text())
assert plan['source_commit'] == SOURCE and plan['target'] == str(TARGET)
assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
# Other local libraries in this minimal feature graph have identical source.
unchanged = ['crates/verum_common', 'crates/verum_ast', 'crates/verum_lexer', 'crates/verum_diagnostics', 'crates/verum_cbgr']
for path in unchanged:
    assert not git('diff', '--name-only', PREVIOUS, SOURCE, '--', path), path
assert len(plan['units']) == 3
for row in plan['units']:
    for key in ['marker', 'companion']:
        assert identity(Path(row[key])) == row[key + '_identity'], row[key]
processes = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,command='], text=True)
assert not [line for line in processes.splitlines() if str(TARGET) in line], 'target is not idle'
OUT.mkdir(exist_ok=False)
record = {'status': 'backing_up', 'source': SOURCE, 'target': str(TARGET), 'plan_sha256': PLAN_SHA,
          'runner_sha256': sha(Path(__file__)), 'unchanged_dependency_crates': unchanged,
          'target_idle_before': True, 'backups': [], 'outputs': {}, 'removed': [], 'pending_unlink': None}
persist(record)
try:
    # Retain all selected unit fingerprint metadata and dep-info before deletion.
    for row in plan['units']:
        unit = Path(row['marker']).parent.parent
        for path in sorted((unit / 'fingerprint').iterdir()):
            if path.is_file():
                destination = OUT / path.relative_to(TARGET)
                destination.parent.mkdir(parents=True, exist_ok=True)
                expected = identity(path)
                shutil.copy2(path, destination)
                with destination.open('rb') as stream:
                    os.fsync(stream.fileno())
                assert identity(destination) == expected
                record['backups'].append({'source': str(path), 'retained': str(destination), **expected})
        for path in sorted((unit / 'out').iterdir()):
            if path.is_file():
                record['outputs'][str(path)] = identity(path)
                if path.suffix == '.d':
                    destination = OUT / path.relative_to(TARGET)
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(path, destination)
                    assert identity(destination) == record['outputs'][str(path)]
        persist(record)
    # Revalidate the entire selected closure after backups, before any unlink.
    for row in plan['units']:
        for key in ['marker', 'companion']:
            assert identity(Path(row[key])) == row[key + '_identity'], row[key]
            assert identity(OUT / Path(row[key]).relative_to(TARGET)) == row[key + '_identity']
    for row in plan['units']:
        marker = Path(row['marker'])
        assert identity(marker) == row['marker_identity']
        record.update(status='invalidating', pending_unlink=str(marker))
        persist(record)
        marker.unlink()
        record['removed'].append(str(marker))
        record['pending_unlink'] = None
        persist(record)
    for row in plan['units']:
        assert not Path(row['marker']).exists()
        assert identity(Path(row['companion'])) == row['companion_identity']
    record['status'] = 'completed'
    persist(record)
except BaseException as error:
    record.update(status='failed', error=f'{type(error).__name__}: {error}')
    persist(record)
    raise
print(json.dumps({'status': record['status'], 'removed': len(record['removed']), 'receipt': str(OUT / 'result.json'), 'sha256': sha(OUT / 'result.json')}))
