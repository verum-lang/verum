from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path('/Users/taaliman/.codex/worktrees/configured-registry-downloads/verum')
OUT = Path('/private/tmp/verum-T1724-landing-wire')
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248-registry-client/target')
SOURCE = '41be1f4679357179fb1ddf56cda91d2118a5a563'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def git(*parts):
    return subprocess.check_output(['git', '-C', str(ROOT), *parts], text=True).strip()


record = json.loads((OUT / 'started.json').read_text())
log = OUT / 'gate.log'
text = log.read_text()
assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
assert all(digest(ROOT / path) == sha for path, sha in record['source_paths'].items())
assert digest(Path('/private/tmp/verum-T1724-landing-wire-runner.py')) == record['runner_sha256']
paths = set()
for line in text.splitlines():
    if line.lstrip().startswith('Running '):
        paths.update(re.findall(r'(/[^ `]+/stdlib_plain_data_visibility-[0-9a-f]+)(?=[ `]|$)', line))
assert len(paths) == 1, paths
exe = Path(paths.pop())
assert exe == TARGET / 'debug/build/verum_vbc/ed0c26c79bb7472f/out/stdlib_plain_data_visibility-ed0c26c79bb7472f'
retained = OUT / exe.name
if not retained.exists():
    subprocess.run(['/bin/cp', '-c', '-p', str(exe), str(retained)], check=True)
assert digest(exe) == digest(retained)
results = re.findall(r'^test result: [^\n]+', text, re.M)
assert len(results) == 1 and results[0].startswith('test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;')
names = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
expected = {'json_error_diagnostic_fields_are_public_in_source_and_archive', 'json_parser_state_remains_private_in_source_and_archive', 'weft_extracted_parameter_storage_remains_private_in_source_and_archive', 'weft_request_transport_fields_are_public_in_source_and_archive'}
assert len(names) == 4 and set(names) == expected
artifacts_after = {name: digest(TARGET / 'precompiled-stdlib' / name) for name in record['artifacts_before']}
assert artifacts_after == record['artifacts_before']
cache = json.loads(Path('/private/tmp/verum-T1724-landing-cache-plan.json').read_text())
units = []
for row in cache['units']:
    unit = Path(row['marker']).parent.parent
    files = {}
    for parent in [unit / 'fingerprint', unit / 'out']:
        for path in sorted(parent.iterdir()):
            if path.is_file():
                files[str(path.relative_to(TARGET))] = {'sha256': digest(path), 'bytes': path.stat().st_size}
                if parent.name == 'fingerprint' or path.suffix == '.d':
                    dest = OUT / 'units-after' / path.relative_to(TARGET)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    subprocess.run(['/bin/cp', '-c', '-p', str(path), str(dest)], check=True)
                    assert digest(dest) == files[str(path.relative_to(TARGET))]['sha256']
    units.append({'unit': str(unit.relative_to(TARGET)), 'files': files})
record.update(status='four_tests_passed_wrapper_harvest_failed', wrapper_exit_code=1, exit_code=None,
              failure='Original wrapper failed after completed libtest output while treating Cargo verbose package-description parentheses as an executable path. Cargo exit code was not persisted; no retry or rerun occurred.',
              test_results=results, test_names=names, announced_test_count=[4],
              recompiled_parser_and_vbc=all(value in text for value in ['Compiling verum_fast_parser ', 'Compiling verum_vbc ']),
              source_unchanged=True, source_paths_unchanged=True, artifacts_after=artifacts_after,
              executables={str(exe): {'sha256': digest(exe), 'retained': str(retained), 'retained_sha256': digest(retained), 'bytes': exe.stat().st_size}},
              units_after=units, log_sha256=digest(log), harvest_runner_sha256=digest(Path(__file__)),
              cargo_finished_line=re.findall(r'^\s*Finished `test` profile[^\n]+', text, re.M))
(OUT / 'wrapper-failure.log').write_text('Traceback (most recent call last):\n  File "/private/tmp/verum-T1724-landing-wire-runner.py", line 84, in <module>\n    assert path.is_file(), path\n           ~~~~~~~~~~~~^^\nAssertionError: VBC\n')
record['wrapper_failure_sha256'] = digest(OUT / 'wrapper-failure.log')
with (OUT / 'result.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'source': SOURCE, 'tests': results, 'status': record['status'], 'result_sha256': digest(OUT / 'result.json'), 'executable_sha256': digest(retained)}))
