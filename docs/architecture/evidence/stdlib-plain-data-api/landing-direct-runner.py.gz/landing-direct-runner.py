from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import time

ROOT = Path('/Users/taaliman/.codex/worktrees/configured-registry-downloads/verum')
PREVIOUS = Path('/private/tmp/verum-T1724-landing-wire/result.json')
OUT = Path('/private/tmp/verum-T1724-landing-direct')
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248-registry-client/target')
EXE = Path('/private/tmp/verum-T1724-landing-wire/stdlib_plain_data_visibility-ed0c26c79bb7472f')
SOURCE = '41be1f4679357179fb1ddf56cda91d2118a5a563'
EXPECTED_EXE_SHA = '1fb461a45e9df97e3cc2825c9437169a04f7d98216b27310cb8a847739bd17a4'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def git(*parts):
    return subprocess.check_output(['git', '-C', str(ROOT), *parts], text=True).strip()


def source_hashes(paths):
    return {name: digest(ROOT / name) for name in paths}


previous = json.loads(PREVIOUS.read_text())
assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
assert digest(EXE) == EXPECTED_EXE_SHA
assert source_hashes(previous['source_paths']) == previous['source_paths']
artifacts_before = {name: digest(TARGET / 'precompiled-stdlib' / name) for name in previous['artifacts_before']}
assert artifacts_before == previous['artifacts_before']
OUT.mkdir(exist_ok=False)
command = [str(EXE), '--test-threads=1', '--nocapture']
record = {'task': 'T1724', 'source_commit': SOURCE, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'command': command, 'environment': previous['environment'], 'deadline_seconds': 120,
          'source_paths': previous['source_paths'], 'artifacts_before': artifacts_before,
          'previous_run': str(PREVIOUS), 'previous_run_sha256': digest(PREVIOUS),
          'executable': {'path': str(EXE), 'sha256': EXPECTED_EXE_SHA, 'bytes': EXE.stat().st_size},
          'runner_sha256': digest(Path(__file__)),
          'scope': 'One explicitly authorized direct execution of the exact retained binary after the original Cargo wrapper failed harvesting completed test output. This completes missing process-exit evidence, does not rebuild, and does not replace or erase the first run. Four actual declaration-to-archive policy controls only; no Weft/JSON runtime, ordinary CLI, fresh stdlib, checker, AOT or registry acceptance.'}
(OUT / 'started.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
timeout = False
with (OUT / 'gate.log').open('xb') as stream:
    process = subprocess.Popen(command, cwd=ROOT, env={**os.environ, **record['environment']}, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (OUT / 'process.json').write_text(json.dumps({'pid': process.pid, 'runner_pid': os.getpid()}) + '\n')
    try:
        code = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timeout = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=10)
text = (OUT / 'gate.log').read_text()
record.update(exit_code=code, timed_out=timeout, seconds=round(time.monotonic() - start, 3),
              source_unchanged=git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain'),
              source_paths_unchanged=source_hashes(previous['source_paths']) == previous['source_paths'],
              artifacts_after={name: digest(TARGET / 'precompiled-stdlib' / name) for name in artifacts_before},
              executable_sha256_after=digest(EXE), log_sha256=digest(OUT / 'gate.log'),
              test_results=re.findall(r'^test result: [^\n]+', text, re.M),
              test_names=re.findall(r'^test (\S+) \.\.\. ok$', text, re.M),
              announced_test_counts=[int(n) for n in re.findall(r'^running (\d+) tests$', text, re.M)])
passed = (code == 0 and not timeout and record['source_unchanged'] and record['source_paths_unchanged']
          and record['artifacts_after'] == artifacts_before and record['executable_sha256_after'] == EXPECTED_EXE_SHA
          and record['announced_test_counts'] == [4] and record['test_names'] == previous['test_names']
          and len(record['test_results']) == 1
          and record['test_results'][0].startswith('test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'))
record['status'] = 'passed' if passed else 'failed'
(OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'source_commit', 'exit_code', 'seconds', 'test_results', 'source_unchanged', 'source_paths_unchanged']}))
raise SystemExit(0 if passed else 1)
