target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r6_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %call_result = call i64 @make()
  store i64 %call_result, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  store i64 6, ptr %r2_slot, align 8
  store i64 255, ptr %r4_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %and = and i64 %r2, %r4
  store i64 %and, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  store i64 %r3, ptr %r5_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %list_ptr = inttoptr i64 %r1 to ptr
  %r5 = load i64, ptr %r5_slot, align 8
  %len_slot = getelementptr inbounds i8, ptr %list_ptr, i64 24
  %len = load i64, ptr %len_slot, align 8
  %cap_slot = getelementptr inbounds i8, ptr %list_ptr, i64 32
  %cap = load i64, ptr %cap_slot, align 8
  %data_ptr_slot = getelementptr inbounds i8, ptr %list_ptr, i64 40
  %data_int = load i64, ptr %data_ptr_slot, align 8
  %data_ptr = inttoptr i64 %data_int to ptr
  %needs_grow = icmp uge i64 %len, %cap
  br i1 %needs_grow, label %list_grow, label %list_push_continue

list_grow:                                        ; preds = %block_0
  call void @verum_list_grow(ptr %list_ptr)
  br label %list_push_continue

list_push_continue:                               ; preds = %list_grow, %block_0
  %data_int_post = load i64, ptr %data_ptr_slot, align 8
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %list_ptr)
  %list_push_off = mul i64 %len, %list_storage_stride
  %list_push_addr = add i64 %data_int_post, %list_push_off
  %list_push_eptr = inttoptr i64 %list_push_addr to ptr
  switch i64 %list_storage_stride, label %list_push_sw8 [
    i64 1, label %list_push_sw1
    i64 2, label %list_push_sw2
    i64 4, label %list_push_sw4
  ]

list_push_sw1:                                    ; preds = %list_push_continue
  %list_push_st = trunc i64 %r5 to i8
  store i8 %list_push_st, ptr %list_push_eptr, align 1
  br label %list_push_smerge

list_push_sw2:                                    ; preds = %list_push_continue
  %list_push_st1 = trunc i64 %r5 to i16
  store i16 %list_push_st1, ptr %list_push_eptr, align 2
  br label %list_push_smerge

list_push_sw4:                                    ; preds = %list_push_continue
  %list_push_st2 = trunc i64 %r5 to i32
  store i32 %list_push_st2, ptr %list_push_eptr, align 4
  br label %list_push_smerge

list_push_sw8:                                    ; preds = %list_push_continue
  store i64 %r5, ptr %list_push_eptr, align 8
  br label %list_push_smerge

list_push_smerge:                                 ; preds = %list_push_sw8, %list_push_sw4, %list_push_sw2, %list_push_sw1
  %new_len = add i64 %len, 1
  store i64 %new_len, ptr %len_slot, align 8
  store i64 0, ptr %r3_slot, align 8
  %r13 = load i64, ptr %r1_slot, align 8
  %list_ptr4 = inttoptr i64 %r13 to ptr
  %lenc_w0 = load i64, ptr %list_ptr4, align 8
  %lenc_is_cell = icmp uge i64 %lenc_w0, 4294967296
  br i1 %lenc_is_cell, label %len_h1_cell, label %len_h1_obj

len_h1_cell:                                      ; preds = %list_push_smerge
  %cell_len_slot = getelementptr inbounds i8, ptr %list_ptr4, i64 8
  %cell_len = load i64, ptr %cell_len_slot, align 8
  br label %len_h1_done

len_h1_obj:                                       ; preds = %list_push_smerge
  %len_hdr_tid = load i32, ptr %list_ptr4, align 4
  %len_is_tuple_pack = icmp eq i32 %len_hdr_tid, 521
  %len_is_byte_slice = icmp eq i32 %len_hdr_tid, 528
  %len_is_pack = or i1 %len_is_tuple_pack, %len_is_byte_slice
  %list_len_slot = getelementptr inbounds i8, ptr %list_ptr4, i64 24
  %pack_len_slot = getelementptr inbounds i8, ptr %list_ptr4, i64 32
  %list_len = load i64, ptr %list_len_slot, align 8
  %pack_len = load i64, ptr %pack_len_slot, align 8
  %len_sel = select i1 %len_is_pack, i64 %pack_len, i64 %list_len
  br label %len_h1_done

len_h1_done:                                      ; preds = %len_h1_obj, %len_h1_cell
  %len_h1_val = phi i64 [ %cell_len, %len_h1_cell ], [ %len_sel, %len_h1_obj ]
  store i64 %len_h1_val, ptr %r3_slot, align 8
  store i64 10000, ptr %r2_slot, align 8
  %r35 = load i64, ptr %r3_slot, align 8
  %r26 = load i64, ptr %r2_slot, align 8
  %mul = mul i64 %r35, %r26
  store i64 %mul, ptr %r4_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r17 = load i64, ptr %r1_slot, align 8
  %arr_ptr = inttoptr i64 %r17 to ptr
  %r28 = load i64, ptr %r2_slot, align 8
  %backing_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %backing_int = load i64, ptr %backing_slot, align 8
  %backing_ptr = inttoptr i64 %backing_int to ptr
  %geteu_w0 = load i64, ptr %arr_ptr, align 8
  %geteu_is_cell = icmp uge i64 %geteu_w0, 4294967296
  br i1 %geteu_is_cell, label %geteu_cv_cell, label %geteu_cv_obj

geteu_cv_cell:                                    ; preds = %len_h1_done
  %geteu_cv_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 8
  %geteu_cv_cell_len = load i64, ptr %geteu_cv_len_slot, align 8
  %geteu_cv_elem_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 16
  %geteu_cv_elem_raw = load i64, ptr %geteu_cv_elem_slot, align 8
  %geteu_cv_e1 = icmp eq i64 %geteu_cv_elem_raw, 1
  %geteu_cv_ew = icmp eq i64 %geteu_cv_elem_raw, 2
  %geteu_cv_edom = or i1 %geteu_cv_e1, %geteu_cv_ew
  %geteu_cv_ew9 = icmp eq i64 %geteu_cv_elem_raw, 4
  %geteu_cv_edom10 = or i1 %geteu_cv_edom, %geteu_cv_ew9
  %geteu_cv_ew11 = icmp eq i64 %geteu_cv_elem_raw, 8
  %geteu_cv_edom12 = or i1 %geteu_cv_edom10, %geteu_cv_ew11
  %geteu_cv_elem = select i1 %geteu_cv_edom12, i64 %geteu_cv_elem_raw, i64 8
  br label %geteu_cv_done

geteu_cv_obj:                                     ; preds = %len_h1_done
  %geteu_cv_tid = load i32, ptr %arr_ptr, align 4
  %geteu_cv_is_tuple = icmp eq i32 %geteu_cv_tid, 521
  %geteu_cv_is_bslice = icmp eq i32 %geteu_cv_tid, 528
  %geteu_cv_is_pack = or i1 %geteu_cv_is_tuple, %geteu_cv_is_bslice
  br i1 %geteu_cv_is_pack, label %geteu_cv_pack, label %geteu_cv_list

geteu_cv_pack:                                    ; preds = %geteu_cv_obj
  %geteu_cv_pk_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_pk_data = load i64, ptr %geteu_cv_pk_data_slot, align 8
  %geteu_cv_pk_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 32
  %geteu_cv_pk_len = load i64, ptr %geteu_cv_pk_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_list:                                    ; preds = %geteu_cv_obj
  %geteu_cv_ls_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %geteu_cv_ls_data = load i64, ptr %geteu_cv_ls_data_slot, align 8
  %geteu_cv_ls_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_ls_len = load i64, ptr %geteu_cv_ls_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_done:                                    ; preds = %geteu_cv_list, %geteu_cv_pack, %geteu_cv_cell
  %geteu_cv_data = phi i64 [ %geteu_w0, %geteu_cv_cell ], [ %geteu_cv_pk_data, %geteu_cv_pack ], [ %geteu_cv_ls_data, %geteu_cv_list ]
  %geteu_cv_len = phi i64 [ %geteu_cv_cell_len, %geteu_cv_cell ], [ %geteu_cv_pk_len, %geteu_cv_pack ], [ %geteu_cv_ls_len, %geteu_cv_list ]
  %geteu_cv_elem13 = phi i64 [ %geteu_cv_elem, %geteu_cv_cell ], [ 1, %geteu_cv_pack ], [ 8, %geteu_cv_list ]
  %geteu_off = mul i64 %r28, %geteu_cv_elem13
  %geteu_addr = add i64 %geteu_cv_data, %geteu_off
  %geteu_eptr = inttoptr i64 %geteu_addr to ptr
  switch i64 %geteu_cv_elem13, label %geteu_lw8 [
    i64 1, label %geteu_lw1
    i64 2, label %geteu_lw2
    i64 4, label %geteu_lw4
  ]

geteu_lw1:                                        ; preds = %geteu_cv_done
  %geteu_lv = load i8, ptr %geteu_eptr, align 1
  %geteu_lz = zext i8 %geteu_lv to i64
  br label %geteu_lmerge

geteu_lw2:                                        ; preds = %geteu_cv_done
  %geteu_lv14 = load i16, ptr %geteu_eptr, align 2
  %geteu_lz15 = zext i16 %geteu_lv14 to i64
  br label %geteu_lmerge

geteu_lw4:                                        ; preds = %geteu_cv_done
  %geteu_lv16 = load i32, ptr %geteu_eptr, align 4
  %geteu_lz17 = zext i32 %geteu_lv16 to i64
  br label %geteu_lmerge

geteu_lw8:                                        ; preds = %geteu_cv_done
  %geteu_lv8 = load i64, ptr %geteu_eptr, align 8
  br label %geteu_lmerge

geteu_lmerge:                                     ; preds = %geteu_lw8, %geteu_lw4, %geteu_lw2, %geteu_lw1
  %geteu_lval = phi i64 [ %geteu_lz, %geteu_lw1 ], [ %geteu_lz15, %geteu_lw2 ], [ %geteu_lz17, %geteu_lw4 ], [ %geteu_lv8, %geteu_lw8 ]
  store i64 %geteu_lval, ptr %r3_slot, align 8
  store i64 100, ptr %r2_slot, align 8
  %r318 = load i64, ptr %r3_slot, align 8
  %r219 = load i64, ptr %r2_slot, align 8
  %mul20 = mul i64 %r318, %r219
  store i64 %mul20, ptr %r6_slot, align 8
  %r421 = load i64, ptr %r4_slot, align 8
  %r6 = load i64, ptr %r6_slot, align 8
  %add = add i64 %r421, %r6
  store i64 %add, ptr %r2_slot, align 8
  store i64 2, ptr %r6_slot, align 8
  %r122 = load i64, ptr %r1_slot, align 8
  %arr_ptr23 = inttoptr i64 %r122 to ptr
  %r624 = load i64, ptr %r6_slot, align 8
  %backing_slot25 = getelementptr inbounds i8, ptr %arr_ptr23, i64 40
  %backing_int26 = load i64, ptr %backing_slot25, align 8
  %backing_ptr27 = inttoptr i64 %backing_int26 to ptr
  %geteu_w033 = load i64, ptr %arr_ptr23, align 8
  %geteu_is_cell34 = icmp uge i64 %geteu_w033, 4294967296
  br i1 %geteu_is_cell34, label %geteu_cv_cell28, label %geteu_cv_obj29

geteu_cv_cell28:                                  ; preds = %geteu_lmerge
  %geteu_cv_len_slot35 = getelementptr inbounds i8, ptr %arr_ptr23, i64 8
  %geteu_cv_cell_len36 = load i64, ptr %geteu_cv_len_slot35, align 8
  %geteu_cv_elem_slot37 = getelementptr inbounds i8, ptr %arr_ptr23, i64 16
  %geteu_cv_elem_raw38 = load i64, ptr %geteu_cv_elem_slot37, align 8
  %geteu_cv_e139 = icmp eq i64 %geteu_cv_elem_raw38, 1
  %geteu_cv_ew40 = icmp eq i64 %geteu_cv_elem_raw38, 2
  %geteu_cv_edom41 = or i1 %geteu_cv_e139, %geteu_cv_ew40
  %geteu_cv_ew42 = icmp eq i64 %geteu_cv_elem_raw38, 4
  %geteu_cv_edom43 = or i1 %geteu_cv_edom41, %geteu_cv_ew42
  %geteu_cv_ew44 = icmp eq i64 %geteu_cv_elem_raw38, 8
  %geteu_cv_edom45 = or i1 %geteu_cv_edom43, %geteu_cv_ew44
  %geteu_cv_elem46 = select i1 %geteu_cv_edom45, i64 %geteu_cv_elem_raw38, i64 8
  br label %geteu_cv_done32

geteu_cv_obj29:                                   ; preds = %geteu_lmerge
  %geteu_cv_tid47 = load i32, ptr %arr_ptr23, align 4
  %geteu_cv_is_tuple48 = icmp eq i32 %geteu_cv_tid47, 521
  %geteu_cv_is_bslice49 = icmp eq i32 %geteu_cv_tid47, 528
  %geteu_cv_is_pack50 = or i1 %geteu_cv_is_tuple48, %geteu_cv_is_bslice49
  br i1 %geteu_cv_is_pack50, label %geteu_cv_pack30, label %geteu_cv_list31

geteu_cv_pack30:                                  ; preds = %geteu_cv_obj29
  %geteu_cv_pk_data_slot51 = getelementptr inbounds i8, ptr %arr_ptr23, i64 24
  %geteu_cv_pk_data52 = load i64, ptr %geteu_cv_pk_data_slot51, align 8
  %geteu_cv_pk_len_slot53 = getelementptr inbounds i8, ptr %arr_ptr23, i64 32
  %geteu_cv_pk_len54 = load i64, ptr %geteu_cv_pk_len_slot53, align 8
  br label %geteu_cv_done32

geteu_cv_list31:                                  ; preds = %geteu_cv_obj29
  %geteu_cv_ls_data_slot55 = getelementptr inbounds i8, ptr %arr_ptr23, i64 40
  %geteu_cv_ls_data56 = load i64, ptr %geteu_cv_ls_data_slot55, align 8
  %geteu_cv_ls_len_slot57 = getelementptr inbounds i8, ptr %arr_ptr23, i64 24
  %geteu_cv_ls_len58 = load i64, ptr %geteu_cv_ls_len_slot57, align 8
  br label %geteu_cv_done32

geteu_cv_done32:                                  ; preds = %geteu_cv_list31, %geteu_cv_pack30, %geteu_cv_cell28
  %geteu_cv_data59 = phi i64 [ %geteu_w033, %geteu_cv_cell28 ], [ %geteu_cv_pk_data52, %geteu_cv_pack30 ], [ %geteu_cv_ls_data56, %geteu_cv_list31 ]
  %geteu_cv_len60 = phi i64 [ %geteu_cv_cell_len36, %geteu_cv_cell28 ], [ %geteu_cv_pk_len54, %geteu_cv_pack30 ], [ %geteu_cv_ls_len58, %geteu_cv_list31 ]
  %geteu_cv_elem61 = phi i64 [ %geteu_cv_elem46, %geteu_cv_cell28 ], [ 1, %geteu_cv_pack30 ], [ 8, %geteu_cv_list31 ]
  %geteu_off62 = mul i64 %r624, %geteu_cv_elem61
  %geteu_addr63 = add i64 %geteu_cv_data59, %geteu_off62
  %geteu_eptr64 = inttoptr i64 %geteu_addr63 to ptr
  switch i64 %geteu_cv_elem61, label %geteu_lw868 [
    i64 1, label %geteu_lw165
    i64 2, label %geteu_lw266
    i64 4, label %geteu_lw467
  ]

geteu_lw165:                                      ; preds = %geteu_cv_done32
  %geteu_lv70 = load i8, ptr %geteu_eptr64, align 1
  %geteu_lz71 = zext i8 %geteu_lv70 to i64
  br label %geteu_lmerge69

geteu_lw266:                                      ; preds = %geteu_cv_done32
  %geteu_lv72 = load i16, ptr %geteu_eptr64, align 2
  %geteu_lz73 = zext i16 %geteu_lv72 to i64
  br label %geteu_lmerge69

geteu_lw467:                                      ; preds = %geteu_cv_done32
  %geteu_lv74 = load i32, ptr %geteu_eptr64, align 4
  %geteu_lz75 = zext i32 %geteu_lv74 to i64
  br label %geteu_lmerge69

geteu_lw868:                                      ; preds = %geteu_cv_done32
  %geteu_lv876 = load i64, ptr %geteu_eptr64, align 8
  br label %geteu_lmerge69

geteu_lmerge69:                                   ; preds = %geteu_lw868, %geteu_lw467, %geteu_lw266, %geteu_lw165
  %geteu_lval77 = phi i64 [ %geteu_lz71, %geteu_lw165 ], [ %geteu_lz73, %geteu_lw266 ], [ %geteu_lz75, %geteu_lw467 ], [ %geteu_lv876, %geteu_lw868 ]
  store i64 %geteu_lval77, ptr %r4_slot, align 8
  %r278 = load i64, ptr %r2_slot, align 8
  %r479 = load i64, ptr %r4_slot, align 8
  %add80 = add i64 %r278, %r479
  store i64 %add80, ptr %r6_slot, align 8
  %r681 = load i64, ptr %r6_slot, align 8
  store i64 %r681, ptr %r4_slot, align 8
  %r182 = load i64, ptr %r1_slot, align 8
  %r483 = load i64, ptr %r4_slot, align 8
  %r484 = load i64, ptr %r4_slot, align 8
  ret i64 %r484
}

define internal i64 @verum_list_storage_stride(ptr %0) {
entry:
  %missing_list = icmp eq ptr %0, null
  br i1 %missing_list, label %invalid, label %read_tag

read_tag:                                         ; preds = %entry
  %list_storage_type = load i32, ptr %0, align 4
  switch i32 %list_storage_type, label %invalid [
    i32 512, label %storage
    i32 527, label %storage1
  ]

invalid:                                          ; preds = %read_tag, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

storage:                                          ; preds = %read_tag
  ret i64 8

storage1:                                         ; preds = %read_tag
  ret i64 1
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal void @verum_list_grow(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %grow

grow:                                             ; preds = %entry
  %cap_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_cap = load i64, ptr %cap_slot, align 8
  %cap_2x = mul i64 %old_cap, 2
  %use_min = icmp slt i64 %cap_2x, 32
  %new_cap = select i1 %use_min, i64 32, i64 %cap_2x
  call void @verum_list_resize_storage(ptr %0, i64 %new_cap)
  br label %ret

ret:                                              ; preds = %grow, %entry
  ret void
}

define internal void @verum_list_resize_storage(ptr %0, i64 %1) {
entry:
  %resized = call i64 @verum_list_try_resize_storage(ptr %0, i64 %1)
  %ok = icmp ne i64 %resized, 0
  br i1 %ok, label %ready, label %failed

ready:                                            ; preds = %entry
  ret void

failed:                                           ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal i64 @verum_list_try_resize_storage(ptr %0, i64 %1) {
entry:
  %validated_owner = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 0)
  %length_slot = getelementptr inbounds i8, ptr %0, i64 24
  %length = load i64, ptr %length_slot, align 8
  %initialized_prefix = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 %length)
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %capacity_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_capacity = load i64, ptr %capacity_slot, align 8
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %old_data = load i64, ptr %data_slot, align 8
  %old_pointer = inttoptr i64 %old_data to ptr
  %capacity_limit = udiv i64 4294967199, %list_storage_stride
  %fits = icmp ule i64 %1, %capacity_limit
  %retains_initialized = icmp uge i64 %1, %length
  %allowed = and i1 %fits, %retains_initialized
  br i1 %allowed, label %valid_capacity, label %failure

valid_capacity:                                   ; preds = %entry
  %unchanged = icmp eq i64 %1, %old_capacity
  br i1 %unchanged, label %success, label %change

change:                                           ; preds = %valid_capacity
  %release_storage = icmp eq i64 %1, 0
  br i1 %release_storage, label %release, label %allocate

release:                                          ; preds = %change
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  store i64 0, ptr %data_slot, align 8
  store i64 0, ptr %capacity_slot, align 8
  br label %success

allocate:                                         ; preds = %change
  %allocation_bytes = mul i64 %1, %list_storage_stride
  %new_backing = call ptr @verum_try_cbgr_allocate_aligned(i64 %allocation_bytes, i64 %list_storage_stride)
  %allocation_failed = icmp eq ptr %new_backing, null
  br i1 %allocation_failed, label %failure, label %allocated

copy:                                             ; preds = %allocated
  %initialized_bytes = mul i64 %length, %list_storage_stride
  %2 = call ptr @verum_internal_memcpy(ptr %new_backing, ptr %initialized_prefix, i64 %initialized_bytes)
  br label %publish

publish:                                          ; preds = %copy, %allocated
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  %new_backing_word = ptrtoint ptr %new_backing to i64
  store i64 %new_backing_word, ptr %data_slot, align 8
  store i64 %1, ptr %capacity_slot, align 8
  br label %success

success:                                          ; preds = %publish, %release, %valid_capacity
  ret i64 1

failure:                                          ; preds = %allocate, %entry
  ret i64 0

allocated:                                        ; preds = %allocate
  %has_initialized_prefix = icmp ne i64 %length, 0
  br i1 %has_initialized_prefix, label %copy, label %publish
}

define internal void @verum_cbgr_deallocate(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %do_dealloc

do_dealloc:                                       ; preds = %entry
  %header_ptr = getelementptr i8, ptr %0, i64 -32
  %gen_ptr = getelementptr i8, ptr %header_ptr, i64 8
  %1 = atomicrmw add ptr %gen_ptr, i32 1 acq_rel, align 4
  %new_gen = add i32 %1, 1
  %ge_max = icmp uge i32 %new_gen, -2
  %lt_old = icmp ult i32 %new_gen, %1
  %overflow = or i1 %ge_max, %lt_old
  br i1 %overflow, label %overflow1, label %set_ref

ret:                                              ; preds = %entry
  ret void

overflow1:                                        ; preds = %do_dealloc
  store i32 1, ptr %gen_ptr, align 4
  %epoch_ptr = getelementptr i8, ptr %header_ptr, i64 12
  %2 = atomicrmw add ptr %epoch_ptr, i16 1 release, align 2
  br label %set_ref

set_ref:                                          ; preds = %overflow1, %do_dealloc
  %rc_ptr = getelementptr i8, ptr %header_ptr, i64 24
  store i32 0, ptr %rc_ptr, align 4
  %hdr_total_ptr = getelementptr i8, ptr %header_ptr, i64 28
  %hdr_total = load i32, ptr %hdr_total_ptr, align 4
  %total = zext i32 %hdr_total to i64
  %hdr_base_off_ptr = getelementptr i8, ptr %header_ptr, i64 6
  %hdr_base_off = load i16, ptr %hdr_base_off_ptr, align 2
  %base_off64 = zext i16 %hdr_base_off to i64
  %header_int = ptrtoint ptr %header_ptr to i64
  %base_int = sub i64 %header_int, %base_off64
  %base = inttoptr i64 %base_int to ptr
  call void @verum_dealloc(ptr %base, i64 %total)
  ret void
}

define void @verum_dealloc(ptr %0, i64 %1) {
entry:
  %dptr_i64 = ptrtoint ptr %0 to i64
  %dptr_null = icmp eq i64 %dptr_i64, 0
  br i1 %dptr_null, label %d_done, label %d_check_size

d_large:                                          ; preds = %d_check_size
  %d_plus_page = add i64 %1, 4095
  %d_page_size = and i64 %d_plus_page, -4096
  call void @verum_os_free(ptr %0, i64 %d_page_size)
  br label %d_done

d_small:                                          ; preds = %d_check_size
  %d_size_m1 = sub i64 %1, 1
  %d_ctlz = call i64 @llvm.ctlz.i64(i64 %d_size_m1, i1 false)
  %d_shift = sub i64 64, %d_ctlz
  %d_class_signed = sub i64 %d_shift, 4
  %d_neg = icmp slt i64 %d_class_signed, 0
  %d_class = select i1 %d_neg, i64 0, i64 %d_class_signed
  br label %d_acquire

d_acquire:                                        ; preds = %d_acquire, %d_small
  %2 = cmpxchg ptr @__verum_alloc_lock, i32 0, i32 1 acquire monotonic, align 4
  %d_cas_ok = extractvalue { i32, i1 } %2, 1
  br i1 %d_cas_ok, label %d_locked, label %d_acquire

d_locked:                                         ; preds = %d_acquire
  %d_head_slot = getelementptr inbounds [9 x ptr], ptr @__verum_freelist_heads, i64 0, i64 %d_class
  %old_head = load ptr, ptr %d_head_slot, align 8
  store ptr %old_head, ptr %0, align 8
  store ptr %0, ptr %d_head_slot, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  br label %d_done

d_done:                                           ; preds = %d_locked, %d_large, %entry
  ret void

d_check_size:                                     ; preds = %entry
  %d_large_q = icmp ugt i64 %1, 4096
  br i1 %d_large_q, label %d_large, label %d_small
}

@__verum_alloc_lock = internal global i32 0
@__verum_freelist_heads = internal global [9 x ptr] zeroinitializer
; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #8

define void @verum_os_free(ptr %0, i64 %1) {
entry:
  %munmap_rc = call i64 @munmap(ptr %0, i64 %1)
  ret void
}

declare i64 @munmap(ptr, i64)

define internal ptr @verum_internal_memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr %0, ptr %1, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

define internal ptr @verum_try_cbgr_allocate_aligned(i64 %0, i64 %1) {
entry:
  %lt32 = icmp ult i64 %1, 32
  %align = select i1 %lt32, i64 32, i64 %1
  %add31 = add i64 %0, 31
  %aligned = and i64 %add31, -32
  %with_hdr = add i64 %aligned, 32
  %total = add i64 %with_hdr, %align
  %raw = call ptr @verum_os_alloc(i64 %total)
  %is_null = icmp eq ptr %raw, null
  br i1 %is_null, label %null_ret, label %init

init:                                             ; preds = %entry
  %2 = call ptr @memset(ptr %raw, i32 0, i64 %total)
  %raw_int = ptrtoint ptr %raw to i64
  %user0 = add i64 %raw_int, 32
  %align_m1 = sub i64 %align, 1
  %bumped = add i64 %user0, %align_m1
  %align_mask = xor i64 %align_m1, -1
  %user_int = and i64 %bumped, %align_mask
  %header_int = sub i64 %user_int, 32
  %header = inttoptr i64 %header_int to ptr
  %gen_ptr = getelementptr i8, ptr %header, i64 8
  store i32 1, ptr %gen_ptr, align 4
  %size32 = trunc i64 %0 to i32
  %size_ptr = getelementptr i8, ptr %header, i64 0
  store i32 %size32, ptr %size_ptr, align 4
  %epoch64 = load i64, ptr @global_epoch, align 8
  %epoch16 = trunc i64 %epoch64 to i16
  %epoch_ptr = getelementptr i8, ptr %header, i64 12
  store i16 %epoch16, ptr %epoch_ptr, align 2
  %cap_ptr = getelementptr i8, ptr %header, i64 14
  store i16 255, ptr %cap_ptr, align 2
  %rc_ptr = getelementptr i8, ptr %header, i64 24
  store i32 1, ptr %rc_ptr, align 4
  %align16 = trunc i64 %1 to i16
  %align_ptr = getelementptr i8, ptr %header, i64 4
  store i16 %align16, ptr %align_ptr, align 2
  %base_off64 = sub i64 %header_int, %raw_int
  %base_off16 = trunc i64 %base_off64 to i16
  %base_off_ptr = getelementptr i8, ptr %header, i64 6
  store i16 %base_off16, ptr %base_off_ptr, align 2
  %total32 = trunc i64 %total to i32
  %total_ptr = getelementptr i8, ptr %header, i64 28
  store i32 %total32, ptr %total_ptr, align 4
  %user_ptr = inttoptr i64 %user_int to ptr
  ret ptr %user_ptr

null_ret:                                         ; preds = %entry
  ret ptr null
}

@global_epoch = global i64 0
declare ptr @memset(ptr, i32, i64)

define ptr @verum_os_alloc(i64 %0) {
entry:
  %mmap_result = call i64 @mmap(i64 0, i64 %0, i64 3, i64 4098, i64 -1, i64 0)
  %mmap_ptr = inttoptr i64 %mmap_result to ptr
  ret ptr %mmap_ptr
}

declare i64 @mmap(i64, i64, i64, i64, i64, i64)

define internal ptr @verum_list_storage_address(ptr %0, i64 %1, i64 %2) {
entry:
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %object_size_ptr = getelementptr inbounds i8, ptr %0, i64 12
  %object_size = load i32, ptr %object_size_ptr, align 4
  %valid_object_shape = icmp uge i32 %object_size, 48
  br i1 %valid_object_shape, label %shape, label %invalid

shape:                                            ; preds = %entry
  %capacity_ptr = getelementptr inbounds i8, ptr %0, i64 32
  %capacity = load i64, ptr %capacity_ptr, align 8
  %capacity_limit = udiv i64 4294967295, %list_storage_stride
  %valid_capacity = icmp ule i64 %capacity, %capacity_limit
  %valid_index = icmp ule i64 %1, %capacity
  %remaining_capacity = sub i64 %capacity, %1
  %valid_count = icmp ule i64 %2, %remaining_capacity
  %valid_owner_index = and i1 %valid_capacity, %valid_index
  %valid_range = and i1 %valid_owner_index, %valid_count
  br i1 %valid_range, label %range_ok, label %invalid

range_ok:                                         ; preds = %shape
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %data_word = load i64, ptr %data_slot, align 8
  %data = inttoptr i64 %data_word to ptr
  %missing_storage = icmp eq ptr %data, null
  br i1 %missing_storage, label %missing_backing, label %extent

empty:                                            ; preds = %ready, %missing_backing
  ret ptr null

nonempty_address:                                 ; preds = %ready
  %element_offset = mul i64 %1, %list_storage_stride
  %element_address = getelementptr inbounds i8, ptr %data, i64 %element_offset
  ret ptr %element_address

missing_backing:                                  ; preds = %range_ok
  %empty_owner = icmp eq i64 %capacity, 0
  br i1 %empty_owner, label %empty, label %invalid

extent:                                           ; preds = %range_ok
  %header_ptr = getelementptr i8, ptr %data, i64 -32
  %extent_ptr = getelementptr inbounds i8, ptr %header_ptr, i64 0
  %allocation_extent = load i32, ptr %extent_ptr, align 4
  %allocation_extent64 = zext i32 %allocation_extent to i64
  %capacity_bytes = mul i64 %capacity, %list_storage_stride
  %capacity_fits_allocation = icmp ule i64 %capacity_bytes, %allocation_extent64
  br i1 %capacity_fits_allocation, label %ready, label %invalid

ready:                                            ; preds = %extent
  %empty_range = icmp eq i64 %2, 0
  br i1 %empty_range, label %empty, label %nonempty_address

invalid:                                          ; preds = %extent, %missing_backing, %shape, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

; Function Attrs: nounwind
define internal i64 @make() #6 {
block_0:
  %r5_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 2, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r1)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %ba_init8 = trunc i64 %r2 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r1, i1 false)
  store i64 0, ptr %r2_slot, align 8
  store i64 4, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %ba_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r21
  %ba_trunc = trunc i64 %r12 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 1, ptr %r1_slot, align 8
  store i64 5, ptr %r2_slot, align 8
  %r03 = load i64, ptr %r0_slot, align 8
  %ba_base4 = inttoptr i64 %r03 to ptr
  %r15 = load i64, ptr %r1_slot, align 8
  %r26 = load i64, ptr %r2_slot, align 8
  %ba_store_ptr7 = getelementptr i8, ptr %ba_base4, i64 %r15
  %ba_trunc8 = trunc i64 %r26 to i8
  store i8 %ba_trunc8, ptr %ba_store_ptr7, align 1
  %r09 = load i64, ptr %r0_slot, align 8
  store i64 %r09, ptr %r3_slot, align 8
  %list_obj = call ptr @verum_list_allocate_storage(i64 2, i32 512)
  %r2_ptr_to_i64 = ptrtoint ptr %list_obj to i64
  store i64 %r2_ptr_to_i64, ptr %r2_slot, align 8
  store i64 2, ptr %r1_slot, align 8
  store i64 0, ptr %r4_slot, align 8
  br label %block_1

block_1:                                          ; preds = %list_push_smerge, %block_0
  %r4 = load i64, ptr %r4_slot, align 8
  %r110 = load i64, ptr %r1_slot, align 8
  %icmp = icmp slt i64 %r4, %r110
  %r5_widen = zext i1 %icmp to i64
  store i64 %r5_widen, ptr %r5_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %jmpnot_cond = trunc i64 %r5 to i1
  br i1 %jmpnot_cond, label %block_2, label %block_3

block_2:                                          ; preds = %block_1
  %r3 = load i64, ptr %r3_slot, align 8
  %tal_base = inttoptr i64 %r3 to ptr
  %r411 = load i64, ptr %r4_slot, align 8
  %tal_off = mul i64 %r411, 1
  %tal_ptr = getelementptr i8, ptr %tal_base, i64 %tal_off
  %tal_raw = load i8, ptr %tal_ptr, align 1
  %tal_zext = zext i8 %tal_raw to i64
  store i64 %tal_zext, ptr %r5_slot, align 8
  %r212 = load i64, ptr %r2_slot, align 8
  %list_ptr = inttoptr i64 %r212 to ptr
  %r513 = load i64, ptr %r5_slot, align 8
  %len_slot = getelementptr inbounds i8, ptr %list_ptr, i64 24
  %len = load i64, ptr %len_slot, align 8
  %cap_slot = getelementptr inbounds i8, ptr %list_ptr, i64 32
  %cap = load i64, ptr %cap_slot, align 8
  %data_ptr_slot = getelementptr inbounds i8, ptr %list_ptr, i64 40
  %data_int = load i64, ptr %data_ptr_slot, align 8
  %data_ptr = inttoptr i64 %data_int to ptr
  %needs_grow = icmp uge i64 %len, %cap
  br i1 %needs_grow, label %list_grow, label %list_push_continue

block_3:                                          ; preds = %block_1
  %r217 = load i64, ptr %r2_slot, align 8
  %r218 = load i64, ptr %r2_slot, align 8
  ret i64 %r218

list_grow:                                        ; preds = %block_2
  call void @verum_list_grow(ptr %list_ptr)
  br label %list_push_continue

list_push_continue:                               ; preds = %list_grow, %block_2
  %data_int_post = load i64, ptr %data_ptr_slot, align 8
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %list_ptr)
  %list_push_off = mul i64 %len, %list_storage_stride
  %list_push_addr = add i64 %data_int_post, %list_push_off
  %list_push_eptr = inttoptr i64 %list_push_addr to ptr
  switch i64 %list_storage_stride, label %list_push_sw8 [
    i64 1, label %list_push_sw1
    i64 2, label %list_push_sw2
    i64 4, label %list_push_sw4
  ]

list_push_sw1:                                    ; preds = %list_push_continue
  %list_push_st = trunc i64 %r513 to i8
  store i8 %list_push_st, ptr %list_push_eptr, align 1
  br label %list_push_smerge

list_push_sw2:                                    ; preds = %list_push_continue
  %list_push_st14 = trunc i64 %r513 to i16
  store i16 %list_push_st14, ptr %list_push_eptr, align 2
  br label %list_push_smerge

list_push_sw4:                                    ; preds = %list_push_continue
  %list_push_st15 = trunc i64 %r513 to i32
  store i32 %list_push_st15, ptr %list_push_eptr, align 4
  br label %list_push_smerge

list_push_sw8:                                    ; preds = %list_push_continue
  store i64 %r513, ptr %list_push_eptr, align 8
  br label %list_push_smerge

list_push_smerge:                                 ; preds = %list_push_sw8, %list_push_sw4, %list_push_sw2, %list_push_sw1
  %new_len = add i64 %len, 1
  store i64 %new_len, ptr %len_slot, align 8
  %r416 = load i64, ptr %r4_slot, align 8
  %inc = add i64 %r416, 1
  store i64 %inc, ptr %r4_slot, align 8
  br label %block_1
}

define internal ptr @verum_list_allocate_storage(i64 %0, i32 %1) {
entry:
  %slots = icmp eq i32 %1, 512
  %bytes = icmp eq i32 %1, 527
  %known_encoding = or i1 %slots, %bytes
  br i1 %known_encoding, label %valid_encoding, label %invalid

valid_encoding:                                   ; preds = %entry
  %width = select i1 %bytes, i64 1, i64 8
  %capacity_limit = udiv i64 4294967295, %width
  %capacity_fits = icmp ule i64 %0, %capacity_limit
  br i1 %capacity_fits, label %allocate, label %invalid

allocate:                                         ; preds = %valid_encoding
  %list_owner = call ptr @verum_checked_malloc(i64 48)
  %malloc_null = icmp eq ptr %list_owner, null
  br i1 %malloc_null, label %list_owner_oom, label %list_owner_ok

invalid:                                          ; preds = %valid_encoding, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_oom:                                   ; preds = %allocate
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_ok:                                    ; preds = %allocate
  %2 = call ptr @verum_internal_memset(ptr %list_owner, i32 0, i64 48)
  store i32 %1, ptr %list_owner, align 4
  %list_object_size = getelementptr inbounds i8, ptr %list_owner, i64 12
  store i32 48, ptr %list_object_size, align 4
  call void @verum_list_resize_storage(ptr %list_owner, i64 %0)
  ret ptr %list_owner
}

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

