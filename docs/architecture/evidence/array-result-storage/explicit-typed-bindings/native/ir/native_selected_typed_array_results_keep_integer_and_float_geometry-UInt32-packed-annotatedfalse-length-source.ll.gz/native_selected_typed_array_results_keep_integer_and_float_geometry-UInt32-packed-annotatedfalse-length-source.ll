target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %call_result = call i64 @selected()
  store i64 %call_result, ptr %r0_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r1_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  store i64 %r2, ptr %r3_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %r31 = load i64, ptr %r3_slot, align 8
  ret i64 %r31
}

; Function Attrs: nounwind
define internal i64 @selected() #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 2, ptr %r1_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %ta_bytes = mul i64 %r1, 4
  %new_typed_array = call ptr @verum_cbgr_allocate(i64 %ta_bytes)
  %r0_ptr_to_i64 = ptrtoint ptr %new_typed_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  br label %ta_fill_check

ta_fill_check:                                    ; preds = %ta_fill_body, %block_0
  %ta_i = phi i64 [ 0, %block_0 ], [ %ta_next, %ta_fill_body ]
  %ta_more = icmp slt i64 %ta_i, %r1
  br i1 %ta_more, label %ta_fill_body, label %ta_fill_done

ta_fill_body:                                     ; preds = %ta_fill_check
  %ta_slot = getelementptr inbounds i32, ptr %new_typed_array, i64 %ta_i
  %ta_v = trunc i64 %r2 to i32
  store i32 %ta_v, ptr %ta_slot, align 4
  %ta_next = add i64 %ta_i, 1
  br label %ta_fill_check

ta_fill_done:                                     ; preds = %ta_fill_check
  store i64 0, ptr %r2_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %tas_base = inttoptr i64 %r0 to ptr
  %r21 = load i64, ptr %r2_slot, align 8
  %r12 = load i64, ptr %r1_slot, align 8
  %tas_off = mul i64 %r21, 4
  %tas_ptr = getelementptr i8, ptr %tas_base, i64 %tas_off
  switch i64 4, label %tas_sw8 [
    i64 1, label %tas_sw1
    i64 2, label %tas_sw2
    i64 4, label %tas_sw4
  ]

tas_sw1:                                          ; preds = %ta_fill_done
  %tas_st = trunc i64 %r12 to i8
  store i8 %tas_st, ptr %tas_ptr, align 1
  br label %tas_smerge

tas_sw2:                                          ; preds = %ta_fill_done
  %tas_st3 = trunc i64 %r12 to i16
  store i16 %tas_st3, ptr %tas_ptr, align 2
  br label %tas_smerge

tas_sw4:                                          ; preds = %ta_fill_done
  %tas_st4 = trunc i64 %r12 to i32
  store i32 %tas_st4, ptr %tas_ptr, align 4
  br label %tas_smerge

tas_sw8:                                          ; preds = %ta_fill_done
  store i64 %r12, ptr %tas_ptr, align 8
  br label %tas_smerge

tas_smerge:                                       ; preds = %tas_sw8, %tas_sw4, %tas_sw2, %tas_sw1
  store i64 1, ptr %r1_slot, align 8
  store i64 65539, ptr %r2_slot, align 8
  %r05 = load i64, ptr %r0_slot, align 8
  %tas_base6 = inttoptr i64 %r05 to ptr
  %r17 = load i64, ptr %r1_slot, align 8
  %r28 = load i64, ptr %r2_slot, align 8
  %tas_off9 = mul i64 %r17, 4
  %tas_ptr10 = getelementptr i8, ptr %tas_base6, i64 %tas_off9
  switch i64 4, label %tas_sw814 [
    i64 1, label %tas_sw111
    i64 2, label %tas_sw212
    i64 4, label %tas_sw413
  ]

tas_sw111:                                        ; preds = %tas_smerge
  %tas_st16 = trunc i64 %r28 to i8
  store i8 %tas_st16, ptr %tas_ptr10, align 1
  br label %tas_smerge15

tas_sw212:                                        ; preds = %tas_smerge
  %tas_st17 = trunc i64 %r28 to i16
  store i16 %tas_st17, ptr %tas_ptr10, align 2
  br label %tas_smerge15

tas_sw413:                                        ; preds = %tas_smerge
  %tas_st18 = trunc i64 %r28 to i32
  store i32 %tas_st18, ptr %tas_ptr10, align 4
  br label %tas_smerge15

tas_sw814:                                        ; preds = %tas_smerge
  store i64 %r28, ptr %tas_ptr10, align 8
  br label %tas_smerge15

tas_smerge15:                                     ; preds = %tas_sw814, %tas_sw413, %tas_sw212, %tas_sw111
  %r019 = load i64, ptr %r0_slot, align 8
  store i64 %r019, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  store i64 %r3, ptr %r2_slot, align 8
  %r220 = load i64, ptr %r2_slot, align 8
  %r221 = load i64, ptr %r2_slot, align 8
  ret i64 %r221
}

