target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r6_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r4_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %list_obj = call ptr @verum_list_allocate_storage(i64 8, i32 512)
  %r0_ptr_to_i64 = ptrtoint ptr %list_obj to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  store i64 1, ptr %r1_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %and = and i64 %r1, %r3
  store i64 %and, ptr %r2_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %list_ptr = inttoptr i64 %r0 to ptr
  %r2 = load i64, ptr %r2_slot, align 8
  %len_slot = getelementptr inbounds i8, ptr %list_ptr, i64 24
  %len = load i64, ptr %len_slot, align 8
  %cap_slot = getelementptr inbounds i8, ptr %list_ptr, i64 32
  %cap = load i64, ptr %cap_slot, align 8
  %data_ptr_slot = getelementptr inbounds i8, ptr %list_ptr, i64 40
  %data_int = load i64, ptr %data_ptr_slot, align 8
  %data_ptr = inttoptr i64 %data_int to ptr
  %needs_grow = icmp uge i64 %len, %cap
  br i1 %needs_grow, label %list_grow, label %list_push_continue

list_grow:                                        ; preds = %block_0
  call void @verum_list_grow(ptr %list_ptr)
  br label %list_push_continue

list_push_continue:                               ; preds = %list_grow, %block_0
  %data_int_post = load i64, ptr %data_ptr_slot, align 8
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %list_ptr)
  %list_push_off = mul i64 %len, %list_storage_stride
  %list_push_addr = add i64 %data_int_post, %list_push_off
  %list_push_eptr = inttoptr i64 %list_push_addr to ptr
  switch i64 %list_storage_stride, label %list_push_sw8 [
    i64 1, label %list_push_sw1
    i64 2, label %list_push_sw2
    i64 4, label %list_push_sw4
  ]

list_push_sw1:                                    ; preds = %list_push_continue
  %list_push_st = trunc i64 %r2 to i8
  store i8 %list_push_st, ptr %list_push_eptr, align 1
  br label %list_push_smerge

list_push_sw2:                                    ; preds = %list_push_continue
  %list_push_st1 = trunc i64 %r2 to i16
  store i16 %list_push_st1, ptr %list_push_eptr, align 2
  br label %list_push_smerge

list_push_sw4:                                    ; preds = %list_push_continue
  %list_push_st2 = trunc i64 %r2 to i32
  store i32 %list_push_st2, ptr %list_push_eptr, align 4
  br label %list_push_smerge

list_push_sw8:                                    ; preds = %list_push_continue
  store i64 %r2, ptr %list_push_eptr, align 8
  br label %list_push_smerge

list_push_smerge:                                 ; preds = %list_push_sw8, %list_push_sw4, %list_push_sw2, %list_push_sw1
  %new_len = add i64 %len, 1
  store i64 %new_len, ptr %len_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r23 = load i64, ptr %r2_slot, align 8
  %r34 = load i64, ptr %r3_slot, align 8
  %and5 = and i64 %r23, %r34
  store i64 %and5, ptr %r1_slot, align 8
  %r06 = load i64, ptr %r0_slot, align 8
  %list_ptr7 = inttoptr i64 %r06 to ptr
  %r18 = load i64, ptr %r1_slot, align 8
  %len_slot9 = getelementptr inbounds i8, ptr %list_ptr7, i64 24
  %len10 = load i64, ptr %len_slot9, align 8
  %cap_slot11 = getelementptr inbounds i8, ptr %list_ptr7, i64 32
  %cap12 = load i64, ptr %cap_slot11, align 8
  %data_ptr_slot13 = getelementptr inbounds i8, ptr %list_ptr7, i64 40
  %data_int14 = load i64, ptr %data_ptr_slot13, align 8
  %data_ptr15 = inttoptr i64 %data_int14 to ptr
  %needs_grow16 = icmp uge i64 %len10, %cap12
  br i1 %needs_grow16, label %list_grow17, label %list_push_continue18

list_grow17:                                      ; preds = %list_push_smerge
  call void @verum_list_grow(ptr %list_ptr7)
  br label %list_push_continue18

list_push_continue18:                             ; preds = %list_grow17, %list_push_smerge
  %data_int_post19 = load i64, ptr %data_ptr_slot13, align 8
  %list_storage_stride20 = call i64 @verum_list_storage_stride(ptr %list_ptr7)
  %list_push_off21 = mul i64 %len10, %list_storage_stride20
  %list_push_addr22 = add i64 %data_int_post19, %list_push_off21
  %list_push_eptr23 = inttoptr i64 %list_push_addr22 to ptr
  switch i64 %list_storage_stride20, label %list_push_sw827 [
    i64 1, label %list_push_sw124
    i64 2, label %list_push_sw225
    i64 4, label %list_push_sw426
  ]

list_push_sw124:                                  ; preds = %list_push_continue18
  %list_push_st29 = trunc i64 %r18 to i8
  store i8 %list_push_st29, ptr %list_push_eptr23, align 1
  br label %list_push_smerge28

list_push_sw225:                                  ; preds = %list_push_continue18
  %list_push_st30 = trunc i64 %r18 to i16
  store i16 %list_push_st30, ptr %list_push_eptr23, align 2
  br label %list_push_smerge28

list_push_sw426:                                  ; preds = %list_push_continue18
  %list_push_st31 = trunc i64 %r18 to i32
  store i32 %list_push_st31, ptr %list_push_eptr23, align 4
  br label %list_push_smerge28

list_push_sw827:                                  ; preds = %list_push_continue18
  store i64 %r18, ptr %list_push_eptr23, align 8
  br label %list_push_smerge28

list_push_smerge28:                               ; preds = %list_push_sw827, %list_push_sw426, %list_push_sw225, %list_push_sw124
  %new_len32 = add i64 %len10, 1
  store i64 %new_len32, ptr %len_slot9, align 8
  store i64 3, ptr %r1_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r133 = load i64, ptr %r1_slot, align 8
  %r334 = load i64, ptr %r3_slot, align 8
  %and35 = and i64 %r133, %r334
  store i64 %and35, ptr %r2_slot, align 8
  %r036 = load i64, ptr %r0_slot, align 8
  %list_ptr37 = inttoptr i64 %r036 to ptr
  %r238 = load i64, ptr %r2_slot, align 8
  %len_slot39 = getelementptr inbounds i8, ptr %list_ptr37, i64 24
  %len40 = load i64, ptr %len_slot39, align 8
  %cap_slot41 = getelementptr inbounds i8, ptr %list_ptr37, i64 32
  %cap42 = load i64, ptr %cap_slot41, align 8
  %data_ptr_slot43 = getelementptr inbounds i8, ptr %list_ptr37, i64 40
  %data_int44 = load i64, ptr %data_ptr_slot43, align 8
  %data_ptr45 = inttoptr i64 %data_int44 to ptr
  %needs_grow46 = icmp uge i64 %len40, %cap42
  br i1 %needs_grow46, label %list_grow47, label %list_push_continue48

list_grow47:                                      ; preds = %list_push_smerge28
  call void @verum_list_grow(ptr %list_ptr37)
  br label %list_push_continue48

list_push_continue48:                             ; preds = %list_grow47, %list_push_smerge28
  %data_int_post49 = load i64, ptr %data_ptr_slot43, align 8
  %list_storage_stride50 = call i64 @verum_list_storage_stride(ptr %list_ptr37)
  %list_push_off51 = mul i64 %len40, %list_storage_stride50
  %list_push_addr52 = add i64 %data_int_post49, %list_push_off51
  %list_push_eptr53 = inttoptr i64 %list_push_addr52 to ptr
  switch i64 %list_storage_stride50, label %list_push_sw857 [
    i64 1, label %list_push_sw154
    i64 2, label %list_push_sw255
    i64 4, label %list_push_sw456
  ]

list_push_sw154:                                  ; preds = %list_push_continue48
  %list_push_st59 = trunc i64 %r238 to i8
  store i8 %list_push_st59, ptr %list_push_eptr53, align 1
  br label %list_push_smerge58

list_push_sw255:                                  ; preds = %list_push_continue48
  %list_push_st60 = trunc i64 %r238 to i16
  store i16 %list_push_st60, ptr %list_push_eptr53, align 2
  br label %list_push_smerge58

list_push_sw456:                                  ; preds = %list_push_continue48
  %list_push_st61 = trunc i64 %r238 to i32
  store i32 %list_push_st61, ptr %list_push_eptr53, align 4
  br label %list_push_smerge58

list_push_sw857:                                  ; preds = %list_push_continue48
  store i64 %r238, ptr %list_push_eptr53, align 8
  br label %list_push_smerge58

list_push_smerge58:                               ; preds = %list_push_sw857, %list_push_sw456, %list_push_sw255, %list_push_sw154
  %new_len62 = add i64 %len40, 1
  store i64 %new_len62, ptr %len_slot39, align 8
  store i64 4, ptr %r2_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r263 = load i64, ptr %r2_slot, align 8
  %r364 = load i64, ptr %r3_slot, align 8
  %and65 = and i64 %r263, %r364
  store i64 %and65, ptr %r1_slot, align 8
  %r066 = load i64, ptr %r0_slot, align 8
  %list_ptr67 = inttoptr i64 %r066 to ptr
  %r168 = load i64, ptr %r1_slot, align 8
  %len_slot69 = getelementptr inbounds i8, ptr %list_ptr67, i64 24
  %len70 = load i64, ptr %len_slot69, align 8
  %cap_slot71 = getelementptr inbounds i8, ptr %list_ptr67, i64 32
  %cap72 = load i64, ptr %cap_slot71, align 8
  %data_ptr_slot73 = getelementptr inbounds i8, ptr %list_ptr67, i64 40
  %data_int74 = load i64, ptr %data_ptr_slot73, align 8
  %data_ptr75 = inttoptr i64 %data_int74 to ptr
  %needs_grow76 = icmp uge i64 %len70, %cap72
  br i1 %needs_grow76, label %list_grow77, label %list_push_continue78

list_grow77:                                      ; preds = %list_push_smerge58
  call void @verum_list_grow(ptr %list_ptr67)
  br label %list_push_continue78

list_push_continue78:                             ; preds = %list_grow77, %list_push_smerge58
  %data_int_post79 = load i64, ptr %data_ptr_slot73, align 8
  %list_storage_stride80 = call i64 @verum_list_storage_stride(ptr %list_ptr67)
  %list_push_off81 = mul i64 %len70, %list_storage_stride80
  %list_push_addr82 = add i64 %data_int_post79, %list_push_off81
  %list_push_eptr83 = inttoptr i64 %list_push_addr82 to ptr
  switch i64 %list_storage_stride80, label %list_push_sw887 [
    i64 1, label %list_push_sw184
    i64 2, label %list_push_sw285
    i64 4, label %list_push_sw486
  ]

list_push_sw184:                                  ; preds = %list_push_continue78
  %list_push_st89 = trunc i64 %r168 to i8
  store i8 %list_push_st89, ptr %list_push_eptr83, align 1
  br label %list_push_smerge88

list_push_sw285:                                  ; preds = %list_push_continue78
  %list_push_st90 = trunc i64 %r168 to i16
  store i16 %list_push_st90, ptr %list_push_eptr83, align 2
  br label %list_push_smerge88

list_push_sw486:                                  ; preds = %list_push_continue78
  %list_push_st91 = trunc i64 %r168 to i32
  store i32 %list_push_st91, ptr %list_push_eptr83, align 4
  br label %list_push_smerge88

list_push_sw887:                                  ; preds = %list_push_continue78
  store i64 %r168, ptr %list_push_eptr83, align 8
  br label %list_push_smerge88

list_push_smerge88:                               ; preds = %list_push_sw887, %list_push_sw486, %list_push_sw285, %list_push_sw184
  %new_len92 = add i64 %len70, 1
  store i64 %new_len92, ptr %len_slot69, align 8
  store i64 5, ptr %r1_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r193 = load i64, ptr %r1_slot, align 8
  %r394 = load i64, ptr %r3_slot, align 8
  %and95 = and i64 %r193, %r394
  store i64 %and95, ptr %r2_slot, align 8
  %r096 = load i64, ptr %r0_slot, align 8
  %list_ptr97 = inttoptr i64 %r096 to ptr
  %r298 = load i64, ptr %r2_slot, align 8
  %len_slot99 = getelementptr inbounds i8, ptr %list_ptr97, i64 24
  %len100 = load i64, ptr %len_slot99, align 8
  %cap_slot101 = getelementptr inbounds i8, ptr %list_ptr97, i64 32
  %cap102 = load i64, ptr %cap_slot101, align 8
  %data_ptr_slot103 = getelementptr inbounds i8, ptr %list_ptr97, i64 40
  %data_int104 = load i64, ptr %data_ptr_slot103, align 8
  %data_ptr105 = inttoptr i64 %data_int104 to ptr
  %needs_grow106 = icmp uge i64 %len100, %cap102
  br i1 %needs_grow106, label %list_grow107, label %list_push_continue108

list_grow107:                                     ; preds = %list_push_smerge88
  call void @verum_list_grow(ptr %list_ptr97)
  br label %list_push_continue108

list_push_continue108:                            ; preds = %list_grow107, %list_push_smerge88
  %data_int_post109 = load i64, ptr %data_ptr_slot103, align 8
  %list_storage_stride110 = call i64 @verum_list_storage_stride(ptr %list_ptr97)
  %list_push_off111 = mul i64 %len100, %list_storage_stride110
  %list_push_addr112 = add i64 %data_int_post109, %list_push_off111
  %list_push_eptr113 = inttoptr i64 %list_push_addr112 to ptr
  switch i64 %list_storage_stride110, label %list_push_sw8117 [
    i64 1, label %list_push_sw1114
    i64 2, label %list_push_sw2115
    i64 4, label %list_push_sw4116
  ]

list_push_sw1114:                                 ; preds = %list_push_continue108
  %list_push_st119 = trunc i64 %r298 to i8
  store i8 %list_push_st119, ptr %list_push_eptr113, align 1
  br label %list_push_smerge118

list_push_sw2115:                                 ; preds = %list_push_continue108
  %list_push_st120 = trunc i64 %r298 to i16
  store i16 %list_push_st120, ptr %list_push_eptr113, align 2
  br label %list_push_smerge118

list_push_sw4116:                                 ; preds = %list_push_continue108
  %list_push_st121 = trunc i64 %r298 to i32
  store i32 %list_push_st121, ptr %list_push_eptr113, align 4
  br label %list_push_smerge118

list_push_sw8117:                                 ; preds = %list_push_continue108
  store i64 %r298, ptr %list_push_eptr113, align 8
  br label %list_push_smerge118

list_push_smerge118:                              ; preds = %list_push_sw8117, %list_push_sw4116, %list_push_sw2115, %list_push_sw1114
  %new_len122 = add i64 %len100, 1
  store i64 %new_len122, ptr %len_slot99, align 8
  store i64 6, ptr %r2_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r2123 = load i64, ptr %r2_slot, align 8
  %r3124 = load i64, ptr %r3_slot, align 8
  %and125 = and i64 %r2123, %r3124
  store i64 %and125, ptr %r1_slot, align 8
  %r0126 = load i64, ptr %r0_slot, align 8
  %list_ptr127 = inttoptr i64 %r0126 to ptr
  %r1128 = load i64, ptr %r1_slot, align 8
  %len_slot129 = getelementptr inbounds i8, ptr %list_ptr127, i64 24
  %len130 = load i64, ptr %len_slot129, align 8
  %cap_slot131 = getelementptr inbounds i8, ptr %list_ptr127, i64 32
  %cap132 = load i64, ptr %cap_slot131, align 8
  %data_ptr_slot133 = getelementptr inbounds i8, ptr %list_ptr127, i64 40
  %data_int134 = load i64, ptr %data_ptr_slot133, align 8
  %data_ptr135 = inttoptr i64 %data_int134 to ptr
  %needs_grow136 = icmp uge i64 %len130, %cap132
  br i1 %needs_grow136, label %list_grow137, label %list_push_continue138

list_grow137:                                     ; preds = %list_push_smerge118
  call void @verum_list_grow(ptr %list_ptr127)
  br label %list_push_continue138

list_push_continue138:                            ; preds = %list_grow137, %list_push_smerge118
  %data_int_post139 = load i64, ptr %data_ptr_slot133, align 8
  %list_storage_stride140 = call i64 @verum_list_storage_stride(ptr %list_ptr127)
  %list_push_off141 = mul i64 %len130, %list_storage_stride140
  %list_push_addr142 = add i64 %data_int_post139, %list_push_off141
  %list_push_eptr143 = inttoptr i64 %list_push_addr142 to ptr
  switch i64 %list_storage_stride140, label %list_push_sw8147 [
    i64 1, label %list_push_sw1144
    i64 2, label %list_push_sw2145
    i64 4, label %list_push_sw4146
  ]

list_push_sw1144:                                 ; preds = %list_push_continue138
  %list_push_st149 = trunc i64 %r1128 to i8
  store i8 %list_push_st149, ptr %list_push_eptr143, align 1
  br label %list_push_smerge148

list_push_sw2145:                                 ; preds = %list_push_continue138
  %list_push_st150 = trunc i64 %r1128 to i16
  store i16 %list_push_st150, ptr %list_push_eptr143, align 2
  br label %list_push_smerge148

list_push_sw4146:                                 ; preds = %list_push_continue138
  %list_push_st151 = trunc i64 %r1128 to i32
  store i32 %list_push_st151, ptr %list_push_eptr143, align 4
  br label %list_push_smerge148

list_push_sw8147:                                 ; preds = %list_push_continue138
  store i64 %r1128, ptr %list_push_eptr143, align 8
  br label %list_push_smerge148

list_push_smerge148:                              ; preds = %list_push_sw8147, %list_push_sw4146, %list_push_sw2145, %list_push_sw1144
  %new_len152 = add i64 %len130, 1
  store i64 %new_len152, ptr %len_slot129, align 8
  store i64 7, ptr %r1_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r1153 = load i64, ptr %r1_slot, align 8
  %r3154 = load i64, ptr %r3_slot, align 8
  %and155 = and i64 %r1153, %r3154
  store i64 %and155, ptr %r2_slot, align 8
  %r0156 = load i64, ptr %r0_slot, align 8
  %list_ptr157 = inttoptr i64 %r0156 to ptr
  %r2158 = load i64, ptr %r2_slot, align 8
  %len_slot159 = getelementptr inbounds i8, ptr %list_ptr157, i64 24
  %len160 = load i64, ptr %len_slot159, align 8
  %cap_slot161 = getelementptr inbounds i8, ptr %list_ptr157, i64 32
  %cap162 = load i64, ptr %cap_slot161, align 8
  %data_ptr_slot163 = getelementptr inbounds i8, ptr %list_ptr157, i64 40
  %data_int164 = load i64, ptr %data_ptr_slot163, align 8
  %data_ptr165 = inttoptr i64 %data_int164 to ptr
  %needs_grow166 = icmp uge i64 %len160, %cap162
  br i1 %needs_grow166, label %list_grow167, label %list_push_continue168

list_grow167:                                     ; preds = %list_push_smerge148
  call void @verum_list_grow(ptr %list_ptr157)
  br label %list_push_continue168

list_push_continue168:                            ; preds = %list_grow167, %list_push_smerge148
  %data_int_post169 = load i64, ptr %data_ptr_slot163, align 8
  %list_storage_stride170 = call i64 @verum_list_storage_stride(ptr %list_ptr157)
  %list_push_off171 = mul i64 %len160, %list_storage_stride170
  %list_push_addr172 = add i64 %data_int_post169, %list_push_off171
  %list_push_eptr173 = inttoptr i64 %list_push_addr172 to ptr
  switch i64 %list_storage_stride170, label %list_push_sw8177 [
    i64 1, label %list_push_sw1174
    i64 2, label %list_push_sw2175
    i64 4, label %list_push_sw4176
  ]

list_push_sw1174:                                 ; preds = %list_push_continue168
  %list_push_st179 = trunc i64 %r2158 to i8
  store i8 %list_push_st179, ptr %list_push_eptr173, align 1
  br label %list_push_smerge178

list_push_sw2175:                                 ; preds = %list_push_continue168
  %list_push_st180 = trunc i64 %r2158 to i16
  store i16 %list_push_st180, ptr %list_push_eptr173, align 2
  br label %list_push_smerge178

list_push_sw4176:                                 ; preds = %list_push_continue168
  %list_push_st181 = trunc i64 %r2158 to i32
  store i32 %list_push_st181, ptr %list_push_eptr173, align 4
  br label %list_push_smerge178

list_push_sw8177:                                 ; preds = %list_push_continue168
  store i64 %r2158, ptr %list_push_eptr173, align 8
  br label %list_push_smerge178

list_push_smerge178:                              ; preds = %list_push_sw8177, %list_push_sw4176, %list_push_sw2175, %list_push_sw1174
  %new_len182 = add i64 %len160, 1
  store i64 %new_len182, ptr %len_slot159, align 8
  store i64 8, ptr %r2_slot, align 8
  store i64 255, ptr %r3_slot, align 8
  %r2183 = load i64, ptr %r2_slot, align 8
  %r3184 = load i64, ptr %r3_slot, align 8
  %and185 = and i64 %r2183, %r3184
  store i64 %and185, ptr %r1_slot, align 8
  %r0186 = load i64, ptr %r0_slot, align 8
  %list_ptr187 = inttoptr i64 %r0186 to ptr
  %r1188 = load i64, ptr %r1_slot, align 8
  %len_slot189 = getelementptr inbounds i8, ptr %list_ptr187, i64 24
  %len190 = load i64, ptr %len_slot189, align 8
  %cap_slot191 = getelementptr inbounds i8, ptr %list_ptr187, i64 32
  %cap192 = load i64, ptr %cap_slot191, align 8
  %data_ptr_slot193 = getelementptr inbounds i8, ptr %list_ptr187, i64 40
  %data_int194 = load i64, ptr %data_ptr_slot193, align 8
  %data_ptr195 = inttoptr i64 %data_int194 to ptr
  %needs_grow196 = icmp uge i64 %len190, %cap192
  br i1 %needs_grow196, label %list_grow197, label %list_push_continue198

list_grow197:                                     ; preds = %list_push_smerge178
  call void @verum_list_grow(ptr %list_ptr187)
  br label %list_push_continue198

list_push_continue198:                            ; preds = %list_grow197, %list_push_smerge178
  %data_int_post199 = load i64, ptr %data_ptr_slot193, align 8
  %list_storage_stride200 = call i64 @verum_list_storage_stride(ptr %list_ptr187)
  %list_push_off201 = mul i64 %len190, %list_storage_stride200
  %list_push_addr202 = add i64 %data_int_post199, %list_push_off201
  %list_push_eptr203 = inttoptr i64 %list_push_addr202 to ptr
  switch i64 %list_storage_stride200, label %list_push_sw8207 [
    i64 1, label %list_push_sw1204
    i64 2, label %list_push_sw2205
    i64 4, label %list_push_sw4206
  ]

list_push_sw1204:                                 ; preds = %list_push_continue198
  %list_push_st209 = trunc i64 %r1188 to i8
  store i8 %list_push_st209, ptr %list_push_eptr203, align 1
  br label %list_push_smerge208

list_push_sw2205:                                 ; preds = %list_push_continue198
  %list_push_st210 = trunc i64 %r1188 to i16
  store i16 %list_push_st210, ptr %list_push_eptr203, align 2
  br label %list_push_smerge208

list_push_sw4206:                                 ; preds = %list_push_continue198
  %list_push_st211 = trunc i64 %r1188 to i32
  store i32 %list_push_st211, ptr %list_push_eptr203, align 4
  br label %list_push_smerge208

list_push_sw8207:                                 ; preds = %list_push_continue198
  store i64 %r1188, ptr %list_push_eptr203, align 8
  br label %list_push_smerge208

list_push_smerge208:                              ; preds = %list_push_sw8207, %list_push_sw4206, %list_push_sw2205, %list_push_sw1204
  %new_len212 = add i64 %len190, 1
  store i64 %new_len212, ptr %len_slot189, align 8
  %r0213 = load i64, ptr %r0_slot, align 8
  store i64 %r0213, ptr %r4_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  store i64 0, ptr %r5_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %arr_ptr = inttoptr i64 %r4 to ptr
  %r5 = load i64, ptr %r5_slot, align 8
  %backing_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %backing_int = load i64, ptr %backing_slot, align 8
  %backing_ptr = inttoptr i64 %backing_int to ptr
  %geteu_w0 = load i64, ptr %arr_ptr, align 8
  %geteu_is_cell = icmp uge i64 %geteu_w0, 4294967296
  br i1 %geteu_is_cell, label %geteu_cv_cell, label %geteu_cv_obj

geteu_cv_cell:                                    ; preds = %list_push_smerge208
  %geteu_cv_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 8
  %geteu_cv_cell_len = load i64, ptr %geteu_cv_len_slot, align 8
  %geteu_cv_elem_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 16
  %geteu_cv_elem_raw = load i64, ptr %geteu_cv_elem_slot, align 8
  %geteu_cv_e1 = icmp eq i64 %geteu_cv_elem_raw, 1
  %geteu_cv_ew = icmp eq i64 %geteu_cv_elem_raw, 2
  %geteu_cv_edom = or i1 %geteu_cv_e1, %geteu_cv_ew
  %geteu_cv_ew214 = icmp eq i64 %geteu_cv_elem_raw, 4
  %geteu_cv_edom215 = or i1 %geteu_cv_edom, %geteu_cv_ew214
  %geteu_cv_ew216 = icmp eq i64 %geteu_cv_elem_raw, 8
  %geteu_cv_edom217 = or i1 %geteu_cv_edom215, %geteu_cv_ew216
  %geteu_cv_elem = select i1 %geteu_cv_edom217, i64 %geteu_cv_elem_raw, i64 8
  br label %geteu_cv_done

geteu_cv_obj:                                     ; preds = %list_push_smerge208
  %geteu_cv_tid = load i32, ptr %arr_ptr, align 4
  %geteu_cv_is_tuple = icmp eq i32 %geteu_cv_tid, 521
  %geteu_cv_is_bslice = icmp eq i32 %geteu_cv_tid, 528
  %geteu_cv_is_pack = or i1 %geteu_cv_is_tuple, %geteu_cv_is_bslice
  br i1 %geteu_cv_is_pack, label %geteu_cv_pack, label %geteu_cv_list

geteu_cv_pack:                                    ; preds = %geteu_cv_obj
  %geteu_cv_pk_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_pk_data = load i64, ptr %geteu_cv_pk_data_slot, align 8
  %geteu_cv_pk_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 32
  %geteu_cv_pk_len = load i64, ptr %geteu_cv_pk_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_list:                                    ; preds = %geteu_cv_obj
  %geteu_cv_ls_data_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 40
  %geteu_cv_ls_data = load i64, ptr %geteu_cv_ls_data_slot, align 8
  %geteu_cv_ls_len_slot = getelementptr inbounds i8, ptr %arr_ptr, i64 24
  %geteu_cv_ls_len = load i64, ptr %geteu_cv_ls_len_slot, align 8
  br label %geteu_cv_done

geteu_cv_done:                                    ; preds = %geteu_cv_list, %geteu_cv_pack, %geteu_cv_cell
  %geteu_cv_data = phi i64 [ %geteu_w0, %geteu_cv_cell ], [ %geteu_cv_pk_data, %geteu_cv_pack ], [ %geteu_cv_ls_data, %geteu_cv_list ]
  %geteu_cv_len = phi i64 [ %geteu_cv_cell_len, %geteu_cv_cell ], [ %geteu_cv_pk_len, %geteu_cv_pack ], [ %geteu_cv_ls_len, %geteu_cv_list ]
  %geteu_cv_elem218 = phi i64 [ %geteu_cv_elem, %geteu_cv_cell ], [ 1, %geteu_cv_pack ], [ 8, %geteu_cv_list ]
  %geteu_off = mul i64 %r5, %geteu_cv_elem218
  %geteu_addr = add i64 %geteu_cv_data, %geteu_off
  %geteu_eptr = inttoptr i64 %geteu_addr to ptr
  switch i64 %geteu_cv_elem218, label %geteu_lw8 [
    i64 1, label %geteu_lw1
    i64 2, label %geteu_lw2
    i64 4, label %geteu_lw4
  ]

geteu_lw1:                                        ; preds = %geteu_cv_done
  %geteu_lv = load i8, ptr %geteu_eptr, align 1
  %geteu_lz = zext i8 %geteu_lv to i64
  br label %geteu_lmerge

geteu_lw2:                                        ; preds = %geteu_cv_done
  %geteu_lv219 = load i16, ptr %geteu_eptr, align 2
  %geteu_lz220 = zext i16 %geteu_lv219 to i64
  br label %geteu_lmerge

geteu_lw4:                                        ; preds = %geteu_cv_done
  %geteu_lv221 = load i32, ptr %geteu_eptr, align 4
  %geteu_lz222 = zext i32 %geteu_lv221 to i64
  br label %geteu_lmerge

geteu_lw8:                                        ; preds = %geteu_cv_done
  %geteu_lv8 = load i64, ptr %geteu_eptr, align 8
  br label %geteu_lmerge

geteu_lmerge:                                     ; preds = %geteu_lw8, %geteu_lw4, %geteu_lw2, %geteu_lw1
  %geteu_lval = phi i64 [ %geteu_lz, %geteu_lw1 ], [ %geteu_lz220, %geteu_lw2 ], [ %geteu_lz222, %geteu_lw4 ], [ %geteu_lv8, %geteu_lw8 ]
  store i64 %geteu_lval, ptr %r2_slot, align 8
  store i64 56, ptr %r6_slot, align 8
  %r2223 = load i64, ptr %r2_slot, align 8
  %r6 = load i64, ptr %r6_slot, align 8
  %shl = shl i64 %r2223, %r6
  store i64 %shl, ptr %r3_slot, align 8
  %r1224 = load i64, ptr %r1_slot, align 8
  %r3225 = load i64, ptr %r3_slot, align 8
  %or = or i64 %r1224, %r3225
  store i64 %or, ptr %r1_slot, align 8
  store i64 1, ptr %r5_slot, align 8
  %r4226 = load i64, ptr %r4_slot, align 8
  %arr_ptr227 = inttoptr i64 %r4226 to ptr
  %r5228 = load i64, ptr %r5_slot, align 8
  %backing_slot229 = getelementptr inbounds i8, ptr %arr_ptr227, i64 40
  %backing_int230 = load i64, ptr %backing_slot229, align 8
  %backing_ptr231 = inttoptr i64 %backing_int230 to ptr
  %geteu_w0237 = load i64, ptr %arr_ptr227, align 8
  %geteu_is_cell238 = icmp uge i64 %geteu_w0237, 4294967296
  br i1 %geteu_is_cell238, label %geteu_cv_cell232, label %geteu_cv_obj233

geteu_cv_cell232:                                 ; preds = %geteu_lmerge
  %geteu_cv_len_slot239 = getelementptr inbounds i8, ptr %arr_ptr227, i64 8
  %geteu_cv_cell_len240 = load i64, ptr %geteu_cv_len_slot239, align 8
  %geteu_cv_elem_slot241 = getelementptr inbounds i8, ptr %arr_ptr227, i64 16
  %geteu_cv_elem_raw242 = load i64, ptr %geteu_cv_elem_slot241, align 8
  %geteu_cv_e1243 = icmp eq i64 %geteu_cv_elem_raw242, 1
  %geteu_cv_ew244 = icmp eq i64 %geteu_cv_elem_raw242, 2
  %geteu_cv_edom245 = or i1 %geteu_cv_e1243, %geteu_cv_ew244
  %geteu_cv_ew246 = icmp eq i64 %geteu_cv_elem_raw242, 4
  %geteu_cv_edom247 = or i1 %geteu_cv_edom245, %geteu_cv_ew246
  %geteu_cv_ew248 = icmp eq i64 %geteu_cv_elem_raw242, 8
  %geteu_cv_edom249 = or i1 %geteu_cv_edom247, %geteu_cv_ew248
  %geteu_cv_elem250 = select i1 %geteu_cv_edom249, i64 %geteu_cv_elem_raw242, i64 8
  br label %geteu_cv_done236

geteu_cv_obj233:                                  ; preds = %geteu_lmerge
  %geteu_cv_tid251 = load i32, ptr %arr_ptr227, align 4
  %geteu_cv_is_tuple252 = icmp eq i32 %geteu_cv_tid251, 521
  %geteu_cv_is_bslice253 = icmp eq i32 %geteu_cv_tid251, 528
  %geteu_cv_is_pack254 = or i1 %geteu_cv_is_tuple252, %geteu_cv_is_bslice253
  br i1 %geteu_cv_is_pack254, label %geteu_cv_pack234, label %geteu_cv_list235

geteu_cv_pack234:                                 ; preds = %geteu_cv_obj233
  %geteu_cv_pk_data_slot255 = getelementptr inbounds i8, ptr %arr_ptr227, i64 24
  %geteu_cv_pk_data256 = load i64, ptr %geteu_cv_pk_data_slot255, align 8
  %geteu_cv_pk_len_slot257 = getelementptr inbounds i8, ptr %arr_ptr227, i64 32
  %geteu_cv_pk_len258 = load i64, ptr %geteu_cv_pk_len_slot257, align 8
  br label %geteu_cv_done236

geteu_cv_list235:                                 ; preds = %geteu_cv_obj233
  %geteu_cv_ls_data_slot259 = getelementptr inbounds i8, ptr %arr_ptr227, i64 40
  %geteu_cv_ls_data260 = load i64, ptr %geteu_cv_ls_data_slot259, align 8
  %geteu_cv_ls_len_slot261 = getelementptr inbounds i8, ptr %arr_ptr227, i64 24
  %geteu_cv_ls_len262 = load i64, ptr %geteu_cv_ls_len_slot261, align 8
  br label %geteu_cv_done236

geteu_cv_done236:                                 ; preds = %geteu_cv_list235, %geteu_cv_pack234, %geteu_cv_cell232
  %geteu_cv_data263 = phi i64 [ %geteu_w0237, %geteu_cv_cell232 ], [ %geteu_cv_pk_data256, %geteu_cv_pack234 ], [ %geteu_cv_ls_data260, %geteu_cv_list235 ]
  %geteu_cv_len264 = phi i64 [ %geteu_cv_cell_len240, %geteu_cv_cell232 ], [ %geteu_cv_pk_len258, %geteu_cv_pack234 ], [ %geteu_cv_ls_len262, %geteu_cv_list235 ]
  %geteu_cv_elem265 = phi i64 [ %geteu_cv_elem250, %geteu_cv_cell232 ], [ 1, %geteu_cv_pack234 ], [ 8, %geteu_cv_list235 ]
  %geteu_off266 = mul i64 %r5228, %geteu_cv_elem265
  %geteu_addr267 = add i64 %geteu_cv_data263, %geteu_off266
  %geteu_eptr268 = inttoptr i64 %geteu_addr267 to ptr
  switch i64 %geteu_cv_elem265, label %geteu_lw8272 [
    i64 1, label %geteu_lw1269
    i64 2, label %geteu_lw2270
    i64 4, label %geteu_lw4271
  ]

geteu_lw1269:                                     ; preds = %geteu_cv_done236
  %geteu_lv274 = load i8, ptr %geteu_eptr268, align 1
  %geteu_lz275 = zext i8 %geteu_lv274 to i64
  br label %geteu_lmerge273

geteu_lw2270:                                     ; preds = %geteu_cv_done236
  %geteu_lv276 = load i16, ptr %geteu_eptr268, align 2
  %geteu_lz277 = zext i16 %geteu_lv276 to i64
  br label %geteu_lmerge273

geteu_lw4271:                                     ; preds = %geteu_cv_done236
  %geteu_lv278 = load i32, ptr %geteu_eptr268, align 4
  %geteu_lz279 = zext i32 %geteu_lv278 to i64
  br label %geteu_lmerge273

geteu_lw8272:                                     ; preds = %geteu_cv_done236
  %geteu_lv8280 = load i64, ptr %geteu_eptr268, align 8
  br label %geteu_lmerge273

geteu_lmerge273:                                  ; preds = %geteu_lw8272, %geteu_lw4271, %geteu_lw2270, %geteu_lw1269
  %geteu_lval281 = phi i64 [ %geteu_lz275, %geteu_lw1269 ], [ %geteu_lz277, %geteu_lw2270 ], [ %geteu_lz279, %geteu_lw4271 ], [ %geteu_lv8280, %geteu_lw8272 ]
  store i64 %geteu_lval281, ptr %r2_slot, align 8
  store i64 48, ptr %r6_slot, align 8
  %r2282 = load i64, ptr %r2_slot, align 8
  %r6283 = load i64, ptr %r6_slot, align 8
  %shl284 = shl i64 %r2282, %r6283
  store i64 %shl284, ptr %r3_slot, align 8
  %r1285 = load i64, ptr %r1_slot, align 8
  %r3286 = load i64, ptr %r3_slot, align 8
  %or287 = or i64 %r1285, %r3286
  store i64 %or287, ptr %r1_slot, align 8
  store i64 2, ptr %r5_slot, align 8
  %r4288 = load i64, ptr %r4_slot, align 8
  %arr_ptr289 = inttoptr i64 %r4288 to ptr
  %r5290 = load i64, ptr %r5_slot, align 8
  %backing_slot291 = getelementptr inbounds i8, ptr %arr_ptr289, i64 40
  %backing_int292 = load i64, ptr %backing_slot291, align 8
  %backing_ptr293 = inttoptr i64 %backing_int292 to ptr
  %geteu_w0299 = load i64, ptr %arr_ptr289, align 8
  %geteu_is_cell300 = icmp uge i64 %geteu_w0299, 4294967296
  br i1 %geteu_is_cell300, label %geteu_cv_cell294, label %geteu_cv_obj295

geteu_cv_cell294:                                 ; preds = %geteu_lmerge273
  %geteu_cv_len_slot301 = getelementptr inbounds i8, ptr %arr_ptr289, i64 8
  %geteu_cv_cell_len302 = load i64, ptr %geteu_cv_len_slot301, align 8
  %geteu_cv_elem_slot303 = getelementptr inbounds i8, ptr %arr_ptr289, i64 16
  %geteu_cv_elem_raw304 = load i64, ptr %geteu_cv_elem_slot303, align 8
  %geteu_cv_e1305 = icmp eq i64 %geteu_cv_elem_raw304, 1
  %geteu_cv_ew306 = icmp eq i64 %geteu_cv_elem_raw304, 2
  %geteu_cv_edom307 = or i1 %geteu_cv_e1305, %geteu_cv_ew306
  %geteu_cv_ew308 = icmp eq i64 %geteu_cv_elem_raw304, 4
  %geteu_cv_edom309 = or i1 %geteu_cv_edom307, %geteu_cv_ew308
  %geteu_cv_ew310 = icmp eq i64 %geteu_cv_elem_raw304, 8
  %geteu_cv_edom311 = or i1 %geteu_cv_edom309, %geteu_cv_ew310
  %geteu_cv_elem312 = select i1 %geteu_cv_edom311, i64 %geteu_cv_elem_raw304, i64 8
  br label %geteu_cv_done298

geteu_cv_obj295:                                  ; preds = %geteu_lmerge273
  %geteu_cv_tid313 = load i32, ptr %arr_ptr289, align 4
  %geteu_cv_is_tuple314 = icmp eq i32 %geteu_cv_tid313, 521
  %geteu_cv_is_bslice315 = icmp eq i32 %geteu_cv_tid313, 528
  %geteu_cv_is_pack316 = or i1 %geteu_cv_is_tuple314, %geteu_cv_is_bslice315
  br i1 %geteu_cv_is_pack316, label %geteu_cv_pack296, label %geteu_cv_list297

geteu_cv_pack296:                                 ; preds = %geteu_cv_obj295
  %geteu_cv_pk_data_slot317 = getelementptr inbounds i8, ptr %arr_ptr289, i64 24
  %geteu_cv_pk_data318 = load i64, ptr %geteu_cv_pk_data_slot317, align 8
  %geteu_cv_pk_len_slot319 = getelementptr inbounds i8, ptr %arr_ptr289, i64 32
  %geteu_cv_pk_len320 = load i64, ptr %geteu_cv_pk_len_slot319, align 8
  br label %geteu_cv_done298

geteu_cv_list297:                                 ; preds = %geteu_cv_obj295
  %geteu_cv_ls_data_slot321 = getelementptr inbounds i8, ptr %arr_ptr289, i64 40
  %geteu_cv_ls_data322 = load i64, ptr %geteu_cv_ls_data_slot321, align 8
  %geteu_cv_ls_len_slot323 = getelementptr inbounds i8, ptr %arr_ptr289, i64 24
  %geteu_cv_ls_len324 = load i64, ptr %geteu_cv_ls_len_slot323, align 8
  br label %geteu_cv_done298

geteu_cv_done298:                                 ; preds = %geteu_cv_list297, %geteu_cv_pack296, %geteu_cv_cell294
  %geteu_cv_data325 = phi i64 [ %geteu_w0299, %geteu_cv_cell294 ], [ %geteu_cv_pk_data318, %geteu_cv_pack296 ], [ %geteu_cv_ls_data322, %geteu_cv_list297 ]
  %geteu_cv_len326 = phi i64 [ %geteu_cv_cell_len302, %geteu_cv_cell294 ], [ %geteu_cv_pk_len320, %geteu_cv_pack296 ], [ %geteu_cv_ls_len324, %geteu_cv_list297 ]
  %geteu_cv_elem327 = phi i64 [ %geteu_cv_elem312, %geteu_cv_cell294 ], [ 1, %geteu_cv_pack296 ], [ 8, %geteu_cv_list297 ]
  %geteu_off328 = mul i64 %r5290, %geteu_cv_elem327
  %geteu_addr329 = add i64 %geteu_cv_data325, %geteu_off328
  %geteu_eptr330 = inttoptr i64 %geteu_addr329 to ptr
  switch i64 %geteu_cv_elem327, label %geteu_lw8334 [
    i64 1, label %geteu_lw1331
    i64 2, label %geteu_lw2332
    i64 4, label %geteu_lw4333
  ]

geteu_lw1331:                                     ; preds = %geteu_cv_done298
  %geteu_lv336 = load i8, ptr %geteu_eptr330, align 1
  %geteu_lz337 = zext i8 %geteu_lv336 to i64
  br label %geteu_lmerge335

geteu_lw2332:                                     ; preds = %geteu_cv_done298
  %geteu_lv338 = load i16, ptr %geteu_eptr330, align 2
  %geteu_lz339 = zext i16 %geteu_lv338 to i64
  br label %geteu_lmerge335

geteu_lw4333:                                     ; preds = %geteu_cv_done298
  %geteu_lv340 = load i32, ptr %geteu_eptr330, align 4
  %geteu_lz341 = zext i32 %geteu_lv340 to i64
  br label %geteu_lmerge335

geteu_lw8334:                                     ; preds = %geteu_cv_done298
  %geteu_lv8342 = load i64, ptr %geteu_eptr330, align 8
  br label %geteu_lmerge335

geteu_lmerge335:                                  ; preds = %geteu_lw8334, %geteu_lw4333, %geteu_lw2332, %geteu_lw1331
  %geteu_lval343 = phi i64 [ %geteu_lz337, %geteu_lw1331 ], [ %geteu_lz339, %geteu_lw2332 ], [ %geteu_lz341, %geteu_lw4333 ], [ %geteu_lv8342, %geteu_lw8334 ]
  store i64 %geteu_lval343, ptr %r2_slot, align 8
  store i64 40, ptr %r6_slot, align 8
  %r2344 = load i64, ptr %r2_slot, align 8
  %r6345 = load i64, ptr %r6_slot, align 8
  %shl346 = shl i64 %r2344, %r6345
  store i64 %shl346, ptr %r3_slot, align 8
  %r1347 = load i64, ptr %r1_slot, align 8
  %r3348 = load i64, ptr %r3_slot, align 8
  %or349 = or i64 %r1347, %r3348
  store i64 %or349, ptr %r1_slot, align 8
  store i64 3, ptr %r5_slot, align 8
  %r4350 = load i64, ptr %r4_slot, align 8
  %arr_ptr351 = inttoptr i64 %r4350 to ptr
  %r5352 = load i64, ptr %r5_slot, align 8
  %backing_slot353 = getelementptr inbounds i8, ptr %arr_ptr351, i64 40
  %backing_int354 = load i64, ptr %backing_slot353, align 8
  %backing_ptr355 = inttoptr i64 %backing_int354 to ptr
  %geteu_w0361 = load i64, ptr %arr_ptr351, align 8
  %geteu_is_cell362 = icmp uge i64 %geteu_w0361, 4294967296
  br i1 %geteu_is_cell362, label %geteu_cv_cell356, label %geteu_cv_obj357

geteu_cv_cell356:                                 ; preds = %geteu_lmerge335
  %geteu_cv_len_slot363 = getelementptr inbounds i8, ptr %arr_ptr351, i64 8
  %geteu_cv_cell_len364 = load i64, ptr %geteu_cv_len_slot363, align 8
  %geteu_cv_elem_slot365 = getelementptr inbounds i8, ptr %arr_ptr351, i64 16
  %geteu_cv_elem_raw366 = load i64, ptr %geteu_cv_elem_slot365, align 8
  %geteu_cv_e1367 = icmp eq i64 %geteu_cv_elem_raw366, 1
  %geteu_cv_ew368 = icmp eq i64 %geteu_cv_elem_raw366, 2
  %geteu_cv_edom369 = or i1 %geteu_cv_e1367, %geteu_cv_ew368
  %geteu_cv_ew370 = icmp eq i64 %geteu_cv_elem_raw366, 4
  %geteu_cv_edom371 = or i1 %geteu_cv_edom369, %geteu_cv_ew370
  %geteu_cv_ew372 = icmp eq i64 %geteu_cv_elem_raw366, 8
  %geteu_cv_edom373 = or i1 %geteu_cv_edom371, %geteu_cv_ew372
  %geteu_cv_elem374 = select i1 %geteu_cv_edom373, i64 %geteu_cv_elem_raw366, i64 8
  br label %geteu_cv_done360

geteu_cv_obj357:                                  ; preds = %geteu_lmerge335
  %geteu_cv_tid375 = load i32, ptr %arr_ptr351, align 4
  %geteu_cv_is_tuple376 = icmp eq i32 %geteu_cv_tid375, 521
  %geteu_cv_is_bslice377 = icmp eq i32 %geteu_cv_tid375, 528
  %geteu_cv_is_pack378 = or i1 %geteu_cv_is_tuple376, %geteu_cv_is_bslice377
  br i1 %geteu_cv_is_pack378, label %geteu_cv_pack358, label %geteu_cv_list359

geteu_cv_pack358:                                 ; preds = %geteu_cv_obj357
  %geteu_cv_pk_data_slot379 = getelementptr inbounds i8, ptr %arr_ptr351, i64 24
  %geteu_cv_pk_data380 = load i64, ptr %geteu_cv_pk_data_slot379, align 8
  %geteu_cv_pk_len_slot381 = getelementptr inbounds i8, ptr %arr_ptr351, i64 32
  %geteu_cv_pk_len382 = load i64, ptr %geteu_cv_pk_len_slot381, align 8
  br label %geteu_cv_done360

geteu_cv_list359:                                 ; preds = %geteu_cv_obj357
  %geteu_cv_ls_data_slot383 = getelementptr inbounds i8, ptr %arr_ptr351, i64 40
  %geteu_cv_ls_data384 = load i64, ptr %geteu_cv_ls_data_slot383, align 8
  %geteu_cv_ls_len_slot385 = getelementptr inbounds i8, ptr %arr_ptr351, i64 24
  %geteu_cv_ls_len386 = load i64, ptr %geteu_cv_ls_len_slot385, align 8
  br label %geteu_cv_done360

geteu_cv_done360:                                 ; preds = %geteu_cv_list359, %geteu_cv_pack358, %geteu_cv_cell356
  %geteu_cv_data387 = phi i64 [ %geteu_w0361, %geteu_cv_cell356 ], [ %geteu_cv_pk_data380, %geteu_cv_pack358 ], [ %geteu_cv_ls_data384, %geteu_cv_list359 ]
  %geteu_cv_len388 = phi i64 [ %geteu_cv_cell_len364, %geteu_cv_cell356 ], [ %geteu_cv_pk_len382, %geteu_cv_pack358 ], [ %geteu_cv_ls_len386, %geteu_cv_list359 ]
  %geteu_cv_elem389 = phi i64 [ %geteu_cv_elem374, %geteu_cv_cell356 ], [ 1, %geteu_cv_pack358 ], [ 8, %geteu_cv_list359 ]
  %geteu_off390 = mul i64 %r5352, %geteu_cv_elem389
  %geteu_addr391 = add i64 %geteu_cv_data387, %geteu_off390
  %geteu_eptr392 = inttoptr i64 %geteu_addr391 to ptr
  switch i64 %geteu_cv_elem389, label %geteu_lw8396 [
    i64 1, label %geteu_lw1393
    i64 2, label %geteu_lw2394
    i64 4, label %geteu_lw4395
  ]

geteu_lw1393:                                     ; preds = %geteu_cv_done360
  %geteu_lv398 = load i8, ptr %geteu_eptr392, align 1
  %geteu_lz399 = zext i8 %geteu_lv398 to i64
  br label %geteu_lmerge397

geteu_lw2394:                                     ; preds = %geteu_cv_done360
  %geteu_lv400 = load i16, ptr %geteu_eptr392, align 2
  %geteu_lz401 = zext i16 %geteu_lv400 to i64
  br label %geteu_lmerge397

geteu_lw4395:                                     ; preds = %geteu_cv_done360
  %geteu_lv402 = load i32, ptr %geteu_eptr392, align 4
  %geteu_lz403 = zext i32 %geteu_lv402 to i64
  br label %geteu_lmerge397

geteu_lw8396:                                     ; preds = %geteu_cv_done360
  %geteu_lv8404 = load i64, ptr %geteu_eptr392, align 8
  br label %geteu_lmerge397

geteu_lmerge397:                                  ; preds = %geteu_lw8396, %geteu_lw4395, %geteu_lw2394, %geteu_lw1393
  %geteu_lval405 = phi i64 [ %geteu_lz399, %geteu_lw1393 ], [ %geteu_lz401, %geteu_lw2394 ], [ %geteu_lz403, %geteu_lw4395 ], [ %geteu_lv8404, %geteu_lw8396 ]
  store i64 %geteu_lval405, ptr %r2_slot, align 8
  store i64 32, ptr %r6_slot, align 8
  %r2406 = load i64, ptr %r2_slot, align 8
  %r6407 = load i64, ptr %r6_slot, align 8
  %shl408 = shl i64 %r2406, %r6407
  store i64 %shl408, ptr %r3_slot, align 8
  %r1409 = load i64, ptr %r1_slot, align 8
  %r3410 = load i64, ptr %r3_slot, align 8
  %or411 = or i64 %r1409, %r3410
  store i64 %or411, ptr %r1_slot, align 8
  store i64 4, ptr %r5_slot, align 8
  %r4412 = load i64, ptr %r4_slot, align 8
  %arr_ptr413 = inttoptr i64 %r4412 to ptr
  %r5414 = load i64, ptr %r5_slot, align 8
  %backing_slot415 = getelementptr inbounds i8, ptr %arr_ptr413, i64 40
  %backing_int416 = load i64, ptr %backing_slot415, align 8
  %backing_ptr417 = inttoptr i64 %backing_int416 to ptr
  %geteu_w0423 = load i64, ptr %arr_ptr413, align 8
  %geteu_is_cell424 = icmp uge i64 %geteu_w0423, 4294967296
  br i1 %geteu_is_cell424, label %geteu_cv_cell418, label %geteu_cv_obj419

geteu_cv_cell418:                                 ; preds = %geteu_lmerge397
  %geteu_cv_len_slot425 = getelementptr inbounds i8, ptr %arr_ptr413, i64 8
  %geteu_cv_cell_len426 = load i64, ptr %geteu_cv_len_slot425, align 8
  %geteu_cv_elem_slot427 = getelementptr inbounds i8, ptr %arr_ptr413, i64 16
  %geteu_cv_elem_raw428 = load i64, ptr %geteu_cv_elem_slot427, align 8
  %geteu_cv_e1429 = icmp eq i64 %geteu_cv_elem_raw428, 1
  %geteu_cv_ew430 = icmp eq i64 %geteu_cv_elem_raw428, 2
  %geteu_cv_edom431 = or i1 %geteu_cv_e1429, %geteu_cv_ew430
  %geteu_cv_ew432 = icmp eq i64 %geteu_cv_elem_raw428, 4
  %geteu_cv_edom433 = or i1 %geteu_cv_edom431, %geteu_cv_ew432
  %geteu_cv_ew434 = icmp eq i64 %geteu_cv_elem_raw428, 8
  %geteu_cv_edom435 = or i1 %geteu_cv_edom433, %geteu_cv_ew434
  %geteu_cv_elem436 = select i1 %geteu_cv_edom435, i64 %geteu_cv_elem_raw428, i64 8
  br label %geteu_cv_done422

geteu_cv_obj419:                                  ; preds = %geteu_lmerge397
  %geteu_cv_tid437 = load i32, ptr %arr_ptr413, align 4
  %geteu_cv_is_tuple438 = icmp eq i32 %geteu_cv_tid437, 521
  %geteu_cv_is_bslice439 = icmp eq i32 %geteu_cv_tid437, 528
  %geteu_cv_is_pack440 = or i1 %geteu_cv_is_tuple438, %geteu_cv_is_bslice439
  br i1 %geteu_cv_is_pack440, label %geteu_cv_pack420, label %geteu_cv_list421

geteu_cv_pack420:                                 ; preds = %geteu_cv_obj419
  %geteu_cv_pk_data_slot441 = getelementptr inbounds i8, ptr %arr_ptr413, i64 24
  %geteu_cv_pk_data442 = load i64, ptr %geteu_cv_pk_data_slot441, align 8
  %geteu_cv_pk_len_slot443 = getelementptr inbounds i8, ptr %arr_ptr413, i64 32
  %geteu_cv_pk_len444 = load i64, ptr %geteu_cv_pk_len_slot443, align 8
  br label %geteu_cv_done422

geteu_cv_list421:                                 ; preds = %geteu_cv_obj419
  %geteu_cv_ls_data_slot445 = getelementptr inbounds i8, ptr %arr_ptr413, i64 40
  %geteu_cv_ls_data446 = load i64, ptr %geteu_cv_ls_data_slot445, align 8
  %geteu_cv_ls_len_slot447 = getelementptr inbounds i8, ptr %arr_ptr413, i64 24
  %geteu_cv_ls_len448 = load i64, ptr %geteu_cv_ls_len_slot447, align 8
  br label %geteu_cv_done422

geteu_cv_done422:                                 ; preds = %geteu_cv_list421, %geteu_cv_pack420, %geteu_cv_cell418
  %geteu_cv_data449 = phi i64 [ %geteu_w0423, %geteu_cv_cell418 ], [ %geteu_cv_pk_data442, %geteu_cv_pack420 ], [ %geteu_cv_ls_data446, %geteu_cv_list421 ]
  %geteu_cv_len450 = phi i64 [ %geteu_cv_cell_len426, %geteu_cv_cell418 ], [ %geteu_cv_pk_len444, %geteu_cv_pack420 ], [ %geteu_cv_ls_len448, %geteu_cv_list421 ]
  %geteu_cv_elem451 = phi i64 [ %geteu_cv_elem436, %geteu_cv_cell418 ], [ 1, %geteu_cv_pack420 ], [ 8, %geteu_cv_list421 ]
  %geteu_off452 = mul i64 %r5414, %geteu_cv_elem451
  %geteu_addr453 = add i64 %geteu_cv_data449, %geteu_off452
  %geteu_eptr454 = inttoptr i64 %geteu_addr453 to ptr
  switch i64 %geteu_cv_elem451, label %geteu_lw8458 [
    i64 1, label %geteu_lw1455
    i64 2, label %geteu_lw2456
    i64 4, label %geteu_lw4457
  ]

geteu_lw1455:                                     ; preds = %geteu_cv_done422
  %geteu_lv460 = load i8, ptr %geteu_eptr454, align 1
  %geteu_lz461 = zext i8 %geteu_lv460 to i64
  br label %geteu_lmerge459

geteu_lw2456:                                     ; preds = %geteu_cv_done422
  %geteu_lv462 = load i16, ptr %geteu_eptr454, align 2
  %geteu_lz463 = zext i16 %geteu_lv462 to i64
  br label %geteu_lmerge459

geteu_lw4457:                                     ; preds = %geteu_cv_done422
  %geteu_lv464 = load i32, ptr %geteu_eptr454, align 4
  %geteu_lz465 = zext i32 %geteu_lv464 to i64
  br label %geteu_lmerge459

geteu_lw8458:                                     ; preds = %geteu_cv_done422
  %geteu_lv8466 = load i64, ptr %geteu_eptr454, align 8
  br label %geteu_lmerge459

geteu_lmerge459:                                  ; preds = %geteu_lw8458, %geteu_lw4457, %geteu_lw2456, %geteu_lw1455
  %geteu_lval467 = phi i64 [ %geteu_lz461, %geteu_lw1455 ], [ %geteu_lz463, %geteu_lw2456 ], [ %geteu_lz465, %geteu_lw4457 ], [ %geteu_lv8466, %geteu_lw8458 ]
  store i64 %geteu_lval467, ptr %r2_slot, align 8
  store i64 24, ptr %r6_slot, align 8
  %r2468 = load i64, ptr %r2_slot, align 8
  %r6469 = load i64, ptr %r6_slot, align 8
  %shl470 = shl i64 %r2468, %r6469
  store i64 %shl470, ptr %r3_slot, align 8
  %r1471 = load i64, ptr %r1_slot, align 8
  %r3472 = load i64, ptr %r3_slot, align 8
  %or473 = or i64 %r1471, %r3472
  store i64 %or473, ptr %r1_slot, align 8
  store i64 5, ptr %r5_slot, align 8
  %r4474 = load i64, ptr %r4_slot, align 8
  %arr_ptr475 = inttoptr i64 %r4474 to ptr
  %r5476 = load i64, ptr %r5_slot, align 8
  %backing_slot477 = getelementptr inbounds i8, ptr %arr_ptr475, i64 40
  %backing_int478 = load i64, ptr %backing_slot477, align 8
  %backing_ptr479 = inttoptr i64 %backing_int478 to ptr
  %geteu_w0485 = load i64, ptr %arr_ptr475, align 8
  %geteu_is_cell486 = icmp uge i64 %geteu_w0485, 4294967296
  br i1 %geteu_is_cell486, label %geteu_cv_cell480, label %geteu_cv_obj481

geteu_cv_cell480:                                 ; preds = %geteu_lmerge459
  %geteu_cv_len_slot487 = getelementptr inbounds i8, ptr %arr_ptr475, i64 8
  %geteu_cv_cell_len488 = load i64, ptr %geteu_cv_len_slot487, align 8
  %geteu_cv_elem_slot489 = getelementptr inbounds i8, ptr %arr_ptr475, i64 16
  %geteu_cv_elem_raw490 = load i64, ptr %geteu_cv_elem_slot489, align 8
  %geteu_cv_e1491 = icmp eq i64 %geteu_cv_elem_raw490, 1
  %geteu_cv_ew492 = icmp eq i64 %geteu_cv_elem_raw490, 2
  %geteu_cv_edom493 = or i1 %geteu_cv_e1491, %geteu_cv_ew492
  %geteu_cv_ew494 = icmp eq i64 %geteu_cv_elem_raw490, 4
  %geteu_cv_edom495 = or i1 %geteu_cv_edom493, %geteu_cv_ew494
  %geteu_cv_ew496 = icmp eq i64 %geteu_cv_elem_raw490, 8
  %geteu_cv_edom497 = or i1 %geteu_cv_edom495, %geteu_cv_ew496
  %geteu_cv_elem498 = select i1 %geteu_cv_edom497, i64 %geteu_cv_elem_raw490, i64 8
  br label %geteu_cv_done484

geteu_cv_obj481:                                  ; preds = %geteu_lmerge459
  %geteu_cv_tid499 = load i32, ptr %arr_ptr475, align 4
  %geteu_cv_is_tuple500 = icmp eq i32 %geteu_cv_tid499, 521
  %geteu_cv_is_bslice501 = icmp eq i32 %geteu_cv_tid499, 528
  %geteu_cv_is_pack502 = or i1 %geteu_cv_is_tuple500, %geteu_cv_is_bslice501
  br i1 %geteu_cv_is_pack502, label %geteu_cv_pack482, label %geteu_cv_list483

geteu_cv_pack482:                                 ; preds = %geteu_cv_obj481
  %geteu_cv_pk_data_slot503 = getelementptr inbounds i8, ptr %arr_ptr475, i64 24
  %geteu_cv_pk_data504 = load i64, ptr %geteu_cv_pk_data_slot503, align 8
  %geteu_cv_pk_len_slot505 = getelementptr inbounds i8, ptr %arr_ptr475, i64 32
  %geteu_cv_pk_len506 = load i64, ptr %geteu_cv_pk_len_slot505, align 8
  br label %geteu_cv_done484

geteu_cv_list483:                                 ; preds = %geteu_cv_obj481
  %geteu_cv_ls_data_slot507 = getelementptr inbounds i8, ptr %arr_ptr475, i64 40
  %geteu_cv_ls_data508 = load i64, ptr %geteu_cv_ls_data_slot507, align 8
  %geteu_cv_ls_len_slot509 = getelementptr inbounds i8, ptr %arr_ptr475, i64 24
  %geteu_cv_ls_len510 = load i64, ptr %geteu_cv_ls_len_slot509, align 8
  br label %geteu_cv_done484

geteu_cv_done484:                                 ; preds = %geteu_cv_list483, %geteu_cv_pack482, %geteu_cv_cell480
  %geteu_cv_data511 = phi i64 [ %geteu_w0485, %geteu_cv_cell480 ], [ %geteu_cv_pk_data504, %geteu_cv_pack482 ], [ %geteu_cv_ls_data508, %geteu_cv_list483 ]
  %geteu_cv_len512 = phi i64 [ %geteu_cv_cell_len488, %geteu_cv_cell480 ], [ %geteu_cv_pk_len506, %geteu_cv_pack482 ], [ %geteu_cv_ls_len510, %geteu_cv_list483 ]
  %geteu_cv_elem513 = phi i64 [ %geteu_cv_elem498, %geteu_cv_cell480 ], [ 1, %geteu_cv_pack482 ], [ 8, %geteu_cv_list483 ]
  %geteu_off514 = mul i64 %r5476, %geteu_cv_elem513
  %geteu_addr515 = add i64 %geteu_cv_data511, %geteu_off514
  %geteu_eptr516 = inttoptr i64 %geteu_addr515 to ptr
  switch i64 %geteu_cv_elem513, label %geteu_lw8520 [
    i64 1, label %geteu_lw1517
    i64 2, label %geteu_lw2518
    i64 4, label %geteu_lw4519
  ]

geteu_lw1517:                                     ; preds = %geteu_cv_done484
  %geteu_lv522 = load i8, ptr %geteu_eptr516, align 1
  %geteu_lz523 = zext i8 %geteu_lv522 to i64
  br label %geteu_lmerge521

geteu_lw2518:                                     ; preds = %geteu_cv_done484
  %geteu_lv524 = load i16, ptr %geteu_eptr516, align 2
  %geteu_lz525 = zext i16 %geteu_lv524 to i64
  br label %geteu_lmerge521

geteu_lw4519:                                     ; preds = %geteu_cv_done484
  %geteu_lv526 = load i32, ptr %geteu_eptr516, align 4
  %geteu_lz527 = zext i32 %geteu_lv526 to i64
  br label %geteu_lmerge521

geteu_lw8520:                                     ; preds = %geteu_cv_done484
  %geteu_lv8528 = load i64, ptr %geteu_eptr516, align 8
  br label %geteu_lmerge521

geteu_lmerge521:                                  ; preds = %geteu_lw8520, %geteu_lw4519, %geteu_lw2518, %geteu_lw1517
  %geteu_lval529 = phi i64 [ %geteu_lz523, %geteu_lw1517 ], [ %geteu_lz525, %geteu_lw2518 ], [ %geteu_lz527, %geteu_lw4519 ], [ %geteu_lv8528, %geteu_lw8520 ]
  store i64 %geteu_lval529, ptr %r2_slot, align 8
  store i64 16, ptr %r6_slot, align 8
  %r2530 = load i64, ptr %r2_slot, align 8
  %r6531 = load i64, ptr %r6_slot, align 8
  %shl532 = shl i64 %r2530, %r6531
  store i64 %shl532, ptr %r3_slot, align 8
  %r1533 = load i64, ptr %r1_slot, align 8
  %r3534 = load i64, ptr %r3_slot, align 8
  %or535 = or i64 %r1533, %r3534
  store i64 %or535, ptr %r1_slot, align 8
  store i64 6, ptr %r5_slot, align 8
  %r4536 = load i64, ptr %r4_slot, align 8
  %arr_ptr537 = inttoptr i64 %r4536 to ptr
  %r5538 = load i64, ptr %r5_slot, align 8
  %backing_slot539 = getelementptr inbounds i8, ptr %arr_ptr537, i64 40
  %backing_int540 = load i64, ptr %backing_slot539, align 8
  %backing_ptr541 = inttoptr i64 %backing_int540 to ptr
  %geteu_w0547 = load i64, ptr %arr_ptr537, align 8
  %geteu_is_cell548 = icmp uge i64 %geteu_w0547, 4294967296
  br i1 %geteu_is_cell548, label %geteu_cv_cell542, label %geteu_cv_obj543

geteu_cv_cell542:                                 ; preds = %geteu_lmerge521
  %geteu_cv_len_slot549 = getelementptr inbounds i8, ptr %arr_ptr537, i64 8
  %geteu_cv_cell_len550 = load i64, ptr %geteu_cv_len_slot549, align 8
  %geteu_cv_elem_slot551 = getelementptr inbounds i8, ptr %arr_ptr537, i64 16
  %geteu_cv_elem_raw552 = load i64, ptr %geteu_cv_elem_slot551, align 8
  %geteu_cv_e1553 = icmp eq i64 %geteu_cv_elem_raw552, 1
  %geteu_cv_ew554 = icmp eq i64 %geteu_cv_elem_raw552, 2
  %geteu_cv_edom555 = or i1 %geteu_cv_e1553, %geteu_cv_ew554
  %geteu_cv_ew556 = icmp eq i64 %geteu_cv_elem_raw552, 4
  %geteu_cv_edom557 = or i1 %geteu_cv_edom555, %geteu_cv_ew556
  %geteu_cv_ew558 = icmp eq i64 %geteu_cv_elem_raw552, 8
  %geteu_cv_edom559 = or i1 %geteu_cv_edom557, %geteu_cv_ew558
  %geteu_cv_elem560 = select i1 %geteu_cv_edom559, i64 %geteu_cv_elem_raw552, i64 8
  br label %geteu_cv_done546

geteu_cv_obj543:                                  ; preds = %geteu_lmerge521
  %geteu_cv_tid561 = load i32, ptr %arr_ptr537, align 4
  %geteu_cv_is_tuple562 = icmp eq i32 %geteu_cv_tid561, 521
  %geteu_cv_is_bslice563 = icmp eq i32 %geteu_cv_tid561, 528
  %geteu_cv_is_pack564 = or i1 %geteu_cv_is_tuple562, %geteu_cv_is_bslice563
  br i1 %geteu_cv_is_pack564, label %geteu_cv_pack544, label %geteu_cv_list545

geteu_cv_pack544:                                 ; preds = %geteu_cv_obj543
  %geteu_cv_pk_data_slot565 = getelementptr inbounds i8, ptr %arr_ptr537, i64 24
  %geteu_cv_pk_data566 = load i64, ptr %geteu_cv_pk_data_slot565, align 8
  %geteu_cv_pk_len_slot567 = getelementptr inbounds i8, ptr %arr_ptr537, i64 32
  %geteu_cv_pk_len568 = load i64, ptr %geteu_cv_pk_len_slot567, align 8
  br label %geteu_cv_done546

geteu_cv_list545:                                 ; preds = %geteu_cv_obj543
  %geteu_cv_ls_data_slot569 = getelementptr inbounds i8, ptr %arr_ptr537, i64 40
  %geteu_cv_ls_data570 = load i64, ptr %geteu_cv_ls_data_slot569, align 8
  %geteu_cv_ls_len_slot571 = getelementptr inbounds i8, ptr %arr_ptr537, i64 24
  %geteu_cv_ls_len572 = load i64, ptr %geteu_cv_ls_len_slot571, align 8
  br label %geteu_cv_done546

geteu_cv_done546:                                 ; preds = %geteu_cv_list545, %geteu_cv_pack544, %geteu_cv_cell542
  %geteu_cv_data573 = phi i64 [ %geteu_w0547, %geteu_cv_cell542 ], [ %geteu_cv_pk_data566, %geteu_cv_pack544 ], [ %geteu_cv_ls_data570, %geteu_cv_list545 ]
  %geteu_cv_len574 = phi i64 [ %geteu_cv_cell_len550, %geteu_cv_cell542 ], [ %geteu_cv_pk_len568, %geteu_cv_pack544 ], [ %geteu_cv_ls_len572, %geteu_cv_list545 ]
  %geteu_cv_elem575 = phi i64 [ %geteu_cv_elem560, %geteu_cv_cell542 ], [ 1, %geteu_cv_pack544 ], [ 8, %geteu_cv_list545 ]
  %geteu_off576 = mul i64 %r5538, %geteu_cv_elem575
  %geteu_addr577 = add i64 %geteu_cv_data573, %geteu_off576
  %geteu_eptr578 = inttoptr i64 %geteu_addr577 to ptr
  switch i64 %geteu_cv_elem575, label %geteu_lw8582 [
    i64 1, label %geteu_lw1579
    i64 2, label %geteu_lw2580
    i64 4, label %geteu_lw4581
  ]

geteu_lw1579:                                     ; preds = %geteu_cv_done546
  %geteu_lv584 = load i8, ptr %geteu_eptr578, align 1
  %geteu_lz585 = zext i8 %geteu_lv584 to i64
  br label %geteu_lmerge583

geteu_lw2580:                                     ; preds = %geteu_cv_done546
  %geteu_lv586 = load i16, ptr %geteu_eptr578, align 2
  %geteu_lz587 = zext i16 %geteu_lv586 to i64
  br label %geteu_lmerge583

geteu_lw4581:                                     ; preds = %geteu_cv_done546
  %geteu_lv588 = load i32, ptr %geteu_eptr578, align 4
  %geteu_lz589 = zext i32 %geteu_lv588 to i64
  br label %geteu_lmerge583

geteu_lw8582:                                     ; preds = %geteu_cv_done546
  %geteu_lv8590 = load i64, ptr %geteu_eptr578, align 8
  br label %geteu_lmerge583

geteu_lmerge583:                                  ; preds = %geteu_lw8582, %geteu_lw4581, %geteu_lw2580, %geteu_lw1579
  %geteu_lval591 = phi i64 [ %geteu_lz585, %geteu_lw1579 ], [ %geteu_lz587, %geteu_lw2580 ], [ %geteu_lz589, %geteu_lw4581 ], [ %geteu_lv8590, %geteu_lw8582 ]
  store i64 %geteu_lval591, ptr %r2_slot, align 8
  store i64 8, ptr %r6_slot, align 8
  %r2592 = load i64, ptr %r2_slot, align 8
  %r6593 = load i64, ptr %r6_slot, align 8
  %shl594 = shl i64 %r2592, %r6593
  store i64 %shl594, ptr %r3_slot, align 8
  %r1595 = load i64, ptr %r1_slot, align 8
  %r3596 = load i64, ptr %r3_slot, align 8
  %or597 = or i64 %r1595, %r3596
  store i64 %or597, ptr %r1_slot, align 8
  store i64 7, ptr %r5_slot, align 8
  %r4598 = load i64, ptr %r4_slot, align 8
  %arr_ptr599 = inttoptr i64 %r4598 to ptr
  %r5600 = load i64, ptr %r5_slot, align 8
  %backing_slot601 = getelementptr inbounds i8, ptr %arr_ptr599, i64 40
  %backing_int602 = load i64, ptr %backing_slot601, align 8
  %backing_ptr603 = inttoptr i64 %backing_int602 to ptr
  %geteu_w0609 = load i64, ptr %arr_ptr599, align 8
  %geteu_is_cell610 = icmp uge i64 %geteu_w0609, 4294967296
  br i1 %geteu_is_cell610, label %geteu_cv_cell604, label %geteu_cv_obj605

geteu_cv_cell604:                                 ; preds = %geteu_lmerge583
  %geteu_cv_len_slot611 = getelementptr inbounds i8, ptr %arr_ptr599, i64 8
  %geteu_cv_cell_len612 = load i64, ptr %geteu_cv_len_slot611, align 8
  %geteu_cv_elem_slot613 = getelementptr inbounds i8, ptr %arr_ptr599, i64 16
  %geteu_cv_elem_raw614 = load i64, ptr %geteu_cv_elem_slot613, align 8
  %geteu_cv_e1615 = icmp eq i64 %geteu_cv_elem_raw614, 1
  %geteu_cv_ew616 = icmp eq i64 %geteu_cv_elem_raw614, 2
  %geteu_cv_edom617 = or i1 %geteu_cv_e1615, %geteu_cv_ew616
  %geteu_cv_ew618 = icmp eq i64 %geteu_cv_elem_raw614, 4
  %geteu_cv_edom619 = or i1 %geteu_cv_edom617, %geteu_cv_ew618
  %geteu_cv_ew620 = icmp eq i64 %geteu_cv_elem_raw614, 8
  %geteu_cv_edom621 = or i1 %geteu_cv_edom619, %geteu_cv_ew620
  %geteu_cv_elem622 = select i1 %geteu_cv_edom621, i64 %geteu_cv_elem_raw614, i64 8
  br label %geteu_cv_done608

geteu_cv_obj605:                                  ; preds = %geteu_lmerge583
  %geteu_cv_tid623 = load i32, ptr %arr_ptr599, align 4
  %geteu_cv_is_tuple624 = icmp eq i32 %geteu_cv_tid623, 521
  %geteu_cv_is_bslice625 = icmp eq i32 %geteu_cv_tid623, 528
  %geteu_cv_is_pack626 = or i1 %geteu_cv_is_tuple624, %geteu_cv_is_bslice625
  br i1 %geteu_cv_is_pack626, label %geteu_cv_pack606, label %geteu_cv_list607

geteu_cv_pack606:                                 ; preds = %geteu_cv_obj605
  %geteu_cv_pk_data_slot627 = getelementptr inbounds i8, ptr %arr_ptr599, i64 24
  %geteu_cv_pk_data628 = load i64, ptr %geteu_cv_pk_data_slot627, align 8
  %geteu_cv_pk_len_slot629 = getelementptr inbounds i8, ptr %arr_ptr599, i64 32
  %geteu_cv_pk_len630 = load i64, ptr %geteu_cv_pk_len_slot629, align 8
  br label %geteu_cv_done608

geteu_cv_list607:                                 ; preds = %geteu_cv_obj605
  %geteu_cv_ls_data_slot631 = getelementptr inbounds i8, ptr %arr_ptr599, i64 40
  %geteu_cv_ls_data632 = load i64, ptr %geteu_cv_ls_data_slot631, align 8
  %geteu_cv_ls_len_slot633 = getelementptr inbounds i8, ptr %arr_ptr599, i64 24
  %geteu_cv_ls_len634 = load i64, ptr %geteu_cv_ls_len_slot633, align 8
  br label %geteu_cv_done608

geteu_cv_done608:                                 ; preds = %geteu_cv_list607, %geteu_cv_pack606, %geteu_cv_cell604
  %geteu_cv_data635 = phi i64 [ %geteu_w0609, %geteu_cv_cell604 ], [ %geteu_cv_pk_data628, %geteu_cv_pack606 ], [ %geteu_cv_ls_data632, %geteu_cv_list607 ]
  %geteu_cv_len636 = phi i64 [ %geteu_cv_cell_len612, %geteu_cv_cell604 ], [ %geteu_cv_pk_len630, %geteu_cv_pack606 ], [ %geteu_cv_ls_len634, %geteu_cv_list607 ]
  %geteu_cv_elem637 = phi i64 [ %geteu_cv_elem622, %geteu_cv_cell604 ], [ 1, %geteu_cv_pack606 ], [ 8, %geteu_cv_list607 ]
  %geteu_off638 = mul i64 %r5600, %geteu_cv_elem637
  %geteu_addr639 = add i64 %geteu_cv_data635, %geteu_off638
  %geteu_eptr640 = inttoptr i64 %geteu_addr639 to ptr
  switch i64 %geteu_cv_elem637, label %geteu_lw8644 [
    i64 1, label %geteu_lw1641
    i64 2, label %geteu_lw2642
    i64 4, label %geteu_lw4643
  ]

geteu_lw1641:                                     ; preds = %geteu_cv_done608
  %geteu_lv646 = load i8, ptr %geteu_eptr640, align 1
  %geteu_lz647 = zext i8 %geteu_lv646 to i64
  br label %geteu_lmerge645

geteu_lw2642:                                     ; preds = %geteu_cv_done608
  %geteu_lv648 = load i16, ptr %geteu_eptr640, align 2
  %geteu_lz649 = zext i16 %geteu_lv648 to i64
  br label %geteu_lmerge645

geteu_lw4643:                                     ; preds = %geteu_cv_done608
  %geteu_lv650 = load i32, ptr %geteu_eptr640, align 4
  %geteu_lz651 = zext i32 %geteu_lv650 to i64
  br label %geteu_lmerge645

geteu_lw8644:                                     ; preds = %geteu_cv_done608
  %geteu_lv8652 = load i64, ptr %geteu_eptr640, align 8
  br label %geteu_lmerge645

geteu_lmerge645:                                  ; preds = %geteu_lw8644, %geteu_lw4643, %geteu_lw2642, %geteu_lw1641
  %geteu_lval653 = phi i64 [ %geteu_lz647, %geteu_lw1641 ], [ %geteu_lz649, %geteu_lw2642 ], [ %geteu_lz651, %geteu_lw4643 ], [ %geteu_lv8652, %geteu_lw8644 ]
  store i64 %geteu_lval653, ptr %r2_slot, align 8
  %r1654 = load i64, ptr %r1_slot, align 8
  %r2655 = load i64, ptr %r2_slot, align 8
  %or656 = or i64 %r1654, %r2655
  store i64 %or656, ptr %r1_slot, align 8
  %r1657 = load i64, ptr %r1_slot, align 8
  store i64 %r1657, ptr %r2_slot, align 8
  %r4658 = load i64, ptr %r4_slot, align 8
  %r2659 = load i64, ptr %r2_slot, align 8
  %r2660 = load i64, ptr %r2_slot, align 8
  ret i64 %r2660
}

define internal i64 @verum_list_storage_stride(ptr %0) {
entry:
  %missing_list = icmp eq ptr %0, null
  br i1 %missing_list, label %invalid, label %read_tag

read_tag:                                         ; preds = %entry
  %list_storage_type = load i32, ptr %0, align 4
  switch i32 %list_storage_type, label %invalid [
    i32 512, label %storage
    i32 527, label %storage1
  ]

invalid:                                          ; preds = %read_tag, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

storage:                                          ; preds = %read_tag
  ret i64 8

storage1:                                         ; preds = %read_tag
  ret i64 1
}

; Function Attrs: noreturn
define internal void @verum_internal_exit_i64(i64 %0) #0 {
entry:
  %code_i32 = trunc i64 %0 to i32
  call void @verum_os_exit(i32 %code_i32)
  unreachable
}

define void @verum_os_exit(i32 %0) #3 {
entry:
  %c64 = sext i32 %0 to i64
  call void @verum_internal_exit_i64(i64 %c64)
  unreachable
}

define internal void @verum_list_grow(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %grow

grow:                                             ; preds = %entry
  %cap_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_cap = load i64, ptr %cap_slot, align 8
  %cap_2x = mul i64 %old_cap, 2
  %use_min = icmp slt i64 %cap_2x, 32
  %new_cap = select i1 %use_min, i64 32, i64 %cap_2x
  call void @verum_list_resize_storage(ptr %0, i64 %new_cap)
  br label %ret

ret:                                              ; preds = %grow, %entry
  ret void
}

define internal void @verum_list_resize_storage(ptr %0, i64 %1) {
entry:
  %resized = call i64 @verum_list_try_resize_storage(ptr %0, i64 %1)
  %ok = icmp ne i64 %resized, 0
  br i1 %ok, label %ready, label %failed

ready:                                            ; preds = %entry
  ret void

failed:                                           ; preds = %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal i64 @verum_list_try_resize_storage(ptr %0, i64 %1) {
entry:
  %validated_owner = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 0)
  %length_slot = getelementptr inbounds i8, ptr %0, i64 24
  %length = load i64, ptr %length_slot, align 8
  %initialized_prefix = call ptr @verum_list_storage_address(ptr %0, i64 0, i64 %length)
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %capacity_slot = getelementptr inbounds i8, ptr %0, i64 32
  %old_capacity = load i64, ptr %capacity_slot, align 8
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %old_data = load i64, ptr %data_slot, align 8
  %old_pointer = inttoptr i64 %old_data to ptr
  %capacity_limit = udiv i64 4294967199, %list_storage_stride
  %fits = icmp ule i64 %1, %capacity_limit
  %retains_initialized = icmp uge i64 %1, %length
  %allowed = and i1 %fits, %retains_initialized
  br i1 %allowed, label %valid_capacity, label %failure

valid_capacity:                                   ; preds = %entry
  %unchanged = icmp eq i64 %1, %old_capacity
  br i1 %unchanged, label %success, label %change

change:                                           ; preds = %valid_capacity
  %release_storage = icmp eq i64 %1, 0
  br i1 %release_storage, label %release, label %allocate

release:                                          ; preds = %change
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  store i64 0, ptr %data_slot, align 8
  store i64 0, ptr %capacity_slot, align 8
  br label %success

allocate:                                         ; preds = %change
  %allocation_bytes = mul i64 %1, %list_storage_stride
  %new_backing = call ptr @verum_try_cbgr_allocate_aligned(i64 %allocation_bytes, i64 %list_storage_stride)
  %allocation_failed = icmp eq ptr %new_backing, null
  br i1 %allocation_failed, label %failure, label %allocated

copy:                                             ; preds = %allocated
  %initialized_bytes = mul i64 %length, %list_storage_stride
  %2 = call ptr @verum_internal_memcpy(ptr %new_backing, ptr %initialized_prefix, i64 %initialized_bytes)
  br label %publish

publish:                                          ; preds = %copy, %allocated
  call void @verum_cbgr_deallocate(ptr %old_pointer)
  %new_backing_word = ptrtoint ptr %new_backing to i64
  store i64 %new_backing_word, ptr %data_slot, align 8
  store i64 %1, ptr %capacity_slot, align 8
  br label %success

success:                                          ; preds = %publish, %release, %valid_capacity
  ret i64 1

failure:                                          ; preds = %allocate, %entry
  ret i64 0

allocated:                                        ; preds = %allocate
  %has_initialized_prefix = icmp ne i64 %length, 0
  br i1 %has_initialized_prefix, label %copy, label %publish
}

define internal void @verum_cbgr_deallocate(ptr %0) {
entry:
  %is_null = icmp eq ptr %0, null
  br i1 %is_null, label %ret, label %do_dealloc

do_dealloc:                                       ; preds = %entry
  %header_ptr = getelementptr i8, ptr %0, i64 -32
  %gen_ptr = getelementptr i8, ptr %header_ptr, i64 8
  %1 = atomicrmw add ptr %gen_ptr, i32 1 acq_rel, align 4
  %new_gen = add i32 %1, 1
  %ge_max = icmp uge i32 %new_gen, -2
  %lt_old = icmp ult i32 %new_gen, %1
  %overflow = or i1 %ge_max, %lt_old
  br i1 %overflow, label %overflow1, label %set_ref

ret:                                              ; preds = %entry
  ret void

overflow1:                                        ; preds = %do_dealloc
  store i32 1, ptr %gen_ptr, align 4
  %epoch_ptr = getelementptr i8, ptr %header_ptr, i64 12
  %2 = atomicrmw add ptr %epoch_ptr, i16 1 release, align 2
  br label %set_ref

set_ref:                                          ; preds = %overflow1, %do_dealloc
  %rc_ptr = getelementptr i8, ptr %header_ptr, i64 24
  store i32 0, ptr %rc_ptr, align 4
  %hdr_total_ptr = getelementptr i8, ptr %header_ptr, i64 28
  %hdr_total = load i32, ptr %hdr_total_ptr, align 4
  %total = zext i32 %hdr_total to i64
  %hdr_base_off_ptr = getelementptr i8, ptr %header_ptr, i64 6
  %hdr_base_off = load i16, ptr %hdr_base_off_ptr, align 2
  %base_off64 = zext i16 %hdr_base_off to i64
  %header_int = ptrtoint ptr %header_ptr to i64
  %base_int = sub i64 %header_int, %base_off64
  %base = inttoptr i64 %base_int to ptr
  call void @verum_dealloc(ptr %base, i64 %total)
  ret void
}

define void @verum_dealloc(ptr %0, i64 %1) {
entry:
  %dptr_i64 = ptrtoint ptr %0 to i64
  %dptr_null = icmp eq i64 %dptr_i64, 0
  br i1 %dptr_null, label %d_done, label %d_check_size

d_large:                                          ; preds = %d_check_size
  %d_plus_page = add i64 %1, 4095
  %d_page_size = and i64 %d_plus_page, -4096
  call void @verum_os_free(ptr %0, i64 %d_page_size)
  br label %d_done

d_small:                                          ; preds = %d_check_size
  %d_size_m1 = sub i64 %1, 1
  %d_ctlz = call i64 @llvm.ctlz.i64(i64 %d_size_m1, i1 false)
  %d_shift = sub i64 64, %d_ctlz
  %d_class_signed = sub i64 %d_shift, 4
  %d_neg = icmp slt i64 %d_class_signed, 0
  %d_class = select i1 %d_neg, i64 0, i64 %d_class_signed
  br label %d_acquire

d_acquire:                                        ; preds = %d_acquire, %d_small
  %2 = cmpxchg ptr @__verum_alloc_lock, i32 0, i32 1 acquire monotonic, align 4
  %d_cas_ok = extractvalue { i32, i1 } %2, 1
  br i1 %d_cas_ok, label %d_locked, label %d_acquire

d_locked:                                         ; preds = %d_acquire
  %d_head_slot = getelementptr inbounds [9 x ptr], ptr @__verum_freelist_heads, i64 0, i64 %d_class
  %old_head = load ptr, ptr %d_head_slot, align 8
  store ptr %old_head, ptr %0, align 8
  store ptr %0, ptr %d_head_slot, align 8
  store i32 0, ptr @__verum_alloc_lock, align 4
  br label %d_done

d_done:                                           ; preds = %d_locked, %d_large, %entry
  ret void

d_check_size:                                     ; preds = %entry
  %d_large_q = icmp ugt i64 %1, 4096
  br i1 %d_large_q, label %d_large, label %d_small
}

@__verum_alloc_lock = internal global i32 0
@__verum_freelist_heads = internal global [9 x ptr] zeroinitializer
; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #8

define void @verum_os_free(ptr %0, i64 %1) {
entry:
  %munmap_rc = call i64 @munmap(ptr %0, i64 %1)
  ret void
}

declare i64 @munmap(ptr, i64)

define internal ptr @verum_internal_memcpy(ptr %0, ptr %1, i64 %2) {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr %0, ptr %1, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

define internal ptr @verum_try_cbgr_allocate_aligned(i64 %0, i64 %1) {
entry:
  %lt32 = icmp ult i64 %1, 32
  %align = select i1 %lt32, i64 32, i64 %1
  %add31 = add i64 %0, 31
  %aligned = and i64 %add31, -32
  %with_hdr = add i64 %aligned, 32
  %total = add i64 %with_hdr, %align
  %raw = call ptr @verum_os_alloc(i64 %total)
  %is_null = icmp eq ptr %raw, null
  br i1 %is_null, label %null_ret, label %init

init:                                             ; preds = %entry
  %2 = call ptr @memset(ptr %raw, i32 0, i64 %total)
  %raw_int = ptrtoint ptr %raw to i64
  %user0 = add i64 %raw_int, 32
  %align_m1 = sub i64 %align, 1
  %bumped = add i64 %user0, %align_m1
  %align_mask = xor i64 %align_m1, -1
  %user_int = and i64 %bumped, %align_mask
  %header_int = sub i64 %user_int, 32
  %header = inttoptr i64 %header_int to ptr
  %gen_ptr = getelementptr i8, ptr %header, i64 8
  store i32 1, ptr %gen_ptr, align 4
  %size32 = trunc i64 %0 to i32
  %size_ptr = getelementptr i8, ptr %header, i64 0
  store i32 %size32, ptr %size_ptr, align 4
  %epoch64 = load i64, ptr @global_epoch, align 8
  %epoch16 = trunc i64 %epoch64 to i16
  %epoch_ptr = getelementptr i8, ptr %header, i64 12
  store i16 %epoch16, ptr %epoch_ptr, align 2
  %cap_ptr = getelementptr i8, ptr %header, i64 14
  store i16 255, ptr %cap_ptr, align 2
  %rc_ptr = getelementptr i8, ptr %header, i64 24
  store i32 1, ptr %rc_ptr, align 4
  %align16 = trunc i64 %1 to i16
  %align_ptr = getelementptr i8, ptr %header, i64 4
  store i16 %align16, ptr %align_ptr, align 2
  %base_off64 = sub i64 %header_int, %raw_int
  %base_off16 = trunc i64 %base_off64 to i16
  %base_off_ptr = getelementptr i8, ptr %header, i64 6
  store i16 %base_off16, ptr %base_off_ptr, align 2
  %total32 = trunc i64 %total to i32
  %total_ptr = getelementptr i8, ptr %header, i64 28
  store i32 %total32, ptr %total_ptr, align 4
  %user_ptr = inttoptr i64 %user_int to ptr
  ret ptr %user_ptr

null_ret:                                         ; preds = %entry
  ret ptr null
}

@global_epoch = global i64 0
declare ptr @memset(ptr, i32, i64)

define ptr @verum_os_alloc(i64 %0) {
entry:
  %mmap_result = call i64 @mmap(i64 0, i64 %0, i64 3, i64 4098, i64 -1, i64 0)
  %mmap_ptr = inttoptr i64 %mmap_result to ptr
  ret ptr %mmap_ptr
}

declare i64 @mmap(i64, i64, i64, i64, i64, i64)

define internal ptr @verum_list_storage_address(ptr %0, i64 %1, i64 %2) {
entry:
  %list_storage_stride = call i64 @verum_list_storage_stride(ptr %0)
  %object_size_ptr = getelementptr inbounds i8, ptr %0, i64 12
  %object_size = load i32, ptr %object_size_ptr, align 4
  %valid_object_shape = icmp uge i32 %object_size, 48
  br i1 %valid_object_shape, label %shape, label %invalid

shape:                                            ; preds = %entry
  %capacity_ptr = getelementptr inbounds i8, ptr %0, i64 32
  %capacity = load i64, ptr %capacity_ptr, align 8
  %capacity_limit = udiv i64 4294967295, %list_storage_stride
  %valid_capacity = icmp ule i64 %capacity, %capacity_limit
  %valid_index = icmp ule i64 %1, %capacity
  %remaining_capacity = sub i64 %capacity, %1
  %valid_count = icmp ule i64 %2, %remaining_capacity
  %valid_owner_index = and i1 %valid_capacity, %valid_index
  %valid_range = and i1 %valid_owner_index, %valid_count
  br i1 %valid_range, label %range_ok, label %invalid

range_ok:                                         ; preds = %shape
  %data_slot = getelementptr inbounds i8, ptr %0, i64 40
  %data_word = load i64, ptr %data_slot, align 8
  %data = inttoptr i64 %data_word to ptr
  %missing_storage = icmp eq ptr %data, null
  br i1 %missing_storage, label %missing_backing, label %extent

empty:                                            ; preds = %ready, %missing_backing
  ret ptr null

nonempty_address:                                 ; preds = %ready
  %element_offset = mul i64 %1, %list_storage_stride
  %element_address = getelementptr inbounds i8, ptr %data, i64 %element_offset
  ret ptr %element_address

missing_backing:                                  ; preds = %range_ok
  %empty_owner = icmp eq i64 %capacity, 0
  br i1 %empty_owner, label %empty, label %invalid

extent:                                           ; preds = %range_ok
  %header_ptr = getelementptr i8, ptr %data, i64 -32
  %extent_ptr = getelementptr inbounds i8, ptr %header_ptr, i64 0
  %allocation_extent = load i32, ptr %extent_ptr, align 4
  %allocation_extent64 = zext i32 %allocation_extent to i64
  %capacity_bytes = mul i64 %capacity, %list_storage_stride
  %capacity_fits_allocation = icmp ule i64 %capacity_bytes, %allocation_extent64
  br i1 %capacity_fits_allocation, label %ready, label %invalid

ready:                                            ; preds = %extent
  %empty_range = icmp eq i64 %2, 0
  br i1 %empty_range, label %empty, label %nonempty_address

invalid:                                          ; preds = %extent, %missing_backing, %shape, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable
}

define internal ptr @verum_list_allocate_storage(i64 %0, i32 %1) {
entry:
  %slots = icmp eq i32 %1, 512
  %bytes = icmp eq i32 %1, 527
  %known_encoding = or i1 %slots, %bytes
  br i1 %known_encoding, label %valid_encoding, label %invalid

valid_encoding:                                   ; preds = %entry
  %width = select i1 %bytes, i64 1, i64 8
  %capacity_limit = udiv i64 4294967295, %width
  %capacity_fits = icmp ule i64 %0, %capacity_limit
  br i1 %capacity_fits, label %allocate, label %invalid

allocate:                                         ; preds = %valid_encoding
  %list_owner = call ptr @verum_checked_malloc(i64 48)
  %malloc_null = icmp eq ptr %list_owner, null
  br i1 %malloc_null, label %list_owner_oom, label %list_owner_ok

invalid:                                          ; preds = %valid_encoding, %entry
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_oom:                                   ; preds = %allocate
  call void @verum_internal_exit_i64(i64 1)
  unreachable

list_owner_ok:                                    ; preds = %allocate
  %2 = call ptr @verum_internal_memset(ptr %list_owner, i32 0, i64 48)
  store i32 %1, ptr %list_owner, align 4
  %list_object_size = getelementptr inbounds i8, ptr %list_owner, i64 12
  store i32 48, ptr %list_object_size, align 4
  call void @verum_list_resize_storage(ptr %list_owner, i64 %0)
  ret ptr %list_owner
}

define internal ptr @verum_internal_memset(ptr %0, i32 %1, i64 %2) {
entry:
  %val_i8 = trunc i32 %1 to i8
  call void @llvm.memset.p0.i64(ptr %0, i8 %val_i8, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

