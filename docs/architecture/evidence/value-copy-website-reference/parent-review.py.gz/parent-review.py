import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/taaliman/projects/oldman/verum-lang/website')
RECEIPT = Path('/private/tmp/verum-T1754-T1755-website/result.json')
OUT = Path('/private/tmp/verum-T1754-T1755-website/parent-review.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

receipt = json.loads(RECEIPT.read_text())
assert sha(RECEIPT.read_bytes()) == '949698239a15cc8030207b446b252e0454ad78269c04b792199e93fbc8b55003'
commit = receipt['website']['commit']
assert git('rev-parse', commit + '^{tree}').decode().strip() == receipt['website']['tree']
assert git('status', '--porcelain') == b''
assert git('rev-parse', 'HEAD').decode().strip() in (receipt['website']['base'], commit)
files_checked = {}
def verify_receipt_files(item):
    if isinstance(item, dict):
        if 'path' in item and 'sha256' in item and item['path'].startswith('/'):
            path = Path(item['path'])
            data = path.read_bytes()
            assert sha(data) == item['sha256'], str(path)
            if 'bytes' in item:
                assert len(data) == item['bytes'], str(path)
            files_checked[str(path)] = item['sha256']
        for value in item.values():
            verify_receipt_files(value)
    elif isinstance(item, list):
        for value in item:
            verify_receipt_files(value)

verify_receipt_files(receipt)
gates = [json.loads(Path(item['path']).read_text()) for item in receipt['gates']]
bindings = gates[0]['source_sha256']
assert len(bindings) == 403
for gate in gates:
    assert gate['exit_code'] == 0 and not gate['timed_out'] and gate['source_unchanged']
    assert gate['source_sha256'] == bindings
    assert sha(Path(gate['log']).read_bytes()) == gate['log_sha256']
paths = sorted(bindings)
specs = ''.join(commit + ':' + path + '\n' for path in paths).encode()
blobs = subprocess.run(['git', '-C', str(ROOT), 'cat-file', '--batch'], input=specs, stdout=subprocess.PIPE, check=True).stdout
offset = 0
for path in paths:
    end = blobs.index(b'\n', offset)
    header = blobs[offset:end].split()
    assert header[1] == b'blob', (path, header)
    size = int(header[2])
    start = end + 1
    data = blobs[start:start + size]
    assert sha(data) == bindings[path], path
    offset = start + size + 1
assert offset == len(blobs)
for item in [i for task in receipt['tasks'].values() for i in task['files']] + receipt['preserved_map_pages']:
    assert bindings[item['path']] == item['sha256']
rendered = json.loads(Path(receipt['rendered_inspection']['path']).read_text())
assert len(rendered['checks']) == 26 and all(rendered['checks'].values())
verify_receipt_files(rendered)
fixture = Path(receipt['preserved_executed_map_example']['path']).read_bytes()
cookbook = git('show', commit + ':docs/cookbook/collections.md')
assert b'```verum\n' + fixture + b'```' in cookbook
review = {
    'tasks': ['T1754', 'T1755'], 'status': 'passed', 'website_commit': commit,
    'receipt_sha256': sha(RECEIPT.read_bytes()), 'gate_count': len(gates),
    'source_bindings_checked': len(bindings) * len(gates),
    'unique_git_blobs_checked': len(bindings), 'rendered_checks': 26,
    'verified_files': files_checked, 'exact_cookbook_fixture_in_committed_source': True,
    'scope': 'Read-only source, receipt and rendered-output identity review; no gate or runtime rerun.'
}
source_evidence = json.loads(Path(receipt['source_evidence']['path']).read_text())
for path, digest in source_evidence['source_sha256'].items():
    data = subprocess.check_output(['git', '-C', '/Users/taaliman/projects/oldman/verum-lang/verum', 'show', source_evidence['language_source'] + ':' + path])
    assert sha(data) == digest, path
review['language_source_bindings_checked'] = len(source_evidence['source_sha256'])
OUT.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({k: v for k, v in review.items() if k != 'verified_files'}, indent=2))
