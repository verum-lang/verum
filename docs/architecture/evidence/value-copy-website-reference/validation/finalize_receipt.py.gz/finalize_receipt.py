from pathlib import Path
import hashlib
import json
import subprocess

out=Path('/private/tmp/verum-T1754-T1755-website')
repo=Path('/private/tmp/verum-website-cog-archive-profile')
language=Path('/Users/taaliman/projects/oldman/verum-lang/verum')
base='a30a1f176b72a85ee8d3e4efc6f0e813fadf8bf5'
first='e3401c248ba608401a6742dee6f02370ff5fc9f8'
final='e7556ca40edea2abc6a3ac0560e76c7b96c0e0f7'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args, root=repo): return subprocess.check_output(['git','-C',str(root),*args],stderr=subprocess.DEVNULL)
def record(p): return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
assert git('rev-parse','HEAD').decode().strip()==final
assert not git('status','--porcelain').strip()
assert git('rev-parse',final+'^').decode().strip()==first
assert git('rev-parse',first+'^').decode().strip()==base
subprocess.run(['git','-C',str(repo),'diff','--check',base,final],check=True,stderr=subprocess.DEVNULL)
changes={
    'T1754':{'commit':first,'paths':['docs/language/memory-model.md','docs/stdlib/mem.md','docs/language/meta/derives.md']},
    'T1755':{'commit':final,'paths':['docs/cookbook/shared-ownership.md']},
}
for task,d in changes.items():
    assert set(git('diff-tree','--no-commit-id','--name-only','-r',d['commit']).decode().splitlines())==set(d['paths'])
    d['files']=[{'path':p,'sha256':sha(git('show',d['commit']+':'+p))} for p in d.pop('paths')]
    for f in d['files']: assert sha(git('show',final+':'+f['path']))==f['sha256']
gate_records=[]
all_sources=None
for path in sorted((out/'gates').glob('*.json')):
    d=json.loads(path.read_text())
    assert d['website_commit']==final
    assert d['exit_code']==0 and not d['timed_out'] and d['source_unchanged']
    assert sha(Path(d['log']).read_bytes())==d['log_sha256']
    if all_sources is None: all_sources=d['source_sha256']
    assert d['source_sha256']==all_sources
    gate_records.append({**record(path),'name':d['name'],'command':d['command'],'seconds':d['elapsed_seconds'],'source_binding_count':len(d['source_sha256']),'log':record(Path(d['log']))})
assert len(gate_records)==5
proc=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
for path,h in all_sources.items():
    proc.stdin.write((final+':'+path+'\n').encode()); proc.stdin.flush()
    header=proc.stdout.readline().split(); assert len(header)==3 and header[1]==b'blob',header
    b=proc.stdout.read(int(header[2])); assert proc.stdout.read(1)==b'\n'
    assert sha(b)==h,path
proc.stdin.close(); assert proc.wait()==0
source=json.loads((out/'source-evidence.json').read_text())
for p,h in source['source_sha256'].items(): assert sha(git('show',source['language_source']+':'+p,root=language))==h,p
rendered=json.loads((out/'rendered-inspection.json').read_text())
assert all(rendered['checks'].values())
for p in rendered['pages'].values(): assert sha(Path(p['path']).read_bytes())==p['sha256']
map_pages=['docs/cookbook/collections.md','docs/stdlib/collections.md']
for p in map_pages: assert git('show',base+':'+p)==git('show',final+':'+p)
cookbook=git('show',final+':docs/cookbook/collections.md').decode()
block=next(b for b in cookbook.split('```verum\n')[1:] if 'map-access: ok' in b).split('```')[0]
fixture=Path('/private/tmp/verum-T1751-map-docs/map_access.vr')
assert block.encode()==fixture.read_bytes()
assert sha(block.encode())=='c48149b7371e14eb681ba1eda8943777afba3846791693201f97b6004cf46807'
result={
    'tasks':changes,'status':'ready for parent review and local main integration',
    'website':{'worktree':str(repo),'branch':git('branch','--show-current').decode().strip(),'base':base,'commit':final,'tree':git('rev-parse',final+'^{tree}').decode().strip(),'clean':True,'source_bindings_per_gate':len(all_sources),'verified_gate_source_bindings':len(all_sources)*len(gate_records)},
    'gates':gate_records,
    'rendered_inspection':{**record(out/'rendered-inspection.json'),'passed':len(rendered['checks']),'inspector':record(out/'inspect_rendered.py')},
    'source_evidence':record(out/'source-evidence.json'),
    'preserved_map_pages':[{'path':p,'sha256':sha(git('show',final+':'+p))} for p in map_pages],
    'preserved_executed_map_example':record(fixture),
    'existing_shared_runtime_task':'T0384 remains owned elsewhere; journal links the separate docs correction, no runtime-task closure.',
    'validation_scope':'One five-gate suite validates the final combined source. Each task commit changes only its owned paths; first-commit path bytes are identical in the tested endpoint.',
    'notes':['Five required website gates passed on clean frozen committed source with Node 22.19.0.','Nonfatal shared node_modules cache/update notices retained in build.log; no dependencies installed or updated.','Changes add prose/table clarification, remove misleading or impossible examples, and correct one comment. No new runnable example or Verum runtime acceptance.','No language build, CLI execution, native/AOT, deployment, push or website main change by this task.'],
    'no_acceptance':source['no_acceptance'],
}
path=out/'result.json'; path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':str(path),'sha256':sha(path.read_bytes()),'commit':final,'source_bindings':result['website']['verified_gate_source_bindings'],'rendered_checks':len(rendered['checks']),'clean':True}))
