import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/private/tmp/verum-website-cog-archive-profile')
OUT = Path('/private/tmp/verum-T1754-T1755-website/gates')
NODE = Path('/Users/taaliman/.nvm/versions/node/v22.19.0/bin')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source_hashes():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    return {os.fsdecode(p): sha((ROOT / os.fsdecode(p)).read_bytes()) for p in paths if p}

name, *command = sys.argv[1:]
before = source_hashes()
env = os.environ.copy()
env['PATH'] = str(NODE) + os.pathsep + env['PATH']
started = time.monotonic()
timed_out = False
with (OUT / f'{name}.log').open('wb') as log:
    try:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=600)
        exit_code = result.returncode
    except subprocess.TimeoutExpired:
        exit_code = None
        timed_out = True
after = source_hashes()
receipt = {
    'name': name, 'cwd': str(ROOT), 'command': command,
    'website_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'node': subprocess.check_output([str(NODE / 'node'), '--version'], text=True).strip(),
    'exit_code': exit_code, 'timed_out': timed_out,
    'elapsed_seconds': round(time.monotonic() - started, 3),
    'source_unchanged': before == after, 'source_sha256': before,
    'log': str(OUT / f'{name}.log'),
    'log_sha256': sha((OUT / f'{name}.log').read_bytes()),
}
(OUT / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'source_sha256'}))
raise SystemExit(0 if exit_code == 0 and before == after else 1)
