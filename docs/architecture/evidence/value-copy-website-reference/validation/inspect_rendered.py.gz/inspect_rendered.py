from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import re

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.path = path
        self.ids = set()
        self.links = set()
        self.data = []
        self.code = []
        self.current_code = None
        self.feed(path.read_text())
        self.text = re.sub(r'\s+', ' ', ''.join(self.data))
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'): self.ids.add(attrs['id'])
        if attrs.get('href'): self.links.add(attrs['href'])
        if tag == 'code': self.current_code = []
        if tag == 'br' and self.current_code is not None: self.current_code.append('\n')
    def handle_data(self, data):
        self.data.append(data)
        if self.current_code is not None: self.current_code.append(data)
    def handle_endtag(self, tag):
        if tag == 'code' and self.current_code is not None:
            self.code.append(''.join(self.current_code))
            self.current_code = None

root = Path('/private/tmp/verum-website-cog-archive-profile/build')
paths = ['docs/language/memory-model.html', 'docs/stdlib/mem.html', 'docs/language/meta/derives.html', 'docs/cookbook/shared-ownership.html']
memory, mem, derives, shared = pages = [Page(root / p) for p in paths]
checks = {
    'copy_depth_anchor': 'copy-depth' in memory.ids,
    'copy_depth_contract_link': 'https://github.com/verum-lang/verum/blob/main/docs/architecture/value-copy-contract.md' in memory.links,
    'fresh_record_outer': 'Fresh outer storage containing shallow copies' in memory.text,
    'container_backing_and_shallow_elements': 'Fresh container storage and backing array; nested element values are not recursively cloned.' in memory.text,
    'nested_list_boundary': "copy that nested list's backing array" in memory.text,
    'reference_identity_and_lifetime': "Another alias to the same referent; copying it does not extend the referent's lifetime." in memory.text,
    'shared_identity_and_refcount': 'Another owning handle to the same cell, with a strong-reference count increment.' in memory.text,
    'resource_copy_separated': 'These copy-depth rules do not authorize duplicating an exclusive resource' in memory.text,
    'no_independent_destructor_claim': 'does not by itself establish a fresh owner with an independent destructor.' in memory.text,
    'explicit_deref_clone_native_limits': 'explicit dereference, .clone() dispatch and native copying require separate validation.' in memory.text,
    'no_unqualified_unique_shared': 'Shared<T>, and custom allocated types are unique owners' not in memory.text,
    'no_universal_noncopy_move': 'A non-Copy type is moved on assignment and parameter passing' not in memory.text,
    'heap_delegates_to_inner_clone': 'containing the result of T.clone()' in mem.text,
    'heap_nested_sharing': 'nested references and Shared handles retain the sharing specified by their own clone contracts.' in mem.text,
    'mem_copy_depth_link': '/docs/language/memory-model#copy-depth' in mem.links,
    'derive_field_contract': "Field-by-field .clone(), following each field's clone contract" in derives.text,
    'derive_identity_not_deep': 'references remain aliases and Shared<T> retains identity.' in derives.text,
    'derive_status_not_promoted': 'the generator status at the top of this page still applies.' in derives.text,
    'derive_copy_depth_link': '/docs/language/memory-model#copy-depth' in derives.links,
    'no_deep_clone_guarantee': 'Deep-clone via field-by-field' not in derives.text and 'deep-copy if T: Clone' not in mem.text,
    'shared_both_uniqueness_conditions': 'one strong reference and no weak references.' in shared.text,
    'is_unique_only_strong': 'is_unique() checks the strong count alone.' in shared.text,
    'shared_cloned_handle_not_unique': 'it does not create a uniquely mutable copy of the value.' in shared.text,
    'shared_topology_labeled': 'This declaration sketch shows owning child edges and weak parent links:' in shared.text,
    'invalid_add_child_removed': all('fn add_child' not in code and 'child.clone().get_mut().unwrap()' not in code for code in shared.code),
    'no_unexecuted_mutation_replacement': 'Updating a shared node needs an explicit mutation API.' in shared.text,
}
result = {
    'checks': checks,
    'pages': {str(page.path.relative_to(root)): {'path': str(page.path), 'sha256': hashlib.sha256(page.path.read_bytes()).hexdigest()} for page in pages},
    'scope': 'Rendered prose/table/signature boundaries, explicit scope labels, removal and cross-page anchors; no layout redesign or new runtime acceptance.'
}
Path('/private/tmp/verum-T1754-T1755-website/rendered-inspection.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed':sum(checks.values()),'total':len(checks),'failures':[k for k,v in checks.items() if not v]}))
assert all(checks.values()), {name: value for name, value in checks.items() if not value}
