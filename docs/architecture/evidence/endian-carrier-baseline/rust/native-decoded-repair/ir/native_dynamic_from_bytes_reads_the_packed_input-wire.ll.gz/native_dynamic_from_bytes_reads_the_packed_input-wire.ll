target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe(i64 %0) #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 %0, ptr %r0_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %siv_fb_bytes = inttoptr i64 %r2 to ptr
  %siv_fb_slot = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 0
  %siv_fb_byte = load i8, ptr %siv_fb_slot, align 1
  %siv_fb_widen = zext i8 %siv_fb_byte to i64
  %siv_fb_or = or i64 0, %siv_fb_widen
  %siv_fb_slot1 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 1
  %siv_fb_byte2 = load i8, ptr %siv_fb_slot1, align 1
  %siv_fb_widen3 = zext i8 %siv_fb_byte2 to i64
  %siv_fb_shl = shl i64 %siv_fb_widen3, 8
  %siv_fb_or4 = or i64 %siv_fb_or, %siv_fb_shl
  %siv_fb_slot5 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 2
  %siv_fb_byte6 = load i8, ptr %siv_fb_slot5, align 1
  %siv_fb_widen7 = zext i8 %siv_fb_byte6 to i64
  %siv_fb_shl8 = shl i64 %siv_fb_widen7, 16
  %siv_fb_or9 = or i64 %siv_fb_or4, %siv_fb_shl8
  %siv_fb_slot10 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 3
  %siv_fb_byte11 = load i8, ptr %siv_fb_slot10, align 1
  %siv_fb_widen12 = zext i8 %siv_fb_byte11 to i64
  %siv_fb_shl13 = shl i64 %siv_fb_widen12, 24
  %siv_fb_or14 = or i64 %siv_fb_or9, %siv_fb_shl13
  %siv_fb_tr = trunc i64 %siv_fb_or14 to i32
  %siv_fb_sx = sext i32 %siv_fb_tr to i64
  store i64 %siv_fb_sx, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  store i64 %r3, ptr %r1_slot, align 8
  %r115 = load i64, ptr %r1_slot, align 8
  %r116 = load i64, ptr %r1_slot, align 8
  ret i64 %r116
}

