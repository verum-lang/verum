target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 72623859790382856, ptr %r1_slot, align 8
  store i64 8, ptr %r2_slot, align 8
  store i64 0, ptr %r3_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r2)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_init8 = trunc i64 %r3 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r2, i1 false)
  store i64 255, ptr %r5_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r21 = load i64, ptr %r2_slot, align 8
  %ashr = ashr i64 %r1, %r21
  store i64 %ashr, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %and = and i64 %r4, %r5
  store i64 %and, ptr %r3_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %ba_base = inttoptr i64 %r0 to ptr
  %r22 = load i64, ptr %r2_slot, align 8
  %r33 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r22
  %ba_trunc = trunc i64 %r33 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 8, ptr %r2_slot, align 8
  %r14 = load i64, ptr %r1_slot, align 8
  %r25 = load i64, ptr %r2_slot, align 8
  %ashr6 = ashr i64 %r14, %r25
  store i64 %ashr6, ptr %r4_slot, align 8
  %r47 = load i64, ptr %r4_slot, align 8
  %r58 = load i64, ptr %r5_slot, align 8
  %and9 = and i64 %r47, %r58
  store i64 %and9, ptr %r3_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r010 = load i64, ptr %r0_slot, align 8
  %ba_base11 = inttoptr i64 %r010 to ptr
  %r212 = load i64, ptr %r2_slot, align 8
  %r313 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr14 = getelementptr i8, ptr %ba_base11, i64 %r212
  %ba_trunc15 = trunc i64 %r313 to i8
  store i8 %ba_trunc15, ptr %ba_store_ptr14, align 1
  store i64 16, ptr %r2_slot, align 8
  %r116 = load i64, ptr %r1_slot, align 8
  %r217 = load i64, ptr %r2_slot, align 8
  %ashr18 = ashr i64 %r116, %r217
  store i64 %ashr18, ptr %r4_slot, align 8
  %r419 = load i64, ptr %r4_slot, align 8
  %r520 = load i64, ptr %r5_slot, align 8
  %and21 = and i64 %r419, %r520
  store i64 %and21, ptr %r3_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  %r022 = load i64, ptr %r0_slot, align 8
  %ba_base23 = inttoptr i64 %r022 to ptr
  %r224 = load i64, ptr %r2_slot, align 8
  %r325 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr26 = getelementptr i8, ptr %ba_base23, i64 %r224
  %ba_trunc27 = trunc i64 %r325 to i8
  store i8 %ba_trunc27, ptr %ba_store_ptr26, align 1
  store i64 24, ptr %r2_slot, align 8
  %r128 = load i64, ptr %r1_slot, align 8
  %r229 = load i64, ptr %r2_slot, align 8
  %ashr30 = ashr i64 %r128, %r229
  store i64 %ashr30, ptr %r4_slot, align 8
  %r431 = load i64, ptr %r4_slot, align 8
  %r532 = load i64, ptr %r5_slot, align 8
  %and33 = and i64 %r431, %r532
  store i64 %and33, ptr %r3_slot, align 8
  store i64 3, ptr %r2_slot, align 8
  %r034 = load i64, ptr %r0_slot, align 8
  %ba_base35 = inttoptr i64 %r034 to ptr
  %r236 = load i64, ptr %r2_slot, align 8
  %r337 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr38 = getelementptr i8, ptr %ba_base35, i64 %r236
  %ba_trunc39 = trunc i64 %r337 to i8
  store i8 %ba_trunc39, ptr %ba_store_ptr38, align 1
  store i64 32, ptr %r2_slot, align 8
  %r140 = load i64, ptr %r1_slot, align 8
  %r241 = load i64, ptr %r2_slot, align 8
  %ashr42 = ashr i64 %r140, %r241
  store i64 %ashr42, ptr %r4_slot, align 8
  %r443 = load i64, ptr %r4_slot, align 8
  %r544 = load i64, ptr %r5_slot, align 8
  %and45 = and i64 %r443, %r544
  store i64 %and45, ptr %r3_slot, align 8
  store i64 4, ptr %r2_slot, align 8
  %r046 = load i64, ptr %r0_slot, align 8
  %ba_base47 = inttoptr i64 %r046 to ptr
  %r248 = load i64, ptr %r2_slot, align 8
  %r349 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr50 = getelementptr i8, ptr %ba_base47, i64 %r248
  %ba_trunc51 = trunc i64 %r349 to i8
  store i8 %ba_trunc51, ptr %ba_store_ptr50, align 1
  store i64 40, ptr %r2_slot, align 8
  %r152 = load i64, ptr %r1_slot, align 8
  %r253 = load i64, ptr %r2_slot, align 8
  %ashr54 = ashr i64 %r152, %r253
  store i64 %ashr54, ptr %r4_slot, align 8
  %r455 = load i64, ptr %r4_slot, align 8
  %r556 = load i64, ptr %r5_slot, align 8
  %and57 = and i64 %r455, %r556
  store i64 %and57, ptr %r3_slot, align 8
  store i64 5, ptr %r2_slot, align 8
  %r058 = load i64, ptr %r0_slot, align 8
  %ba_base59 = inttoptr i64 %r058 to ptr
  %r260 = load i64, ptr %r2_slot, align 8
  %r361 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr62 = getelementptr i8, ptr %ba_base59, i64 %r260
  %ba_trunc63 = trunc i64 %r361 to i8
  store i8 %ba_trunc63, ptr %ba_store_ptr62, align 1
  store i64 48, ptr %r2_slot, align 8
  %r164 = load i64, ptr %r1_slot, align 8
  %r265 = load i64, ptr %r2_slot, align 8
  %ashr66 = ashr i64 %r164, %r265
  store i64 %ashr66, ptr %r4_slot, align 8
  %r467 = load i64, ptr %r4_slot, align 8
  %r568 = load i64, ptr %r5_slot, align 8
  %and69 = and i64 %r467, %r568
  store i64 %and69, ptr %r3_slot, align 8
  store i64 6, ptr %r2_slot, align 8
  %r070 = load i64, ptr %r0_slot, align 8
  %ba_base71 = inttoptr i64 %r070 to ptr
  %r272 = load i64, ptr %r2_slot, align 8
  %r373 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr74 = getelementptr i8, ptr %ba_base71, i64 %r272
  %ba_trunc75 = trunc i64 %r373 to i8
  store i8 %ba_trunc75, ptr %ba_store_ptr74, align 1
  store i64 56, ptr %r2_slot, align 8
  %r176 = load i64, ptr %r1_slot, align 8
  %r277 = load i64, ptr %r2_slot, align 8
  %ashr78 = ashr i64 %r176, %r277
  store i64 %ashr78, ptr %r4_slot, align 8
  %r479 = load i64, ptr %r4_slot, align 8
  %r580 = load i64, ptr %r5_slot, align 8
  %and81 = and i64 %r479, %r580
  store i64 %and81, ptr %r3_slot, align 8
  store i64 7, ptr %r2_slot, align 8
  %r082 = load i64, ptr %r0_slot, align 8
  %ba_base83 = inttoptr i64 %r082 to ptr
  %r284 = load i64, ptr %r2_slot, align 8
  %r385 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr86 = getelementptr i8, ptr %ba_base83, i64 %r284
  %ba_trunc87 = trunc i64 %r385 to i8
  store i8 %ba_trunc87, ptr %ba_store_ptr86, align 1
  %r088 = load i64, ptr %r0_slot, align 8
  store i64 %r088, ptr %r1_slot, align 8
  %r189 = load i64, ptr %r1_slot, align 8
  %r190 = load i64, ptr %r1_slot, align 8
  ret i64 %r190
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

