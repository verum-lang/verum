target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe() #6 {
block_0:
  %r4_slot = alloca i64, align 8
  %r5_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  store i64 72623859790382856, ptr %r1_slot, align 8
  store i64 2, ptr %r2_slot, align 8
  store i64 0, ptr %r3_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %new_byte_array = call ptr @verum_cbgr_allocate(i64 %r2)
  %r0_ptr_to_i64 = ptrtoint ptr %new_byte_array to i64
  store i64 %r0_ptr_to_i64, ptr %r0_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  %ba_init8 = trunc i64 %r3 to i8
  call void @llvm.memset.p0.i64(ptr %new_byte_array, i8 %ba_init8, i64 %r2, i1 false)
  store i64 255, ptr %r5_slot, align 8
  store i64 8, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r21 = load i64, ptr %r2_slot, align 8
  %ashr = ashr i64 %r1, %r21
  store i64 %ashr, ptr %r4_slot, align 8
  %r4 = load i64, ptr %r4_slot, align 8
  %r5 = load i64, ptr %r5_slot, align 8
  %and = and i64 %r4, %r5
  store i64 %and, ptr %r3_slot, align 8
  store i64 0, ptr %r2_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  %ba_base = inttoptr i64 %r0 to ptr
  %r22 = load i64, ptr %r2_slot, align 8
  %r33 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr = getelementptr i8, ptr %ba_base, i64 %r22
  %ba_trunc = trunc i64 %r33 to i8
  store i8 %ba_trunc, ptr %ba_store_ptr, align 1
  store i64 0, ptr %r2_slot, align 8
  %r14 = load i64, ptr %r1_slot, align 8
  %r25 = load i64, ptr %r2_slot, align 8
  %ashr6 = ashr i64 %r14, %r25
  store i64 %ashr6, ptr %r4_slot, align 8
  %r47 = load i64, ptr %r4_slot, align 8
  %r58 = load i64, ptr %r5_slot, align 8
  %and9 = and i64 %r47, %r58
  store i64 %and9, ptr %r3_slot, align 8
  store i64 1, ptr %r2_slot, align 8
  %r010 = load i64, ptr %r0_slot, align 8
  %ba_base11 = inttoptr i64 %r010 to ptr
  %r212 = load i64, ptr %r2_slot, align 8
  %r313 = load i64, ptr %r3_slot, align 8
  %ba_store_ptr14 = getelementptr i8, ptr %ba_base11, i64 %r212
  %ba_trunc15 = trunc i64 %r313 to i8
  store i8 %ba_trunc15, ptr %ba_store_ptr14, align 1
  %r016 = load i64, ptr %r0_slot, align 8
  store i64 %r016, ptr %r1_slot, align 8
  %r117 = load i64, ptr %r1_slot, align 8
  %r118 = load i64, ptr %r1_slot, align 8
  ret i64 %r118
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

