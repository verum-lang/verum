target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin25.4.0"
attributes #0 = { noreturn "noreturn" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "noreturn" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { noinline nounwind optnone }
attributes #6 = { nounwind }
attributes #7 = { noinline }
attributes #8 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { returns_twice "verum.platform.extern" }
attributes #10 = { noreturn "verum.platform.extern" }
attributes #11 = { "cold" "noreturn" }
declare ptr @verum_cbgr_allocate(i64)
declare ptr @verum_checked_malloc(i64)
; Function Attrs: nounwind
define internal i64 @probe(i64 %0) #6 {
block_0:
  %r3_slot = alloca i64, align 8
  %r2_slot = alloca i64, align 8
  %r1_slot = alloca i64, align 8
  %r0_slot = alloca i64, align 8
  store i64 %0, ptr %r0_slot, align 8
  store i64 0, ptr %r1_slot, align 8
  %r0 = load i64, ptr %r0_slot, align 8
  store i64 %r0, ptr %r2_slot, align 8
  %r1 = load i64, ptr %r1_slot, align 8
  %r2 = load i64, ptr %r2_slot, align 8
  %siv_fb_bytes = inttoptr i64 %r2 to ptr
  %siv_fb_slot = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 0
  %siv_fb_byte = load i8, ptr %siv_fb_slot, align 1
  %siv_fb_widen = zext i8 %siv_fb_byte to i64
  %siv_fb_shl = shl i64 %siv_fb_widen, 56
  %siv_fb_or = or i64 0, %siv_fb_shl
  %siv_fb_slot1 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 1
  %siv_fb_byte2 = load i8, ptr %siv_fb_slot1, align 1
  %siv_fb_widen3 = zext i8 %siv_fb_byte2 to i64
  %siv_fb_shl4 = shl i64 %siv_fb_widen3, 48
  %siv_fb_or5 = or i64 %siv_fb_or, %siv_fb_shl4
  %siv_fb_slot6 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 2
  %siv_fb_byte7 = load i8, ptr %siv_fb_slot6, align 1
  %siv_fb_widen8 = zext i8 %siv_fb_byte7 to i64
  %siv_fb_shl9 = shl i64 %siv_fb_widen8, 40
  %siv_fb_or10 = or i64 %siv_fb_or5, %siv_fb_shl9
  %siv_fb_slot11 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 3
  %siv_fb_byte12 = load i8, ptr %siv_fb_slot11, align 1
  %siv_fb_widen13 = zext i8 %siv_fb_byte12 to i64
  %siv_fb_shl14 = shl i64 %siv_fb_widen13, 32
  %siv_fb_or15 = or i64 %siv_fb_or10, %siv_fb_shl14
  %siv_fb_slot16 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 4
  %siv_fb_byte17 = load i8, ptr %siv_fb_slot16, align 1
  %siv_fb_widen18 = zext i8 %siv_fb_byte17 to i64
  %siv_fb_shl19 = shl i64 %siv_fb_widen18, 24
  %siv_fb_or20 = or i64 %siv_fb_or15, %siv_fb_shl19
  %siv_fb_slot21 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 5
  %siv_fb_byte22 = load i8, ptr %siv_fb_slot21, align 1
  %siv_fb_widen23 = zext i8 %siv_fb_byte22 to i64
  %siv_fb_shl24 = shl i64 %siv_fb_widen23, 16
  %siv_fb_or25 = or i64 %siv_fb_or20, %siv_fb_shl24
  %siv_fb_slot26 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 6
  %siv_fb_byte27 = load i8, ptr %siv_fb_slot26, align 1
  %siv_fb_widen28 = zext i8 %siv_fb_byte27 to i64
  %siv_fb_shl29 = shl i64 %siv_fb_widen28, 8
  %siv_fb_or30 = or i64 %siv_fb_or25, %siv_fb_shl29
  %siv_fb_slot31 = getelementptr inbounds i8, ptr %siv_fb_bytes, i64 7
  %siv_fb_byte32 = load i8, ptr %siv_fb_slot31, align 1
  %siv_fb_widen33 = zext i8 %siv_fb_byte32 to i64
  %siv_fb_or34 = or i64 %siv_fb_or30, %siv_fb_widen33
  store i64 %siv_fb_or34, ptr %r3_slot, align 8
  %r3 = load i64, ptr %r3_slot, align 8
  store i64 %r3, ptr %r1_slot, align 8
  %r135 = load i64, ptr %r1_slot, align 8
  %r136 = load i64, ptr %r1_slot, align 8
  ret i64 %r136
}

