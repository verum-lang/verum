#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

WT = Path('/Users/taaliman/projects/oldman/verum-lang/verum')
TARGET = Path('/Users/taaliman/.tmp/verum-codex-01a10248/native-target')
PRODUCT = Path('/private/tmp/verum-registry-stage22-field-authority')
MANIFEST_SHA = '91a90f9b3343732651ad8d8fd35f64363ededd7328e15f02d1da1fe99dc9ee72'
CLI_SHA = '73d96b4c346d8d8eb759abf03c5c3316f3d349fb8e5601318d0d5da368979f10'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args], text=True).strip()

def sources():
    paths = subprocess.check_output(['git', '-C', str(WT), 'ls-files', '-z']).decode().split('\0')
    return {p: sha(WT / p) for p in paths if p and (p.endswith(('.rs', '.toml', '.vr')) or p == 'Cargo.lock')}

def artifacts():
    return {p.name: identity(p) for p in sorted((TARGET / 'precompiled-stdlib').glob('runtime.*')) if p.is_file()}

def product():
    manifest = identity(PRODUCT / 'build-manifest.json')
    assert manifest['sha256'] == MANIFEST_SHA
    data = json.loads((PRODUCT / 'build-manifest.json').read_text())
    cli = identity(data['cli']['path'])
    assert cli['sha256'] == CLI_SHA
    retained = {name: identity(Path(data['artifact_snapshot']) / name) for name in data['artifacts']}
    for name, entry in retained.items():
        assert entry['sha256'] == data['artifacts'][name]['sha256'], name
    return {'manifest': manifest, 'cli': cli, 'artifacts': retained}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--evidence-dir', required=True, type=Path)
    parser.add_argument('--transition-only', action='store_true')
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == args.expected_source
    assert not git('status', '--porcelain')
    out = args.evidence_dir
    out.mkdir()
    env = os.environ.copy()
    override = {
        'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '1',
        'CARGO_INCREMENTAL': '0', 'VERUM_NO_AUTO_PRECOMPILE': '1',
        'VERUM_LLVM_DIR': '/Users/taaliman/projects/oldman/verum-lang/verum/llvm/install',
        'RUST_MIN_STACK': '16777216',
        'VERUM_CACHE_POLICY_EVIDENCE_DIR': str(out / 'cargo-transitions'),
        'CARGO_LOG': 'cargo::core::compiler::fingerprint=trace',
    }
    for name in ['DOCS_RS', 'VERUM_ALLOW_STALE_STDLIB', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS']:
        assert not env.get(name), f'unexpected inherited {name}'
        env.pop(name, None)
    env.update(override)
    cmd = ['cargo', '+nightly-2026-08-20', 'test', '--offline', '--locked',
           '--message-format=json-render-diagnostics', '--manifest-path', str(WT / 'Cargo.toml'),
           '-p', 'verum_compiler', '--test', 'stdlib_cache_identity']
    if args.transition_only:
        cmd += ['cargo_rechecks_auto_precompile_policy_on_environment_changes']
    cmd += ['--', '--test-threads=1', '--nocapture']
    if args.transition_only:
        cmd += ['--exact']
    before_source, before_artifacts, before_product = sources(), artifacts(), product()
    metadata = {
        'source': args.expected_source, 'tree': git('rev-parse', 'HEAD^{tree}'),
        'branch': git('branch', '--show-current'), 'command': cmd,
        'environment_overrides': override, 'source_paths': before_source,
        'artifacts_before': before_artifacts, 'stage22_product_before': before_product,
        'timeout_seconds': 900, 'runner': identity(__file__),
        'scope': 'Actual Cargo policy transition and cache-key controls. Synthetic cache-hit sentinels; no real archive bake or language runtime acceptance.',
    }
    (out / 'started.json').write_text(json.dumps(metadata, indent=2) + '\n')
    begin = time.monotonic()
    timed_out = False
    interrupted = False
    with (out / 'gate.log').open('wb') as log:
        proc = subprocess.Popen(cmd, cwd=WT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (out / 'process.json').write_text(json.dumps({'pid': proc.pid, 'command': cmd}, indent=2) + '\n')
        print(f'gate pid={proc.pid} source={args.expected_source} log={out / "gate.log"}', flush=True)
        try:
            code = proc.wait(timeout=900)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
            timed_out = isinstance(error, subprocess.TimeoutExpired)
            interrupted = isinstance(error, KeyboardInterrupt)
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                code = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait()
    metadata.update({'seconds': round(time.monotonic() - begin, 3), 'exit_code': code,
                     'timed_out': timed_out, 'interrupted': interrupted,
                     'source_unchanged': sources() == before_source and git('rev-parse', 'HEAD') == args.expected_source and not git('status', '--porcelain'),
                     'artifacts_after': artifacts(), 'stage22_product_after': product(),
                     'log': identity(out / 'gate.log')})
    metadata['artifacts_unchanged'] = metadata['artifacts_after'] == before_artifacts
    metadata['stage22_product_unchanged'] = metadata['stage22_product_after'] == before_product
    executables = []
    for line in (out / 'gate.log').read_text(errors='replace').splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') == 'compiler-artifact' and event.get('target', {}).get('name') == 'stdlib_cache_identity' and event.get('executable'):
            executable = Path(event['executable'])
            entry = identity(executable)
            retained = out / executable.name
            shutil.copy2(executable, retained)
            entry['retained'] = identity(retained)
            entry['fresh'] = event.get('fresh')
            executables.append(entry)
    metadata['test_executables'] = executables
    metadata['test_summaries'] = re.findall(r'test result: [^\n]+', (out / 'gate.log').read_text(errors='replace'))
    metadata['transition_files'] = {str(p.relative_to(out)): identity(p) for p in sorted((out / 'cargo-transitions').glob('*')) if p.is_file()}
    (out / 'result.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps({k: metadata[k] for k in ['seconds','exit_code','timed_out','source_unchanged','artifacts_unchanged','stage22_product_unchanged','test_summaries']}, indent=2), flush=True)
    return code

if __name__ == '__main__':
    raise SystemExit(main())
