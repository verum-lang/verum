//! Test-only observation of native transaction owners. No exported condition
//! authorizes commit; the actual runtime supplies every Result and transition.
use super::*;
use crate::program::observer::{
    InputBinding, InputSource,
    lifecycle_export::{Identities, identity},
};
use crate::program::{Operand, Operation, Program};
use serde_json::{Value as Json, json};
use std::collections::BTreeMap;

pub(crate) struct Export<V: Clone, P, D, S: Semantics<V, P>, Y> {
    cuts: Identities<V, P, D, S>,
    scores: Vec<Arc<residual::Score>>,
    models: Vec<Arc<residual::Model>>,
    protocols: Vec<Arc<residual::Protocol<V, Y>>>,
    inputs: Vec<InputRow<D, V>>,
    sources: BTreeMap<usize, Vec<usize>>,
    prepared_sources: BTreeMap<usize, Json>,
    events: Vec<Json>,
    value: fn(&V) -> Json,
    interface: fn(&D) -> Json,
    operation: fn(&P) -> Json,
    semantics: &'static str,
    wire_protocol: Json,
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>, Y> Export<V, P, D, S, Y> {
    pub(crate) fn new(
        value: fn(&V) -> Json,
        interface: fn(&D) -> Json,
        operation: fn(&P) -> Json,
        semantics: &'static str,
        wire_protocol: Json,
    ) -> Self {
        Self {
            cuts: Identities::new(),
            scores: Vec::new(),
            models: Vec::new(),
            protocols: Vec::new(),
            inputs: Vec::new(),
            sources: BTreeMap::new(),
            prepared_sources: BTreeMap::new(),
            events: Vec::new(),
            value,
            interface,
            operation,
            semantics,
            wire_protocol,
        }
    }
    fn score(&mut self, score: &Arc<residual::Score>) -> usize {
        identity(&mut self.models, score.model());
        identity(&mut self.scores, score)
    }
    fn input(&mut self, input: &InputRow<D, V>) -> usize {
        if let Some(id) = self.inputs.iter().position(|old| old.same_owner(input)) {
            return id;
        }
        let id = self.inputs.len();
        self.inputs.push(input.clone());
        id
    }
    fn source(&self, event: usize) -> Json {
        json!(
            self.sources
                .get(&event)
                .into_iter()
                .flatten()
                .map(|&query| json!({"query":query,"event":event}))
                .collect::<Vec<_>>()
        )
    }
    fn prepared(&mut self, prepared: &Prepared<V, P, D, S>) -> Json {
        self.cuts.prepared(prepared, self.value)
    }
    pub(crate) fn runtime<H, K>(&mut self, runtime: &Runtime<V, P, D, S, H, K, Y>) -> Json {
        json!({"cut":self.cuts.cut(&runtime.cut(),self.value),"score":self.score(&runtime.score),
            "protocol":identity(&mut self.protocols,&runtime.protocol)})
    }
    pub(crate) fn predicting(&mut self, pending: &Predicting<V, P, D, S, Y>) -> Json {
        json!({"cut":self.cuts.cut(pending.read.cut(),self.value),
            "query":self.input(pending.read.input()),"event":pending.event.as_ref().map(|v|self.input(v)),
            "previous_score":self.score(&pending.previous),
            "protocol":identity(&mut self.protocols,&pending.protocol),"done":pending.done})
    }
    pub(crate) fn ticket(
        &mut self,
        pending: &Predicting<V, P, D, S, Y>,
        ticket: &Ticket<V, P, D, S, Y>,
    ) -> Json {
        let event = self.input(&ticket.event);
        let query = self.input(pending.read.input());
        let queries = self.sources.entry(event).or_default();
        if !queries.contains(&query) {
            queries.push(query);
        }
        json!({"reading":{"cut":self.cuts.cut(ticket.reading.cut(),self.value),"value":(self.value)(ticket.reading.value()),
                "retained_sources":self.source(event)},
            "event":event,"previous_score":self.score(&ticket.previous),
            "protocol":identity(&mut self.protocols,&ticket.protocol),
            "forecast":ticket.forecast.native_frontier()})
    }
    pub(crate) fn learning(&mut self, pending: &Learning<V, P, D, S>) -> Json {
        let event = self.input(&pending.event);
        let source = self.source(event);
        let prepared = pending.prepared.as_ref().map(|p| {
            let actual = self.prepared(p);
            let state = actual["after"]["state"].as_u64().expect("native state ID") as usize;
            self.prepared_sources.insert(state, source.clone());
            actual
        });
        json!({"reading":pending.reading.as_ref().map(|r|json!({
                "cut":self.cuts.cut(r.cut(),self.value),"value":(self.value)(r.value()),"retained_sources":source})),
            "preparing":pending.preparing.as_ref().map(|p|json!({"before":self.cuts.cut(p.before(),self.value),"event":self.input(p.input())})),
            "completion_pending":pending.completion.is_some(),"completion_poisoned":pending.completion_poisoned,
            "prepared":prepared,"retained_sources":source,"previous_score":self.score(&pending.previous),
            "target":pending.target.as_ref(),"accumulator":pending.acc.as_ref().map(|a|a.native_frontier()),"done":pending.done})
    }
    pub(crate) fn update(&mut self, update: &Update<V, P, D, S>) -> Json {
        let prepared = self.prepared(&update.prepared);
        let state = prepared["after"]["state"]
            .as_u64()
            .expect("native state ID") as usize;
        let source = self.prepared_sources.get(&state).cloned();
        json!({"reading":{"cut":self.cuts.cut(update.reading.cut(),self.value),"value":(self.value)(update.reading.value()),
                "retained_sources":source},"prepared":prepared,"retained_sources":source,
            "previous_score":self.score(&update.previous),"next_score":self.score(&update.next),"target":update.target.as_ref()})
    }
    fn receipt(&mut self, receipt: &Receipt<V, P, D, S>) -> Json {
        let committed = self.cuts.committed(&receipt.committed, self.value);
        let state = committed["after"]["state"]
            .as_u64()
            .expect("native state ID") as usize;
        json!({"reading":{"cut":self.cuts.cut(receipt.reading.cut(),self.value),"value":(self.value)(receipt.reading.value())},
            "committed":committed,"retained_sources":self.prepared_sources.get(&state),
            "target":receipt.target.as_ref(),"previous_score":self.score(&receipt.before),"next_score":self.score(&receipt.after)})
    }
    /// Calls the actual existing guard exactly once and returns the same owner.
    pub(crate) fn commit<H, K>(
        &mut self,
        runtime: &mut Runtime<V, P, D, S, H, K, Y>,
        update: Update<V, P, D, S>,
    ) -> Result<Receipt<V, P, D, S>, Update<V, P, D, S>> {
        let before = self.runtime(runtime);
        let incoming = self.update(&update);
        let result = runtime.commit(update);
        let outcome = match &result {
            Ok(receipt) => json!({"kind":"accepted","receipt":self.receipt(receipt)}),
            Err(update) => json!({"kind":"refused","returned_update":self.update(update)}),
        };
        let after = self.runtime(runtime);
        self.events.push(json!({"kind":"commit","before":before,"incoming_update":incoming,"result":outcome,"after":after}));
        result
    }
    pub(crate) fn push(&mut self, event: Json) {
        self.events.push(event);
    }
    pub(crate) fn frozen(&mut self, label: &str, forecast: &residual::Forecast) {
        self.events.push(
            json!({"kind":"frozen_forecast","label":label,"frontier":forecast.native_frontier()}),
        );
    }
    fn program(&self, program: &Program<V, P>) -> Json {
        json!({"steps":program.steps.iter().map(|step|json!({
            "operation":match &step.operation { Operation::Primitive(p)=>json!({"primitive":(self.operation)(p)}),Operation::Call(i)=>json!({"call":i}),Operation::Branch{yes,no}=>json!({"branch":{"yes":yes,"no":no}}),Operation::Fold{body}=>json!({"fold":{"body":body}}) },
            "arguments":step.arguments.iter().map(|a|match a { Operand::Input(i)=>json!({"input":i}),Operand::Register(i)=>json!({"register":i}),Operand::Literal(v)=>json!({"literal":(self.value)(v)}) }).collect::<Vec<_>>()
        })).collect::<Vec<_>>(),"output":program.output,"library":program.library.iter().map(|p|self.program(p)).collect::<Vec<_>>()})
    }
    fn binding(&self, binding: &InputBinding<D>) -> Json {
        json!({"interface":(self.interface)(binding.interface()),"width":binding.width(),
            "slots":binding.slots().iter().map(|s|match s { InputSource::State=>json!({"state":true}),InputSource::External(i)=>json!({"external":i}) }).collect::<Vec<_>>()})
    }
    pub(crate) fn finish(self, case: &str) -> Json {
        let scores = self.scores.iter().enumerate().map(|(id,score)|json!({"id":id,
            "model":self.models.iter().position(|m|Arc::ptr_eq(m,score.model())).expect("retained model owner"),
            "frontier":score.native_frontier()})).collect::<Vec<_>>();
        json!({"format":"synarc-residual-transactions-v1","case":case,
            "scope":"native predictive transaction and scoring frontiers; internal VM continuation is outside this snapshot",
            "semantics":self.semantics,"wire_protocol":self.wire_protocol,
            "definitions":self.cuts.definitions().iter().enumerate().map(|(id,d)|json!({"id":id,"initial":(self.value)(d.initial()),
                "update":self.program(d.update()),"read":self.program(d.read()),
                "update_binding":self.binding(d.update_binding()),"read_binding":self.binding(d.read_binding())})).collect::<Vec<_>>(),
            "inputs":self.inputs.iter().enumerate().map(|(id,row)|json!({"id":id,"interface":(self.interface)(row.interface()),
                "values":row.values().iter().map(self.value).collect::<Vec<_>>()})).collect::<Vec<_>>(),
            "scores":scores,"models":(0..self.models.len()).map(|id|json!({"id":id})).collect::<Vec<_>>(),
            "protocols":(0..self.protocols.len()).map(|id|json!({"id":id})).collect::<Vec<_>>(),"events":self.events})
    }
}
