//! Production input language for general acquired observers.
//!
//! These primitives only interpret represented values. All program execution,
//! state ownership, replay and transactions use program::observer. Events are
//! exact pre-action inputs already retained by causal_coordinates; no successor,
//! outcome or past pose is invented. The optional pre-action pose belongs to the retained native event;
//! a later live pose cannot fill a missing historical port. The update/read grammar and adapter are frozen before examples enter.

use super::{causal_coordinates as history, ObservedWorldOutcome, ObserverWork};
use crate::program::{self, Operand, Operation, Program, Semantics, Step};
use crate::program::observer::{self, InputBinding, InputSource};
use crate::program::observer::acquisition::{self as acquisition, construction, installation};
use std::sync::Arc;
mod value_dag;
pub(super) mod portable;
pub(super) use value_dag::SharedValue;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) enum Shape { Event, Query }
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Source { pub sensory: bool, pub epoch: u128, pub raw_space: u128, pub owner: Option<history::Lineage>, pub shape: Shape }

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Event<A> {
    pub sensory: Option<super::Sensory>,
    pub epoch: u128, pub raw_space: u128, pub owner: Option<history::Lineage>, pub raw: u64, pub input: u64,
    pub action: A, pub episode: u64, pub life_age: u64, pub pose: Option<u8>,
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Query<A> {
    pub sensory: Option<super::Sensory>,
    pub epoch: u128, pub raw_space: u128, pub owner: Option<history::Lineage>, pub raw: u64, pub input: u64,
    pub episode: u64, pub life_age: u64, pub pose: Option<u8>,
    /// State naming uses None because the action has not been chosen. A
    /// transition query may carry the full A, but is a different declared input.
    pub action: Option<A>,
}

/// Persistent exact event sequence. Append shares its predecessor; comparison
/// and destruction are iterative, so a long owned life does not recurse on the
/// host stack. Ordering is lexicographic newest-first, equality is exact history.
#[derive(Clone)]
pub(super) struct Trace<A> { head: Option<Arc<Link<A>>>, len: usize }
struct Link<A> { event: Event<A>, previous: Option<Arc<Link<A>>> }
impl<A: std::fmt::Debug> std::fmt::Debug for Trace<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Trace").field("len", &self.len)
            .field("newest", &self.head.as_deref().map(|node| &node.event)).finish_non_exhaustive()
    }
}
impl<A> Drop for Link<A> {
    fn drop(&mut self) {
        let mut cursor = self.previous.take();
        while let Some(link) = cursor {
            match Arc::into_inner(link) { Some(mut unique) => cursor = unique.previous.take(), None => break }
        }
    }
}
impl<A> Trace<A> {
    fn empty() -> Self { Self { head: None, len: 0 } }
    fn append(&self, event: Event<A>, capacity: usize) -> Result<Self, DomainRefusal> {
        let len = self.len.checked_add(1).ok_or(DomainRefusal::Overflow)?;
        if len > capacity { return Err(DomainRefusal::TraceCapacity); }
        Ok(Self { head: Some(Arc::new(Link { event, previous: self.head.clone() })), len })
    }
    fn at(&self, index: usize) -> Option<&Event<A>> {
        let back = self.len.checked_sub(index.checked_add(1)?)?;
        let mut node = self.head.as_deref()?;
        for _ in 0..back { node = node.previous.as_deref()?; }
        Some(&node.event)
    }
    fn last(&self) -> Option<&Event<A>> { self.head.as_deref().map(|node| &node.event) }
    pub(super) fn len(&self) -> usize { self.len }
}
impl<A: Ord> Ord for Trace<A> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        let (mut a, mut b) = (self.head.as_deref(), other.head.as_deref());
        loop { match (a, b) {
            (Some(left), Some(right)) => { if std::ptr::eq(left,right) { return std::cmp::Ordering::Equal; }
                let cmp = left.event.cmp(&right.event);
                if cmp != std::cmp::Ordering::Equal { return cmp; }
                a = left.previous.as_deref(); b = right.previous.as_deref(); },
            (None, None) => return std::cmp::Ordering::Equal,
            (None, Some(_)) => return std::cmp::Ordering::Less,
            (Some(_), None) => return std::cmp::Ordering::Greater,
        } }
    }
}
impl<A: Ord> PartialOrd for Trace<A> { fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> { Some(self.cmp(other)) } }
impl<A: Ord> PartialEq for Trace<A> { fn eq(&self, other: &Self) -> bool { self.cmp(other) == std::cmp::Ordering::Equal } }
impl<A: Ord> Eq for Trace<A> {}

#[derive(Clone)]
pub(super) enum Value<A: Ord> {
    Unit, Nat(u64), Bool(bool), Action(A), Event(Event<A>), Query(Query<A>),
    Pair(SharedValue<A>, SharedValue<A>), Trace(Trace<A>), Outcome(ObservedWorldOutcome), Bytes(Arc<[u8]>),
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) enum Op {
    Unit, Zero, EmptyTrace, Identity,
    Append, At, Last, Length, EventInput, EventRaw, EventAction, EventAge, EventPose,
    QueryInput, QueryRaw, QueryAge, QueryAction, QueryPose,
    Pair, First, Second, Equal, Select, Add, Rem, Next, Refused, EventSensory, QuerySensory,
}
impl Op {
    pub(super) fn arity(self) -> usize {
        match self { Self::Unit | Self::Zero | Self::EmptyTrace => 0, Self::Append | Self::At | Self::Pair | Self::Equal | Self::Add | Self::Rem => 2,
            Self::Select => 3, _ => 1 }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum DomainRefusal { Arity, Sort, Missing, Overflow, TraceCapacity, Allocation }

/// Trace length has an explicit semantic resource limit. Pair results share
/// finite immutable DAG nodes; total reachable Value size is not bounded by
/// max_trace. VM accounting meters instructions/bindings, not every generic
/// comparison, allocation or leaf traversal. The stack-safe DAG operations
/// still require sufficient heap and lawful action-type trait implementations.
#[derive(Debug)]
pub(super) struct Meaning { max_trace: usize }
#[cfg(test)]
impl Meaning { pub(super) fn for_sensory_court(max_trace: usize) -> Self { Self { max_trace } } }
impl<A: Copy + Ord> Semantics<Value<A>, Op> for Meaning {
    type Error = DomainRefusal;
    fn classify_failure(&self, error: &DomainRefusal) -> program::PrimitiveRefusal {
        if matches!(error, DomainRefusal::TraceCapacity | DomainRefusal::Allocation) { program::PrimitiveRefusal::Resource }
        else { program::PrimitiveRefusal::Undefined }
    }
    fn apply(&self, operation: &Op, a: &[Value<A>]) -> Result<Value<A>, DomainRefusal> {
        use DomainRefusal as E;
        if a.len() != operation.arity() { return Err(E::Arity); }
        match (operation, a) {
            (Op::Unit, []) => Ok(Value::Unit),
            (Op::Zero, []) => Ok(Value::Nat(0)),
            (Op::EmptyTrace, []) => Ok(Value::Trace(Trace::empty())),
            (Op::Identity, [value]) => Ok(value.clone()),
            (Op::Append, [Value::Trace(old), Value::Event(event)]) => {
                Ok(Value::Trace(old.append(event.clone(), self.max_trace)?))
            }
            (Op::At, [Value::Trace(trace), Value::Nat(index)]) => {
                let index = usize::try_from(*index).map_err(|_| E::Overflow)?;
                trace.at(index).cloned().map(Value::Event).ok_or(E::Missing)
            }
            (Op::At, [Value::Bytes(bytes), Value::Nat(index)]) => {
                let index = usize::try_from(*index).map_err(|_| E::Overflow)?;
                bytes.get(index).map(|byte| Value::Nat(u64::from(*byte))).ok_or(E::Missing)
            }
            (Op::Length, [Value::Bytes(bytes)]) => Ok(Value::Nat(u64::try_from(bytes.len()).map_err(|_| E::Overflow)?)),
            (Op::EventSensory, [Value::Event(event)]) => sensory_value(event.sensory.as_ref()),
            (Op::QuerySensory, [Value::Query(query)]) => sensory_value(query.sensory.as_ref()),
            (Op::Last, [Value::Trace(trace)]) => trace.last().cloned().map(Value::Event).ok_or(E::Missing),
            (Op::Length, [Value::Trace(trace)]) => Ok(Value::Nat(u64::try_from(trace.len()).map_err(|_| E::Overflow)?)),
            (Op::EventInput, [Value::Event(e)]) => Ok(Value::Nat(e.input)),
            (Op::EventRaw, [Value::Event(e)]) => Ok(Value::Nat(e.raw)),
            (Op::EventAction, [Value::Event(e)]) => Ok(Value::Action(e.action)),
            (Op::EventAge, [Value::Event(e)]) => Ok(Value::Nat(e.life_age)),
            (Op::EventPose, [Value::Event(e)]) => e.pose.map(|p| Value::Nat(u64::from(p))).ok_or(E::Missing),
            (Op::QueryInput, [Value::Query(q)]) => Ok(Value::Nat(q.input)),
            (Op::QueryRaw, [Value::Query(q)]) => Ok(Value::Nat(q.raw)),
            (Op::QueryAge, [Value::Query(q)]) => Ok(Value::Nat(q.life_age)),
            (Op::QueryPose, [Value::Query(q)]) => q.pose.map(|p| Value::Nat(u64::from(p))).ok_or(E::Missing),
            (Op::QueryAction, [Value::Query(q)]) => q.action.map(Value::Action).ok_or(E::Missing),
            (Op::Pair, [first, second]) => Ok(Value::Pair(SharedValue::new(first.clone()), SharedValue::new(second.clone()))),
            (Op::First, [Value::Pair(first, _)]) => Ok((**first).clone()),
            (Op::Second, [Value::Pair(_, second)]) => Ok((**second).clone()),
            (Op::Equal, [left, right]) => Ok(Value::Bool(left == right)),
            (Op::Select, [Value::Bool(test), left, right]) => Ok(if *test { left } else { right }.clone()),
            (Op::Add, [Value::Nat(left), Value::Nat(right)]) => left.checked_add(*right).map(Value::Nat).ok_or(E::Overflow),
            (Op::Rem, [Value::Nat(left), Value::Nat(right)]) => left.checked_rem(*right).map(Value::Nat).ok_or(E::Missing),
            (Op::Next, [Value::Nat(key)]) => Ok(Value::Outcome(ObservedWorldOutcome::Next(*key))),
            (Op::Refused, [Value::Nat(key)]) => Ok(Value::Outcome(ObservedWorldOutcome::Refused(*key))),
            _ => Err(E::Sort),
        }
    }
}

fn sensory_value<A: Ord>(value: Option<&super::Sensory>) -> Result<Value<A>, DomainRefusal> {
    let value = value.ok_or(DomainRefusal::Missing)?;
    Ok(Value::Pair(SharedValue::new(Value::Bytes(Arc::clone(value.schema()))),
        SharedValue::new(Value::Bytes(Arc::clone(value.body())))))
}

pub(super) type Definition<A: Copy + Ord> = observer::Definition<Value<A>, Op, Source, Meaning>;
pub(super) type Instance<A: Copy + Ord> = observer::Instance<Value<A>, Op, Source, Meaning>;
pub(super) type Cut<A: Copy + Ord> = observer::Cut<Value<A>, Op, Source, Meaning>;
pub(super) type Prepared<A: Copy + Ord> = observer::Prepared<Value<A>, Op, Source, Meaning>;
pub(super) type NativeHistory<A: Ord> = acquisition::History<history::InputOrigin, Source, Value<A>>;
pub(super) type Context<A> = (u128, u64, A);
pub(super) type Validated<A: Copy + Ord> = acquisition::Validated<Value<A>, Op, Source, Meaning, history::InputOrigin, Context<A>, Value<A>>;
pub(super) type Installed<A: Copy + Ord> = installation::Installed<Value<A>, Op, Source, Meaning, history::InputOrigin, Context<A>, Value<A>>;
pub(super) type TraceGrammar<A: Copy + Ord> = construction::TraceGrammar<Value<A>, Op, Source, Meaning>;
pub(super) type Proposal<A: Copy + Ord> = construction::Proposal<Value<A>, Op, Source, Meaning, history::InputOrigin, Context<A>>;
pub(super) type InputRow<A: Ord> = acquisition::InputRow<Source, Value<A>>;

pub(super) fn source<A: Copy + Ord>(epoch: u128, raw_space: u128, owner: Option<history::Lineage>, max_trace: usize,
    grammar: crate::construction::family::Grammar<Op, Value<A>>)
    -> Result<Arc<TraceGrammar<A>>, construction::BuildRefusal> {
    source_in(Source { sensory: false, epoch, raw_space, owner, shape: Shape::Event }, max_trace, grammar)
}

pub(super) fn source_in<A: Copy + Ord>(interface: Source, max_trace: usize,
    grammar: crate::construction::family::Grammar<Op, Value<A>>)
    -> Result<Arc<TraceGrammar<A>>, construction::BuildRefusal> {
    let append = Program { steps: vec![Step { operation: Operation::Primitive(Op::Append),
        arguments: vec![Operand::Input(0), Operand::Input(1)] }], output: Some(0), library: Vec::new() };
    // Reuse is structural and lexically scoped in the same native machine.
    let update = Program { steps: vec![Step { operation: Operation::Call(0),
        arguments: vec![Operand::Input(0), Operand::Input(1)] }], output: Some(0), library: vec![append] };
    TraceGrammar::new(Value::Trace(Trace::empty()), update,
        InputBinding::new(interface.clone(), 1,
            vec![InputSource::State, InputSource::External(0)]).expect("declared event row"),
        Source { shape: Shape::Query, ..interface }, 1, Arc::new(Meaning { max_trace }), grammar)
}

#[derive(Debug)]
pub(super) enum SourceRefusal { History(history::Refusal), ForeignSource, Capacity }

/// Exact full prefix from its native origin, including complete typed actions.
/// Uses the same remaining work owner which will subsequently meter VM replay.
pub(super) fn history_rows<A: Copy + Ord>(prefix: &history::HistoryPrefix<A>,
    origin: history::InputOrigin, source: &Source, work: &mut ObserverWork)
    -> Result<Arc<NativeHistory<A>>, SourceRefusal> {
    let lineage = origin.lineage();
    if source.owner.is_some_and(|owner| owner != lineage) || prefix.lineage() != lineage || origin.epoch() != source.epoch || origin.ordinal() > prefix.len() { return Err(SourceRefusal::ForeignSource); }
    let len = usize::try_from(prefix.len() - origin.ordinal()).map_err(|_| SourceRefusal::Capacity)?;
    let mut rows = Vec::new(); rows.try_reserve(len).map_err(|_| SourceRefusal::Capacity)?;
    let mut cursor = prefix.cursor(origin.ordinal()).map_err(SourceRefusal::History)?;
    while let Some(event) = cursor.next(&mut work.remaining).map_err(SourceRefusal::History)? {
        if event.id().lineage != lineage || event.raw_space() != source.raw_space { return Err(SourceRefusal::ForeignSource); }
        let input = event.input(source.epoch).map_err(SourceRefusal::History)?;
        let row = Event { sensory: event.sensory().cloned(), epoch: source.epoch, raw_space: source.raw_space, owner: source.owner, raw: event.event().raw_state,
            input, action: event.event().action, episode: event.time().episode, life_age: event.time().life_age, pose: event.pose() };
        rows.push(acquisition::HistoryEvent::Observed(event_row(row)));
    }
    Ok(acquisition::History::from_origin(origin, rows))
}

pub(super) fn event_row<A: Ord>(event: Event<A>) -> InputRow<A> {
    InputRow::new(Source { sensory: event.sensory.is_some(), epoch: event.epoch, raw_space: event.raw_space, owner: event.owner, shape: Shape::Event }, vec![Value::Event(event)])
}
pub(super) fn query_row<A: Ord>(query: Query<A>) -> InputRow<A> {
    InputRow::new(Source { sensory: query.sensory.is_some(), epoch: query.epoch, raw_space: query.raw_space, owner: query.owner, shape: Shape::Query }, vec![Value::Query(query)])
}

/// Bind the actual pre-action query of one retained native cut. The observed
/// outcome is supplied separately to the typed builder, never to its own input.
pub(super) fn measured_query<A: Copy + Ord>(cut: &history::Cut<A>, source: &Source)
    -> Result<InputRow<A>, SourceRefusal> {
    measured_query_for(cut, source, None)
}

pub(super) fn measured_action_query<A: Copy + Ord>(cut: &history::Cut<A>, source: &Source)
    -> Result<InputRow<A>, SourceRefusal> {
    measured_query_for(cut, source, Some(cut.event().action))
}

fn measured_query_for<A: Copy + Ord>(cut: &history::Cut<A>, source: &Source, action: Option<A>)
    -> Result<InputRow<A>, SourceRefusal> {
    if cut.raw_space() != source.raw_space || source.owner.is_some_and(|owner| owner != cut.id().lineage) { return Err(SourceRefusal::ForeignSource); }
    let input = cut.input(source.epoch).map_err(SourceRefusal::History)?;
    Ok(query_row(Query { sensory: cut.sensory().cloned(), epoch: source.epoch, raw_space: source.raw_space, owner: source.owner, raw: cut.event().raw_state,
        input, episode: cut.time().episode, life_age: cut.time().life_age, pose: cut.pose(), action }))
}

/// Both acquisition paths publish the same native Definition/Installed runtime.
pub(super) enum Producer<A: Copy + Ord> {
    Constructed(Arc<Proposal<A>>),
    Joint(Arc<acquisition::joint::Candidate<Value<A>, Op, Source, Meaning>>),
}
impl<A: Copy + Ord> Clone for Producer<A> {
    fn clone(&self) -> Self { match self { Self::Constructed(p) => Self::Constructed(Arc::clone(p)), Self::Joint(p) => Self::Joint(Arc::clone(p)) } }
}
impl<A: Copy + Ord> Producer<A> {
    pub(super) fn definition(&self) -> &Arc<Definition<A>> { match self { Self::Constructed(p) => p.definition(), Self::Joint(p) => p.definition() } }
}
impl<A: Copy + Ord> From<Arc<Proposal<A>>> for Producer<A> { fn from(value: Arc<Proposal<A>>) -> Self { Self::Constructed(value) } }

pub(super) type JointSeries<A: Copy + Ord> = acquisition::joint::Series<Value<A>, Op, Source, Meaning>;
pub(super) type JointCandidate<A: Copy + Ord> = acquisition::joint::Candidate<Value<A>, Op, Source, Meaning>;
pub(super) type JointFreezing<A: Copy + Ord> = acquisition::joint::Freezing<Value<A>, Op, Source, Meaning>;
/// Freeze structural programs without a machine-sized cardinality/index. Exact
/// Uniform cardinality is computed by the retained native continuation before
/// any observation enters its trial. This finite scope can grow without a
/// numeric 2^53/usize family ceiling; practical service/retention is still paid.
pub(super) fn joint_source<A: Copy + Ord>(source: Source, max_trace: usize, steps: usize) -> Result<JointFreezing<A>, String> {
    use crate::construction::family::{Grammar, OperationSpec, syntax::structural::Language};
    let grammar = |inputs, operations: &[Op]| Grammar { inputs,
        operations: operations.iter().map(|&id| OperationSpec { id, arity: id.arity() }).collect(), literals: Vec::new(), max_steps: steps };
    let initial = Language::finite(grammar(0, &[Op::Unit, Op::Zero, Op::EmptyTrace, Op::Pair]), Vec::new())
        .map_err(|e| format!("initial syntax: {e:?}"))?;
    let mut operations = vec![Op::Identity, Op::EventInput, Op::EventRaw, Op::EventAction, Op::EventAge, Op::EventPose,
        Op::QueryInput, Op::QueryRaw, Op::QueryAge, Op::QueryAction, Op::QueryPose,
        Op::Pair, Op::First, Op::Second, Op::Equal, Op::Select, Op::Add, Op::Rem,
        Op::Append, Op::At, Op::Last, Op::Length, Op::Zero, Op::Unit, Op::EmptyTrace];
    if source.sensory { operations.extend([Op::EventSensory, Op::QuerySensory]); }
    let update = Language::finite(grammar(2, &operations), Vec::new()).map_err(|e| format!("update syntax: {e:?}"))?;
    let read = Language::finite(grammar(2, &operations), Vec::new()).map_err(|e| format!("read syntax: {e:?}"))?;
    let query = Source { shape: Shape::Query, ..source.clone() };
    JointFreezing::new([initial, update, read],
        InputBinding::new(source, 1, vec![InputSource::State, InputSource::External(0)]).map_err(|e| format!("update binding: {e:?}"))?,
        InputBinding::new(query, 1, vec![InputSource::State, InputSource::External(0)]).map_err(|e| format!("read binding: {e:?}"))?,
        Arc::new(Meaning { max_trace }), acquisition::joint::Retention { address_cells: max_trace, pending: max_trace })
        .map_err(|e| format!("joint grammar: {e:?}"))
}

#[cfg(all(test, feature = "serde"))]
pub(super) mod lifecycle_export;

#[cfg(test)]
mod value_dag_courts;
