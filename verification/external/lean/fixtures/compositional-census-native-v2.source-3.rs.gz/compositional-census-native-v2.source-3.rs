//! Frozen indexed syntax from the existing construction grammar.
//!
//! This owner contains no examples and claims no learned semantics. It names
//! every eager straight-line Program with 1..=max_steps instructions, valid
//! input/register/literal references and an explicitly selected root output.
//! Indexing is mixed-radix; the entire exponential family is never allocated.
//! Actual interpretation always belongs to program::execute_metered.
pub mod structural;

use super::Grammar;
use crate::program::{Operand, Operation, Program, Step, WorkMeter};
use std::sync::Arc;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SyntaxRefusal { EmptyOperations, DuplicateOperation, DuplicateLiteral, CountCapacity, Index, Allocation, ControlShape, InfiniteChild }
#[derive(Debug)]
pub enum IndexRefusal<E> { Syntax(SyntaxRefusal), Work(E) }

// The indexed and structural routes share the same declaration checks.
fn validate<V: Ord, P: Ord>(grammar: &Grammar<P, V>, calls: &[(usize, Program<V, P>)]) -> Result<(), SyntaxRefusal> {
    let mut names = std::collections::BTreeSet::new();
    if grammar.operations.iter().any(|op| !names.insert(&op.id)) { return Err(SyntaxRefusal::DuplicateOperation); }
    // Operand::Literal stores a value, not a source-pool index. Repeated
    // equal values would otherwise give different indices identical code.
    let mut literals = std::collections::BTreeSet::new();
    if grammar.literals.iter().any(|value| !literals.insert(value)) { return Err(SyntaxRefusal::DuplicateLiteral); }
    if grammar.operations.is_empty() && calls.is_empty() { return Err(SyntaxRefusal::EmptyOperations); }
    Ok(())
}

/// A stratum names its original complete family before any evidence arrives.
/// Counts include root-output selection and unused eager instructions; no
/// empirical or singleton pruning can silently make a selected name cheaper.
pub struct Syntax<V, P> {
    grammar: Grammar<P, V>, calls: Vec<(usize, Program<V, P>)>, levels: Vec<Level>, count: usize,
}
struct Level { radices: Vec<usize>, bodies: usize, programs: usize }
impl<V, P> Syntax<V, P> {
    pub fn count(&self) -> usize { self.count }
    pub fn grammar(&self) -> &Grammar<P, V> { &self.grammar }
}
impl<V: Clone + Ord, P: Clone + Ord> Syntax<V, P> {
    pub fn freeze(grammar: Grammar<P, V>) -> Result<Arc<Self>, SyntaxRefusal> {
        Self::with_library(grammar, Vec::new())
    }
    /// A callee is captured code with a declared input arity, interpreted in
    /// its own lexical library by the existing VM. No opaque function adapter.
    pub fn with_library(grammar: Grammar<P, V>, calls: Vec<(usize, Program<V, P>)>) -> Result<Arc<Self>, SyntaxRefusal> {
        validate(&grammar, &calls)?;
        let mut levels = Vec::new(); let mut radices = Vec::new();
        levels.try_reserve(grammar.max_steps).map_err(|_| SyntaxRefusal::Allocation)?;
        radices.try_reserve(grammar.max_steps).map_err(|_| SyntaxRefusal::Allocation)?;
        let mut bodies = 1usize; let mut count = 0usize;
        for depth in 0..grammar.max_steps {
            let pool = grammar.inputs.checked_add(depth).and_then(|n| n.checked_add(grammar.literals.len()))
                .ok_or(SyntaxRefusal::CountCapacity)?;
            let mut instructions = 0usize;
            for arity in grammar.operations.iter().map(|op| op.arity).chain(calls.iter().map(|(arity, _)| *arity)) {
                let mut tuples = 1usize;
                for _ in 0..arity { tuples = tuples.checked_mul(pool).ok_or(SyntaxRefusal::CountCapacity)?; }
                instructions = instructions.checked_add(tuples).ok_or(SyntaxRefusal::CountCapacity)?;
            }
            bodies = bodies.checked_mul(instructions).ok_or(SyntaxRefusal::CountCapacity)?;
            radices.push(instructions);
            let programs = bodies.checked_mul(depth + 1).ok_or(SyntaxRefusal::CountCapacity)?;
            count = count.checked_add(programs).ok_or(SyntaxRefusal::CountCapacity)?;
            levels.push(Level { radices: radices.clone(), bodies, programs });
        }
        Ok(Arc::new(Self { grammar, calls, levels, count }))
    }

}

impl<V: Clone, P: Clone + Ord> Syntax<V, P> {
    /// Materialize exactly one original name. Every grammar/pool visit and
    /// resulting operand is charged; generic clone/allocator cost is separate.
    pub fn program<M: WorkMeter + ?Sized>(&self, mut index: usize, meter: &mut M)
        -> Result<Program<V, P>, IndexRefusal<M::Error>> {
        let failure = IndexRefusal::Syntax;
        if index >= self.count { return Err(failure(SyntaxRefusal::Index)); }
        let mut selected = None;
        for (depth, level) in self.levels.iter().enumerate() {
            meter.charge(1).map_err(IndexRefusal::Work)?;
            if index < level.programs { selected = Some((depth + 1, level)); break; }
            index -= level.programs;
        }
        let (length, level) = selected.ok_or_else(|| failure(SyntaxRefusal::Index))?;
        let output = index / level.bodies;
        let mut body = index % level.bodies;
        let mut digits = Vec::new();
        digits.try_reserve(length).map_err(|_| failure(SyntaxRefusal::Allocation))?;
        // Earliest instructions are the low digits: a suffix does not change a
        // prior register's lexical scope. This is a bijection, not a heuristic.
        for &radix in &level.radices {
            meter.charge(1).map_err(IndexRefusal::Work)?;
            if radix == 0 { return Err(failure(SyntaxRefusal::Index)); }
            digits.push(body % radix); body /= radix;
        }
        let mut steps = Vec::new();
        steps.try_reserve(length).map_err(|_| failure(SyntaxRefusal::Allocation))?;
        for (depth, mut digit) in digits.into_iter().enumerate() {
            let pool = self.grammar.inputs + depth + self.grammar.literals.len();
            let mut selected = None;
            let operations = self.grammar.operations.iter().map(|op| (Operation::Primitive(op.id.clone()), op.arity))
                .chain(self.calls.iter().enumerate().map(|(i, (arity, _))| (Operation::Call(i), *arity)));
            for (operation, arity) in operations {
                meter.charge(arity.checked_add(1).ok_or_else(|| failure(SyntaxRefusal::CountCapacity))?)
                    .map_err(IndexRefusal::Work)?;
                let mut tuples = 1usize;
                for _ in 0..arity { tuples = tuples.checked_mul(pool).ok_or_else(|| failure(SyntaxRefusal::CountCapacity))?; }
                if digit < tuples { selected = Some((operation, arity)); break; }
                digit -= tuples;
            }
            let (operation, arity) = selected.ok_or_else(|| failure(SyntaxRefusal::Index))?;
            let mut arguments = Vec::new();
            arguments.try_reserve(arity).map_err(|_| failure(SyntaxRefusal::Allocation))?;
            for _ in 0..arity {
                meter.charge(1).map_err(IndexRefusal::Work)?;
                let at = digit % pool; digit /= pool;
                arguments.push(if at < self.grammar.inputs { Operand::Input(at) }
                    else if at < self.grammar.inputs + depth { Operand::Register(at - self.grammar.inputs) }
                    else { Operand::Literal(self.grammar.literals[at - self.grammar.inputs - depth].clone()) });
            }
            steps.push(Step { operation, arguments });
        }
        meter.charge(self.calls.len()).map_err(IndexRefusal::Work)?;
        Ok(Program { steps, output: Some(output), library: self.calls.iter().map(|(_, body)| body.clone()).collect() })
    }
}

#[cfg(test)]
mod courts {
    use super::*;
    #[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)] enum Op { Zero, Id, Pair }
    struct Work(usize);
    impl WorkMeter for Work { type Error = (); fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.0 = self.0.checked_sub(n).ok_or(())?; Ok(())
    } }
    #[test]
    fn indexed_names_equal_independent_small_syntax_enumeration() {
        let grammar = Grammar { inputs: 1, operations: vec![super::super::OperationSpec { id: Op::Zero, arity: 0 },
            super::super::OperationSpec { id: Op::Id, arity: 1 }, super::super::OperationSpec { id: Op::Pair, arity: 2 }],
            literals: vec![17u8], max_steps: 2 };
        let owner = Syntax::freeze(grammar).unwrap();
        // First position: 1+2+4=7 choices. Second: 1+3+9=13,
        // with two explicit root outputs for every two-instruction body.
        assert_eq!(owner.count(), 7 + 7 * 13 * 2);
        let mut names = std::collections::BTreeSet::new();
        for index in 0..owner.count() {
            let program = owner.program(index, &mut Work(1000)).unwrap();
            assert!(names.insert(format!("{program:?}")), "distinct syntax names must not coalesce on observations");
            for (at, step) in program.steps.iter().enumerate() {
                for arg in &step.arguments { if let Operand::Register(register) = arg { assert!(*register < at); } }
            }
        }
        assert_eq!(names.len(), owner.count());
        assert!(matches!(owner.program(0, &mut Work(0)), Err(IndexRefusal::Work(()))));
        assert!(matches!(owner.program(owner.count(), &mut Work(1000)), Err(IndexRefusal::Syntax(SyntaxRefusal::Index))));
    }
    #[test]
    fn indexed_family_matches_independently_generated_program_trees() {
        // Direct tree generation uses no family counts, mixed radices, or
        // indexed decoder. Exact Program equality also checks literal and
        // library ownership, every operand, and every root output.
        fn reference(inputs: usize, literals: &[u8], depth: usize,
            calls: &[(usize, Program<u8, Op>)]) -> Vec<Program<u8, Op>> {
            let mut bodies: Vec<Vec<Step<u8, Op>>> = vec![Vec::new()];
            let mut result = Vec::new();
            for at in 0..depth {
                let pool: Vec<_> = (0..inputs).map(Operand::Input)
                    .chain((0..at).map(Operand::Register))
                    .chain(literals.iter().copied().map(Operand::Literal)).collect();
                let mut choices = vec![Step { operation: Operation::Primitive(Op::Zero), arguments: vec![] }];
                for value in &pool {
                    choices.push(Step { operation: Operation::Primitive(Op::Id), arguments: vec![value.clone()] });
                    for other in &pool {
                        choices.push(Step { operation: Operation::Primitive(Op::Pair), arguments: vec![value.clone(), other.clone()] });
                    }
                    for (index, (arity, _)) in calls.iter().enumerate() {
                        assert_eq!(*arity, 1, "independent reference fixture uses unary callees");
                        choices.push(Step { operation: Operation::Call(index), arguments: vec![value.clone()] });
                    }
                }
                let mut extended = Vec::new();
                for body in &bodies { for step in &choices {
                    let mut next = body.clone(); next.push(step.clone());
                    for output in 0..next.len() {
                        result.push(Program { steps: next.clone(), output: Some(output),
                            library: calls.iter().map(|(_, code)| code.clone()).collect() });
                    }
                    extended.push(next);
                } }
                bodies = extended;
            }
            result
        }
        let callee = Program { steps: vec![Step { operation: Operation::Primitive(Op::Id),
            arguments: vec![Operand::Input(0)] }], output: Some(0), library: vec![] };
        for inputs in 0..=2 { for literals in [vec![], vec![17]] { for depth in 0..=2 {
            for calls in [vec![], vec![(1, callee.clone())]] {
                let grammar = Grammar { inputs, operations: vec![
                    super::super::OperationSpec { id: Op::Zero, arity: 0 },
                    super::super::OperationSpec { id: Op::Id, arity: 1 },
                    super::super::OperationSpec { id: Op::Pair, arity: 2 }],
                    literals: literals.clone(), max_steps: depth };
                let mut expected = reference(inputs, &literals, depth, &calls);
                let indexed = Syntax::with_library(grammar, calls).unwrap();
                assert_eq!(indexed.count(), expected.len());
                for index in 0..indexed.count() {
                    let actual = indexed.program(index, &mut Work(10_000)).unwrap();
                    let position = expected.iter().position(|program| *program == actual)
                        .expect("every indexed program is one as-yet-unvisited independently generated tree");
                    expected.swap_remove(position);
                }
                assert!(expected.is_empty(), "every independent syntax tree must have an index");
            }
        } } }
    }

    #[test]
    fn duplicate_literal_values_are_refused_before_naming_the_family() {
        let grammar = Grammar { inputs: 0,
            operations: vec![super::super::OperationSpec { id: Op::Id, arity: 1 }],
            literals: vec![17u8, 17u8], max_steps: 1 };
        assert!(matches!(Syntax::freeze(grammar), Err(SyntaxRefusal::DuplicateLiteral)));
        let grammar = Grammar { inputs: 0,
            operations: vec![super::super::OperationSpec { id: Op::Id, arity: 1 }],
            literals: vec![17u8, 18u8], max_steps: 1 };
        let names = Syntax::freeze(grammar).unwrap();
        assert_eq!(names.count(), 2);
        assert_ne!(format!("{:?}", names.program(0, &mut Work(100)).unwrap()),
            format!("{:?}", names.program(1, &mut Work(100)).unwrap()));
    }

}
