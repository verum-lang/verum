//! Outcome-blind connected-expression priority, not a restricted source family.
//! The ordinary source remains complete. A model returns possible result sorts;
//! it proves neither totality nor empirical usefulness. Unknown means the whole
//! vocabulary. Flat library calls use Unknown summaries; their code is neither
//! executed nor certified here. Control syntax remains in ordinary service.
use super::*;
mod rank;
pub use rank::Ranking;
pub(crate) use rank::RankBasis;
pub(crate) use rank::FlatRankBound;
mod flatten;
pub use flatten::Flatten;

/// Finite abstract vocabulary owned by the actual primitive interpretation.
/// For every defined concrete application represented by `arguments`, its tag
/// must occur in the returned mask. Zero asserts impossibility only to this
/// PRIORITY producer; it never excludes a name from the original source.
/// Protocol requirement: universe, literals, argument domains and application
/// summaries stay stable for this frozen declaration; they must not depend on
/// mutable observations. Shared incidence and retained summaries rely on this
/// contract. The complete source remains the independent coverage authority.
pub trait Abstract<V, P>: Send + Sync {
    fn universe(&self) -> u64;
    fn literal(&self, value: &V) -> u64;
    fn argument_domain(&self, _operation: &P, _argument: usize) -> u64 {
        self.universe()
    }
    fn apply(&self, operation: &P, arguments: &[u64]) -> u64;
}
/// One input row per abstract state tag, in ascending-bit order. All three
/// phases use the same tag axis. Lexical dependencies are represented input
/// positions, not a claim of causal sensitivity or a concrete predicted value.
pub struct Configuration<V, P> {
    pub model: Arc<dyn Abstract<V, P>>,
    pub inputs: [Arc<[Vec<u64>]>; 3],
}
#[derive(Clone)]
pub struct Summary {
    pub outputs: Arc<[u64]>,
    pub dependencies: u64,
}
enum Body {
    Leaf(usize),
    Node {
        alternative: usize,
        children: Vec<Arc<Expression>>,
    },
}
pub struct Expression {
    owner: Arc<()>,
    body: Body,
    pub summary: Summary,
    pub size: usize,
}
pub enum Progress {
    Advanced,
    Expression(Arc<Expression>),
    Complete,
}

/// Fixed-cardinality projection of the actual streaming constructor.
#[cfg(test)]
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct ExpressionCensus {
    pub(crate) phase: &'static str,
    pub(crate) max_emitted_size: usize,
    pub(crate) catalogue_entries: usize,
    pub(crate) indexed_entries: usize,
    pub(crate) pending_index: Option<usize>,
    pub(crate) pending_emission: bool,
    pub(crate) append_ready: bool,
    pub(crate) next_ordinary_lane: usize,
    pub(crate) constructor_cursor: usize,
    pub(crate) wake_cursor: usize,
    pub(crate) pending_owner: Option<usize>,
    pub(crate) posting_entries: usize,
    pub(crate) constructors: usize,
    pub(crate) active_constructors: usize,
    pub(crate) active_tuples: usize,
    pub(crate) newest: Option<usize>,
    pub(crate) anchor: usize,
    pub(crate) alternative: usize,
    pub(crate) leaf: usize,
    pub(crate) argument: usize,
    pub(crate) case: usize,
    pub(crate) carry: usize,
    pub(crate) retained_cells: usize,
    pub(crate) pending_cells: usize,
    pub(crate) poisoned: bool,
}
mod streaming;
pub use streaming::{Expressions, ExpressionStorage};
#[cfg(test)]
pub(crate) use streaming::probe::{ComponentLocation, PendingLocation, ProbeRefusal, same_address};
#[cfg(test)]
mod streaming_courts;
#[cfg(test)]
mod streaming_join_courts;
impl<V, P> Language<V, P> {
    // The original primitive/captured-call prefix keeps its V1/V2 alternative
    // indexes. Controls stay in the complete source, not in this typed subset.
    fn expression_alternatives(&self) -> Result<usize, StructuralRefusal> {
        self.operations.len().checked_add(self.calls.len())
            .ok_or(StructuralRefusal::Capacity)
    }
    pub(crate) fn expressions(
        self: &Arc<Self>,
        model: Arc<dyn Abstract<V, P>>,
        inputs: Arc<[Vec<u64>]>,
    ) -> Option<Expressions<V, P>> {
        let cases = model.universe().count_ones() as usize;
        if self.inputs > 64
            || cases == 0
            || inputs.len() != cases
            || inputs.iter().any(|r| r.len() != self.inputs)
        {
            return None;
        }
        Some(Expressions::new(Arc::clone(self), model, inputs))
    }
}
#[cfg(test)]
mod courts {
    use super::*;
    #[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
    enum Op {
        Unit,
        Zero,
        Succ,
        Empty,
        Cons,
        Identity,
        EventOnly,
    }
    struct Model;
    impl Abstract<u8, Op> for Model {
        fn universe(&self) -> u64 {
            15
        }
        fn literal(&self, v: &u8) -> u64 {
            if *v == 0 { 1 } else { 2 }
        }
        fn argument_domain(&self, o: &Op, a: usize) -> u64 {
            match o {
                Op::Succ => 2,
                Op::Cons => {
                    if a == 0 {
                        2
                    } else {
                        4
                    }
                }
                Op::EventOnly => 8,
                _ => 15,
            }
        }
        fn apply(&self, o: &Op, a: &[u64]) -> u64 {
            match o {
                Op::Unit => 1,
                Op::Zero => 2,
                Op::Empty => 4,
                Op::Succ if a[0] & 2 != 0 => 2,
                Op::Cons if a[0] & 2 != 0 && a[1] & 4 != 0 => 4,
                Op::Identity => a[0],
                Op::EventOnly if a.iter().all(|v| v & 8 != 0) => 8,
                _ => 0,
            }
        }
    }
    struct Work {
        left: usize,
        spent: usize,
    }
    impl WorkMeter for Work {
        type Error = ();
        fn charge(&mut self, n: usize) -> Result<(), ()> {
            self.left = self.left.checked_sub(n).ok_or(())?;
            self.spent += n;
            Ok(())
        }
    }
    fn language() -> Arc<Language<u8, Op>> {
        Language::finite(
            Grammar {
                inputs: 0,
                operations: vec![
                    OperationSpec {
                        id: Op::Zero,
                        arity: 0,
                    },
                    OperationSpec {
                        id: Op::Succ,
                        arity: 1,
                    },
                    OperationSpec {
                        id: Op::Empty,
                        arity: 0,
                    },
                    OperationSpec {
                        id: Op::Cons,
                        arity: 2,
                    },
                ],
                literals: vec![],
                max_steps: 3,
            },
            vec![],
        )
        .unwrap()
    }
    fn run(grant: usize) -> (Vec<(BigUint, Vec<u8>, u64)>, usize) {
        let language = language();
        let mut producer = language
            .expressions(Arc::new(Model), vec![vec![]; 4].into())
            .unwrap();
        let mut result = Vec::new();
        let mut spent = 0;
        for _ in 0..100_000 {
            let mut work = Work {
                left: grant,
                spent: 0,
            };
            let next = producer.advance(&mut work, 100_000).unwrap();
            spent += work.spent;
            match next {
                Progress::Advanced => {}
                Progress::Complete => return (result, spent),
                Progress::Expression(e) => {
                    let mut flatten = language.flatten(Arc::clone(&e)).unwrap();
                    while flatten.address().is_none() {
                        let mut w = Work {
                            left: grant,
                            spent: 0,
                        };
                        flatten.advance(&mut w, 100_000).unwrap();
                        spent += w.spent;
                    }
                    let address = flatten.address().unwrap().clone();
                    let mut rank = language.rank(address.clone()).unwrap().unwrap();
                    while rank.value().is_none() {
                        let mut w = Work {
                            left: grant,
                            spent: 0,
                        };
                        rank.advance(&mut w).unwrap();
                        spent += w.spent;
                    }
                    let mut encoder = language.encode(address).unwrap();
                    loop {
                        let mut w = Work {
                            left: grant,
                            spent: 0,
                        };
                        let done = encoder.advance(&mut w).unwrap();
                        spent += w.spent;
                        if done {
                            break;
                        }
                    }
                    let encoded = encoder.finish().unwrap_or_else(|_| panic!("paid word"));
                    result.push((
                        rank.value().unwrap().clone(),
                        encoded.bits().to_vec(),
                        e.summary.outputs[0],
                    ));
                }
            }
        }
        panic!("finite connected grammar");
    }
    #[test]
    fn constructors_are_generic_closed_nat_and_bytes_derivations_with_paid_partition_invariance() {
        let a = run(1);
        assert_eq!(a, run(7));
        assert!(a.0.iter().any(|(_, _, s)| *s == 2));
        assert!(a.0.iter().any(|(_, _, s)| *s == 4));
        assert_eq!(
            a.0.iter()
                .map(|e| &e.0)
                .collect::<std::collections::BTreeSet<_>>()
                .len(),
            a.0.len()
        );
    }
    #[test]
    fn flat_calls_have_unknown_sorts_and_exact_original_ranks_without_inspecting_callee_code() {
        // Deliberately malformed callee: an abstract producer must not run it,
        // infer totality, or guess a result from an earlier acquired admission.
        let language = Language::finite(Grammar {
            inputs: 1,
            operations: vec![OperationSpec { id: Op::Identity, arity: 1 }],
            literals: vec![], max_steps: 2,
        }, vec![(1, Program { steps: vec![Step {
            operation: Operation::Call(99), arguments: vec![Operand::Input(0)],
        }], output: Some(0), library: vec![] })]).unwrap();
        let encode = |address: Address| {
            let mut cursor = language.encode(address).unwrap();
            while !cursor.advance(&mut Work { left: 1, spent: 0 }).unwrap() {}
            cursor.finish().unwrap_or_else(|_| panic!("original word")).bits().to_vec()
        };
        let mut originals = std::collections::BTreeMap::new();
        let mut original = language.enumerate();
        loop {
            match original.advance(&mut Work { left: 1, spent: 0 }).unwrap() {
                super::super::Progress::Advanced => {},
                super::super::Progress::Complete => break,
                super::super::Progress::Address(address) => {
                    let rank = BigUint::from(originals.len());
                    assert!(originals.insert(encode(address), rank).is_none());
                },
            }
        }
        let inputs: Arc<[Vec<u64>]> = vec![vec![1], vec![2], vec![4], vec![8]].into();
        let mut producer = language.expressions(Arc::new(Model), inputs).unwrap();
        let mut call_seen = false;
        let mut nested_call_seen = false;
        loop {
            match producer.advance(&mut Work { left: 1, spent: 0 }, 100_000).unwrap() {
                Progress::Advanced => {},
                Progress::Complete => break,
                Progress::Expression(expression) => {
                    let mut flattened = language.flatten(Arc::clone(&expression)).unwrap();
                    while flattened.address().is_none() {
                        flattened.advance(&mut Work { left: 1, spent: 0 }, 100_000).unwrap();
                    }
                    let address = flattened.address().unwrap().clone();
                    let has_call = (0..address.len()).any(|i| address.instruction(i).unwrap().0 == 1);
                    if has_call {
                        assert_eq!(expression.summary.outputs.as_ref(), &[15, 15, 15, 15]);
                        assert_eq!(expression.summary.dependencies, 1);
                        call_seen = true;
                        nested_call_seen |= address.len() == 2;
                    }
                    let mut rank = language.rank(address.clone()).unwrap().unwrap();
                    while rank.value().is_none() { rank.advance(&mut Work { left: 1, spent: 0 }).unwrap(); }
                    assert_eq!(rank.value(), originals.get(&encode(address)));
                },
            }
        }
        assert!(call_seen && nested_call_seen, "calls and primitive/call compositions really enter the guide");
    }
    #[test]
    fn empty_retention_and_foreign_language_keep_a_real_pending_derivation() {
        let language = language();
        let mut producer = language
            .expressions(Arc::new(Model), vec![vec![]; 4].into())
            .unwrap();
        let before = producer.retained_cells();
        assert!(matches!(
            producer.advance(&mut Work { left: 0, spent: 0 }, 0),
            Err(Failure::Work(()))
        ));
        assert_eq!(producer.retained_cells(), before);
        assert!(matches!(
            producer.advance(&mut Work { left: 1, spent: 0 }, 0),
            Err(Failure::Structural(StructuralRefusal::Capacity))
        ));
        let e = loop {
            if let Progress::Expression(e) = producer
                .advance(&mut Work { left: 1, spent: 0 }, 4096)
                .unwrap()
            {
                break e;
            }
        };
        assert!(matches!(
            super::courts::language().flatten(e),
            Err(StructuralRefusal::ForeignOwner)
        ));
    }
}
