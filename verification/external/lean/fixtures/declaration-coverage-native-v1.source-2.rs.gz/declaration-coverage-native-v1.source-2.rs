//! Retained production declaration followed by the shared exact family price.
//! No observations, outcome labels or preferred child programs enter this door.
use super::*;
use crate::construction::family::syntax::{SyntaxRefusal, structural::{self, DeclarationBounds, DeclarationCursor, DeclarationFailure}};
use crate::program::WorkMeter;
use acquisition::joint;

pub(in crate::organism) enum SourceFailure<E> {
    Work(E), Structural(structural::StructuralRefusal), Syntax(SyntaxRefusal), Build(joint::BuildRefusal),
}
struct Declaring<A: Copy + Ord> {
    parts: [DeclarationCursor<Value<A>, Op>; 3], source: Source, max_trace: usize, at: usize,
}
pub(in crate::organism) struct AutomaticFreezing<A: Copy + Ord> { declaring: Option<Declaring<A>>, frozen: Option<JointFreezing<A>>, retained_cells: usize }
pub(in crate::organism) fn automatic_joint_source<A: Copy + Ord>(source: Source, max_trace: usize, steps: usize, composition: Option<DeclarationBounds>)
    -> Result<AutomaticFreezing<A>, String> {
    let Some(bounds) = composition else { return Ok(AutomaticFreezing { declaring: None, frozen: Some(joint_source(source, max_trace, steps)?), retained_cells: 0 }); };
    let [a,b,c] = joint_grammars(&source, steps, false);
    let parts = [DeclarationCursor::new(a,bounds), DeclarationCursor::new(b,bounds), DeclarationCursor::new(c,bounds)];
    let [a,b,c] = parts;
    let result = AutomaticFreezing { declaring: Some(Declaring { parts: [a.map_err(|e| format!("initial declaration: {e:?}"))?,
        b.map_err(|e| format!("update declaration: {e:?}"))?, c.map_err(|e| format!("read declaration: {e:?}"))?],
        source, max_trace, at: 0 }), frozen: None, retained_cells: 0 };
    Ok(result)
}
impl<A: Copy + Ord> AutomaticFreezing<A> {
    pub(in crate::organism) fn advance<M: WorkMeter + ?Sized>(&mut self, meter: &mut M, capacity: usize) -> Result<bool, SourceFailure<M::Error>> {
        // Recheck the retained declaration across handoff and counting too.
        // A failed grant is a paid attempt, and cannot advance either owner.
        let required = match &self.declaring {
            Some(d) => d.parts.iter().try_fold(0usize, |sum,p| sum.checked_add(p.retained_cells())),
            None => Some(self.retained_cells),
        };
        let Some(required) = required.filter(|&n| n <= capacity) else {
            meter.charge(1).map_err(SourceFailure::Work)?;
            return Err(SourceFailure::Structural(structural::StructuralRefusal::Capacity));
        };
        if let Some(d) = &mut self.declaring {
            if d.at < d.parts.len() {
                let others = required - d.parts[d.at].retained_cells();
                let capacity = capacity - others;
                if d.parts[d.at].advance(meter, capacity).map_err(|e| match e {
                    DeclarationFailure::Work(e) => SourceFailure::Work(e),
                    DeclarationFailure::Structural(e) => SourceFailure::Structural(e),
                    DeclarationFailure::Syntax(e) => SourceFailure::Syntax(e),
                })? { d.at += 1; }
                return Ok(false);
            }
            meter.charge(1).map_err(SourceFailure::Work)?;
            let roots = d.parts.each_ref().map(|p| Arc::clone(p.language().expect("all declaration roots completed")));
            let (update,read) = joint_bindings(d.source.clone(), false).expect("fixed native input widths");
            let frozen = JointFreezing::new(roots, update, read, Arc::new(Meaning { max_trace: d.max_trace }),
                joint::Retention { address_cells: d.max_trace, pending: d.max_trace }).map_err(SourceFailure::Build)?;
            self.retained_cells = required; self.frozen = Some(frozen); self.declaring = None;
            return Ok(false);
        }
        self.frozen.as_mut().expect("declaration or exact freezing owner").advance(meter).map_err(|e| match e {
            structural::Failure::Work(e) => SourceFailure::Work(e), structural::Failure::Structural(e) => SourceFailure::Structural(e),
        })
    }
    pub(in crate::organism) fn finish(mut self) -> Result<JointSeries<A>, (Self, joint::BuildRefusal)> {
        let Some(frozen) = self.frozen.take() else { return Err((self,joint::BuildRefusal::Unfinished)); };
        match frozen.finish() {
            Ok(series) => Ok(series),
            Err((frozen, reason)) => { self.frozen = Some(frozen); Err((self,reason)) },
        }
    }
}

#[cfg(test)]
mod courts {
    use super::*;
    fn source() -> Source { Source { sensory:false,epoch:0,raw_space:0,owner:None,shape:Shape::Event } }
    #[test]
    fn lowered_retention_grant_cannot_bypass_declaration_handoff_or_counting() {
        let mut cursor = automatic_joint_source::<u8>(source(),4096,1,Some(DeclarationBounds {nesting:1,body_inputs:0})).unwrap();
        for _ in 0..10_000 {
            if cursor.declaring.as_ref().is_some_and(|d|d.at==3) { break; }
            assert!(!cursor.advance(&mut ObserverWork {remaining:1},4096).unwrap_or_else(|_|panic!("declaration")));
        }
        assert_eq!(cursor.declaring.as_ref().unwrap().at,3);
        let owners = cursor.declaring.as_ref().unwrap().parts.each_ref().map(|p|Arc::clone(p.language().unwrap()));
        for handed_off in [false,true] {
            let mut zero = ObserverWork {remaining:0};
            assert!(matches!(cursor.advance(&mut zero,0),Err(SourceFailure::Work(()))));
            let mut one = ObserverWork {remaining:1};
            assert!(matches!(cursor.advance(&mut one,0),Err(SourceFailure::Structural(structural::StructuralRefusal::Capacity))));
            assert_eq!(one.remaining,0);
            assert_eq!(cursor.frozen.is_some(),handed_off);
            if !handed_off {
                for (p,old) in cursor.declaring.as_ref().unwrap().parts.iter().zip(&owners) { assert!(Arc::ptr_eq(p.language().unwrap(),old)); }
                assert!(!cursor.advance(&mut ObserverWork {remaining:1},4096).unwrap_or_else(|_|panic!("handoff")));
                assert!(cursor.retained_cells>0);
            }
        }
        let mut complete=false;
        for _ in 0..100_000 { if cursor.advance(&mut ObserverWork {remaining:1},4096).unwrap_or_else(|_|panic!("count")) {complete=true;break;} }
        assert!(complete);
        let series=cursor.finish().unwrap_or_else(|_|panic!("finished source"));
        assert_eq!(series.exact_family_count(),Some(&num_bigint::BigUint::from(20_667u32)));
    }
    #[test]
    fn aggregate_capacity_refusal_is_paid_and_resumable_before_any_copy() {
        let mut cursor = automatic_joint_source::<u8>(source(),4096,1,Some(DeclarationBounds {nesting:1,body_inputs:0})).unwrap();
        let before=cursor.declaring.as_ref().unwrap().parts.each_ref().map(|p|p.retained_cells());
        assert!(matches!(cursor.advance(&mut ObserverWork {remaining:0},0),Err(SourceFailure::Work(()))));
        let mut work=ObserverWork {remaining:1};
        assert!(matches!(cursor.advance(&mut work,0),Err(SourceFailure::Structural(structural::StructuralRefusal::Capacity))));
        assert_eq!(work.remaining,0);
        assert_eq!(before,cursor.declaring.as_ref().unwrap().parts.each_ref().map(|p|p.retained_cells()));
        assert!(!cursor.advance(&mut ObserverWork {remaining:1},4096).unwrap_or_else(|_|panic!("resumed")));
    }
}
