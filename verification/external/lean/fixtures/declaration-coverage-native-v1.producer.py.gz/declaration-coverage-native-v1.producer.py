from pathlib import Path
import hashlib,json,os,re,shutil,signal,subprocess,sys,time,traceback
repo=Path('/Users/taaliman/projects/oldman/synarcai/omega')
sys.path.insert(0,str(repo/'scripts/measure'));sys.dont_write_bytecode=True
from validation_resources import ResourceContract, darwin_memory_snapshot
from build_engine_receipt import fingerprint
import native_test_inputs
out=repo/'.diagnostics/2026-10-29/endogenous-declarations-v54b'
out.mkdir(parents=True,exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('SYNARC_','OMVEK_','G1_','RUST_TEST_'))}
env.update(SLOT_PRIO='1',PYTHONDONTWRITEBYTECODE='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',SYNARC_TRANSFER_TRACE='1')
inputs=native_test_inputs.provision(repo/'.diagnostics/2026-10-25/kan-main-contracts/empirical-inputs-v2.json',out/'inputs')
env.update(native_test_inputs.verify(inputs))
paths=['rust/Cargo.toml','rust/Cargo.lock','rust/crates']
def snapshot():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--',*paths],cwd=repo,text=True).splitlines()
 return {n:fingerprint(repo/n) for n in sorted(set(names)) if (repo/n).is_file()}
source=snapshot()
record={'resource_contract':fingerprint(repo/'scripts/measure/validation_resources.py'),'status':'registered','scope':'Endogenous finite compositional declarations, fair independent bounds, exact full-family prices and retained production opening; no public accuracy claim','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source':source,'inputs':inputs,'script':fingerprint(__file__),'stages':[],'build_environment':{k:env[k] for k in ('CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','SYNARC_TRANSFER_TRACE')}}
subprocess.run(['git','diff','--binary','HEAD','--',*paths],cwd=repo,stdout=(out/'source.patch').open('wb'),check=True)
for n in source:
 if subprocess.run(['git','ls-files','--error-unmatch',n],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
  target=out/'untracked'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,target)
def save():
 temp=out/'receipt.tmp';temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(out/'receipt.json')
def resource(pids):
 raw=subprocess.check_output(['vm_stat'],text=True);page=int(re.search(r'page size of (\d+)',raw)[1]);v={m[1]:int(m[2]) for m in re.finditer(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)}
 rows=[tuple(map(int,row.split())) for row in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()]
 owned=set(pids)|{os.getpid()}
 while True:
  more={p for p,parent,rss in rows if parent in owned}
  if more<=owned:break
  owned|=more
 r=dict(at=time.time(),**darwin_memory_snapshot(raw),legacy_queue_estimate_gib=max(0,(v['Pages free']+v['Pages speculative']+v['Pages inactive']/4-v['Pages occupied by compressor']/2)*page/2**30),disk_free_gib=shutil.disk_usage(out).free/2**30,pressure_dispatch_level=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True)),owned_rss_bytes=sum(rss*1024 for p,parent,rss in rows if p in owned))
 with (out/'resources.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 return r
contract=ResourceContract(25_000_000_000);initial=resource([])
def execute(name,cmd,pool,timeout,cwd,extra=None):
 admission_deadline=time.time()+600
 while True:
  r=resource([]);why=contract.failure(r,initial['swapouts'],admission=True)
  if why is not None:
   if why!='admission_reserve':raise RuntimeError(why)
   if time.time()>admission_deadline:raise TimeoutError('admission '+name)
   record.update(status='waiting_admission',latest_resource=r);save();time.sleep(5);continue
  slot=subprocess.check_output(['zsh','/tmp/heavy_slot.sh','acquire','endogenous-declarations-v54b-'+name,pool],env=env,text=True).strip()
  try:
   assert name not in ('library-default','typecheck','typecheck-no-serde','build','build-arena','consumer-typecheck') or snapshot()==source,'dependency source changed before '+name
   native_test_inputs.verify(inputs)
   r=resource([]);why=contract.failure(r,initial['swapouts'],admission=True)
   if why is None:break
   if why!='admission_reserve':raise RuntimeError(why)
  except BaseException:
   subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True)
   raise
  subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True)
  record.update(status='waiting_admission',latest_resource=r);save()
  if time.time()>admission_deadline:raise TimeoutError('admission '+name)
  time.sleep(2)
 p=None;s={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'status':'running','started_at':time.time(),'timeout_seconds':timeout,'slot':slot};record['stages'].append(s);record['status']='running';save();print('RUN '+name,flush=True)
 try:
  with (out/(name+'.log')).open('xb') as log:
   p=subprocess.Popen(cmd,cwd=cwd,env=env|dict(extra or {}),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);s['pid']=p.pid;save()
   while p.poll() is None:
    r=resource([p.pid]);s['latest_resource']=r;s['peak_owned_rss_bytes']=max(s.get('peak_owned_rss_bytes',0),r['owned_rss_bytes']);save()
    failure=contract.failure(r,initial['swapouts'],admission=False)
    if failure:raise RuntimeError(failure)
    if time.time()-s['started_at']>timeout:raise TimeoutError(name)
    time.sleep(2)
  assert name not in ('library-default','typecheck','typecheck-no-serde','build','build-arena','consumer-typecheck') or snapshot()==source,'dependency source changed during '+name
  s.update(returncode=p.returncode,status='passed' if p.returncode==0 else 'failed')
  text=(out/(name+'.log')).read_text(errors='replace')
  native=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
  if native:s['counts']=dict(zip(('passed','failed','ignored','measured','filtered'),map(int,native.groups()[1:])))
  if name not in ('library-default','typecheck','typecheck-no-serde','build','build-arena','consumer-typecheck') and (not native or s['counts']['passed']+s['counts']['failed']==0 or s['counts']['ignored']):
   s['status']='invalid_test_coverage';s['error']='required tests absent or ignored';return 2
  return p.returncode
 finally:
  if p is not None and p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  s.update(status='interrupted',error='stage did not return') if s['status']=='running' else None
  s['seconds']=time.time()-s['started_at'];s['log']=fingerprint(out/(name+'.log')) if (out/(name+'.log')).exists() else None
  subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True);s['slot_released']=True;save();print(json.dumps({k:s.get(k) for k in ('name','status','returncode','seconds','counts')}),flush=True)
try:
 save()
 target=repo/'.diagnostics/2026-10-09/depth-contract/target'
 base=['--manifest-path',str(repo/'rust/Cargo.toml'),'--locked','--offline','--target-dir',str(target),'--jobs','1']
 rc=execute('build',['cargo','test',*base,'-p','synarc-kan','--lib','--features','serde','--no-run'],'build',3600,repo)
 if rc:raise RuntimeError('KAN build failed')
 matches=re.findall(r'Executable unittests src/lib.rs \(([^\n]*synarc_kan-[^\n]*)\)',(out/'build.log').read_text())
 assert len(matches)==1,matches
 src=Path(matches[0]);src=src if src.is_absolute() else repo/src
 binary=out/'kan-courts';shutil.copy2(src,binary);record['kan_binary']=fingerprint(binary);save()
 for name,selector in [
  ('structural','construction::family::syntax::'),
  ('pricing','program::code_mass::'),
  ('control-vm','program::control_courts::'),
  ('acquisition','program::observer::acquisition::'),
  ('automatic','organism::observer_acceptance::automatic::'),
  ('source-boundary','organism::observer_acquired::structural_source::'),
  ('causal-history','organism::causal_coordinates::'),
  ('receiver','organism::observer_acceptance::predictive_receiver::'),
  ('native-invocation','program::observer::invocation::')]:
  rc=execute(name,[str(binary),selector,'--test-threads=1','--nocapture'],'light',1800,repo,{
   'SYNARC_COMPOSITIONAL_EXPORT':str(out/'compositional-acquisition.jsonl'),
   'SYNARC_CAUSAL_LIFECYCLE_EXPORT':str(out/'causal-lifecycle.jsonl'),
   'SYNARC_PHYSICAL_CAUSAL_EXPORT':str(out/'physical-lifecycle.jsonl'),
   'SYNARC_CAUSAL_RECEIVER_EXPORT':str(out/'receiver-lifecycle.jsonl')})
  if rc:raise RuntimeError(name+' failed')
 rc=execute('typecheck-no-serde',['cargo','check',*base,'-p','synarc-kan','--all-targets'],'build',3600,repo)
 if rc:raise RuntimeError('default all-target check failed')
 assert snapshot()==source,'source changed during selected export verification'
 record['status']='passed';save()
except BaseException as e:
 record.update(status='failed',error=repr(e));save();raise
