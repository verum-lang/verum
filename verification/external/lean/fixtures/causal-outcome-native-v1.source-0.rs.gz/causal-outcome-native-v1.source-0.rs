//! The same complete target drives acquired state in replay, installation and
//! live transactions. These are interface/ownership courts, not acquisition wins.
use super::*;
use crate::program::observer::{InputBinding, InputSource};
use crate::program::{ExecutionLimit, Operand, Operation, Program, Step, code_mass::Mass};
use num_bigint::BigUint;
use std::cell::Cell;

#[derive(Clone, Copy, Debug)]
enum Op { Identity, Add }
struct Meaning;
impl Semantics<u64, Op> for Meaning {
    type Error = ();
    fn apply(&self, op: &Op, values: &[u64]) -> Result<u64, ()> {
        match (op, values) {
            (Op::Identity, [v]) => Ok(*v),
            (Op::Add, [a, b]) => a.checked_add(*b).ok_or(()),
            _ => Err(()),
        }
    }
}
struct Work(usize);
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.0 = self.0.checked_sub(n).ok_or(())?;
        Ok(())
    }
}
thread_local! { static ENCODINGS: Cell<usize> = const { Cell::new(0) }; }
type A = Assessment<u64, Op, u8, Meaning, u8, u64, u64>;
type T = Trial<u64, Op, u8, Meaning, u8, u64, u64>;
type V = Validated<u64, Op, u8, Meaning, u8, u64, u64>;
fn code(op: Op, arguments: Vec<Operand<u64>>) -> Program<u64, Op> {
    Program { steps: vec![Step { operation: Operation::Primitive(op), arguments }], output: Some(0), library: vec![] }
}
fn definition() -> Arc<Definition<u64, Op, u8, Meaning>> {
    Arc::new(Definition::new(0,
        code(Op::Identity, vec![Operand::Input(2)]),
        code(Op::Add, vec![Operand::Input(0), Operand::Input(1)]),
        InputBinding::new(0, 2, vec![InputSource::State, InputSource::External(0), InputSource::External(1)]).unwrap(),
        InputBinding::new(1, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(), Arc::new(Meaning)))
}
fn encode(y: &u64) -> Result<residual::Wire, residual::Invalid> {
    ENCODINGS.with(|n| n.set(n.get() + 1));
    Ok(Arc::from(y.to_le_bytes()))
}
fn protocol() -> Arc<residual::Protocol<u64, u64>> {
    residual::Protocol::causal(
        |v| Ok(residual::Prediction::new(Arc::from([]), Arc::from(v.to_le_bytes()))), encode,
        |wire| wire.as_ref().try_into().map(u64::from_le_bytes).map_err(|_| residual::Invalid::Encoding))
}
fn profile() -> AdmissionProfile {
    AdmissionProfile::ExactResidualPredictiveV1 { risk: Mass::uniform(BigUint::from(20u8)).unwrap() }
}
fn event() -> InputRow<u8, u64> { InputRow::new(0, vec![83]) }
fn query(x: u64) -> InputRow<u8, u64> { InputRow::new(1, vec![x]) }
fn complete(value: u64) -> HistoryEvent<u8, u64> {
    HistoryEvent::Completed { event: event(), outcome: Arc::from(value.to_le_bytes()) }
}
fn x(i: usize) -> u64 { u64::from((i as u32).wrapping_mul(2654435761).wrapping_add(97531)) }
fn targets(n: usize) -> Vec<u64> {
    let mut previous = 0;
    (0..n).map(|i| { previous += x(i); previous }).collect()
}
fn history(values: &[u64]) -> Arc<History<u8, u8, u64>> {
    History::from_origin(7, values.iter().copied().map(complete).collect())
}
fn trial(n: usize, wire: Arc<residual::Protocol<u64, u64>>) -> Arc<T> {
    let family = Family::with_profile(vec![definition()], profile()).unwrap();
    let mut builder = family.open_wire_trial(wire).unwrap();
    let ys = targets(n);
    let h = history(&ys);
    for (i, &y) in ys.iter().enumerate() {
        builder.observe(Arc::clone(&h), i, x(i), query(x(i)), y).unwrap();
    }
    builder.finish().unwrap()
}
fn evaluate(trial: Arc<T>, grant: usize) -> Arc<A> {
    let mut cursor = Evaluation::new(trial, 0);
    for turn in 0..200_000 {
        let mut work = Work(if turn % 2 == 0 { 0 } else { grant });
        match cursor.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            Ok(Some(a)) => return a,
            Ok(None) => {},
            Err(e) if e.can_resume() => {},
            Err(e) => panic!("{e:?}"),
        }
    }
    panic!("finite causal replay did not finish");
}
fn validated(n: usize, fresh: usize) -> Arc<V> {
    let accepted = evaluate(trial(n, protocol()), 100_000).accepted().unwrap().unwrap();
    let mut builder = accepted.open_validation();
    let ys = targets(n + fresh);
    let h = history(&ys);
    for (i, &y) in ys.iter().enumerate().skip(n) {
        builder.observe(Arc::clone(&h), i, x(i), query(x(i)), y).unwrap();
    }
    let mut work = Work(1_000_000);
    builder.finish().unwrap().evaluate(&mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap().validated().unwrap().unwrap()
}

#[test]
fn replay_installation_and_live_consume_the_identical_complete_target() {
    let t = trial(24, protocol());
    let coarse = evaluate(Arc::clone(&t), 100_000);
    let fine = evaluate(t, 1);
    let expected = targets(24);
    assert_eq!(coarse.readings.iter().map(|r| *r.value()).collect::<Vec<_>>(), expected);
    assert_eq!(fine.readings.iter().map(|r| *r.value()).collect::<Vec<_>>(), expected);
    assert_eq!(coarse.score.residual(), fine.score.residual());

    let admitted = validated(48, 24);
    let ys = targets(74);
    let mut installing = admitted.begin_installation(history(&ys[..72]), 72);
    for turn in 0..100_000 {
        let mut work = Work(if turn % 2 == 0 { 0 } else { 1 });
        match installing.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            Ok(true) => break,
            Ok(false) | Err(installation::InstallReason::Work(WorkRefusal::Meter(()))) => {},
            Err(installation::InstallReason::Replay(e)) if e.reason().can_resume() => {},
            Err(_) => panic!("causal installation refused"),
        }
    }
    let installed = installing.finish().unwrap_or_else(|_| panic!("installation incomplete"));
    assert_eq!(*installed.cut().state(), ys[71]);
    let mut runtime = installed.into_predictive().unwrap_or_else(|_| panic!("exact evidence frontier"));
    let mut prediction = runtime.begin(query(x(72)), event());
    let ticket = loop {
        let mut work = Work(1000);
        if let Some(ticket) = prediction.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)).unwrap() { break ticket; }
    };
    assert_eq!(ticket.forecast().prediction().mask(), ys[72].to_le_bytes());
    let before_encodings = ENCODINGS.with(Cell::get);
    let mut learning = ticket.observe(&ys[72]).unwrap();
    assert_eq!(ENCODINGS.with(Cell::get), before_encodings + 1);
    let mut zero = Work(0);
    assert!(matches!(learning.advance(&mut Budget::new(&mut zero, ExecutionLimit::Unlimited)),
        Err(installation::predictive::Stop::Work(WorkRefusal::Meter(())))));
    assert_eq!(*runtime.cut().state(), ys[71]);
    let update = loop {
        let mut work = Work(1);
        match learning.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            Ok(Some(update)) => break update,
            Ok(None) => {},
            Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {},
            Err(e) => panic!("{e:?}"),
        }
    };
    assert_eq!(ENCODINGS.with(Cell::get), before_encodings + 1, "live target encoded only once");
    runtime.commit(update).unwrap_or_else(|_| panic!("same owner commit"));
    assert_eq!(*runtime.cut().state(), ys[72]);
    let mut work = Work(100_000);
    let replayed = admitted.install(history(&ys[..73]), 73, &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("full target replay"));
    assert_eq!(runtime.cut().state(), replayed.cut().state());
}

fn read_at_end(values: &[u64]) -> u64 {
    let family = Family::with_profile(vec![definition()], profile()).unwrap();
    let mut builder = family.open_wire_trial(protocol()).unwrap();
    // None of the earlier updates is a selected scored row.
    builder.observe(history(values), values.len(), 0, query(0), 0).unwrap();
    *evaluate(builder.finish().unwrap(), 1).readings[0].value()
}
#[test]
fn outcome_order_changes_acquired_state_even_when_pre_events_and_marginals_match() {
    assert_eq!(read_at_end(&[3, 7]), 7);
    assert_eq!(read_at_end(&[7, 3]), 3);
}

#[test]
fn own_target_is_checked_but_never_replayed_into_its_pre_action_read() {
    let observe = |current| {
        let family = Family::with_profile(vec![definition()], profile()).unwrap();
        let mut builder = family.open_wire_trial(protocol()).unwrap();
        builder.observe(history(&[9, current]), 1, 0, query(5), current).unwrap();
        *evaluate(builder.finish().unwrap(), 1).readings[0].value()
    };
    assert_eq!(observe(14), 14);
    assert_eq!(observe(999), 14);
}

#[test]
fn causal_intake_rejects_foreign_or_missing_current_receipts_without_consuming_row() {
    let family = Family::with_profile(vec![definition()], profile()).unwrap();
    let mut builder = family.open_wire_trial(protocol()).unwrap();
    let h = history(&[7]);
    assert_eq!(builder.observe(Arc::clone(&h), 0, 0, query(0), 8),
        Err(IntakeRefusal::Wire(residual::Invalid::ConflictingOutcome)));
    for e in [HistoryEvent::Observed(event()), HistoryEvent::Gap] {
        assert_eq!(builder.observe(History::from_origin(7, vec![e]), 0, 0, query(0), 7),
            Err(IntakeRefusal::Wire(residual::Invalid::MissingOutcome)));
    }
    builder.observe(h, 0, 0, query(0), 7).unwrap();
    assert_eq!(builder.finish().unwrap().observations().len(), 1);
}

#[test]
fn causal_replay_and_installation_refuse_missing_prior_outcomes() {
    let family = Family::with_profile(vec![definition()], profile()).unwrap();
    let mut builder = family.open_wire_trial(protocol()).unwrap();
    builder.observe(History::from_origin(7, vec![HistoryEvent::Observed(event())]), 1, 0, query(0), 7).unwrap();
    let mut cursor = Evaluation::new(builder.finish().unwrap(), 0);
    let mut work = Work(10_000);
    loop {
        match cursor.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            Err(FailureReason::Wire(residual::Invalid::MissingOutcome)) => break,
            Ok(None) => {},
            _ => panic!("missing causal history must not be projected to a legacy event"),
        }
    }
    let admitted = validated(48, 24);
    let mut work = Work(10_000);
    let error = admitted.install(History::from_origin(8, vec![HistoryEvent::Observed(event())]), 1,
        &mut Budget::new(&mut work, ExecutionLimit::Unlimited)).err().expect("missing installation receipt");
    assert!(matches!(error.reason(), installation::InstallReason::Wire { event: 0, reason: residual::Invalid::MissingOutcome }));
    let mut changed = targets(72);
    changed[0] += 1;
    let mut work = Work(10_000);
    let error = admitted.install(history(&changed), 72, &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .err().expect("changed target rejected");
    assert!(matches!(error.reason(), installation::InstallReason::HistoryChanged { event: 0 }));
}

#[test]
fn completion_preserves_nonclone_interface_and_explicit_legacy_projection() {
    #[derive(Debug, PartialEq, Eq)]
    struct NonCloneInterface(u8);
    let input = InputRow::new(NonCloneInterface(9), vec![83]);
    let target: residual::Wire = Arc::from(7u64.to_le_bytes());
    let completed = protocol().complete_input(&input, Some(&target)).unwrap();
    assert!(std::ptr::eq(input.interface(), completed.interface()));
    assert_eq!(completed.values(), &[83, 7]);
    assert_eq!(input.values(), &[83]);
    let legacy = residual::Protocol::new(
        |v: &u64| Ok(residual::Prediction::new(Arc::from([]), Arc::from(v.to_le_bytes()))), encode);
    assert!(legacy.complete_input(&input, Some(&target)).unwrap().same_owner(&input));
    assert!(legacy.complete_input(&input, None).unwrap().same_owner(&input));
    assert!(matches!(protocol().complete_input(&input, None), Err(residual::Invalid::MissingOutcome)));
}

#[test]
fn descriptive_window_uses_the_same_completed_history_replay() {
    let mut builder = common_window::Builder::wire(profile(), protocol()).unwrap();
    builder.observe(history(&[3, 7]), 2, 0u64, query(5), 12).unwrap();
    let window = builder.finish().unwrap_or_else(|_| panic!("nonempty window"));
    let mut cursor = common_window::Evaluation::new(window, definition());
    for turn in 0..10_000 {
        let mut work = Work(if turn % 2 == 0 { 0 } else { 1 });
        match cursor.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            Ok(Some(a)) => { assert_eq!(*a.readings()[0].value(), 12); return; },
            Ok(None) => {},
            Err(e) if e.can_resume() => {},
            Err(e) => panic!("{e:?}"),
        }
    }
    panic!("descriptive causal replay did not finish");
}

#[cfg(feature = "serde")]
mod causal_snapshot {
    use super::*;
    use serde_json::{Value as Json, json};
    type Runtime = installation::predictive::Runtime<u64, Op, u8, Meaning, u8, u64, u64>;
    type Export = installation::predictive::transaction_export::Export<u64, Op, u8, Meaning, u64>;
    type Ticket = installation::predictive::Ticket<u64, Op, u8, Meaning, u64>;

    fn input(row: &InputRow<u8, u64>) -> Json {
        json!({"interface":row.interface(),"values":row.values(),
            "value_wires_u64_le":row.values().iter().map(|v|v.to_le_bytes()).collect::<Vec<_>>()})
    }
    fn assessment(a: &A, histories: &mut Vec<Arc<History<u8, u8, u64>>>) -> Json {
        let rows = a.trial().observations().iter().zip(a.readings()).map(|(row, reading)| {
            let h = row.history();
            let id = histories.iter().position(|old| Arc::ptr_eq(old, h)).unwrap_or_else(|| {
                let id = histories.len(); histories.push(Arc::clone(h)); id
            });
            json!({"history":id,"origin":row.id().origin(),"ordinal":row.id().ordinal(),
                "cut":row.cut(),"context":row.context(),"query":input(row.query()),
                "outcome_value":row.outcome(),
                "recorded_target_wire":h.events().get(row.cut()).and_then(HistoryEvent::outcome).map(|w|w.as_ref()),
                "state_before_read":reading.cut().state(),"reading":reading.value()})
        }).collect::<Vec<_>>();
        json!({"candidate":a.candidate(),"rows":rows,
            "score":a.score().residual().expect("wire assessment").native_frontier()})
    }
    fn read(runtime: &Runtime, export: &mut Export, query: InputRow<u8, u64>, event: InputRow<u8, u64>) -> (Ticket, Json) {
        let mut pending = runtime.begin(query, event);
        for turn in 0..10_000 {
            let mut work = Work(turn % 2);
            match pending.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
                Ok(Some(ticket)) => {
                    let actual = export.ticket(&pending, &ticket);
                    return (ticket, actual);
                }
                Ok(None) => {},
                Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {},
                other => panic!("snapshot read refused: {}", match other {
                    Err(e) => format!("{e:?}"), _ => "unexpected result".to_owned(),
                }),
            }
        }
        panic!("snapshot read did not finish");
    }

    /// Observes real commits and exact state laws. Internal VM phases and the
    /// admission algorithm are not proved by this diagnostic snapshot packet.
    #[test]
    fn live_outcome_order_snapshot() {
        let admitted = validated(48, 24);
        let mut histories = Vec::new();
        let training = assessment(admitted.validation().training().assessment(), &mut histories);
        let fresh = assessment(admitted.validation().fresh(), &mut histories);
        let complete_history = history(&targets(72));
        let mut work = Work(1_000_000);
        let installed = admitted.install(Arc::clone(&complete_history), 72,
            &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
            .unwrap_or_else(|_| panic!("actual admitted installation"));
        let seed = installed.into_predictive().unwrap_or_else(|_| panic!("actual predictive frontier"));
        let mut export = Export::new(|v| json!(v), |d| json!(d),
            |op| json!(match op { Op::Identity => "identity", Op::Add => "checked_add" }),
            "u64 identity/checked_add with exact arity; overflow and foreign argument shapes refuse",
            json!({"evidence":"source-reviewed fixture callback premise, not a native purity proof",
                "prediction":{"context":[],"mask":{"source":"actual native reading","encoding":"u64_le","width_bytes":8}},
                "outcome":{"source":"actual observed u64","encoding":"u64_le","width_bytes":8},
                "update_injection":{"source":"same encoded outcome wire","encoding":"u64_from_le_bytes",
                    "required_width_bytes":8,"on_wrong_width":"Encoding",
                    "placement":"append one value to retained pre-event external inputs; preserve interface owner"},
                "diagnostic_input_wires":"u64_le rendering of each actual typed u64 value; not a separate input protocol",
                "observational_counter":"ENCODINGS only counts calls and cannot affect returned bytes"}));
        let initial = export.runtime(&seed);
        let initial_bank = seed.score().native_frontier();
        let mut branches = Vec::new();
        let mut final_states = Vec::new();
        for (label, order) in [("forward", [3u64, 7]), ("reversed", [7u64, 3])] {
            let mut runtime = seed.fork();
            let branch_initial = export.runtime(&runtime);
            let mut steps = Vec::new();
            for actual_outcome in order {
                let query = query(0);
                let event = event();
                let query_data = input(&query);
                let event_data = input(&event);
                let before = export.runtime(&runtime);
                let (ticket, ticket_data) = read(&runtime, &mut export, query, event);
                let forecast = ticket.forecast().native_frontier();
                let mut learning = ticket.observe(&actual_outcome).unwrap();
                let mut completed_update_input = None;
                let mut transaction = None;
                for turn in 0..20_000 {
                    let mut work = Work(turn % 2);
                    match learning.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
                        Ok(Some(update)) => { transaction = Some(update); break; },
                        Ok(None) => {},
                        Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {},
                        Err(installation::predictive::Stop::Work(WorkRefusal::Meter(()))) => {},
                        Err(e) => panic!("snapshot update refused: {e:?}"),
                    }
                    if completed_update_input.is_none() {
                        let actual = export.learning(&learning);
                        if !actual["prepared"].is_null() {
                            completed_update_input = Some(json!({"preparing":actual["preparing"],
                                "prepared":actual["prepared"]}));
                        }
                    }
                }
                // This wrapper calls the actual runtime guard exactly once.
                let receipt = export.commit(&mut runtime, transaction.expect("completed native update"))
                    .unwrap_or_else(|_| panic!("same-owner native commit"));
                assert_eq!(*runtime.cut().state(), actual_outcome);
                assert_eq!(receipt.target.as_ref(), actual_outcome.to_le_bytes());
                let after = export.runtime(&runtime);
                steps.push(json!({"query":query_data,"pre_event":event_data,
                    "observed_outcome_value":actual_outcome,"returned_target_wire":receipt.target.as_ref(),
                    "before":before,"ticket":ticket_data,"forecast":forecast,
                    "completed_update_input":completed_update_input.expect("observed native preparation"),
                    "after":after,"state_after_commit":runtime.cut().state(),
                    "bank_before":receipt.before.native_frontier(),"bank_after":receipt.after.native_frontier()}));
            }
            let (final_ticket, final_read) = read(&runtime, &mut export, query(0), event());
            assert_eq!(final_ticket.forecast().prediction().mask(), runtime.cut().state().to_le_bytes());
            final_states.push(*runtime.cut().state());
            branches.push(json!({"label":label,"initial":branch_initial,"steps":steps,
                "final":export.runtime(&runtime),"final_read":final_read,
                "final_forecast":final_ticket.forecast().native_frontier()}));
        }
        assert_eq!(final_states, [7, 3]);
        let histories = histories.iter().enumerate().map(|(id, h)| json!({"id":id,"origin":h.origin(),
            "events":h.events().iter().map(|event| match event {
                HistoryEvent::Completed { event, outcome } => json!({"kind":"completed","pre_event":input(event),"target_wire":outcome.as_ref()}),
                HistoryEvent::Observed(event) => json!({"kind":"legacy_observed","pre_event":input(event)}),
                HistoryEvent::Gap => json!({"kind":"gap"}),
            }).collect::<Vec<_>>() })).collect::<Vec<_>>();
        let packet = json!({"format":"synarc-causal-outcome-update-snapshot-v1",
            "scope":"actual acquired update/read definitions and bindings, retained owner identities, causal target inputs, committed states and prediction banks; no claim about internal VM continuations or acquired discovery",
            "source_binding":"external source-and-binary build receipt; this packet does not authenticate its own executable",
            "histories":histories,"training":training,"fresh":fresh,
            "initial":initial,"initial_bank":initial_bank,"branches":branches,
            "native_tables":export.finish("causal_live_outcome_order_snapshot")});
        if let Some(path) = std::env::var_os("SYNARC_CAUSAL_UPDATE_EXPORT") {
            use std::io::Write;
            let mut line = serde_json::to_vec(&packet).unwrap();
            line.push(b'\n');
            std::fs::OpenOptions::new().create(true).append(true).open(path).unwrap().write_all(&line).unwrap();
        }
    }
}
