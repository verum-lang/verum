//! Evidence-independent finite envelopes of lexical control programs.
//! Bounds are coordinates of a source declaration, not execution truncations.
//! Union over steps, nesting and body width covers every finite tree over the
//! declared primitive/literal alphabet. It does not establish search efficiency.
//! Work counts logical comparisons/copies/edges, not generic Clone/Ord, allocator
//! or BigUint costs. Retention conservatively counts all constructed cells,
//! including temporary catalogue slots; capacity never changes the language.
use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DeclarationBounds { pub nesting: usize, pub body_inputs: usize }
#[derive(Debug)]
pub enum DeclarationFailure<E> { Work(E), Structural(StructuralRefusal), Syntax(SyntaxRefusal) }
impl<E> From<StructuralRefusal> for DeclarationFailure<E> {
    fn from(value: StructuralRefusal) -> Self { Self::Structural(value) }
}
#[derive(Clone, Copy)]
enum Phase { Operations { at: usize, prior: usize }, Literals { at: usize, prior: usize },
    CopyOperation(usize), CopyLiteral(usize), Control { at: usize, fold: bool }, Publish, Done }

pub struct DeclarationCursor<V, P> {
    grammar: Grammar<P, V>, bounds: DeclarationBounds, phase: Phase,
    level: usize, width: usize, previous: Vec<Arc<Language<V, P>>>, next: Vec<Arc<Language<V, P>>>,
    operations: Vec<OperationSpec<P>>, literals: Vec<V>, controls: Vec<ControlSpec<V, P>>,
    cells: usize, result: Option<Arc<Language<V, P>>>, refused: Option<SyntaxRefusal>,
}
impl<V: Clone + Ord, P: Clone + Ord> DeclarationCursor<V, P> {
    pub fn new(grammar: Grammar<P, V>, bounds: DeclarationBounds) -> Result<Self, SyntaxRefusal> {
        let additions = grammar.max_steps.saturating_sub(1).checked_add(grammar.literals.len()).ok_or(SyntaxRefusal::CountCapacity)?;
        grammar.inputs.checked_add(additions).ok_or(SyntaxRefusal::CountCapacity)?;
        if bounds.nesting > 0 {
            bounds.body_inputs.checked_add(1).and_then(|_| bounds.body_inputs.checked_add(additions)).ok_or(SyntaxRefusal::CountCapacity)?;
        }
        let cells = 1usize.checked_add(grammar.operations.len()).and_then(|n| n.checked_add(grammar.literals.len())).ok_or(SyntaxRefusal::CountCapacity)?;
        Ok(Self { grammar, bounds, phase: Phase::Operations { at: 0, prior: 0 }, level: 0, width: 0,
            previous: Vec::new(), next: Vec::new(), operations: Vec::new(), literals: Vec::new(), controls: Vec::new(),
            cells, result: None, refused: None })
    }
    pub fn retained_cells(&self) -> usize { self.cells }
    pub fn language(&self) -> Option<&Arc<Language<V, P>>> { self.result.as_ref() }
    fn reserve(&self, additional: usize, capacity: usize) -> Result<usize, StructuralRefusal> {
        let total = self.cells.checked_add(additional).ok_or(StructuralRefusal::Capacity)?;
        if total > capacity { return Err(StructuralRefusal::Capacity); }
        Ok(total)
    }
    fn invalid<E>(&mut self, why: SyntaxRefusal) -> Result<bool, DeclarationFailure<E>> {
        self.refused = Some(why.clone()); Err(DeclarationFailure::Syntax(why))
    }
    pub fn advance<M: WorkMeter + ?Sized>(&mut self, meter: &mut M, capacity: usize) -> Result<bool, DeclarationFailure<M::Error>> {
        meter.charge(1).map_err(DeclarationFailure::Work)?;
        if let Some(why) = &self.refused { return Err(DeclarationFailure::Syntax(why.clone())); }
        self.reserve(0, capacity)?;
        match self.phase {
            Phase::Operations { at, prior } => {
                if at == self.grammar.operations.len() { self.phase = Phase::Literals { at: 0, prior: 0 }; }
                else if prior == at { self.phase = Phase::Operations { at: at + 1, prior: 0 }; }
                else if self.grammar.operations[at].id == self.grammar.operations[prior].id { return self.invalid(SyntaxRefusal::DuplicateOperation); }
                else { self.phase = Phase::Operations { at, prior: prior + 1 }; }
            },
            Phase::Literals { at, prior } => {
                if at == self.grammar.literals.len() {
                    if self.grammar.operations.is_empty() { return self.invalid(SyntaxRefusal::EmptyOperations); }
                    self.phase = Phase::CopyOperation(0);
                } else if prior == at { self.phase = Phase::Literals { at: at + 1, prior: 0 }; }
                else if self.grammar.literals[at] == self.grammar.literals[prior] { return self.invalid(SyntaxRefusal::DuplicateLiteral); }
                else { self.phase = Phase::Literals { at, prior: prior + 1 }; }
            },
            Phase::CopyOperation(at) => {
                if let Some(op) = self.grammar.operations.get(at) {
                    let cells = self.reserve(1, capacity)?;
                    self.operations.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    self.operations.push(op.clone()); self.cells = cells; self.phase = Phase::CopyOperation(at + 1);
                } else { self.phase = Phase::CopyLiteral(0); }
            },
            Phase::CopyLiteral(at) => {
                if let Some(value) = self.grammar.literals.get(at) {
                    let cells = self.reserve(1, capacity)?;
                    self.literals.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    self.literals.push(value.clone()); self.cells = cells; self.phase = Phase::CopyLiteral(at + 1);
                } else { self.phase = Phase::Control { at: 0, fold: false }; }
            },
            Phase::Control { at, fold } => {
                if let Some(child) = self.previous.get(at) {
                    if fold {
                        if child.inputs >= 2 {
                            let cells = self.reserve(2, capacity)?;
                            self.controls.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                            self.controls.push(ControlSpec::Fold { body: Arc::clone(child) }); self.cells = cells;
                        }
                        self.phase = Phase::Control { at: at + 1, fold: false };
                    } else {
                        let cells = self.reserve(3, capacity)?;
                        self.controls.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                        self.controls.push(ControlSpec::Branch { yes: Arc::clone(child), no: Arc::clone(child) });
                        self.cells = cells; self.phase = Phase::Control { at, fold: true };
                    }
                } else { self.phase = Phase::Publish; }
            },
            Phase::Publish => {
                let cells = self.reserve(2, capacity)?;
                let root = self.level == self.bounds.nesting;
                if !root { self.next.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?; }
                // All catalogue entries were checked/copied above. Children
                // are earlier immutable layers; their ports were checked in new.
                let language = Arc::new(Language { owner: Arc::new(()), inputs: if root { self.grammar.inputs } else { self.width },
                    operations: std::mem::take(&mut self.operations), literals: std::mem::take(&mut self.literals), calls: Vec::new(),
                    extent: Extent::Finite(self.grammar.max_steps), controls: std::mem::take(&mut self.controls), version: if self.level == 0 { 1 } else { 2 } });
                self.cells = cells;
                if root { self.result = Some(language); self.phase = Phase::Done; }
                else {
                    self.next.push(language);
                    if self.width == self.bounds.body_inputs {
                        self.previous = std::mem::take(&mut self.next); self.width = 0; self.level += 1;
                    } else { self.width += 1; }
                    self.phase = Phase::CopyOperation(0);
                }
            },
            Phase::Done => {},
        }
        Ok(self.result.is_some())
    }
}

#[cfg(test)]
mod courts;
