//! Test-only observations. No method constructs a point, receipt or clock phase.
use super::*;
use serde_json::{json, Value};

pub(in crate::organism) struct Recorder {
    // Retention prevents pointer reuse from merging distinct native origins.
    origins: Vec<Arc<Origin>>,
    samples: Vec<SampleId>,
    rows: Vec<Value>,
}

impl Recorder {
    pub(in crate::organism) fn new() -> Self {
        Self { origins: Vec::new(), samples: Vec::new(), rows: Vec::new() }
    }
    fn origin(&mut self, origin: &Arc<Origin>) -> usize {
        if let Some(index) = self.origins.iter().position(|known| Arc::ptr_eq(known, origin)) {
            return index;
        }
        let index = self.origins.len();
        self.origins.push(Arc::clone(origin));
        index
    }
    fn sample(&mut self, sample: SampleId) -> usize {
        if let Some(index) = self.samples.iter().position(|known| *known == sample) {
            return index;
        }
        let index = self.samples.len();
        self.samples.push(sample);
        index
    }
    fn time(time: PreActionTime) -> Value {
        json!({"episode": time.episode, "age": time.life_age})
    }
    pub(in crate::organism) fn clock(&mut self, clock: &Clock) -> Value {
        json!({"origin": self.origin(&clock.origin), "episode": clock.episode,
            "age": clock.life_age, "phase": match clock.phase {
                Phase::Ready => "ready", Phase::InFlight => "inFlight",
                Phase::TerminalPending => "terminalPending" }})
    }
    pub(in crate::organism) fn outcome(outcome: ObservedAction) -> Value {
        match outcome {
            ObservedAction::Step => json!({"step": null}),
            ObservedAction::Refused => json!({"refused": null}),
            ObservedAction::Terminal { kind, resumption } =>
                json!({"terminal": {"kind": format!("{kind:?}"), "resumption": format!("{resumption:?}")}}),
        }
    }
    pub(in crate::organism) fn point(&mut self, point: &Point) -> Value {
        json!({"origin": self.origin(&point.origin), "time": Self::time(point.time)})
    }
    pub(in crate::organism) fn receipt(&mut self, receipt: &Receipt) -> Value {
        self.edge(&receipt.edge)
    }
    pub(in crate::organism) fn applied(&mut self, applied: &Applied) -> Value { self.edge(&applied.edge) }
    pub(in crate::organism) fn edge(&mut self, edge: &Edge) -> Value {
        json!({"point": self.point(&edge.point),
            "sample": edge.sample.map(|sample| self.sample(sample)),
            "transition": match edge.transition {
                Transition::Tick => json!({"tick": null}),
                Transition::TerminalReset(kind) => json!({"terminal": format!("{kind:?}")}),
            }, "successor": edge.successor.map(Self::time)})
    }
    pub(in crate::organism) fn sample_catalogue(&self) -> Value {
        json!(self.samples.iter().enumerate().map(|(identity,sample)| json!({"identity":identity,
            "lineage":super::super::lifecycle_lineage(&sample.lineage),"ordinal":sample.ordinal})).collect::<Vec<_>>())
    }
    pub(in crate::organism) fn row(&mut self, operation: &str, input: Value,
        before: Value, after: Value, result: Value) {
        self.rows.push(json!({"operation": operation, "input": input,
            "before": before, "after": after, "result": result}));
    }
    pub(in crate::organism) fn write(self, case: &str, initialization: &str) {
        let Some(root) = std::env::var_os("SYNARC_PHYSICAL_CLOCK_EXPORT") else { return; };
        let root = std::path::PathBuf::from(root);
        std::fs::create_dir_all(&root).unwrap();
        let data = json!({"protocol": "synarc-physical-clock-v1", "case": case,
            "maximum": u64::MAX, "initialization": initialization,
            "origin_count": self.origins.len(), "sample_count": self.samples.len(),
            "steps": self.rows});
        std::fs::write(root.join(format!("{case}.json")), serde_json::to_vec_pretty(&data).unwrap()).unwrap();
    }
}
