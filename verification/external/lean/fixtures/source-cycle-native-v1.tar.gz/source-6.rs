//! Exact delayed membership transport along actual native commits.
//! The old Binding API remains strict: only this source-service cursor follows
//! a continuous successful U chain while its captured value is compared.
use super::*;

/// Exact composition of k successors of the certified lasso. The number k need
/// not fit in any integer: (min(k,N), k mod (N-c)) represents its full action on
/// every original state index. No wrapping arithmetic or payload journal.
struct Shift {
    states: usize,
    start: usize,
    capped: usize,
    residue: usize,
}
impl Shift {
    fn new(states: usize, start: usize) -> Self {
        assert!(start < states, "nonempty certified lasso");
        Self { states, start, capped: 0, residue: 0 }
    }
    fn advance(&mut self) {
        if self.capped < self.states { self.capped += 1; }
        let length = self.states - self.start;
        self.residue = if self.residue == length - 1 { 0 } else { self.residue + 1 };
    }
    fn apply(&self, index: usize) -> usize {
        assert!(index < self.states, "checked original carrier membership");
        let until_wrap = self.states - index;
        if self.capped < until_wrap { return index + self.capped; }
        let length = self.states - self.start;
        let subtract = until_wrap % length;
        let residue = if self.residue >= subtract { self.residue - subtract }
            else { length - (subtract - self.residue) };
        self.start + residue
    }
}

/// Owns the original exact comparison and only the latest actual revision.
/// Losing any commit makes the chain unusable; equal states cannot fill a gap.
pub(in crate::organism) struct FollowingBinding<A: Copy + Ord> {
    binding: Binding<A>,
    latest: Cut<A>,
    shift: Shift,
    broken: bool,
}
impl<A: Copy + Ord> CertifiedCycle<A> {
    pub(in crate::organism) fn begin_following_binding(self: &Arc<Self>, installed: &Installed<A>)
        -> Result<FollowingBinding<A>, BindingRefusal> {
        let binding = self.begin_binding(installed)?;
        let latest = binding.cut.clone();
        Ok(FollowingBinding { binding, latest,
            shift: Shift::new(self.cuts.len(), self.closing_target), broken: false })
    }
}
impl<A: Copy + Ord> FollowingBinding<A> {
    pub(in crate::organism) fn current(&self, installed: &Installed<A>) -> bool {
        !self.broken && !self.binding.taken && self.latest.same_revision(&installed.cut())
            && Arc::ptr_eq(&self.binding.history, installed.history())
            && self.binding.origin_cut == installed.origin_cut()
    }
    /// Called inside the native runtime's successful commit boundary. This
    /// transports native membership only; no physical tick/anchor is granted.
    pub(in crate::organism) fn committed(&mut self,
        receipt: &crate::organism::observer_runtime::Commit<A>, installed: &Installed<A>) {
        if self.broken || self.binding.taken || !self.latest.same_revision(receipt.before())
            || !receipt.after().same_revision(&installed.cut())
            || !Arc::ptr_eq(&self.binding.history, installed.history())
            || self.binding.origin_cut != installed.origin_cut()
            || !self.binding.certificate.autonomy.applies_to(receipt.after().definition()) {
            self.broken = true;
            return;
        }
        self.shift.advance();
        self.latest = receipt.after().clone();
    }
    pub(in crate::organism) fn advance(&mut self, work: &mut ObserverWork) -> Result<bool, Stop<A>> {
        if self.broken { return Err(Stop::Poisoned); }
        self.binding.advance(work)
    }
    pub(in crate::organism) fn outside(&self) -> bool { self.binding.exhausted_without_member() }
    #[cfg(test)]
    pub(in crate::organism) fn captured_cut(&self) -> &Cut<A> { &self.binding.cut }
    pub(in crate::organism) fn take(&mut self, installed: &Installed<A>) -> Result<BoundCycle<A>, BindingRefusal> {
        if self.binding.taken { return Err(BindingRefusal::Consumed); }
        if !self.current(installed) || self.binding.poisoned { return Err(BindingRefusal::StaleInstallation); }
        let original = self.binding.found.ok_or(if self.outside() {
            BindingRefusal::OutsideOrbit
        } else { BindingRefusal::Incomplete })?;
        self.binding.taken = true;
        Ok(BoundCycle { certificate: Arc::clone(&self.binding.certificate),
            cut: self.latest.clone(), history: Arc::clone(&self.binding.history),
            origin_cut: self.binding.origin_cut, state: self.shift.apply(original) })
    }
}

#[cfg(test)]
mod courts {
    use super::Shift;
    #[test]
    fn bounded_transport_matches_independent_successor_walk_for_every_prefix_index() {
        for states in 1..=12 {
            for start in 0..states {
                let mut shift = Shift::new(states, start);
                let mut direct: Vec<_> = (0..states).collect();
                for _ in 0..4097 {
                    for index in 0..states { assert_eq!(shift.apply(index), direct[index]); }
                    assert!(shift.capped <= states);
                    assert!(shift.residue < states - start);
                    for value in &mut direct { *value = if *value + 1 == states { start } else { *value + 1 }; }
                    shift.advance();
                }
            }
        }
    }
    #[test]
    fn transport_arithmetic_at_usize_boundary_never_wraps() {
        let mut almost_full = Shift { states: usize::MAX, start: 0,
            capped: usize::MAX - 1, residue: usize::MAX - 1 };
        assert_eq!(almost_full.apply(0), usize::MAX - 1);
        assert_eq!(almost_full.apply(1), 0);
        almost_full.advance();
        assert_eq!(almost_full.apply(0), 0);
        assert_eq!(almost_full.apply(1), 1);
        almost_full.advance();
        assert_eq!(almost_full.capped, usize::MAX);
        assert_eq!(almost_full.apply(0), 1);
        assert_eq!(almost_full.apply(1), 2);
        for start in [0, 1, usize::MAX - 7, usize::MAX - 1] {
            let states = usize::MAX;
            let mut shift = Shift::new(states, start);
            let indices = [0, 1, usize::MAX - 8, usize::MAX - 2, usize::MAX - 1];
            let mut direct = indices;
            for _ in 0..257 {
                for (index, expected) in indices.into_iter().zip(direct) { assert_eq!(shift.apply(index), expected); }
                for value in &mut direct { *value = if *value + 1 == states { start } else { *value + 1 }; }
                shift.advance();
            }
        }
    }
}

#[cfg(all(test, feature = "serde"))]
pub(in crate::organism) struct ExportView<'a> {
    pub certificate: &'a Arc<CertifiedCycle<u8>>,
    pub original: &'a Cut<u8>, pub latest: &'a Cut<u8>,
    pub history: &'a Arc<NativeHistory<u8>>, pub origin_cut: usize,
    pub comparison_cursor: usize, pub comparing: bool, pub found: Option<usize>,
    pub states: usize, pub start: usize, pub capped: usize, pub residue: usize,
    pub broken: bool, pub taken: bool, pub poisoned: bool,
}
#[cfg(all(test, feature = "serde"))]
impl FollowingBinding<u8> {
    pub(in crate::organism) fn export_view(&self) -> ExportView<'_> {
        ExportView { certificate: &self.binding.certificate,
            original: &self.binding.cut, latest: &self.latest, history: &self.binding.history,
            origin_cut: self.binding.origin_cut, comparison_cursor: self.binding.at,
            comparing: self.binding.comparing.is_some(), found: self.binding.found,
            states: self.shift.states, start: self.shift.start, capped: self.shift.capped, residue: self.shift.residue,
            broken: self.broken, taken: self.binding.taken, poisoned: self.binding.poisoned }
    }
}
