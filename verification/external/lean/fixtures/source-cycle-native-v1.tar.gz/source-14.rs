//! The Organism — the target integral core of the universal
//! cognitive architecture (the 11.08 mandate).
//!
//! One reusable type binds the hierarchy together:
//! perception encodes into Gamma food (EL-176/177), the food
//! feeds the BASE of the §07 simplicial tower ([`CogTower`]),
//! upper levels live by inner dynamics; the tick's bodily
//! climate reads the L.7 duo-wheel ([`DuoWheel`]); the
//! world's geography is EARNED through a transition table,
//! and the curiosity policy (untried -> plan -> BFS to the
//! frontier) walks the body where the world is not yet
//! eaten. A task plugs in through [`Habitat`] — a narrow
//! interface of "observation as seven features, actions, a
//! situation key"; nothing grid-, text- or arena-specific
//! lives in the core — from the test maze to the live ARC
//! arena the organism is ONE AND THE SAME.

use std::collections::{HashMap, VecDeque};

/// [ФАЗА-2б] мир-агностичные стёкла-вахты:
/// generic-орган читает WATCH_*; ARC_WATCH_* —
/// совместимое имя эпохи ARC-полигона.
pub(crate) fn watch_val(
    name: &str,
) -> Option<String> {
    std::env::var(format!("WATCH_{name}"))
        .ok()
        .or_else(|| {
            std::env::var(format!(
                "ARC_WATCH_{name}"
            ))
            .ok()
        })
}

pub(crate) fn watch_glass(name: &str) -> bool {
    std::env::var(format!("WATCH_{name}"))
        .is_ok()
        || std::env::var(format!(
            "ARC_WATCH_{name}"
        ))
        .is_ok()
}


use synarc_math::cascade::{CascadeNode, CascadeTick};
use synarc_math::{Axis, C64, Gamma, Herm7, N, invariants};

use crate::motor::MotorOrgan as _;
use std::ops::Not as _;
use crate::tower::{CogTower, LevelFrame, LiftKind};
use crate::wheel::{DuoWheel, Takeover};

/// A task through the organism's eyes. Implementations must
/// yield normalised features (sum = 1, each > 0): this is
/// food, not a raw frame.

/// The world's two NO-STEP voices (the third voice is
/// `Ok`): a world speaks a step, a refusal, or a death —
/// nothing else. One `Err(String)` for both was the
/// generic false ontology this enum razes: a MazeRooms
/// wall bump tore `life_age` to zero and salted every
/// death-reading court (guard floors, the standing
/// court's harm metric) with deaths nobody died.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Cut {
    /// The gesture is REFUSED: the body stands where it
    /// stood (a wall bump, a jammed lever). The world did
    /// NOT reset. Life continues — `life_age` keeps
    /// flowing; the grave ledger (Z-6) records the
    /// refused gesture and the window turns suspect, but
    /// no death is written.
    Refusal,
    /// The environment CUT the episode and returned to
    /// the start by itself: true death. `life_age` tears
    /// to zero; the death ledger and the guard floor
    /// listen to this voice alone.
    Death,
    /// [THE CLOCK'S CUT IS NOT THE GESTURE'S — M-1654] the
    /// episode was cut because the life's clock ran out
    /// (the world's gauge was spent). The life ends as in a
    /// death — `life_age` tears to zero, the world stands at
    /// its start — but no gesture is guilty of it: no grave,
    /// no ban, no deadly witness, no buried goal.
    Time,
    /// A completed goal followed by a valid resumption.
    Completed,
    /// An observed terminal of unspecified cause followed by resumption.
    Ended,
}

mod action;
mod causal_coordinates;
mod decision;
use decision::Decision;
mod event_domain;
pub(crate) mod context;
use context::Context;
mod observer_runtime;
mod observer_replay;
#[cfg(test)]
pub(crate) use observer_replay::periodic_replay_schema;
pub(crate) use observer_replay::{ReplayHistory, ReplayRefusal, SchemaReplay};
mod observer_chain;
mod tier_dictionary;
use tier_dictionary::TierDictionary;
mod observer_domain;
pub use observer_domain::{DomainBoundary, DomainRetirementReceipt};
pub use observer_domain::recovery::{ObserverResumeGrant, ObserverResumeRefusal, ObserverContinuationStatus, ObserverContinuationPhase};
pub use observer_domain::before::{BeforeActResumeGrant, BeforeActResumeRefusal, BeforeActResumeError, BeforeActPhase, BeforeActStatus, ProposalCancellation, ProposalCancellationReason};
mod observer_acquired;
pub(crate) fn observer_schema_cells(bytes: &[u8]) -> Option<usize> {
    observer_acquired::portable::decode::<u8>(bytes).ok().map(|code| code.cells)
}
mod observer_acceptance;
mod observer_audit;
pub use observer_audit::promotion::{ObserverPromotionPhase, ObserverPromotionOutcome, ObserverPromotionRound,
    ObserverPromotionDeclaration, ObserverPromotionPair, ObserverPromotionSnapshot, ObserverPromotionVisit,
    ObserverPromotionRefusal, ObserverPromotionRefusalClass, ObserverPromotionComparison};
mod observer_finite;
pub use observer_audit::retention::{ObserverRetentionRole, ObserverRetentionStage, ObserverCumulativeRetention, ObserverRetentionSnapshot, ObserverRetentionVisit, ObserverRetentionInspection};
pub use observer_finite::{ObserverFiniteLimits, ObserverFiniteStatus, ObserverFiniteBinding, ObserverFiniteUnknown, ObserverFinitePause, ObserverFiniteReceipt, ObserverFiniteService, ObserverFiniteRefusal, ObserverSourceCycleReceipt};
pub use observer_audit::{ObserverReceipt, ObserverTrainingWindow, ObserverEventId, ObserverAcquisitionReceipt, ObserverProvenance, ObserverSource, ObserverSourceShape, ObserverLineage, ObserverObservationId, ObserverAttemptAddress, ObserverAttemptRole, ObserverCompositionBounds, ObserverAdmissionProfile, ObserverExactScore, ObserverReceiptUnavailable, ObserverCodeRefusal, ObserverAuditRefusal};
mod acquisition_budget;
pub use acquisition_budget::{AcquisitionWorkReceipt, AcquisitionWorkRefusal};
#[cfg(test)]
mod observer_acquired_courts;
mod observer_duel;
mod observer_transport;
#[cfg(test)]
mod standing_courts;
#[cfg(test)]
mod observer_transport_courts;
#[cfg(test)]
mod observer_execution_courts;
mod context_projection;
mod observed_relation;
#[cfg(test)]
mod relation_courts;
#[cfg(test)]
mod tier_composition_courts;
pub use observed_relation::{Gap as ReachabilityGap, Incomplete as ReachabilityGapKind, Report as ReachabilityReport, Verdict as ReachabilityVerdict};
use event_domain::EventDomain;
pub use action::{ActionContext, ActionFailure, ActionOperation, ActionStage, LifeRun, ObservedAction, Resumption, RunEnd, StepOutcome, TerminalKind, TerminalScope, TerminalReceipt, ObservedWorldOutcome};

mod action_capture;
#[cfg(test)]
mod action_capture_courts;
pub use action_capture::{ActionCapture, CapturedOutcome, CaptureError, TargetError, TargetView, TargetKind, TargetDecodeError};
mod declared_task;
mod goal_forecast;
mod goal_selection;
pub use goal_selection::{GoalActionEstimate, GoalDecisionReport};
pub use declared_task::{DeclaredTask, GoalSnapshot, GoalDecoder};

mod sensory;
pub use sensory::Sensory;
#[cfg(test)]
mod sensory_courts;

/// A world with a declared complete sensory port, legacy Gamma features,
/// an address, available actions and observed action outcomes. A missing
/// sensory port is explicit and cannot be reconstructed from its address.
pub trait Habitat {
    /// An action in this task.
    type Action: Copy + Eq + std::hash::Hash + Ord;
    /// Seven features of the situation — Gamma-food ore.
    fn observe(&self) -> [f64; 7];
    /// The situation key (an address in the earned geography).
    fn key(&self) -> u64;
    /// Complete observation in the world's declared encoding. Absence is an
    /// unavailable port, never a body reconstructed from key() or observe().
    fn sensory(&self) -> Option<Sensory> { None }
    /// Stable immutable task declaration. Reusing a body after reset does not reset its witnessed thresholds.
    fn declared_task(&self) -> Option<DeclaredTask> { None }
    /// The dictionary of actions available NOW.
    fn actions(&self) -> Vec<Self::Action>;
    /// ЗАЯВЛЕННЫЙ ПРОГРЕСС-СЕНСОР (рынок целей).
    /// None (дефолт) — мир прогресса не заявляет и
    /// рынком целей не облагается. Прожитый обвал:
    /// рынок читал observe()[0] как прогресс, а в
    /// стенде Trails там код буквы/255 — ложные цели
    /// съели фронтир (мотор-пара 1502→501). Валюта
    /// не назначается — она заявляется миром и
    /// выводится строгим ростом (М-15).
    fn progress(&self) -> Option<f64> {
        None
    }
    /// [НАМЕРЕНИЕ-КАК-ДЕРЖАНИЕ] живые задачи мира:
    /// (рабочий адрес, остаток дефицита own-актов).
    /// Пусто по дефолту — мир без заявленных задач
    /// не облагает тело служением. Телу задача
    /// видна как ЦЕЛЬ той же Дейкстры и как ДОХОД
    /// места той же валюты недожитых актов
    /// (слагаемое yield_of; ни одного нового веса
    /// — пререг intent-as-holding).
    /// [ПРЕРЕГ-23] всего гашений задач за жизнь
    /// мира (валюта служения на рынке желаний).
    fn task_confirms(&self) -> u64 {
        0
    }
    /// [ФАЗОВАЯ ТЯГА] двери недожитых фазовых
    /// рёбер текущего уровня С АКТОМ РЕБРА (кворум
    /// гасится проживанием ИМЕННО пары — стук
    /// любым актом бил не тот палец: ft09-гвоздь
    /// шесть циклов недолёта).
    fn phase_targets(
        &self,
    ) -> Vec<(u64, Self::Action)> {
        Vec::new()
    }
    /// Витрина живых задач мира: (дверь, дефицит).
    fn task_addrs(&self) -> Vec<(u64, u32)> {
        Vec::new()
    }
    /// [ПЕРЕЗРЕЛЫЙ ДОЛГ] есть долг двойной
    /// выдержки — зов имеет право прожечь скуку
    /// (валюта предмета покупает такт; default —
    /// немые миры не тронуты).
    fn stale_overdue(&self) -> bool {
        false
    }
    /// [ЗОВ СТАРШИНСТВОМ] застарелые долги мира:
    /// (адрес двери, возраст неоплаты), уже
    /// отфильтрованные порогом мира (юрисдикция
    /// клока/эпох — мирская; прожитость и место
    /// в каскаде судит организм). Возраст
    /// принадлежит ПРЕДМЕТУ: чужие крошки его
    /// не сбрасывают — только own-касание.
    fn stale_tasks(&self) -> Vec<(u64, u64)> {
        Vec::new()
    }
    /// [ТЕНЬ ДЛЯ ШАГА, пятая ипостась] кадры
    /// одного суда — совпадение для суда шага
    /// (расхождение поста не расхождение, когда
    /// живой кадр того же суда, что узел плана).
    /// Default false — немые миры не тронуты.
    fn same_court(&self, _a: u64, _b: u64) -> bool {
        false
    }
    /// [ЗАЧЁТ ТЕНИ ДЛЯ ДОЕЗДА] все кадры-двери
    /// долга wa ({wa} ∪ капли его судного ключа):
    /// «тело на цели» истинно на ЛЮБОМ из них.
    fn task_doors_of(&self, wa: u64) -> Vec<u64> {
        vec![wa]
    }
    /// [ДОРОГА МИРА] прожитая дорога от «здесь»
    /// мира к двери задачи — по памяти прожитых
    /// троек (богатство мира), НЕ по каналу
    /// предсказаний тела. Рвёт вечный круг немоты
    /// последнего метра: own-акты у цели нужны,
    /// чтобы канал выучил цепь, а цепь — чтобы
    /// доехать до own; но дорога уже ПРОЖИТА
    /// (forced-проездами) и суд оптимальности её
    /// видит — исполнителю положен тот же граф.
    /// Мир сам знает своё «здесь»; None = мир
    /// без памяти дорог (немые миры не тронуты).
    ///
    /// [ЗАКОН ТРЁХ ДОРОГ, аудит 27.08] у плана
    /// три источника трёх юрисдикций, это НЕ
    /// двоевластие: (1) map тела — переходы,
    /// выученные СВОИМ выбором (исходы, цены,
    /// баны; map-к-задаче казнён единовластием,
    /// вернётся узкой постройкой V2); (2)
    /// exam-цепи канала — предсказательное
    /// знание; (3) plan_to мира — ПРОЖИТОЕ, в
    /// т.ч. чужое (forced/дидактика), которого
    /// в (1)-(2) нет по построению. Каскад:
    /// канал → мир (эта ветвь) — мир последним,
    /// ибо его дорога не несёт ожиданий
    /// (plan_expect=None) и не банится.
    /// [ЗРЯЧАЯ ДОРОГА] шаг = (акт,
    /// узел-назначение); ждущий шаг несёт
    /// узел==pre — исполнение отличает «ждать»
    /// от «перейти» самим носителем.
    fn plan_to(
        &self,
        _door: u64,
    ) -> Option<Vec<(Self::Action, u64)>> {
        None
    }
    /// [ДОРОГА ПО НОТАМ] реплей сегмента урока
    /// own-актами к фазово-зависимому суду
    /// (рельса дидактики); None = мир без лент.
    fn lesson_rail(
        &self,
        _door: u64,
    ) -> Option<Vec<Self::Action>> {
        None
    }
    /// [ТОЧНОЕ ПРИБЫТИЕ] кадр тела стоит В САМОМ
    /// суде цели (не тенью): арх-долг платится
    /// только точным проездом (p161w: тень
    /// снимала цель рано, own ложился соседом).
    fn exact_at(
        &self,
        _goal: u64,
        _cur: u64,
    ) -> bool {
        false
    }
    /// [ОЖИДАНИЕ УЗЛА] недвигающий акт суда —
    /// «переждать поезд» фазового конвейера;
    /// None = мир не знает, как стоять здесь.
    fn idle_of(
        &self,
        _court: u64,
    ) -> Option<Self::Action> {
        None
    }
    /// Ребро (суд, акт) двусмысленно (два живых
    /// фазовых слота) — кандидат на ожидание.
    fn edge_is_phased(
        &self,
        _court: u64,
        _act: Self::Action,
    ) -> bool {
        false
    }
    /// [ЖЕСТ-ОБЪЕКТ, седьмой род] пере-вычислить
    /// клик-акт на ЖИВОМ кадре мира: эталонный
    /// (raw-ключ, байт) прожитой тройки → тот же
    /// ОБЪЕКТ на текущем кадре → его сегодняшний
    /// байт. None = жать как есть (двигательные
    /// акты переносимы; словарь не знает).
    fn rebind_act(
        &self,
        _ref_raw: u64,
        _act: Self::Action,
    ) -> Option<Self::Action> {
        None
    }
    /// [ГРАНИЦА «ДВЕРЬ МЕРТВА», обмен двух рук]
    /// СЫРОЕ множество дверей живых задач
    /// ({wa} ∪ капли их судных ключей) БЕЗ
    /// MVT-витрины: стабильно (меняется только
    /// пере-назначением задач), потому годится
    /// судом границы намерения — витринный снимок
    /// мигает и дребезжит (казнённая «ушла»).
    fn raw_task_doors(&self) -> Vec<u64> {
        Vec::new()
    }
    /// Execute one action. Successful results describe observed world outcomes;
    /// infrastructure failures never imply refusal, death, or a resumed state.
    /// A terminal marked Resumed requires an actual valid reset observation.
    fn act(&mut self, action: Self::Action) -> Result<ObservedAction, ActionFailure<Self::Action>>;
    /// Capture the action's own complete observation separately from any
    /// automatically resumed situation. Override when act() can replace the
    /// terminal frame. The legacy default never invents that terminal frame.
    fn act_captured(&mut self, action: Self::Action) -> ActionCapture<Self::Action> {
        action_capture::legacy(self, action)
    }
    /// The organ POSE this world exposes to the witness
    /// (П-ВНИМ-3 phase C): the lived efferent copy, or
    /// None when the world carries no gaze organ.
    /// CONTRACT: a pose is 0..=254 — 255 is the witness's
    /// «no organ» sentinel and a world must never return
    /// Some(255) (debug-asserted at the witness).
    fn pose(&self) -> Option<u8> {
        None
    }
    /// The "switch context" action (a teleport to the
    /// root), when the task has one; the L.7 wheel answers
    /// stagnation with it.
    fn reset_action(&self) -> Option<Self::Action>;
    /// [СТРАЖА СПРАШИВАЕТ МИР] мир свидетельствует:
    /// акт из этого суда прожит и его смерти
    /// погашены жизнью — бан организма опровергнут
    /// свежим фактом мира (двойной суд смерти душил
    /// доставку: план мира УЖЕ оплатил риск ценой
    /// (смерти, длина)). Default — мир молчит.
    fn act_absolved(
        &self,
        _state: u64,
        _act: Self::Action,
    ) -> bool {
        false
    }
    /// [СТРОГИЙ КОД] мир, чей жест-род — код
    /// (клики-кнопки: лишнее нажатие = ошибка):
    /// ноты в нём ХРУПКИ; движковый мир дожимает
    /// (повтор легален — фаза ловится). Default —
    /// движковый.
    fn strict_code(&self) -> bool {
        false
    }
    /// [МАКРО-ДОРОГА, В-3] субплан (пары акт+суд)
    /// с хвостом на суде цели — исполнение
    /// noted-каналом. Default — мир без словаря.
    fn macro_rail(
        &self,
        _goal: u64,
    ) -> Option<Vec<(Self::Action, u64)>> {
        None
    }
    /// [СОЛЬ-СДВИГ] мир свидетельствует: кадры
    /// несут сессионную соль (первый live-ресет
    /// приземлился мимо канона наследия) — вся
    /// наследованная позиционная память соль-зоны
    /// мертва; доставка — рельсой (ноты
    /// детерминированы актами). Default — соль
    /// не судима.
    fn salt_shift(&self) -> bool {
        false
    }
    /// [МИЛЯ-АКТ] мир велит: тело стоит на суде
    /// недожитого фазового ребра — вот акт
    /// кворума. Прямой приоритет ниже планов,
    /// выше мотора (m0r0: 369 посещений суда и
    /// ни одного нужного акта — рацион ≠ выбор).
    fn mile_act(&self) -> Option<Self::Action> {
        None
    }
    /// [ФАЗОВЫЙ ОТКАЗ] мир запоминает ребро,
    /// отказавшее исполнению LAW² подряд —
    /// маршруты его объезжают. Default — мир без
    /// леджера.
    fn note_refused(
        &self,
        _court: u64,
        _act: Self::Action,
    ) {
    }
    /// [ПРОДОЛЖЕНИЕ МЕСТА, свёртка №6] мир
    /// отдаёт КУПЛЕННУЮ последовательность актов,
    /// начинающуюся в этом суде: один источник
    /// макро-жестов вместо двух (перебор пар —
    /// лишь фолбэк пустого словаря). Валюта та
    /// же, что у всех чеканок — MDL прожитой
    /// ленты (`seq_mint`). Default — мир без
    /// словаря субпланов.
    fn macro_seq(
        &self,
        _court: u64,
    ) -> Vec<Self::Action> {
        Vec::new()
    }
    /// [ОТКАЗ ПОСТ-ВЕТКИ] мир запоминает
    /// несбывшееся ожидание плана: ребро
    /// (суд, акт) обещало пост-узел exp — мир
    /// дал иное; кворум LAW² вычёркивает ветку
    /// из оптимизма Дейкстры. Default — мир без
    /// леджера.
    fn note_refused_post(
        &self,
        _court: u64,
        _act: Self::Action,
        _expected_key: u64,
    ) {
    }
    /// [ЦЕЛЕВОЙ КОНТУР] мир велит маршрут к
    /// старшей задаче ОТ ТЕКУЩЕГО места (зрячая
    /// дорога): один орган доезда вместо шести
    /// заплат. None — целей нет, карта не знает
    /// дороги или тело уже на месте (тогда
    /// миля/рацион жмут дело). Default — мир
    /// без задачника.
    fn goal_route(
        &self,
    ) -> Option<Vec<(Self::Action, u64)>> {
        None
    }
    /// [РОД УЗЛА — СУД МИРА] живой суд мира
    /// стоит на узле дороги (сам или склейкой):
    /// сверка мировых шагов идёт МИРОМ — узлы
    /// дорог суть суды мира (court_state, без
    /// акта), а state организма — глазной ключ
    /// (fnv⊕акт): их сличение лгало всегда.
    fn at_court(&self, _node: u64) -> bool {
        false
    }
    /// живой суд мира СЕЙЧАС (без акта) — судья
    /// «тела на месте»: глазной ключ несёт акт и
    /// слеп к самопетле
    fn court_now(&self) -> Option<u64> {
        None
    }
    /// [VTE] ЧЕКПОЙНТ МИРА для грёзы: мир, умеющий
    /// сохраниться (локальные игры, моки, тест-миры),
    /// отвечает true — организм получает право
    /// ПРОКАТАТЬ акты на чекпойнте и откатить
    /// (vicarious trial-and-error: forward sweep на
    /// точке выбора; Redish-род). Грёза — не
    /// свидетельство: прокат НЕ проходит через
    /// организм (мир крутится напрямую, леджеры тела
    /// не пишутся). Сервер/необратимый мир отвечает
    /// false — организм грезит по прожитой карте, как
    /// прежде. Вложенные push законны (стек).
    fn dream_push(&mut self) -> Result<bool, ActionFailure<Self::Action>> {
        Ok(false)
    }
    /// [VTE] откат к последнему чекпойнту.
    fn dream_pop(&mut self) -> Result<(), ActionFailure<Self::Action>> {
        Err(ActionFailure::restore(ActionStage::Replay, "Habitat has no checkpoint to restore"))
    }
    /// [THE DOOR OF RULES] the world's frame as the door of rules reads it: a square grid of colours whose facts are
    /// the combat eye's objects (`rules`). A world without a frame feeds the door nothing and is not dreamt by it.
    fn rule_frame(&self) -> Option<Vec<u8>> {
        None
    }
    /// [THE DOOR OF RULES] an act's name for the door of rules: a key, a click at a cell of the frame, a reset.
    fn rule_act(&self, _a: Self::Action) -> Option<crate::rules::Act> {
        None
    }
}

/// The conscious feeding mode (EL-185/EL-187): the working
/// point (gamma, dt, lambda) where the organism clears all
/// four T-153 thresholds on rich worlds — found by sweep,
/// confirmed on three task genera (arena, room, session
/// worlds). ONE name instead of magic numbers per client.
pub const CONSCIOUS_GAMMA: f64 = 0.25;
/// The conscious mode's tick step.
pub const CONSCIOUS_DT: f64 = 0.01;
/// The conscious mode's injection (moderation buys R).
pub const CONSCIOUS_LAMBDA: f64 = 0.02;
/// The canon molt window (P-MOLT-ORG, lived by
/// `molt_heals_a_world_that_changed_its_law`): surprises
/// are counted over this many KNOWN transitions.
pub const CANON_MOLT_WINDOW: usize = 30;
/// The canon molt threshold within [`CANON_MOLT_WINDOW`]:
/// at this many surprises the map is declared a lie and
/// re-earned.
pub const CANON_MOLT_THRESHOLD: usize = 6;

/// Feature normalisation into the floored simplex (the
/// [`Habitat`] contract): every feature >= 1e-6, sum 1. One
/// function for every bridge — sessions, arenas, worlds.
#[must_use]
pub fn normalise_features(raw: &[f64; 7]) -> [f64; 7] {
    let mut f = [0.0f64; 7];
    let mut tot = 0.0;
    for (dst, &a) in f.iter_mut().zip(raw.iter()) {
        *dst = a.abs().max(1e-6);
        tot += *dst;
    }
    for dst in &mut f {
        *dst /= tot;
    }
    f
}

/// The conscious-by-construction food anchor (EL-176):
/// `(1-l)*I/7 + l*|psi><psi|` with uniform `|psi>` and
/// `l = 0.6`.
///
/// # Panics
/// Never: the anchor is a valid density matrix by
/// construction.
#[must_use]
pub fn conscious_anchor() -> Gamma {
    let lam = 0.6;
    let mut h = Herm7::identity().scaled((1.0 - lam) / 7.0);
    for i in 0..N {
        for j in i..N {
            let v = h.get(i, j) + C64::new(lam / 7.0, 0.0);
            h.set_hermitian(i, j, v);
        }
    }
    Gamma::try_from_herm(h, 1e-9).expect("valid anchor")
}

/// THE HEART TICK (E-wave slice 1, moved whole from the
/// arena's gamma contour): seven features feed the anchor
/// (Givens food), the canonical Strang step drives Γ toward
/// the NAMED conscious mode (D3: EL-185/187), and the
/// returned |dΓ| is the climate the duo-wheel listens to.
/// One home for the physics — adapters keep only percepts
/// (features) and traces. `#[inline(never)]`: the judged
/// formula is pinned against cross-crate ULP forks (the
/// `beta_mix_step` lesson).
#[inline(never)]
pub fn heart_tick(
    features: &[f64; 7],
    base: &Gamma,
    g: &mut Gamma,
) -> f64 {
    use synarc_math::channels::strang_step_towards;
    let food = food_from_features(features, base);
    let (g2, _tick) = strang_step_towards(
        g,
        None, synarc_math::Regime { gamma: CONSCIOUS_GAMMA, dt: CONSCIOUS_DT, omega0: 1.0 },
        &food,
    );
    let mut dg = 0.0;
    for i in 0..N {
        for j in 0..N {
            let d = g2.herm().get(i, j)
                - g.herm().get(i, j);
            dg += d.norm_sqr();
        }
    }
    *g = g2;
    dg.sqrt()
}

/// Food from features (EL-177): seven Givens rotations of
/// the anchor in the (k, k+1 mod 7) planes with angles
/// `theta_k = 2*f_k`.
#[must_use]
pub fn food_from_features(f: &[f64; 7], base: &Gamma) -> Gamma {
    let mut u = [[C64::new(0.0, 0.0); N]; N];
    for (i, row) in u.iter_mut().enumerate() {
        row[i] = C64::new(1.0, 0.0);
    }
    for k in 0..N {
        let (a, b) = (k, (k + 1) % N);
        let th = 2.0 * f[k];
        let (c, s) = (th.cos(), th.sin());
        for col in 0..N {
            let ua = u[a][col];
            let ub = u[b][col];
            u[a][col] = ua.scale(c) + ub * C64::new(0.0, -s);
            u[b][col] = ua * C64::new(0.0, -s) + ub.scale(c);
        }
    }
    let ah = base.herm();
    let mut tmp = [[C64::new(0.0, 0.0); N]; N];
    for i in 0..N {
        for j in 0..N {
            let mut acc = C64::new(0.0, 0.0);
            for k in 0..N {
                acc += u[i][k] * ah.get(k, j);
            }
            tmp[i][j] = acc;
        }
    }
    let mut out = Herm7::identity().scaled(0.0);
    for i in 0..N {
        for j in i..N {
            let mut acc = C64::new(0.0, 0.0);
            for k in 0..N {
                acc += tmp[i][k] * u[j][k].conj();
            }
            out.set_hermitian(i, j, acc);
        }
    }
    Gamma::try_from_herm(out, 1e-7).unwrap_or(*base)
}

/// The E-carrying Fano line through an axis: the one child
/// genus that feeds the parent's kappa0 (the K.2 iv
/// neurogenesis addressing — the soma's logic verbatim).
fn e_carrying_line_through(axis: usize) -> Option<usize> {
    let lines = synarc_math::fano::lines();
    let a = Axis::from_index(axis)?;
    lines
        .iter()
        .position(|l| l.contains(a) && l.contains(Axis::Interiority))
}

/// The organism's organ body: the §05 cascade at the tower
/// base, fed the same food; a chronically hungry axis (a
/// syndrome) births an organ on the E-carrying line through
/// it. Knobs are the soma's defaults.
#[derive(Debug)]
struct Organs {
    body: CascadeNode,
    since_spawn: u64,
    spawned: u32,
    spawned_lines: Vec<usize>,
}

impl Organs {
    fn new(anchor: &Gamma) -> Self {
        Self {
            body: CascadeNode::root(*anchor),
            since_spawn: 0,
            spawned: 0,
            spawned_lines: Vec::new(),
        }
    }

    fn on_food(&mut self, food: &Gamma) {
        self.body.feed(food, 10.0, 0.02);
        let knobs = CascadeTick {
            gamma: 0.5,
            dt: 0.02,
            omega0: 1.0,
            injection: 0.1,
            merge_threshold: 0.02,
            cooldown: 50,
        };
        self.body.tick(None, &knobs);
        self.since_spawn = self.since_spawn.saturating_add(1);
        if self.since_spawn >= 100 {
            // Two detectors of two diseases: STRESS
            // (discord, the K.2 syndrome) and DIET
            // (concordant impoverishment — an axis with a
            // chronically hungry diagonal; the stress
            // syndrome is blind to it: a body that accepted
            // poor food is not strained).
            let stress_axis = invariants::syndrome_axis(
                invariants::syndrome_bits(self.body.gamma()),
            );
            let diet_axis = stress_axis.or_else(|| {
                let g = self.body.gamma();
                let mut axis = 0usize;
                let mut low = f64::INFINITY;
                for k in 0..7 {
                    let w = g.herm().get(k, k).re;
                    if w < low {
                        low = w;
                        axis = k;
                    }
                }
                (low < 1.0 / 7.0 - 0.01).then_some(axis)
            });
            if let Some(axis) = diet_axis {
                if let Some(line) = e_carrying_line_through(axis) {
                    if self.body.spawn(line).is_ok() {
                        self.spawned += 1;
                        self.spawned_lines.push(line);
                        self.since_spawn = 0;
                    }
                }
            }
        }
    }
}

/// How real one autogeny floor is in THIS organism — the
/// anti-misreport scale: a floor counts only for what has
/// actually happened, never for what a builder promised.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FloorMark {
    /// No mechanism for this floor is even built in.
    Missing,
    /// The mechanism is wired but has not fired in this
    /// life.
    Installed,
    /// The mechanism has LIVED — the floor is real.
    Lived,
}

/// THE AUTOBATHY PROFILE (autogeny programme item 5): how
/// deep into itself this organism actually reaches, floor
/// by floor of the self-depth ladder — and the number 𝔞 =
/// the length of the unbroken LIVED prefix. Growth of 𝔞
/// over a life is the formal meaning of «growable».
///
/// The floors, mechanised here as:
/// 0 inert — holds state (the earned geography);
/// 1 predicative — sees its own past as an object (the
///   glass trace has recorded ticks);
/// 2 measuring — judges itself (a molt or a rut verdict
///   has fired);
/// 3 reflexive — re-chooses its own representation at the
///   price of ⊥ (the key ladder has climbed a rung);
/// 4 autopoietic — reproduces and repairs its own parts
///   (an organ was born, or a dream reconsolidated the
///   past and regenerated the body);
/// ω autoplectic — the full self-model closure: honestly
///   MISSING today, and said so.
#[derive(Debug, Clone, Copy)]
pub struct AbathyProfile {
    /// Floors 0..=4, in ladder order.
    pub floors: [FloorMark; 5],
    /// The autoplectic closure — named, not pretended.
    pub omega: FloorMark,
    /// The number 𝔞: the length of the unbroken LIVED
    /// prefix — 0 = nothing has lived yet, 1 = a stone
    /// (state held), …, 5 = the whole ladder through the
    /// autopoietic floor.
    pub a: u8,
}

/// One step's pulse — what shows on the outside.
#[derive(Debug, Clone, Copy)]
pub struct Pulse<A> {
    /// The executed action.
    pub action: A,
    /// Did the step open a new situation.
    pub novel: bool,
    /// The tick's bodily climate ||dGamma|| at the base.
    pub climate: f64,
    /// The wheel channel, when it seized BEFORE this step.
    pub takeover: Option<Takeover>,
}

/// The lived stretch's summary.
#[derive(Debug, Clone, Copy)]
pub struct LifeReport {
    /// Distinct situations seen.
    pub uniq: usize,
    /// Body seizures of the wheel.
    pub body_seizures: u64,
    /// Mind seizures of the wheel.
    pub mind_seizures: u64,
    /// The tower frame at the stretch's end.
    pub tower: [LevelFrame; crate::tower::LEVELS],
    /// Organ-body nodes (1 = no organs or a single root).
    pub organ_nodes: usize,
    /// Organs born over the life.
    pub organs_spawned: u32,
}

/// The universal cognitive organism: tower x wheel x
/// geography x curiosity, generic over the task.
#[derive(Debug)]
#[allow(
    clippy::struct_excessive_bools,
    reason = "each bool is an independent organ switch \
              (patrol, licence, ladder, gaze); the typed \
              organ registry that would absorb them is a \
              written road, not a debt to hide"
)]
/// СК THE GLUE ORGAN (prereg-glue-organ, struck by both
/// hands): the missing DOWNWARD half of the partition
/// ladder. Evidence is LOCAL (У-1, the GUILT-2 lesson):
/// (situation, gesture) → the IMMEDIATE outcome over the
/// Habitat-observable alphabet {moved, stayed, death} —
/// death a separate outcome (У-2: one deadly taste is
/// automatically expensive to any merge). The court is
/// the one partition market (У-3): greedy agglomeration
/// by the sign of bits(apart) − bits(merged), KT over
/// outcome counts, no thresholds; it sits ON BOREDOM
/// (the novelty frontier came up empty — the lived
/// moment of generalization, no new cadence constant).
/// Т-ЯРУС is the zero-price limit case (У-4, theorem).
#[derive(Clone, Copy)]
enum GlueOutcome {
    Moved,
    Stayed,
    Death,
}

/// Организм: единый носитель жизни (ARC-клетки,
/// текст-байты, любой Habitat) — рынки, суды,
/// леджеры и каскад выбора одного закона.
#[derive(Debug)]
pub struct Organism<
    A: Copy
        + Eq
        + std::hash::Hash
        + Ord
        + crate::worldmap::Wire,
> {
    action_failure: Option<ActionFailure<A>>,
    action_stop: Option<(A, TerminalKind)>,
    terminal_receipts: Vec<TerminalReceipt<A>>,
    /// Physical dispatch owns ticks and terminal time transitions. A caller
    /// restart declares a distinct origin; exhausted episode identity never wraps.
    source_time: causal_coordinates::physical_time::Clock,
    action_attempts: u64,
    declared_task: Option<declared_task::TaskSession>,
    goal_attempts: std::collections::BTreeMap<A,u64>,
    goal_report: Option<GoalDecisionReport<A>>,
    /// СК: immediate-outcome counts per (state, gesture).
    glue_counts: HashMap<(u64, A), [u32; 3]>,
    /// Г4 (Б2-О3): situations whose ledgers changed since
    /// the last market sitting. The incremental market
    /// re-judges ONLY groups touched by these — О1 proves
    /// the untouched pairs hold their KT sign, so a dirty
    /// rebuild ≡ the full one (the full form stays in the
    /// code as the court's reference twin).
    glue_dirty: std::collections::HashSet<u64>,
    /// СК: state → class representative (path-compressed
    /// on read; identity when absent).
    glue_rep: HashMap<u64, u64>,
    /// СК v2: representative → folded members (the
    /// split court needs per-member ledgers).
    glue_members: HashMap<u64, Vec<u64>>,
    /// Z-6 НА ПЛАНОВОМ НОСИТЕЛЕ (серия-2000: 62% caps
    /// горят на дороге к вечно-непрожитым глубинам —
    /// план-к-фронтиру не ценил дорогу): умер, идя по
    /// плану к цели — виновна ЦЕЛЬ; могила цели
    /// опровержима её достижением. Новая гранулярность
    /// вины (Т-ГРАН): вина плана живёт на цели плана.
    plan_goal: Option<u64>,
    goal_graves: crate::holdings::Graves<u64>,
    /// А1-грань-7 (могила без права ревизии — сама
    /// лимит-цикл): life_age последних похорон цели; сон
    /// могилы = (похороны+LAW) × средний межпохоронный
    /// интервал (из собственного леджера — без ручек);
    /// давность будит редкий retest, неверная фаза
    /// удлиняет сон (самозащита), достижение опровергает
    /// (уже в кремнии). Вечная могила — двойник
    /// G1_GRAVE_ETERNAL (М-4-щит).
    /// А1-кольцо: ожидаемое состояние после последнего
    /// планового жеста — план ОПРОВЕРЖИМ ФАКТОМ: если
    /// мир пришёл не туда (ресет посреди пути, сдвиг
    /// фазы), план сгорает и не исполняется вслепую
    /// (вечный план-к-недостижимому был 18-циклом).
    plan_expect: Option<u64>,
    /// [ФАЗОВЫЙ ОТКАЗ] копилка свидетельств до
    /// слива в мир (kill-точка не видит мира)
    pending_refusals: Vec<(u64, A)>,
    /// Версия карты в момент постройки плана: сгорание
    /// хоронит цель ТОЛЬКО если карта с тех пор ничему
    /// не научилась (version тот же — план был пуст по
    /// знанию); научилась — сгорание уже оплачено
    /// знанием, цель не виновата (яд композиции: юные
    /// карт-планы сгорали → хоронили цели → оба
    /// планировщика голодали: 357/1500).
    plan_version: u64,
    /// Сырой ключ мира на текущем такте (для карты:
    /// канон сырых ключей) и сырой исток жизни.
    cur_raw_key: u64,
    cur_sensory: Option<Sensory>,
    root_raw: Option<u64>,
    /// М-СТЕКЛО: событийный буфер леджер-сдвигов такта
    /// (burial/ban/arrival/plan_burn/retest; rod=self у
    /// рода-3 самоинтервенций) — раннер дренирует после
    /// строки жеста (И-7: жест раньше своих событий).
    /// [СТЕКЛО ПО ТРЕБОВАНИЮ, Ф4] формат-строки
    /// пишутся ТОЛЬКО при включённом сливе:
    /// 64К+ format!-аллокаций за прогон копились
    /// в Vec и умирали непрочитанными без
    /// G1_MSTEKLO (единственный слив).
    glass_on: bool,
    glass_events: Vec<String>,
    /// Т-КЛЮЧ В ЖИВОМ ЦИКЛЕ: купленные координаты по
    /// сырому ключу (период органных часов от root);
    /// карта пишет ЧЕКАНЕННЫЕ ключи с момента покупки —
    /// свежие рёбра копят чистую массу, старые смешанные
    /// теряют вес сами (инкремент без ретро-перечеканки).
    coords: HashMap<u64, Vec<u32>>,
    /// [Ф13-1] ЛЕДЖЕРЫ ДЕРЖАНИЙ монет (суд двух часов):
    /// рождение = +net_birth; свежие улики сидок ±; без
    /// улик — заморожен; смерть при ≤ −net_birth;
    /// проданное продано (sold-set — пути назад нет).
    coin_ledger: HashMap<(u64, u32), f64>,
    coin_sold: std::collections::HashSet<(u64, u32)>,
    /// Органные часы: тактов с последнего root-прибытия
    /// (root — собственное понятие организма).
    since_root: u32,
    /// Закон удвоения сидок рынка (как сон ледника):
    /// рынок сидит, когда прожитых тактов вдвое больше,
    /// чем на прошлой сидке — log-много сидок за жизнь
    /// (сидка на каждой скуке была патологией: рынок
    /// дороже жизни).
    coin_sat_at: u64,
    coin_tacts: u64,
    /// Сидка по СОБЫТИЮ: рождений ветвлений на прошлой
    /// сидке (рынок слушает карту — нулевая ручка).
    coin_births_at: u64,
    /// СУД РУЛЯ (эталон holon steering_gate_ref, GREEN
    /// 4/4): обе руки предсказывают цену остатка до цели
    /// в единой валюте c = m + λ·L; прожитый остаток
    /// судит обе (меньшая |ĉ−c| побеждает); KT-счёт
    /// побед, руль = знак лог-оддсов ((w_map+½)/(w_exam
    /// +½)); ничьи не двигают. KT-прайор = барьер юности
    /// Б2 конструкцией. Двойник G1_NO_STEER=1 —
    /// фолбэк-композиция без руля.
    steer_w_map: u32,
    steer_w_exam: u32,
    /// Незавершённое предсказание пары: (ĉ_map, ĉ_exam,
    /// life_age старта, смертей на старте).
    steer_pending: Option<(u64, u64, u64, u64)>,
    steer_lane: [u32; 4],
    steer_autopsy: [u32; 4],
    /// [НАМЕРЕНИЕ-КАК-ДЕРЖАНИЕ] задачи мира на этот
    /// тик: (адрес, дефицит) — снимок из step_inner
    world_tasks: Vec<(u64, u32)>,
    /// [ПРЕРЕГ-23 РЫНОК ЖЕЛАНИЙ, V1] леджеры двух
    /// торговцев: любопытство платит НОВЫМИ
    /// тройками table, служение — гашениями,
    /// сведёнными прожитым курсом (новых троек за
    /// жизнь / гашений за жизнь); KT(+½) обоим;
    /// право LAW первых проб каждому до рынка;
    /// суд только на границах планов.
    mk_cur_acts: u64,
    mk_cur_new: u64,
    mk_serve_acts: u64,
    mk_new_life: u64,
    /// [ревью-грань-(г)] гашения ДЕЛЬТА-СЪЁМОМ в
    /// леджер организма: все четыре числа рынка —
    /// один носитель, одно окно (мир пересоздаётся
    /// проходами; его счёт напрямую рвал окна)
    mk_pays: u64,
    mk_pays_seen: u64,
    /// [V2-ВАЛЮТА] платёж приписан юрисдикции
    /// ПРОЖИТОГО акта (R16-шрам: гашения tu93
    /// всегда были ПОПУТНЫМИ — езда любопытства
    /// платила мимоходом, серв-планы съели езду и
    /// валюту вместе с ней)
    mk_pays_cur: u64,
    mk_pays_serve: u64,
    /// [НЕВЫМИРАНИЕ ПРОБЫ] жребий Кронекера по
    /// долям: аккумулятор доли серва (квант 2^20);
    /// серв пробуется с частотой r_s/(r_s+r_c) —
    /// эскейп никогда не ноль, детерминизм цел
    /// (cd82-замок: после LAW-проб серв не
    /// избирался никогда — r_cur вечно богат
    /// фазовой лавиной, порочный круг голода)
    mk_kron: u64,

    /// [РЫНОК-СТЕКЛО] [входов-на-границах,
    /// капель-жребия, выборов-серва, выборов-cur,
    /// LAW-прав-осталось-серву]
    mk_glass: [u64; 5],
    /// граница эпохи прав: уровень тела последнего
    /// возврата LAW-прав
    mk_epoch_level: u32,
    /// [ЦЕЛЬ-ПАМЯТЬ, суд двух рук] намерение живёт
    /// от выбора до ГРАНИЦЫ; план — одноразовое
    /// исполнение; re-plan после рвача бесплатен от
    /// рынка. Границы: LAW доигранных-недоехавших
    /// (наст. попытки, пререг-18) → отпуск рынку;
    /// LAW² рвачей (кап: вечный ресет-мир не держит
    /// цель навсегда); смена уровня тела.
    hold_goal: Option<u64>,
    hold_torn: u32,
    hold_fail: u32,
    /// [МЕЖА] снимки счётчиков на границе
    /// дидактика→свобода
    fr_task_glass: [u32; 4],
    fr_mk_glass: [u64; 5],
    fr_knocks: u32,
    fr_marked: bool,
    /// [СКУКА] жизнь повторилась буквально (ни
    /// одной новой тройки за проход) — взводится
    /// миром/цепью; ломатель гасит одним актом
    bored: bool,
    // [АКТ-УГАСАНИЕ, закон трёх диких] счёт
    // ПОДРЯД бесплодных прожитий пары (pre==post
    // или откат в корень): LAW подряд — временная
    // могила в свободном выборе (план и миля
    // свободны); все акты state в могиле —
    // амнистия state (мир мог смениться).
    // ka59: 43% жизни в ресет-спаме; su15: 83%
    // в мёртвом акте-10; re86: 78K самодавлений.
    // [СВЁРТКА №1] закон ренты живёт ОДИН РАЗ
    // (synarc_store::rent): пара (место, акт) —
    // такой же резидент, как руна или страница;
    // визиты дают зрелость, новизна обнуляет
    // бесплодность, гибель хоронит сразу.
    barren: HashMap<(u64, A), synarc_store::rent::Rent>,
    // [МАКРО-ПРОБА У ЗАМКА, род-Б lf52/ka59]
    // одиночные акты исчерпаны кругами могил —
    // замок открывается ПАРОЙ подряд: счётчик
    // комбинаций (i,j) по меню state и очередь
    // второго акта пары (исполняется forced-
    // веткой, минуя выбор).
    /// [ПЛАТА ОТМЕНЯЕТ БЕСПЛОДНОСТЬ] высшая
    /// отметка прогресса мира: её рост —
    /// свидетельство оплаты такта.
    progress_seen: f64,
    combo_next: HashMap<u64, u32>,
    combo_queue: std::collections::VecDeque<A>,
    /// стекло скуки: [скучных проходов, ломателей
    /// прожито, новых троек после последнего]
    bore_glass: [u64; 3],
    /// счёт прожитий пар (для ломателя скуки:
    /// настоящий аргмин, не 0/1)
    lived_pairs: HashMap<(u64, A), u32>,
    /// [ЛОМАТЕЛЬ-ДОРОГА] скука оплачивает риск:
    /// Дейкстра шагами без смертного штрафа
    bored_risk: bool,
    /// [ПОСЛЕДНЯЯ МИЛЯ, кап] сухие постройки мили
    /// (без дожития кворума): LAW подряд возвращает
    /// обычный порядок до новой эпохи (note_boredom
    /// сбрасывает; ноль фазовых целей — тоже)
    mile_dry: u32,
    /// [ПАЛОМНИК] стекло [зовов, дошёл-до-ресета,
    /// хвост-исполнен, доезд, own-на-цели]
    pilgrim_glass: [u64; 5],
    /// приоритет хвоста: столько тактов выдача
    /// плана идёт РАНЬШЕ рефлекса (ставится длиной
    /// хвоста при пережитой плановой смерти)
    pilgrim_hold: u32,
    /// кап: LAW бесплодных паломничеств подряд —
    /// обычная скука до эпохи (note_boredom
    /// сбрасывает)
    pilgrim_dry: u32,
    /// живая дальняя цель паломника
    pilgrim_goal: Option<u64>,
    /// [ЖИВОЙ КОНТУР] план положен ДОРОГОЙ МИРА:
    /// пере-прокладывается от фактического суда
    /// каждый такт (исходы актов дрожат — слепое
    /// исполнение уводит мимо; t10-t12 ft09).
    world_road: bool,
    /// [СУД НЕВОЗМОЖНОСТИ ДОРОГИ, u38w: 584
    /// пере-прокладки одной двери] такты жизни
    /// текущей мировой дороги; бюджет = LAW ×
    /// длина первой прокладки — дальше цель
    /// признаётся фактически недостижимой ЗДЕСЬ,
    /// зов сгорает (жертвенная механика возьмёт
    /// своё второй жизнью/ресетом).
    world_road_ticks: usize,
    /// [Д-27 вахта] расхождения штампа витрины
    /// с живым меню (под ARC_WATCH_MENU)
    menu_stale: u64,
    /// [ПЕРЕЖДАТЬ ПОЕЗД] последний суд, с
    /// которого мировая дорога уходила
    /// двусмысленным ребром (фазовая попытка)
    world_try: Option<(u64, u64)>,
    /// [СМЕРТЬ ОПРОВЕРГАЕТ КАНАЛ, f2-разрез:
    /// жертвенные дороги канала гибли 6/7 на
    /// конвейере — канал слеп к смертям рёбер,
    /// дорога мира их видит] цель, чья канальная
    /// дорога опровергнута смертью экспедиции:
    /// следующий зов первенствует ДОРОГОЙ МИРА
    /// (уверенность без спора — ложная
    /// уверенность, для дорог).
    exp_refuted: Option<u64>,
    /// [ПАРА НЕДЕЛИМА] кадр последней пере-
    /// прокладки мировой дороги
    world_road_key: Option<u64>,
    /// [ФЛИП — ПРИБЫТИЕ В МИР ЗАДАЧ] уровень
    /// прошлого такта (смена вверх при задачах
    /// нового уровня зовёт дорогу немедленно —
    /// ft09: 162 own-флипа гибли в юном L2 за
    /// 1-3 такта до всякого зова)
    last_here: Option<u32>,
    /// [ГРАНЬ КАПА, s53] план дожил до своего
    /// ресета: только такой считается ПОПЫТКОЙ —
    /// смерть до первого шага есть сырость
    /// постройки, не бесплодность (пререг-18-род:
    /// похороны только доездом; кап против
    /// вечного похода не смеет душить
    /// ученичество)
    pilgrim_ripe: bool,
    /// [СТЕКЛО-ЧИНКА s54] первый шаг паломничьего
    /// плана ИСПОЛНЕН фактом выдачи (мягкие миры
    /// не знают Cut::Death-взвода — метка по
    /// укоротившемуся плану)
    pilgrim_started: bool,
    /// длина плана на зове
    pilgrim_len0: usize,
    /// [ФЛИП-КАНОН, честный носитель] этаж места
    /// ВЫДАЧИ последнего планового шага: сгорание
    /// сравнивало уровни exp и state — а при
    /// прыжке они всегда равны (оба — приземление):
    /// гейт был мёртвой веткой с рождения (R68:
    /// exp=179166/state=179567, оба L3, остаток 0).
    /// Межуровневость шага судится этажом выдачи
    /// против этажа приземления.
    plan_step_lv: Option<u32>,
    /// выданный шаг плана был РЕСЕТ-актом —
    /// межпопыточная дверь (родня флипа)
    plan_step_reset: bool,
    /// [ФАЗОВЫЙ ШАГ ДЕРЖИТ ТЕЛО] суд тела в
    /// момент выдачи шага плана — «на месте» =
    /// фазовое несрабатывание
    plan_step_pre: Option<u64>,
    /// повторы фазового шага (кап LAW²)
    plan_phase_retry: u32,
    /// акт последнего выданного шага плана
    last_step_act: Option<A>,
    /// узел-назначение последнего шага МИРОВОЙ
    /// дороги (суд мира)
    plan_step_ref: Option<u64>,
    /// суд мира в момент выдачи шага плана —
    /// носитель «на месте» (мир не сдвинулся)
    plan_step_court: Option<u64>,
    /// [НОТЫ УЧИТЕЛЯ] план — own-реплей урока
    /// (перворожденная рельса): стража ему не
    /// судья (урок жил и победил — высшее
    /// свидетельство; глубинные рёбра невинны и
    /// отпущение молчит, а баны массой миллионов
    /// тактов нижних уровней рвали ноты — 60
    /// стражей на пробе tu93)
    plan_notes: bool,
    /// [ПРИБОР РОДА НОТ] дожатия нот, за
    /// которыми суд сдвинулся (дожал — фазовое
    /// свидетельство) vs ноты, доигранные
    /// повторами без WIN (строгое) — валюта
    /// будущего рынка рода
    notes_retry_hits: u32,
    /// ноты доиграны/погашены без own-WIN
    notes_spent: u32,
    /// [ЛЕСТНИЦА ПЛАТИТ ПРОВАЛАМИ] счёт неудач
    /// целей зова ЭТОЙ жизни (сгорание, доигрыш
    /// без доезда) — порядок лестницы
    pilgrim_fails:
        std::collections::HashMap<u64, u32>,
    /// [СОЛЬ-СВИДЕТЕЛЬСТВО] тело прожило
    /// расхождение ресет-приземления с памятью
    /// (кадры мира несут сессионную соль) — вся
    /// наследованная позиционная память в
    /// соль-зоне системно лжива
    salt_seen: bool,
    /// [РЕСЕТ-ПАЛОМНИЧЕСТВО] сгорания живой
    /// дороги к ТЕКУЩЕЙ цели паломника: LAW
    /// подряд — живая сокращёнка фикционна
    /// (вход own=0 пять прогонов), зов строит
    /// от КОРНЯ с ресет-префиксом (повтор
    /// урока целиком; вторая жизнь и приоритет
    /// хвоста уже ждут)
    pilgrim_burn_cnt: u32,
    /// [ЖЕСТ-ОБЪЕКТ, седьмой род — вся дорога]
    /// эталонные кадры КАЖДОГО шага exam-плана
    /// (pre из сон-дороги, синхронно plan): на
    /// выдаче шага мир пере-вычисляет байт по
    /// объекту живого кадра (rebind_act; None =
    /// жать как есть — двигательные акты
    /// переносимы). Рассинхрон длины = не сметь
    /// ребиндить (планы мили/стука/карты рефов
    /// не несут).
    plan_refs: std::collections::VecDeque<u64>,
    /// [ЖЕРТВЕННЫЙ ТРАНЗИТ, суд двух рук]
    /// экспедиционный режим: все живые цели —
    /// соседний уровень (на своём делать нечего) →
    /// задачный план строится ценой риска; кап
    /// азарта: LAW жертвенных построек подряд без
    /// гашения → обычная цена до новой эпохи.
    exp_streak: u32,
    exp_cold: bool,
    /// [построек, доездов, смертей-в-пути]
    exp_glass: [u64; 3],
    /// [РАЗДЕЛЕНИЕ НОСИТЕЛЕЙ] акты ЗНАНИЯ по
    /// ключу (индекс table для ходьбы
    /// планировщика; seen остаётся носителем ПРОБ
    /// тела — сон его не трогает)
    table_acts: HashMap<u64, Vec<A>>,
    /// сухость фронтира: ломатели подряд без
    /// единой новой тройки (LAW → цель из задач)
    dry_breaks: u32,
    /// цель-стекло: [выбрана, рвачей-при-held,
    /// отпущена-LAW, отпущена-капом-рвачей,
    /// отпущена-уровнем, гашена/исчезла]
    hold_glass: [u64; 6],
    /// РВАЧ-СТЕКЛО — раскол other на роды палачей
    /// (суд рукавов, не вера): [стража-выдачи,
    /// End-мира, свой-ресет-ЧУЖИМ-актом,
    /// свой-ресет-ШАГОМ-ПЛАНА]. Последний род —
    /// кандидат ложного палача: прыжок, который
    /// таблица знала (ресет-ребро — шаг дороги),
    /// рвётся досрочно, хотя burn-суд следующего
    /// такта сам оправдал бы план.
    tear_kinds: [u32; 4],
    /// [СТУК В ДВЕРЬ] жест-стекло: построенных
    /// стук-планов (тело на цели, план = один
    /// жест); доезд-с-жестом различим от немого —
    /// оплату говорят события гашений.
    knocks: u32,
    /// [MAP-ДОВОДКА] расчеканка узлов карты:
    /// coined → raw (карта живёт в чекане
    /// coined_key(raw, since_root), цели мира — в
    /// raw; goal-тест сравнивал разные роды и
    /// совпадал только у root: tu93 213 хитов на
    /// близких дверях, ft09 0 на глубине при
    /// 33481 exam-плане «мимо»)
    unmint: HashMap<u64, u64>,
    /// [ПРЕРЕГ-19] леджер грёзы: узлов прожжено,
    /// планов куплено, возраст последней покупки,
    /// молчаний по MVT
    dream_nodes: u64,
    dream_plans: u64,
    dream_last_buy: u64,
    dream_muted: u64,
    /// [ПРЕРЕГ-16c] мир держит ЖИВЫЕ задачи
    /// (до уровневого фильтра): ресет «при полном
    /// знании» законен только при пустоте мира —
    /// иначе дорога глубже, руль ведёт к WIN
    /// (пасть L1: тело жгло 84-91% жизни в цикле
    /// добровольных ресетов при живых целях)
    any_world_tasks: bool,
    /// стекло служения: [map-план к задаче найден,
    /// map None, exam-план найден, exam None]
    task_glass: [u32; 4],
    /// план построен при живых задачах (пометка
    /// для леджера причин его смерти)
    plan_is_task: bool,
    /// источник плана: карта (макро-рёбра, ветвление
    /// уплачено) или exam-таблица (микро-план,
    /// валиден только на точном пути)
    plan_from_map: bool,
    /// языковых чисток банов (линька: bans.clear)
    ban_lang_clears: u32,
    /// СМЕРТНЫЕ баны отдельно от отказных: ярусы
    /// живут LAW отказов — стража выдачи и серия
    /// опровержения судят ТОЛЬКО смертную массу
    /// (свод v5: стража по смешанному счётчику
    /// душила отказные рёбра — 8 стендов ярусов)
    deadly_bans: HashMap<(u64, A), u32>,
    /// серия ЖИВЫХ проходов по забаненному ребру:
    /// опровержение ТЯЖЁЛОГО бана (масса >= LAW)
    /// требует LAW живых подряд — одно выживание
    /// случайность, серия — смена мира (примирение
    /// ForcedGate-канона с убийцей tu93)
    retest_streak: HashMap<(u64, A), u32>,
    /// [77b37a38, ФАЗОВЫЙ ГОЛОД ПОД ЗАМКОМ] старый
    /// канон переоценки: тяжёлый бан опровержим одним
    /// живым проходом. Замок (streak >= mass) — боевое
    /// число tu93; малые миры стендов под замком
    /// голодают фазами (лестница смертей глохнет,
    /// этажи не рождаются — банк/мета немы). Ручка
    /// НАЗВАНА; env G1_RETEST_SIMPLE остаётся
    /// диагностическим оверрайдом процесса.
    retest_simple: bool,
    /// причины смерти планов-к-задаче:
    /// [сгорание фактом, takeover-захват,
    /// исчерпан (дошёл), прочие сбросы]
    task_plan_death: [u32; 4],
    /// цели exam-планов служения: goal → (планов,
    /// Σдлин) — К КОМУ тело реально идёт
    task_goal_census:
        std::collections::HashMap<u64, (u32, u64)>,
    /// [ПРЕРЕГ-9] попытки доставки по адресу;
    /// кворум LAW² хоронит недоставимый
    task_attempts: HashMap<u64, u32>,
    /// могилы недоставимых адресов (сон 2^burials
    /// в валюте планирований)
    task_graves: crate::holdings::Graves<u64>,
    /// часы служения: планирований-к-задачам
    task_plan_clock: u64,
    /// Ребро последнего планового жеста (сырой ключ,
    /// такт часов, жест) — суд сгорания сверяется с
    /// картой: приход в ИЗВЕСТНУЮ ветку ребра = не
    /// ложь, а уплаченная неопределённость (describes-
    /// мир: бросок вопроса жёг планы и рвал поток улик
    /// exhaust-а — wrong=44 лечился этим судом).
    plan_edge: Option<(u64, u32, A)>,
    /// Последняя цена exam-плана (заполняет exam-Дейкстра
    /// при находке цели).
    last_exam_cost: Option<(u64, u32)>,
    /// Ограниченная лента жизни для рынка координат:
    /// (сырой ключ, жест, исход, часы) — рынок судит
    /// недавнее прожитое на границах скуки/смерти.
    live_tape: std::collections::VecDeque<(
        u64,
        A,
        crate::worldmap::Outcome<u64, u8>,
        u32,
    )>,
    /// Г-СТЕКЛО ВЫБОРА (урок четырёх бит-в-бит-прогонов:
    /// чинить ветку, не зная её живости, — гадание):
    /// счётчик срабатываний КАЖДОЙ ветки choose_action —
    /// [valent, untried-справка, untried-первый, план,
    /// патруль, кольцо, avoidance, takeover]; мёртвая
    /// ветка видна одним прогоном без интерпретаций.
    choice_counts: [u64; 12],
    /// Было ли движение ключа с последнего ресета
    /// (закон плодотворного цикла: фолбэк-ресет
    /// разрешён только после похода; DeadPose-шторм
    /// = вечный ресет без единого шага).
    moved_since_reset: bool,
    /// ПЛОДОТВОРНОСТЬ-V2: с прошлого ресета посещён
    /// новый класс (su15-шторм: движение вечно в
    /// мире сборки — плодотворность судится
    /// НОВИЗНОЙ; G1_MOVED_RESET=1 — архив движения).
    novel_since_reset: bool,
    /// Г-СТЕКЛО ЦЕЛЕЙ: перепись plan_goal при постройке
    /// плана — вечный фронтир виден поимённо, не суммой.
    goal_census: HashMap<u64, u32>,
    /// РЫНОК ЦЕЛЕЙ (приоритет-2 владельца): классы,
    /// прибытие в которые ПОДНЯЛО прогресс-сенсор
    /// observe()[0] — выведенная валюта (М-15: рост
    /// прожит, не назначен). Держания судимы теми же
    /// могилами целей (goal_graves).
    progress_goals:
        crate::holdings::Ledger<(u64, A), f64>,
    /// [КУРС-ЛЕДЖЕР, УГМ-мандат второй руки] прожитые
    /// строки обмена валют: (Δпрогресса взятия, новые
    /// места, новые пары карты до следующего взятия) —
    /// курс «цель ↔ биты карты» НЕ выводится, пока
    /// интервал строк не сузится (валюты не смешиваются
    /// без прожитого курса; тогда R*-суд заработает
    /// сквозь валюты законно).
    goal_rate: Vec<(f64, u64, u64)>,
    /// Открытая строка курса: (Δp, seen на взятии,
    /// table на взятии) — закрывается следующим
    /// взятием.
    goal_rate_open: Option<(f64, usize, usize)>,
    prev_progress: f64,
    /// Выключатель рынка целей (двойник судов; env
    /// G1_GOALS_OFF — внешний щит М-4).
    progress_goals_on: bool,
    /// Стекло рынка целей: [в_источнике, куплен,
    /// дороги_нет, пустой_разворот, вызовов_плана,
    /// bfs_ранний, могила_спит] — отказы судимы.
    goal_probe: [u64; 7],
    /// SPACED-ПАТРУЛЬ (сага несходимости exam:
    /// ревизионный налог рос без предела — age против
    /// фикс-порога 1024; 26110 патрулей из 65k выборов,
    /// регрет поздней жизни 18.56 против 12.48 ранней).
    /// Геометрия удвоения — прожитый закон сна банов и
    /// могил: бесплодная ревизия (без сюрприза) удваивает
    /// порог ребра, сюрприз сбрасывает — ревизия
    /// покупается ожидаемой новизной (Т-ПОВТОР holon:
    /// касание по цене, не по возрасту).
    patrol_futile: HashMap<(u64, A), u32>,
    /// РЕГРЕТ-ЭТАЖ БАШНИ (мета-мандат М-А,
    /// measures_self ЧИСЛОМ): текущий поход — (класс
    /// цели плана, life_age старта похода); леджер —
    /// класс -> (best прожитых шагов, сумма излишка
    /// над best, число прибытий). Организм сам
    /// свидетельствует свой best и расстояние до него
    /// — «минимум шагов» как внутренняя валюта.
    cur_walk: Option<(u64, u64)>,
    goal_regret: HashMap<u64, (u64, u64, u32)>,
    /// СТУПЕНЬ-3 МАКРО-ШВА: НАВЫКИ — переиспользуемые
    /// подпрограммы. Материал: акты текущего похода
    /// (walk_acts копится при живом cur_walk); тело
    /// успешного похода чеканится счётом (goal, fnv
    /// тела); покупка — ТОЧНЫЙ MDL-суд по прожитому:
    /// Σ описание успешных походов с алфавитом+1
    /// (тело в библиотеке + имя вместо повторов)
    /// ПАДАЕТ против описания без навыка (налог
    /// ветвления holon по прожитому, будущее не
    /// гадаем). Ledger — закон держаний.
    walk_acts: Vec<A>,
    /// суд свопа: (цель, ключ навыка) активного
    /// свопнутого плана — burn хоронит навык
    /// (body_burn: тело устарело), прибытие
    /// подтверждает (своп-шторм lp85: 2902 свопа
    /// при 27 навыках без выученного отказа)
    swap_pending: Option<(u64, (u64, u64))>,
    skill_counts: HashMap<(u64, u64), u32>,
    skill_bodies: HashMap<(u64, u64), Vec<A>>,
    skills: crate::holdings::Ledger<
        (u64, u64),
        Vec<A>,
    >,
    /// всего шагов успешных походов (валюта MDL-суда)
    walk_steps_total: u64,
    /// СТУПЕНЬ-2 МАКРО-ШВА: перенос-эксперимент под
    /// судом — (класс-где-пробуем, пара-донор);
    /// провал хоронит ЗАПИСЬ переноса (не пару-донора
    /// — она валидна дома), рост рождает НОВУЮ пару
    /// текущего источника (самообучение переноса).
    transfer_pending: Option<(u64, (u64, A))>,
    tried_transfers:
        std::collections::HashSet<(u64, (u64, A))>,
    /// Обещание рынка целей под судом: купленный план
    /// «дорога к источнику + повтор акта» исполняется;
    /// когда план пуст — прогресс-сенсор выносит
    /// вердикт (вырос — цель жива; молчит — пара
    /// ОПРОВЕРГНУТА и умирает: цель, переставшая
    /// платить, не цель — М-15).
    pending_goal_fire: Option<(u64, A)>,
    /// КАРТА МИРА (worldmap): мульти-исходы с
    /// терминалами — единая юрисдикция цены и долга;
    /// копит параллельно table (М-4-пара), планы по ней
    /// под G1_MAP_PLAN=1; DIED=1 — единственный
    /// организмо-видимый терминал (гол/cap — семантика
    /// мира; ресет честно пишется Next-переходом).
    map: crate::worldmap::WorldMap<u64, A, u8>,
    /// ПРИХОДЫ на ключ (стекло целей вскрыло вечный
    /// двигатель: цель=гол-узел, мир ресетит раньше
    /// жеста — untried(гол) невзыскуем): LAW приходов
    /// без единого своего жеста = терминал, долг спит.
    arrivals: HashMap<u64, u32>,
    /// [ТЕЛЕПОРТ-ЗАКОН] леджер глобальной судьбы
    /// жеста: (единственный прожитый исход, прожитий,
    /// исход един отовсюду). Жест с единым исходом
    /// из ЛЮБОГО ключа при прожитии ≥ LAW² —
    /// протокольный телепорт: его исход известен
    /// глобально, на свежем ключе он не новизна и не
    /// фронтирный долг (прожито tu93: RESET «свежий
    /// непробованный» на каждом новом ключе — 29
    /// обвалов игры за проход, весь бюджет в обвалах;
    /// точечная форма Lubow-рода — гасится ТОЛЬКО
    /// глобально детерминированный жест, содержательные
    /// акты с разными исходами не тормозятся никогда).
    act_dest: HashMap<A, (Option<u64>, u32, bool)>,
    /// Г-СТЕКЛО: ветка последнего выбора (0..7 как в
    /// choice_counts; 255 = не выбирал) + цель плана —
    /// causal-строка каждого жеста для эхо-зонда.
    last_branch: u8,
    /// Прибытие на цель фронтира с живым долгом: ключ,
    /// где ветка недоплаты имеет право хода (ТОЛЬКО
    /// здесь — глобальная недоплата рушила жизнь:
    /// 428 смертей, caps 1555 на 3000).
    just_arrived: Option<u64>,
    /// СК: the glue organ's switch — an OPTION like
    /// patrol/valent/gaze (the 11-red lesson: a
    /// policy-changing organ enters by explicit
    /// composition, never through the base path;
    /// canonical() stays untouched — К-4 passport).
    glue_on: bool,
    /// СК-чтение (канал б): outcome sums per (gesture
    /// SIGNATURE, gesture) — the reference a YOUNG state
    /// reads before any membership (reading without
    /// belonging: the transfer that needs no maturity).
    sig_counts: HashMap<(u64, A), [u32; 3]>,
    /// [СУД ПРОТИВОРЕЧИЯ] рынок убеждений тела:
    /// версии вопросов с провенансом; живые
    /// потребители — правила (вопросы динамики) и
    /// цель-пары (вопросы прогресса).
    belief_market: crate::beliefs::BeliefMarket,
    /// [THE DOOR OF RULES] the dynamics of the world bought from its shows (rules.rs): fed every lived tick while the
    /// rule dream is armed, read by the dream.
    rule_door: crate::rules::Door,
    /// [THE DOOR OF RULES] the rules bought last; bought again after a tick the world contradicted them.
    rule_model: Option<crate::rules::Model>,
    /// [ГРЁЗА ПРАВИЛАМИ] орган взведён программно
    /// (двойник env G1_RULEDREAM)
    rule_dream: bool,
    /// [ГРЁЗА ПРАВИЛАМИ] могилы гипотез-целей (роль,
    /// чья дорога прожита без роста прогресса) — С
    /// ДАВНОСТЬЮ и ретестом (вечная могила каменила
    /// тело: одна ложная гипотеза казнила роль
    /// навсегда; тот же самокалибрующийся род, что
    /// могилы целей)
    goal_role_graves:
        crate::holdings::Graves<u64>,
    /// [ГРЁЗА ПРАВИЛАМИ] живая гипотеза: (роль цели,
    /// прогресс на взводе) — сенсор-суд по прибытии
    rule_goal_armed: Option<(u64, f64)>,
    /// [РИТМ, вердикт девяти] ЩЕЛЬ ПО ПОСТРОЕНИЮ:
    /// дорога суда исчерпана — один такт суд молчит
    /// («дорога тишины» длины 0: в щели живут
    /// канонические органы — взгляд, скука-рынки,
    /// патруль; канонический ритм был эмерджентом
    /// коротких планов — теперь он закон вырождения).
    road_rest: bool,
    /// [VTE] текущий план положен грёзой (стекло
    /// веток: исполнение печатается веткой 11)
    vte_plan: bool,
    /// [VTE] ключ последнего ПРОВАЛЬНОГО свипа —
    /// остывание: не пересаживаться, пока мир не
    /// сменил ключ (свип дорог, мост жевал deepcopy
    /// на каждом такте)
    vte_failed_at: Option<u64>,
    /// [НОВИЗНА-2] леджер ОТКРЫТИЙ класса жеста:
    /// (сигнатура меню, жест) → (открыл новое место,
    /// прожит) — БЕЗУСЛОВНЫЙ (СК-леджер пишется только
    /// под склейкой, и glueless-доход суда дорог был
    /// пуст: все классы на приоре ½ — потолок пустой
    /// истины М-22 в собственном органе). Истинная
    /// цель дохода — ожидаемые ОТКРЫТИЯ, moved был
    /// прокси.
    sig_novel: HashMap<(u64, A), (u32, u32)>,
    /// [В-1] ВИНА ДЛИНЫ (цена времени из cap-смерти,
    /// Т-ГРАН: носитель cap — ДЛИНА, числовой): леджер
    /// life_age В МОМЕНТ проживания жеста (локально);
    /// жест поздних фаз жизни несёт вину размазанности
    /// — четвёртая лексикографическая ось справки.
    sig_len_use: HashMap<(u64, A), (u32, u64)>,
    /// state → its signature hash (cached).
    sig_of: HashMap<u64, u64>,
    tower: CogTower,
    wheel: DuoWheel,
    anchor: Gamma,
    seen: HashMap<u64, Vec<A>>,
    table: HashMap<(u64, A), u64>,
    plan: VecDeque<A>,
    pending: Option<Takeover>,
    organs: Option<Organs>,
    organ_feedback: f64,
    /// P-MOLT-ORG: the geography molt law — when a window
    /// of `molt_window` known transitions gathers
    /// `molt_threshold` SURPRISES (the world answered other
    /// than the table remembers), the map is declared a lie
    /// and re-earned.
    molt_rule: Option<(usize, usize)>,
    surprise_window: VecDeque<bool>,
    surprises_total: u64,
    /// [М-21, №17] знаменатель промахов: сколько
    /// предсказаний ВООБЩЕ сверялось с миром.
    /// «MISS=0» без него — пустая истина (карта,
    /// не предсказывавшая вовсе, безгрешна даром).
    predictions_total: u64,
    molts: u32,
    /// P-PATROL: live the life's tail as revision —
    /// instead of spamming the first action, replay the
    /// LEAST RECENTLY checked transition (an LRU patrol of
    /// one's own map).
    patrol: bool,
    /// The patrol licence (the EL-189 depth licence
    /// generalized): revising one's own memory is a
    /// meta-practice — only a CONSCIOUS tower meta-level
    /// executes it.
    patrol_licence: bool,
    patrol_blocked: u64,
    /// Форма патруля: false = голодный LRU (канон
    /// Room-судов: ложь ищется жадно); true =
    /// амортизированный давностью (G1-линия: сон
    /// score<1024 отдаёт хвост жизни кольцу). Две
    /// законные формы одной ревизии — состав тела,
    /// не флаг стенда.
    patrol_amortized: bool,
    /// The CURRENT organ pose as of the latest step
    /// (255 = no organ) — the fold's pre-act pose source
    /// for eyed()/virtual runs, refreshed each step.
    cur_pose: u8,
    steps: u64,
    verified_at: HashMap<(u64, A), ObservationReceipt>,
    attention: f64,
    attention_kind: LiftKind,
    root: Option<u64>,
    gamma: f64,
    dt: f64,
    feed_ticks: u32,
    injection: f64,
    /// Compatibility rung metadata. Current native publication sets this to
    /// 1. This number does not certify a finite factor of the native program.
    unfold: u32,
    glass: Option<GlassMind>,
    rut: Option<RutWatch>,
    /// THE GAZE (the ω rhythm as an organ): the organism
    /// looks at itself when EXHAUSTED (no plan, nothing
    /// untried here) and IN THE WINDOW — and only then.
    /// No timer, no knob: a look drops the base out of the
    /// window, living feeds it back (~the price of a look),
    /// so the window itself is the refractory mechanism and
    /// the rhythm is a self-paced limit cycle.
    gaze: bool,
    looks: u32,
    /// THE IDENTITY WATCH: the post-dream holonomy is the
    /// standing «who I am now»; waking drift is measured
    /// against it by ink-weighted affinity, and a fall
    /// below 1/LAW is a BREAK — the organism itself feels
    /// a wound to its continuity (and re-anchors to the
    /// new self, honestly counting the seam).
    identity: Option<(
        [synarc_math::holonomy::Hol; 7],
        f64,
        synarc_math::phase::PhasePassport,
    )>,
    identity_watch: bool,
    breaks: u32,
    /// THE FROZEN VERDICTS (Cor. 18.9 as an organ; law Z-6
    /// «death writes the ledger»): a transition's death
    /// count. At `LAW_OF_REPETITION` deaths the ban FREEZES —
    /// avoided while alternatives exist, re-examined ONLY
    /// on refutation (a lived passage through it), never by
    /// per-reading re-judging. The regret bound is the
    /// law itself: at most LAW deaths per transition before
    /// the verdict stands.
    bans: Option<HashMap<(u64, A), u32>>,
    /// Симметрия грани-7 на РЁБРА: life_age последнего
    /// бана перехода — без языкового двора (exhaust)
    /// замороженный вердикт слушается ДАВНОСТЬЮ тем же
    /// законом сна, что могилы целей (вечный бан — сам
    /// лимит-цикл: залип {24} тропой A при banned B/C).
    ban_at: HashMap<(u64, A), u64>,
    /// THE MERGE-DOWN INCUBATOR (Sh-2): when on, a razed
    /// floor COARSENS the policy instead of clearing it
    /// (the skill survives; bans reset with the
    /// language). Incubating behind a flag: the S-world
    /// proved the law (door X stays solved through the
    /// raze), but the lever world shows a second-order
    /// effect (the smoother gait feeds the gate floor
    /// forever and suspicion never begins) that needs its
    /// own telemetry before the law rules every world.
    /// The Sh-3 name map: mapped foreign-rung structures.
    name_map: Vec<crate::letter::Schema>,
    /// THE SURPRISE RING (transparency organ): the last
    /// LAW² mismatches as (state, action, expected, got) —
    /// the organism can always answer WITH WHAT exactly
    /// the world surprised it, not merely how often.
    surprise_ring: VecDeque<(u64, A, ObservedWorldOutcome, ObservedWorldOutcome)>,
    /// [СТЕКЛО СГОРАНИЙ, слой-2 замка L3]
    /// гистограмма длин плана в момент сгорания —
    /// «сколько нот оставалось до конца серии».
    pub burn_glass:
        std::collections::BTreeMap<usize, u32>,
    /// THE HUNGER FOR EVIDENCE on: the idle fallback walks
    /// toward the thinnest-evidenced lawful context (the
    /// epistemic valence organ; off = the first lawful act,
    /// the historic gait).
    hunger: bool,
    /// VALENCE v1 (prereg-valence-rollout): the value
    /// rollout — dream roads priced by the mortal ledger.
    valent: bool,
    /// THE APPEAL DOCKET: when a frozen transition last had
    /// its hearing (in witnessed-tick time). With the
    /// language court present, a frozen verdict is
    /// re-heard once per court window — the probe that
    /// keeps the ban from strangling the very evidence the
    /// court needs (the living-wreath court's discovery).
    /// Zero new constants: the cadence is the court's own.
    appeals: HashMap<(u64, A), u64>,
    /// THE DOCKET GATE (maze phase 2, third organ): one
    /// appeal per court window GLOBALLY. Per-verdict
    /// re-hearings alone turn a large graveyard into a
    /// squall — 130 frozen walls x ~20 windows gave ~2600
    /// lawful re-tests (x17 per wall measured). One
    /// sitting hears one appeal (the confirmation law's
    /// twin); the queue rhythm is the ledger's own.
    appeal_gate: u64,
    /// THE INTERVENTION DOCKET (Ф-3.2 v1, the docket
    /// court): when at least two frozen verdicts stand
    /// rested, exactly ONE case per court window
    /// unfreezes — the least-heard verdict (max EIG in
    /// the Т-ЛЮБ-2 passport form with K=1: the one
    /// Bernoulli parameter «is this edge lethal here»),
    /// ties by deferral count then canonical key. Off,
    /// every rested verdict unfreezes at once and the
    /// hearing goes to the accident of the walk — a wall
    /// can starve forever.
    intervention: bool,
    /// АВТОНОМИЯ-1: the self-arming organ — the organism
    /// arms its own options when their trigger ledgers
    /// (which run unarmed by the meter law) reach the law
    /// of repetition. v1 menu: the tier ladder alone (the
    /// only option whose trigger meter runs unarmed).
    autonomy: bool,
    /// The hearings ledger: how many times each frozen
    /// verdict was actually re-heard (the act taken while
    /// frozen). The witness is the ledger; it runs even
    /// with the organ off (a meter, not a behaviour).
    hearings: HashMap<(u64, A), u32>,
    /// Deferral streaks: full court windows a chosen case
    /// sat unheard. At LAW consecutive deferrals the
    /// bank-of-forms gate is waived — refutability
    /// outranks safety by law, not by chance.
    defers: HashMap<(u64, A), u32>,
    /// The chosen docket case and the witnessed clock at
    /// its selection; None between selections.
    docket_case: Option<((u64, A), u64)>,
    /// Glass counters: hearings held under the organ, and
    /// hearings that fired on an exhausted deferral (the
    /// DEFER-EXHAUSTED stamp).
    docket_heard: u64,
    defer_exhausted: u64,
    /// THE LANGUAGE COURT (Cor. 18.5(ii) as an organ): the
    /// SECOND lawful climb signal beside the molt. Over
    /// every fresh window of witnessed world-answers the
    /// pointwise court (Def. 18.6, selective grammar) asks
    /// whether naming a carrier and a period buys its
    /// price — the eye grows when language is bought, and
    /// stands when the language is honestly exhausted.
    exhaust: Option<ExhaustClimb<A>>,
}

struct ObserverWork { remaining: usize }
impl crate::program::WorkMeter for ObserverWork {
    type Error = ();
    fn charge(&mut self, amount: usize) -> Result<(), ()> {
        self.remaining = self.remaining.checked_sub(amount).ok_or(())?;
        Ok(())
    }
}

struct PreparedRepresentation<A: Copy + Ord> {
    inputs: Vec<(u128, u64)>,
    updates: Vec<observer_runtime::Prepared<A>>,
    raw_top: Option<u64>,
    tier_inputs: Vec<TierInput>,
    remaining_work: usize,
}



/// A live execution owner cannot be discarded by a lifecycle/configuration API.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverLifecycleRefusal {
    PendingBoundary,
    UnknownDelivery,
    PendingPhysicalTime,
    PendingTerminalClosure,
    HistoryAuthorityCapacity,
    TransferLibraryCapacity,
}
impl std::fmt::Display for ObserverLifecycleRefusal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::PendingBoundary => "an owned observer boundary is still unfinished",
            Self::UnknownDelivery => "the native observer history has unknown physical delivery",
            Self::PendingPhysicalTime => "the physical outcome has not committed its source time",
            Self::PendingTerminalClosure => "the observed terminal still owns unfinished episode closure",
            Self::HistoryAuthorityCapacity => "native history authority capacity exhausted",
            Self::TransferLibraryCapacity => "declared library exceeds receiver retention",
        })
    }
}
impl std::error::Error for ObserverLifecycleRefusal {}
impl From<causal_coordinates::physical_time::RestartRefusal> for ObserverLifecycleRefusal {
    fn from(reason: causal_coordinates::physical_time::RestartRefusal) -> Self {
        match reason {
            causal_coordinates::physical_time::RestartRefusal::PendingOutcome => Self::PendingPhysicalTime,
            causal_coordinates::physical_time::RestartRefusal::PendingTerminal => Self::PendingTerminalClosure,
        }
    }
}
impl<A> From<ObserverLifecycleRefusal> for ActionFailure<A> {
    fn from(reason: ObserverLifecycleRefusal) -> Self { Self::begin(ActionStage::Restart, reason.to_string()) }
}

/// Refused consuming reconfiguration returns the exact original organism. The
/// caller may keep/resume it; failure is neither a reset nor implicit disposal.
pub struct ObserverConfigurationRefusal<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> {
    reason: ObserverLifecycleRefusal,
    organism: Box<Organism<A>>,
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> ObserverConfigurationRefusal<A> {
    pub fn reason(&self) -> ObserverLifecycleRefusal { self.reason }
    pub fn into_organism(self) -> Organism<A> { *self.organism }
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> std::fmt::Debug for ObserverConfigurationRefusal<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ObserverConfigurationRefusal").field("reason", &self.reason).finish_non_exhaustive()
    }
}

/// Statistical policy changes must precede the first observation and source.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverAdmissionRefusal { Unarmed, AlreadyObserved, NontrivialRiskRequired }

/// A refused library declaration returns its original organism and history.
pub struct LibraryConfigurationRefusal<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> {
    reason: String,
    organism: Box<Organism<A>>,
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> LibraryConfigurationRefusal<A> {
    /// Exact declaration-boundary refusal, with no admission claim.
    pub fn reason(&self) -> &str { &self.reason }
    /// Recover the unchanged prior owner after an invalid or late declaration.
    pub fn into_organism(self) -> Organism<A> { *self.organism }
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> std::fmt::Debug for LibraryConfigurationRefusal<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LibraryConfigurationRefusal").field("reason",&self.reason).finish_non_exhaustive()
    }
}

/// Per-organism resource policy. These are engineering allowances, never
/// semantic constants, evidence weights, or a claim of total process RAM.
#[derive(Clone, Copy, Debug)]
pub struct ObserverResources {
    pub history_nodes: usize,
    pub capture_work: usize,
    pub search_work: usize,
}
impl Default for ObserverResources {
    fn default() -> Self {
        Self { history_nodes: 1 << 20, capture_work: 1 << 16, search_work: 1 << 24 }
    }
}

/// [МИЦЕЛИЙ U.5, ЭА-4] Типизированный отказ слияния тел —
/// ДО каких-либо мутаций принимающего (юрисдикция старше
/// валюты: сперва суд совместимости, потом обмен).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExAnastomosisRefusal {
    /// An unfinished owned physical boundary cannot be moved or dropped by merge.
    ObserverContinuation,
    /// у стороны нет выхлопного суда — телу нечем судить
    Unarmed,
    /// ярус лишь у одной стороны: асимметричное слияние
    /// языков — отдельный род следующего круга (нижний
    /// язык входит в ярусный live-new чеканкой, что
    /// требует пере-адресации corpus на входе; честный
    /// отказ типом вместо тихой полу-правды)
    TierAsymmetry,
    /// Dictionary inputs have different meanings; no partial merge is permitted.
    TierAncestry,
    /// The complete action-name union exceeds native ordinal/address representability.
    ActionCapacity,
    /// A context ordinal has no unique native action binding.
    ActionBinding,
    /// No certified transport connects the required input languages.
    InputLanguage,
    /// General definitions need native language/state transport, not residue translation.
    ObserverTransportRequired,
    /// Complete receiver input history is unavailable for this extension.
    ObserverHistory,
    /// Preflight exhausted its work or live-layer allowance.
    ObserverResource,
    /// Aggregated ledgers overlap and lack an inclusion/exclusion receipt.
    HistoryOverlap,
    /// An aggregate ledger cannot represent the exact merged count.
    CounterOverflow,
}

/// An installed program's native language identity. Output epochs are
/// never reused within their native owner, including after raze and re-climb.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FloorIdentity {
    lineage: causal_coordinates::Lineage,
    input_epoch: u128,
    output_epoch: u128,
}
impl FloorIdentity {
    /// Language consumed by this floor.
    pub fn input_epoch(&self) -> u128 { self.input_epoch }
    /// Language produced by this installed program revision.
    pub fn output_epoch(&self) -> u128 { self.output_epoch }
}

/// The court that authorized an actual representation rollback.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RazeReason {
    /// Strict-majority observed death deterioration during probation.
    Harmed,
    /// The description-length demolition court.
    Mdl,
    /// An acquired program was undefined on the actual native boundary.
    Undefined,
    /// A better candidate displaced the incumbent.
    Displaced,
    /// Explicit installation-boundary fixture; unavailable in production.
    #[cfg(test)]
    Declared(&'static str),
}
impl std::fmt::Display for RazeReason {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Harmed => "harmed", Self::Mdl => "mdl", Self::Displaced => "displaced", Self::Undefined => "undefined",
            #[cfg(test)] Self::Declared(name) => name,
        })
    }
}

/// Receipt of a completed rollback. The organism retains at most the latest
/// receipt; a proposal or a refused raze cannot overwrite it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RazeReceipt {
    /// Exact installed floor revision consumed by the rollback.
    pub floor: FloorIdentity,
    /// Adjudication that authorized it.
    pub reason: RazeReason,
    /// Local language sitting at commitment.
    pub sitting: u32,
    /// Native confirmed-event prefix at commitment.
    pub event_ordinal: u64,
}

/// Deaths are compared with the worst lived baseline window. Surprises do not
/// vote on cross-representation risk; an empty trial never has a majority.
fn standing_harmed(stacked: bool, baseline: u32, trial: &[(u32, u32)]) -> bool {
    stacked && trial.iter().filter(|window| window.1 > baseline).count() > trial.len() / 2
}

/// Стекло анастомоза (пререг: «стекло обязано печатать
/// уровни/этажи/претенденты»).
#[derive(Debug, Clone, PartialEq)]
pub struct ExAnastomosisGlass {
    /// The merged observed-action count, retaining the existing maximum law.
    pub witnessed: u64,
}


/// Evidence retained in one representation window. A road is a projection of
/// unanimous observed outcomes; `latest` is only the sequential forecast used
/// by surprise/molt. Conflicting evidence is retired only at an explicit
/// representation reset, never by another sample of a previously seen outcome.
#[derive(Clone, Debug, PartialEq, Eq)]
struct ObservationReceipt {
    /// Conservative age of all retained premises, including transported fibers.
    at: u64,
    outcomes: std::collections::BTreeSet<ObservedWorldOutcome>,
    /// A forecast in this exact language, invalidated by coordinate transport.
    latest: Option<(u64, ObservedWorldOutcome)>,
}

impl ObservationReceipt {
    fn new(at: u64, outcome: ObservedWorldOutcome) -> Self {
        Self { at, outcomes: std::collections::BTreeSet::from([outcome]), latest: Some((at, outcome)) }
    }

    fn observe(&mut self, at: u64, outcome: ObservedWorldOutcome) {
        self.at = self.at.min(at);
        self.outcomes.insert(outcome);
        self.latest = Some((at, outcome));
    }

    fn last_observed_at(&self) -> u64 {
        self.latest.map_or(self.at, |(at, _)| at)
    }

    fn next(&self) -> Option<u64> {
        if self.outcomes.len() != 1 { return None; }
        match self.outcomes.first()? {
            ObservedWorldOutcome::Next(next) => Some(*next),
            ObservedWorldOutcome::Refused(_) | ObservedWorldOutcome::End(_) => None,
        }
    }

}

/// One action's input coordinates, captured before advancing the representation.
/// Consuming this receipt admits that action once; terminal observations have
/// no successor even though their owned carrier clocks still advance.
#[derive(Debug)]
struct RepresentationWitness<A: Copy> {
    state: u64,
    raw_state: u64,
    context: Context,
    age_at_act: u64,
    raw_top: Option<u64>,
    cut: causal_coordinates::Cut<A>,
    capture: Option<ActionCapture<A>>,
}

/// Actual successor ports and pre-effect witness. Resumption never resamples a
/// Habitat or repeats a physical action; all ordinary bookkeeping uses this.
struct Successor<A: Copy> {
    state: u64,
    raw: u64,
    acted: A,
    observed: ObservedAction,
    takeover: Option<Takeover>,
    witness: Option<RepresentationWitness<A>>,
    progress: Option<f64>,
    menu: Vec<A>,
    features: [f64; 7],
}

#[derive(Clone, Debug)]
struct SampleCoordinates<A: Copy> {
    raw_top: Option<u64>,
    cut: std::sync::Arc<causal_coordinates::Cut<A>>,
    capture: Option<ActionCapture<A>>,
}

/// The language-court organ's memory: a ring of lived ticks
/// (context, age, answer-variability) and complete native captures for
/// program acquisition. The observation bit records whether
/// the typed outcome differs from the FIRST answer this
/// (situation, action) context ever gave — never the map's
/// opinion of itself (a frozen map is surprise-free exactly
/// where the world stays invisible; the first answer is the
/// reference the map itself was born from, so in an
/// age-driven world the bit is a pure function of age).
#[derive(Debug)]
struct ExhaustClimb<A: Copy + Ord> {
    window: usize,
    observer_history: causal_coordinates::Timeline<A>,
    /// Latest confirmed physical witness, independent of scoring-corpus
    /// eviction and representation changes. One bounded shared Cut/capture;
    /// readers must still check lineage, source origin and current ordinal.
    last_observed_cut: Option<SampleCoordinates<A>>,
    observer_work: usize,
    program_duel: std::cell::RefCell<observer_duel::program::Courts<A>>,
    observer_capture_work: usize,
    action_names: std::collections::BTreeMap<A, u64>,
    base_input_epoch: u128,
    last_raze: Option<RazeReceipt>,
    domain_retirements: Vec<DomainRetirementReceipt<A>>,
    #[cfg(all(test, feature = "serde"))]
    domain_retirement_audit: Option<for<'a> fn(
        &ExhaustClimb<A>,
        observer_domain::retirement_export::PhysicalPorts,
        usize,
        observer_domain::retirement_export::Point<'a>,
    )>,
    domain_retirement_limit: usize,
    domain_retirement_used: usize,
    pending_domain_retirement: Option<observer_domain::PendingRetirement<A>>,
    after_act_continuation: Option<observer_domain::recovery::AfterAct<A>>,
    before_act_continuation: Option<observer_domain::before::BeforeAct<A>>,
    proposal_cancellations: Vec<ProposalCancellation<A>>,
    input_links: std::collections::BTreeMap<observer_transport::LanguageRef, observer_transport::LanguageRef>,
    /// THE FAIR CORPUS (Def. 18.3: experience is a multiset
    /// PER NODE): one bounded deque per situation, each
    /// capped at `window` — a rare context's evidence is
    /// never drowned by a busy one's flood (the global
    /// sliding window did exactly that: one appeal hearing
    /// per window sank among 287 routine ticks and the
    /// court starved). Each tick carries the world's RAW
    /// answer beside it: the demolition court must
    /// re-derive the observation under a CANDIDATE keying
    /// (obs is relative to the language it was witnessed
    /// in — stripping keys without re-deriving firsts
    /// falsely equalises an earning floor, the tide
    /// court's first run proved it by demolishing mid-
    /// tide).
    corpus: HashMap<
        u64,
        VecDeque<(crate::exhaust::Tick, ObservedWorldOutcome, u64, SampleCoordinates<A>)>,
    >,
    first_next: HashMap<Context, ObservedWorldOutcome>,
    /// [ЗАМКНУТОСТЬ КЛЮЧА] three ledgers of the SAME
    /// question asked in three languages: does (key, act)
    /// determine the NEXT KEY OF THAT SAME LANGUAGE? This
    /// is the question the organism actually lives by —
    /// its map is key→key, and planning breaks exactly
    /// where the next key is undetermined. Asking instead
    /// «does the key predict the WORLD's raw answer» is a
    /// different question and USELESS as a court: a finer
    /// key always predicts raw better simply by carrying
    /// more, so against the raw answer even the PROVEN
    /// games convict (ar25 0.543 vs 0.009, sc25 0.743 vs
    /// 0.420) and the court would raze everywhere. In
    /// own-language terms the separation is clean:
    /// ar25 eye 0.000 vs world 0.009 — the eye EARNS its
    /// distinctions; cd82 eye 0.521 vs world 0.028 — the
    /// eye INVENTS doubt the world does not have.
    /// full = the eye as lived; low = the tower minus its
    /// top storey; world = the raw key the adapter gives.
    /// Распределения следующих ключей по контексту — по
    /// одному на язык. Хранится РАСПРЕДЕЛЕНИЕ, а не
    /// «первый ответ»: цена сомнения есть КТ-длина кода
    /// самой последовательности исходов, и посчитать её
    /// по одному лишь первому ответу нельзя.
    doubt_eye: HashMap<Context, HashMap<ObservedWorldOutcome, u32>>,
    doubt_world: HashMap<Context, HashMap<ObservedWorldOutcome, u32>>,
    /// Накопленная цена сомнения в БИТАХ по каждому языку.
    bits_eye: f64,
    bits_world: f64,
    /// The pair opened by the previous witnessed act,
    /// closed by this one: (contexts, opening life age, refusal tag). A pair whose age does not advance by
    /// exactly one is DROPPED — a gap would inject false
    /// doubt, and unequally into three languages.
    pend: Option<(Context, Context, u64, bool)>,
    /// Стекло для человека: опоры и расхождения по
    /// каждому языку. В СУДЕ НЕ УЧАСТВУЮТ — доли
    /// несравнимы между языками разной зернистости
    /// (М-49), судят только биты выше.
    /// Consecutive sittings convicting the BAPTISM — the
    /// eye's KIND against the world's own key, both
    /// predicting the SAME outcome (the raw next) in KT
    /// bits. Repeatability is the same quorum every
    /// refusal demands. The FLOOR arm of this court was
    /// EXECUTED (М-49): the floor already has its lawful
    /// judge — the demolition court, the exact MDL mirror
    /// of the purchase (same obs outcome, same formula,
    /// opposite sign). A second judge of the same
    /// defendant with a different outcome razed lawful
    /// floors 16 times per life and never let the tier be
    /// born. The eye's KIND, by contrast, had NO judge
    /// before this court — that arm is the organ.
    baptism_strikes: u32,
    /// Ticks witnessed since the last court — the court
    /// sits once per fresh window, never per reading
    /// (Cor. 18.9's spirit: no verdict drumbeat).
    fresh: usize,
    /// Monotone count of witnessed ticks — the court's own
    /// clock, quoted by the appeal probe (a frozen verdict
    /// may be re-heard once per court window).
    witnessed: u64,
    /// THE TOWER: bought floors, oldest first. Each floor
    /// conditions on the keys the floors below produce —
    /// the wreath, not the product. A purchase APPENDS a
    /// floor; the demolition court RETIRES the top floor
    /// when it stops earning its keep (MDL both ways:
    /// growth and un-growth are the same law).
    floors: Vec<Floor<A>>,
    program_agenda: Option<observer_acceptance::Agenda<A>>,
    observer_current_raw: Option<u64>,
    /// The prospective SITUATION tally: acts ever taken
    /// from each current-language situation — the default
    /// events axis (a carrier's bit may flip on ANY act
    /// there, so the own-axis counts the whole situation).
    top_tally: HashMap<u64, u64>,
    /// The prospective CONTEXT tally: acts per (situation,
    /// action) — the foreign-suspect axis (a lever is an
    /// ACT, not a place). THE COHERENCE LAW binds both to
    /// the floors they buy: the judged axis must equal the
    /// lived clock exactly — own purchases wind the sum of
    /// the mask's contexts, suspect purchases wind the one
    /// named context.
    ctx_tally: HashMap<Context, u64>,
    climbs: u32,
    /// Floors retired by the demolition court.
    demolitions: u32,
    /// THE ROTATING SUSPECT: when the court exhausts while
    /// variability persists, the events axis of the NEXT
    /// window quotes a FOREIGN situation's clock — the
    /// suspects rotate through the atlas in sorted order,
    /// one per court window, until one buys or the circle
    /// closes. `None` = the own situation (the default
    /// semantics every prior court judged).
    suspect: Option<Context>,
    /// THE RAZED LEDGER — freeze-until-contradiction for
    /// the architecture store itself: a rung shape
    /// (`age_mod`, `events_mod`, origin) razed LAW times is
    /// frozen out of future purchases. Without it the
    /// wrong gait-folded floors re-buy forever and the
    /// default never exhausts — the rotation never begins
    /// (the lever hunt sat at 7 buys / 6 razings, the
    /// true carrier unreached).
    /// Keyed by AXIS FAMILY (origin, age-wound?,
    /// events-wound?): a razed floor refutes its family —
    /// finer retries of the same fold are the same fold.
    /// (Per-modulus freezing was tried and crawled: the
    /// noise-shape space is long, one modulus at a time.)
    razed: std::collections::BTreeMap<(observer_transport::ContextRef<A>, bool, bool), u32>,
    /// THE EXECUTION WINDOW (standing court): the last
    /// LAW sittings' (surprises, deaths) pairs — written
    /// at the TOP of every sitting, BEFORE any climb
    /// (the sitting order law: a fresh floor's baseline
    /// is the life actually lived, never an empty zero).
    exec_window: std::collections::VecDeque<(u32, u32)>,
    /// Totals at the last sitting (for the window deltas).
    last_exec: (u64, u64),
    /// P-RED-1: how often each axis kind was caught lying
    /// («events» / «time» / «raw») — the REFUTED tallies.
    miss_names:
        std::collections::HashMap<&'static str, u64>,
    /// P-RED-3: MODEL lies (events/time, not raw) in the
    /// window being lived now…
    window_model_misses: u32,
    /// …and in the last window a court finished judging:
    /// the closure witness (0 = the language re-explained
    /// its whole window without one model lie).
    last_window_model_misses: u32,
    /// §16.6-а THE REGISTRY TRACE: per-sitting chronicle
    /// (model lies, raw novelty) — the tape the strategy
    /// meta-trade judges policies on. Budget: LAW² windows
    /// (the same law as the surprise ring).
    window_log: VecDeque<(u32, u32)>,
    /// Raw novelty in the living window (the chronicle's
    /// second column).
    window_raw_misses: u32,
    /// THE KEY HEADROOM WITNESS: the widest RAW key ever
    /// seen (in bits) — the climb gate refuses a floor
    /// that would not fit the 64-bit written road (16 bits
    /// per storey + 8 for the action ordinal).
    max_raw_bits: u32,
    /// §16.6-а THE BOUGHT PATIENCE: how many consecutive
    /// clean windows CLOSE the model — not a knob, the
    /// strategy meta-trade buys it on the registry trace
    /// (default 1 = the cheapest name; tie goes to it).
    closure_patience: u32,
    /// §16.6-а' THE BOUGHT HYSTERESIS (the fifth
    /// meta-trade): how many consecutive DIRTY windows
    /// re-OPEN a committed model — a single flash need
    /// not evict a proven regime; bought on the same
    /// chronicle (false exits are the price), tie to the
    /// cheaper name.
    closure_patience_out: u32,
    /// The strategy automaton's live state: committed?
    in_commit: bool,
    /// Foreign-clock installations recorded at the actual publication point.
    /// Confirmation or a capacity refusal never increments this count.
    /// Foreign-clock floors EVER bought (Sh-2): the
    /// schema «a clock may live in another room» is
    /// knowledge of the LIFE, not of the storey — a
    /// demolished carrier retires a floor, never the
    /// hypothesis (the tide probe watched the schema
    /// vanish with its floor and the patience reset).
    foreign_climbs: u32,
    /// Court sittings (forensics only).
    sat: u32,
    /// The life's monotone death count (the guard law).
    life_deaths: u64,
    /// Shipments over the whole life: how many times this
    /// organism's schemas were HANDED OUT by the lived
    /// act `ship_schemas` (the meter's `spores` witness —
    /// a LEDGER; `export_schemas` stays a glass read and
    /// testifies nothing).
    shipments: u64,
    /// Consecutive exhausted sittings with LIVE surprises
    /// in the window — the fourth face's smoke: the
    /// market can buy nothing, yet the world keeps
    /// surprising. At LAW the re-election court sits.
    exhausted_streak: u32,
    /// Ф-3.1, THE BLIND METER: smoky empty sittings in a
    /// row that survive re-election — reset ONLY by a
    /// purchase, by world silence, or by a raze; the duel
    /// does NOT reset it (unlike its own chronometer
    /// above). Strictly more than LAW means the streak
    /// outlived a duel that razed nothing: the CLASS is
    /// blind, not a standing floor.
    blind_streak: u32,
    /// Optional fraction of each shared native discovery work request.
    glass_budget_frac: Option<f64>,
    acquisition_budget: acquisition_budget::Ledger,
    /// Displaced verdicts over the whole life (glass):
    /// how many seats the re-election court re-let.
    displaced: u32,
    /// The fourth seat's ledger: duels where the crown
    /// LAWFULLY held because the challenger's edge did
    /// not cover the switch-wave W (cand > inc yet
    /// cand − inc ≤ W) — the right without a witness is
    /// no right, and the held throne is a verdict too.
    /// The duel's confirmation law (the symmetry of
    /// purchase): a challenger must beat the incumbent
    /// LAW duels IN A ROW with the SAME rung before the
    /// Displaced verdict lands — one lucky window
    /// unseated honest shelves in a roulette of moduli
    /// (the third wind lesson). (rung, streak).
    /// Т-ЯРУС state: the one re-tokenization (phase 1).
    tier: Option<Tier>,
    /// [АНАСТОМОЗ-2] претенденты карантина:
    /// соматические этажи чужой жизни — заморожены
    /// (в eyed()/грамматике не живут; стекло видит;
    /// будущий суд впустит их СВОИМ прожитием).
    /// The organ is an OPTION until its certificate.
    tier_armed: bool,
    /// Consecutive headroom refusals with no purchase in
    /// between — the tier-birth trigger streak (LAW).
    headroom_streak: u32,
    /// [Д-26, стекло немоты] окна суда после
    /// рождения тира / кандидаты в них / покупки.
    tier_sits: u32,
    tier_cands: u64,
    tier_buys: u32,
    tier_forgets: u32,
    tier_court_entries: u32,
    tier_raze_returns: u32,
    /// [Д-26] THE WALL REMEMBERS ITS HEIGHT: the upper
    /// height (floors above the boundary) at the last
    /// headroom refusal. A purchase breaks the streak
    /// ONLY by BREACHING the wall (buying at or above
    /// this height): the raze->rebuy churn BELOW the
    /// wall re-buys demolished floors forever and the
    /// tier was never born (refusals=2, streak=0 — the
    /// lazy-post witnessed shift of the retest lock made
    /// the churn the stand's steady state).
    wall_above: u32,
    /// заседание (sat), на котором стена уже
    /// произнесена — один голос стены за заседание
    /// (climb-путь и sit-путь не двоят streak)
    wall_spoken_sat: u32,
    /// АВТОНОМИЯ-1 glass: options the organism armed
    /// ITSELF (the act is ledgered with its evidence).
    autonomy_arms: u32,
    /// Purchases refused by the FINITE ROAD (headroom law:
    /// 16 bits a storey + the ordinal 8 + raw bits > 64) —
    /// the lived hunger for RE-TOKENIZATION (Т-ЯРУС): each
    /// refusal is a bought-and-blocked deepening.
    headroom_refusals: u32,
    /// Т-ЯРУС phase 1, the structural freeze's glass
    /// counter: razes refused because they would bite the
    /// LOWER tower under the tier dictionary (a demolition
    /// below the boundary permutes the key space under the
    /// coined ordinals — dead keys, a lying ledger). This
    /// pressure is the named smoke of the phase-2
    /// lower-raze law.
    lower_raze_refusals: u32,
    /// Names coined over the whole life: shorthand cells
    /// first opened (the lived meter's `names` witness).
    /// A LEDGER, not a state — `forget()` never clears it.
    coined: u64,
    /// Refused gestures over the whole life (the world's
    /// `Cut::Refusal` voice) — glass-mind twin of
    /// `life_deaths`; no court reads it yet.
    life_refusals: u64,
    /// Death states of the CURRENT court window (cleared
    /// each sitting): where the body died, in the full
    /// language of the standing tower — the guard's
    /// classes are fed from here.
    window_deaths: std::collections::HashSet<u64>,
    /// States MOVED THROUGH alive this window: a
    /// successful act that CHANGED the world's key. The
    /// guard's counterproof demands lived MOTION through
    /// a death class — on the ice a skid at the door's
    /// threshold is a lived tick with no death and no
    /// motion, and it must not impeach the guard (it
    /// did: the guard fell within two windows and the
    /// raze cycle returned).
    window_moves: std::collections::HashSet<u64>,
    /// THE FOREIGN PURCHASE LOG (Sh-2's chronometer):
    /// every installed foreign-clock floor as (witnessed tick,
    /// full carrier action context, age modulus, event modulus), append-only. The tower's floors come and
    /// go — the BODY absorbs a bought language into its
    /// gait and the floor lawfully stops earning (the
    /// probe watched X's floor bought, embodied, and
    /// razed in 1400 ticks) — but the S-theorem prices
    /// the PURCHASES, so the purchases are what the
    /// passport must remember.
    foreign_log: Vec<(u64, Context, u32, u32)>,
}

/// A published native observer and its current standing/evidence metadata.
#[derive(Debug)]
#[allow(
    clippy::struct_excessive_bools,
    reason = "the axis flags ARE the design: a floor wears \
              exactly one time/pose tongue and the flags \
              name which compatibility axis was recorded"
)]
struct Floor<A: Copy + Ord> {
    input_epoch: u128,
    observer: observer_runtime::FloorObserver<A>,
    age_mod: u32,
    events_mod: u32,
    /// The time axis of `age_mod`: false = the life age,
    /// true = the clock of the floor DIRECTLY BELOW this
    /// one at purchase time (the tower time of theorem W —
    /// the wreath composition made literal: a storey winds
    /// the storey under it). The bottom floor is always
    /// life-axed: with no floors the witness records
    /// tower=0 and the grammar offers no tower rung.
    tower_axis: bool,
    /// The THIRD time axis (§16.9, Т-ТРИ-ВРЕМЕНИ):
    /// `age_mod` winds the floor's RECENCY clock `rec`
    /// instead of the life age — ticks since the last
    /// carrier act, reset by the same act that advances
    /// `clock`. Exactly one of `tower_axis` / `recency_axis`
    /// may hold (a rung wears one time axis).
    recency_axis: bool,
    /// STANDING COURT (Т-МЕСТО): windows left on trial —
    /// LAW at birth, judged once at zero; 0 = confirmed.
    probation_left: u32,
    /// К-6 THE THRONE'S HEARINGS: how many
    /// re-election/castling sittings THIS rung has
    /// lived — the throne's own Ville ordinal s_r/s_t
    /// (one law's life is one betting series; prereg
    /// form (б) of both К-6 courts).
    hearings: u32,
    /// (Е) The sitting this floor was born at — the
    /// wheel-band scanner's join key: a purchase is
    /// lawful only in a hall the meta-court opened at
    /// ITS OWN sitting (meter against meter, zero
    /// taste). Test-built floors carry 0 (before any
    /// sitting — outside the scanner's jurisdiction).
    born_sat: u32,
    /// The pre-purchase baseline: mean (surprises,
    /// deaths) per sitting over the exec window at climb
    /// time — the glass mind's anchor. By the SITTING
    /// ORDER LAW (the window is written BEFORE any
    /// climb), a young life's first floor inherits the
    /// newborn's own lived chaos, never zero.
    base: (f64, f64),
    /// The WORST death count of any baseline window —
    /// the harm bar. A sign test against the MEAN is a
    /// coin flip on stationary noise (the wind floor —
    /// honest gain 156.9 — was executed at ~50% odds by
    /// the first form); harm must mean «worse than
    /// anything this life had seen»: a strict majority
    /// of trial windows strictly above this worst.
    base_worst_deaths: u32,
    /// True iff this floor climbed OVER a living floor
    /// (the tower was inhabited at climb time). The
    /// standing court's phase-1 jurisdiction is EXACTLY
    /// the stacked floor — the second tenant of the
    /// place (axis interference, Т-МЕСТО). A FIRST floor
    /// on an empty tower changes the life itself (the
    /// bought tongue walks the body to the door: the
    /// Matryoshka floor read surprises 79.5→0 yet deaths
    /// 41→70 per window — a new life, not harm), so its
    /// pre/post curve is not causal evidence; the first
    /// tenant answers to the MDL court alone.
    stacked: bool,
    /// The lived probation pairs (surprises, deaths) per
    /// sitting — at most LAW entries.
    trial: Vec<(u32, u32)>,
    /// The POSE floor (phase C): the ra byte reads the
    /// CURRENT organ pose instead of any time axis —
    /// sight bought by the fourth hall. Exactly one of
    /// tower/recency/theta axes may hold.
    theta_axis: bool,
    /// The living R-clock: acts since the last carrier act
    /// of THIS floor. ONE per floor, riding every key —
    /// the same lesson as the summed `clock` (a
    /// per-situation recency would blind the sources: an
    /// arriving neighbour cannot know the target's shelf
    /// position). Reset to 0 by a carrier act AFTER the
    /// fold reads it (pre-act discipline, symmetric to
    /// `clock`).
    rec: u64,
    #[allow(
        dead_code,
        reason = "the record of WHAT was bought: the \
                  uniform eye no longer reads the mask, \
                  but the passport and forensics may — \
                  transparency keeps the purchase's name"
    )]
    mask: std::collections::HashSet<u64>,
    /// The INFORMATIVE contexts of the purchase — the
    /// (situation, action) keys whose answers varied in
    /// the judged corpus, in the floor's INPUT language.
    /// The demolition counts residue classes over these
    /// alone: a floor's worth is its discrimination, and
    /// wait-ticks at the carrier exercise nothing (the
    /// living-eye tail razed a true floor off wait-only
    /// windows before this clause).
    variable_ctx: std::collections::HashSet<Context>,
    /// The suspect that bought this floor (None = the own
    /// default axis) — the rung's identity for the razed
    /// ledger.
    origin: Option<Context>,
    /// Whose acts advance this floor's clock. Usually the
    /// mask itself; under a bought FOREIGN suspicion — the
    /// lever room whose acts drive a door elsewhere — the
    /// carriers differ from the mask: the mode lives in
    /// another room, and the floor names where.
    carriers: EventDomain,
    /// The SUM clock over all carriers — the floor's tower
    /// time (theorem W): what the storey above winds, and
    /// what the castling contests. NOT the events axis.
    clock: u64,

    /// Consecutive worthless sittings — demolition fires
    /// only at LAW of them (Cor. 18.9 for the architecture
    /// itself: no verdict drumbeat; one lucky window must
    /// not raze a floor the next window earns with).
    idle: u32,
    /// THE GUARD OF THE SILENCED DEATH: a floor born in a
    /// deadly world holds the door — its worth is the
    /// deaths that DON'T happen, and a quiet corpus court
    /// cannot see the unhappened (MDL razed the working
    /// floor and the deaths returned, forever). A guard
    /// floor is exempt from the MDL court in deathless
    /// windows; its counterproof is a lived deathless
    /// tick in one of its DEATH CLASSES (the ebb: the
    /// world's door died, the class survives its
    /// visitors, the guard steps down and MDL rules).
    guard: bool,
    /// Death classes seen while this floor stood (in the
    /// full tower language).
    guard_classes: std::collections::HashSet<u64>,
    /// The life's death count at the last sitting.
    last_deaths: u64,
    /// Live sittings since the last CENSUS re-election:
    /// every LAW² live windows the floor must clear the
    /// judge's FULL price, not the priceless gain — a
    /// partially-correlating lie (mod-5 over a mod-6
    /// truth) re-elects forever on gain>0 (a fifth of the
    /// information is still information) but can never
    /// clear the price it once slipped past on a noisy
    /// window. Honest floors clear it whenever their
    /// subject is truly alive.
    since_census: u32,
}

impl<A: Copy + Ord> Floor<A> {

}


/// Т-ЯРУС (prereg-tier-retokenization): one re-tokenization
/// of the finite road. floors[..boundary] are the FROZEN
/// lower tier (no purchases, no demolitions — a lower raze
/// would permute the key space under the dictionary); the
/// dictionary maps lower-tier keys to dense ordinals, and
/// the upper tower grows over ordinals. Dense bits are
/// declared AT BIRTH and never move (live bits would
/// reprice bought upper storeys — the ledger would lie);
/// an overflowing key takes the SENTINEL letter and counts
/// in the overflow ledger — the smoke of the NEXT tier.
#[derive(Debug)]
struct Tier {
    /// Earlier dictionary stages remain part of every existing floor input.
    previous: Option<Box<Tier>>,
    /// None marks a legacy declared dictionary without a history certificate.
    initial_dict: Option<std::sync::Arc<HashMap<u64, u64>>>,
    birth: Option<causal_coordinates::SampleId>,
    input_epoch: Option<u128>,
    /// floors[..boundary] belong to the lower tier.
    boundary: usize,
    /// lower-tier key -> dense ordinal (a LEDGER: never
    /// cleared; atlas frozen at birth in canonical key
    /// order, live-new keys by appearance).
    dict: TierDictionary,
    /// next free ordinal (capped by the sentinel).
    next_ordinal: u64,
    /// the fixed alphabet width declared at birth.
    dense_bits: u32,
    /// OVERFLOW-REFUSAL ledger — width refusals, the
    /// documented smoke of the next re-tokenization.
    overflows: u64,
    /// witnessed seq at birth (the letter stamp).
    #[allow(
        dead_code,
        reason = "the letter stamp's reader is the \
                  phase-2 tier-stamped letter header"
    )]
    born_at: u64,
}

/// Each key is the input actually read before dispatch, including sentinels
/// produced by an earlier dictionary. Coining must not recompute these inputs.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct TierInput {
    input_epoch: Option<u128>,
    boundary: usize,
    born_at: u64,
    key: u64,
}

impl Drop for Tier {
    fn drop(&mut self) {
        // Long-lived recoin chains must not recurse through Box::drop.
        let mut previous = self.previous.take();
        while let Some(mut stage) = previous {
            previous = stage.previous.take();
        }
    }
}

impl Tier {
    /// Newest first. The temporary stack borrows dictionaries; it never copies
    /// their atlases. Construction/capture reserves its structural work below.
    fn stages(&self) -> Vec<&Self> {
        let mut stages = Vec::new();
        let mut cursor = Some(self);
        while let Some(stage) = cursor {
            stages.push(stage);
            cursor = stage.previous.as_deref();
        }
        stages
    }

    fn fold_at_boundary(&self, boundary: usize, mut key: u64,
        mut capture: impl FnMut(TierInput)) -> (u64, bool)
    {
        let mut crossed = false;
        for stage in self.stages().into_iter().rev() {
            if stage.boundary == boundary {
                capture(TierInput { input_epoch: stage.input_epoch, boundary, born_at: stage.born_at, key });
                key = stage.read(key);
                crossed = true;
            }
        }
        (key, crossed)
    }

    fn read_at_boundary(&self, boundary: usize, key: u64) -> (u64, bool) {
        self.fold_at_boundary(boundary, key, |_| {})
    }

    fn capture_at_boundary(&self, boundary: usize, key: u64,
        inputs: &mut Vec<TierInput>) -> (u64, bool)
    {
        self.fold_at_boundary(boundary, key, |input| inputs.push(input))
    }

    /// Prepay structural stage inspections, captured keys and finish-side coin
    /// visits. Hash-table/allocator costs are adapter costs, not an RSS bound.
    fn capture_work(&self, floors: usize, allowance: usize) -> Option<usize> {
        let per_stage = floors.checked_add(1)?.checked_mul(2)?.checked_add(8)?;
        let mut cost = 0usize;
        let mut cursor = Some(self);
        while let Some(stage) = cursor {
            cost = cost.checked_add(per_stage)?;
            if cost > allowance { return None; }
            cursor = stage.previous.as_deref();
        }
        Some(cost)
    }

    fn coin_captured(&mut self, inputs: &[TierInput]) {
        // Validate the entire stage identity/order before changing any atlas.
        let stages = self.stages();
        assert_eq!(stages.len(), inputs.len(), "exclusive dispatch preserves tier stages");
        assert!(stages.iter().rev().zip(inputs).all(|(stage, input)|
            stage.boundary == input.boundary && stage.born_at == input.born_at && stage.input_epoch == input.input_epoch),
            "exclusive dispatch preserves tier identities");
        drop(stages);
        let mut stages = Vec::with_capacity(inputs.len());
        let mut cursor = Some(self);
        while let Some(stage) = cursor {
            let Tier { previous, dict, next_ordinal, dense_bits, overflows, .. } = stage;
            stages.push((dict, next_ordinal, *dense_bits, overflows));
            cursor = previous.as_deref_mut();
        }
        for ((dict, next, bits, overflows), input) in stages.into_iter().rev().zip(inputs) {
            Self::coin_dictionary(dict, next, bits, overflows, input.key);
        }
    }

    /// Reverse the complete floor/dictionary composition. Every intermediate
    /// sentinel or ambiguous ordinal remains unavailable, never raw zero.
    #[cfg(test)]
    fn raw_key(&self, mut key: u64, mut floors: usize) -> Option<u64> {
        let mut cursor = Some(self);
        while let Some(stage) = cursor {
            let above = floors.checked_sub(stage.boundary)?;
            let ordinal = key.checked_shr(u32::try_from(above.checked_mul(16)?).ok()?)?;
            if ordinal == stage.sentinel() { return None; }
            let mut candidates = stage.dict.iter().filter_map(|(&input, &name)|
                (name == ordinal).then_some(input));
            key = candidates.next()?;
            if candidates.next().is_some() { return None; }
            floors = stage.boundary;
            cursor = stage.previous.as_deref();
        }
        key.checked_shr(u32::try_from(floors.checked_mul(16)?).ok()?)
    }

    fn ancestry_compatible(a: &Self, b: &Self) -> bool {
        if a.boundary != b.boundary { return false; }
        let (mut left, mut right) = (a.previous.as_deref(), b.previous.as_deref());
        loop {
            match (left, right) {
                (None, None) => return true,
                (Some(a), Some(b)) if a.boundary == b.boundary && a.dict == b.dict
                    && a.next_ordinal == b.next_ordinal && a.dense_bits == b.dense_bits
                    && a.initial_dict == b.initial_dict && a.birth.is_some() == b.birth.is_some()
                    && a.input_epoch.is_some() == b.input_epoch.is_some() => {
                        left = a.previous.as_deref();
                        right = b.previous.as_deref();
                    }
                _ => return false,
            }
        }
    }

    fn clone_chain(&self) -> Box<Self> {
        let mut previous = None;
        for stage in self.stages().into_iter().rev() {
            previous = Some(Box::new(Self { previous, boundary: stage.boundary,
                initial_dict: stage.initial_dict.clone(), birth: stage.birth, input_epoch: stage.input_epoch,
                dict: stage.dict.clone(), next_ordinal: stage.next_ordinal,
                dense_bits: stage.dense_bits, overflows: stage.overflows, born_at: stage.born_at }));
        }
        previous.expect("a tier chain contains its root")
    }
    /// The sentinel letter of the unknown/overflowing key.
    fn sentinel(&self) -> u64 {
        (1u64 << self.dense_bits) - 1
    }

    /// Validate a boundary-language name against the actual dictionary. A
    /// sentinel, missing or ambiguous name is unknown, never raw novelty.
    /// This diagnostic scan borrows the atlas; it allocates no inverse map.
    fn validate_name(&self, name: u64) -> Result<(), observer_runtime::origin::Refusal> {
        use observer_runtime::origin::Refusal;
        if name == self.sentinel() { return Err(Refusal::UnknownSourceName { name }); }
        let mut found = false;
        for &value in self.dict.values() {
            if value == name {
                if found { return Err(Refusal::AmbiguousSourceName { name }); }
                found = true;
            }
        }
        if found { Ok(()) } else { Err(Refusal::UnknownSourceName { name }) }
    }

    /// Read-only lookup (the eye): an unknown key reads
    /// the sentinel letter for one tick — the witness
    /// coins its ordinal (or counts the overflow).
    fn read(&self, key: u64) -> u64 {
        self.dict
            .get(&key)
            .copied()
            .unwrap_or_else(|| self.sentinel())
    }

    /// [АНАСТОМОЗ ЯРУСА] Слияние словарей двух тел =
    /// РОЖДЕНИЕ НОВОГО ЯРУСА: объединённый атлас
    /// пере-чеканивается каноническим порядком ключей
    /// (детерминизм — закон рождения яруса), ширина
    /// dense_bits выводится заново из мощности союза,
    /// overflow-леджер чист — это СОБЫТИЕ
    /// ретокенизации, а не мутация живого («bits
    /// declared at birth never move» не нарушен: тут
    /// birth). Обе стороны получают КАРТЫ
    /// ПЕРЕИМЕНОВАНИЯ старый→новый ординал — ими
    /// зовущий пере-ключает свои носители; этажи НАД
    /// ярусом в слияние не входят (они говорят на
    /// ординалах старых языков) — по АНАСТОМОЗ-2 они
    /// претенденты карантина, не сумма.
    #[allow(
        dead_code,
        reason = "орган анастомоза ярусов: судим \
                  the_tier_merge_recoins; зовущий — \
                  Council/Exhaust-слияние следующего \
                  круга"
    )]
    #[must_use]
    pub(crate) fn merge_dicts(
        a: &Self,
        b: &Self,
        born_at: u64,
    ) -> Result<(
        Self,
        HashMap<u64, u64>,
        HashMap<u64, u64>,
    ), ExAnastomosisRefusal> {
        if !Self::ancestry_compatible(a, b) {
            return Err(ExAnastomosisRefusal::TierAncestry);
        }
        let mut keys: Vec<u64> = a
            .dict
            .keys()
            .chain(b.dict.keys())
            .copied()
            .collect();
        keys.sort_unstable();
        keys.dedup();
        let n = keys.len();
        let dense_bits = (usize::BITS
            - (n + 2).leading_zeros())
        .max(2);
        let mut dict: HashMap<u64, u64> =
            HashMap::new();
        for (o, k) in keys.iter().enumerate() {
            dict.insert(
                *k,
                u64::try_from(o)
                    .expect("союз влезает"),
            );
        }
        let remap = |old: &HashMap<u64, u64>| {
            old.iter()
                .map(|(k, &ord)| (ord, dict[k]))
                .collect::<HashMap<u64, u64>>()
        };
        let (ra, rb) =
            (remap(&a.dict), remap(&b.dict));
        Ok((
            Self {
                previous: a.previous.as_ref().map(|stage| stage.clone_chain()),
                // This pure dictionary union has no native installation receipt.
                initial_dict: None, birth: None, input_epoch: None,
                boundary: a.boundary,
                dict: dict.into(),
                next_ordinal: u64::try_from(n)
                    .expect("союз влезает"),
                dense_bits,
                overflows: 0,
                born_at,
            },
            ra,
            rb,
        ))
    }

    /// Witness-side coin: assign the next ordinal, or
    /// count an overflow and return the sentinel.
    #[cfg(test)]
    fn coin(&mut self, key: u64) -> u64 {
        Self::coin_dictionary(&mut self.dict, &mut self.next_ordinal,
            self.dense_bits, &mut self.overflows, key)
    }

    fn coin_dictionary(dict: &mut HashMap<u64, u64>, next: &mut u64,
        bits: u32, overflows: &mut u64, key: u64) -> u64
    {
        if let Some(&ordinal) = dict.get(&key) { return ordinal; }
        let sentinel = (1u64 << bits) - 1;
        if *next >= sentinel {
            *overflows = overflows.saturating_add(1);
            return sentinel;
        }
        let ordinal = *next;
        *next += 1;
        dict.insert(key, ordinal);
        ordinal
    }
}

impl<A: Copy + Ord> ExhaustClimb<A> {
    fn name_actions(&mut self, actions: impl IntoIterator<Item = A>) -> Result<(), causal_coordinates::Refusal> {
        context::register_actions(&mut self.action_names, actions)
            .map_err(|_| causal_coordinates::Refusal::Overflow)
    }

    fn action_named(&self, name: u64) -> Option<A> {
        self.action_names.iter().find_map(|(a, n)| (*n == name).then_some(*a))
    }

    fn context(&self, state: u64, action: A) -> Result<Context, causal_coordinates::Refusal> {
        Context::bind(state, &action, &self.action_names).ok_or(causal_coordinates::Refusal::MissingLayer)
    }

    fn validate_context(&self, context: Context, coordinates: &SampleCoordinates<A>, epoch: u128)
        -> Result<(), causal_coordinates::Refusal>
    {
        if coordinates.cut.input(epoch)? != context.situation()
            || !context.names(&coordinates.cut.event().action, &self.action_names)
        { return Err(causal_coordinates::Refusal::ConflictingSample); }
        Ok(())
    }

    fn cause_domain(&self, epoch: u128, carriers: &EventDomain)
        -> Result<causal_coordinates::Domain<A>, causal_coordinates::Refusal>
    {
        let states = carriers.situation_keys().copied().collect();
        let actions = carriers.explicit_contexts().map(|context| {
            self.action_named(context.action_rank()).map(|action| (context.situation(), action))
                .ok_or(causal_coordinates::Refusal::MissingLayer)
        }).collect::<Result<_,_>>()?;
        Ok(causal_coordinates::Domain::situated(epoch, states, actions))
    }

    /// [МИЦЕЛИЙ U.5] Анастомоз выхлопных тел — зов готовых
    /// органов одним законом (пререг ЭА, порядок обязателен:
    /// юрисдикция старше валюты).
    /// 1. ЯЗЫК: ярусы — рождением (merge_dicts, обе карты);
    ///    язык сменился ⇒ forget() корпусов (climb-род).
    /// 2. ЭТАЖИ: несоматические чужие — приняты (совпавшая
    ///    программа — только перенос её свидетельств, не чужого состояния);
    ///    соматические чужие — претенденты карантина
    ///    (АНАСТОМОЗ-2: чужое не выше своего доказанного).
    /// 3. ЛЕДЖЕРЫ: суммой (закон кристалла); производные —
    ///    сброс (пересуживаются юным телом).
    /// 4. СОВЕТ: в этом теле не живёт — тип не несёт зова.
    /// 5. ЧАСЫ: witnessed = max (время тела соматично);
    ///    ритм-метки — к новому witnessed.
    fn apply_anastomose(
        &mut self,
        mut other: Self,
        plan: observer_transport::MergePlan<A>,
    ) -> ExAnastomosisGlass {
        plan.apply(self, &mut other);
        self.bits_eye += other.bits_eye;
        self.bits_world += other.bits_world;
        for (k, n) in other.miss_names.drain() {
            *self
                .miss_names
                .entry(k)
                .or_insert(0) += n;
        }
        self.climbs += other.climbs;
        self.demolitions += other.demolitions;
        self.foreign_climbs +=
            other.foreign_climbs;
        // Physical death time belongs to the receiving life; foreign trials are quarantined.
        self.shipments += other.shipments;
        self.displaced += other.displaced;
        self.tier_forgets += other.tier_forgets;
        self.max_raw_bits = self
            .max_raw_bits
            .max(other.max_raw_bits);
        // — производные: сброс (пересуживаются) —
        self.exhausted_streak = 0;
        self.blind_streak = 0;
        self.closure_patience = 0;
        self.closure_patience_out = 0;
        self.suspect = None;
        self.pend = None;
        self.in_commit = false;
        self.baptism_strikes = 0;
        self.fresh = 0;
        self.exec_window.clear();
        self.window_log.clear();
        self.window_model_misses = 0;
        self.last_window_model_misses = 0;
        self.window_raw_misses = 0;
        // — 5. ЧАСЫ —
        self.witnessed = self
            .witnessed
            .max(other.witnessed);
        self.last_exec = (0, 0);
        ExAnastomosisGlass { witnessed: self.witnessed }
    }

    /// Forget the lived evidence — the language just
    /// changed (a climb or a molt): old ticks would poison
    /// the next court.
    fn forget(&mut self) {
        self.corpus.clear();
        self.first_next.clear();
        // обе тетради замкнутости гаснут вместе, хотя
        // сырой язык смены не пережил: сравнение честно
        // лишь на ОДНОМ окне — иначе свежий глаз без
        // повторов судился бы против сырого леджера со
        // всей прошлой жизнью
        self.doubt_eye.clear();
        self.doubt_world.clear();
        self.bits_eye = 0.0;
        self.bits_world = 0.0;
        self.pend = None;
        self.baptism_strikes = 0;
        self.fresh = 0;
        // [Д-26 стекло] сброс окна ВНЕ суда — кто
        // гасит fresh-окна юного языка (sits=19 при
        // 184 ожидаемых)
        if self.tier.is_some() {
            self.tier_forgets += 1;
        }
    }
}

/// THE RUT WATCH (autogeny's H9 candidate-theorem made an
/// organ: porosity of memory ⟹ anti-rutting). The carrier
/// is the visit-tick multiset of the window's most visited
/// situation; a RUT is a scale at which that carrier is
/// periodically DENSE (porosity zero, every touched residue
/// class owned by repetition) with the pattern itself
/// proven twice over (2×LAW visits). A rut is the policy's
/// self-capture — and its verdict is the SECOND sleep
/// trigger: stagnation reconsolidates the ice just as the
/// molt does.
#[derive(Debug)]
struct RutWatch {
    window: usize,
    ring: VecDeque<(u64, u64)>,
    ruts: u32,
    /// The last called rut's signature (king, scale): the
    /// SAME rut is one stagnation, not a drumbeat — sleep
    /// fires once per capture, and again only when the
    /// policy falls into a DIFFERENT rut.
    last: Option<(u64, u32)>,
}

/// THE GLASS MIND: the organism's own two-layer trace. The
/// E16 reader LIVES the stream of situation bytes; the
/// glass trace records the whole life (hot window + ice);
/// and the molt — the moment the map is declared a lie —
/// is when the organism SLEEPS: the ice is reconsolidated
/// over the organ that lived it (UHM's reconsolidation of
/// the Γ-trace, ridden on the molt the way the key ladder
/// rides it).
#[derive(Debug)]
struct GlassMind {
    reader: crate::ctw::CtwBits,
    trace: crate::glacier::GlassTrace,
    dreams: u32,
    /// The living signature of the CURRENT episode (an
    /// episode runs from one dream to the next): the FNV
    /// walk of every trace byte since the last dream —
    /// ORDER-SENSITIVE, unlike a bare xor-fold (whose
    /// commutativity made two lives around one ring read
    /// as twins: the recognition court caught it). At the
    /// dream the brush writes its byte-fold into the
    /// adjoint and the walk restarts.
    episode_fold: u64,
    /// Where the current episode begins on the lived trace
    /// (the tick position of the last dream). The wound's
    /// reconsolidation re-reads exactly this segment.
    episode_start: usize,
}

/// Historical expressibility labels for an empirical acquisition-window
/// diagnostic. `Blind` records search stagnation, not an impossibility proof;
/// `Expressed` records absence of misses in a completed window, not future
/// generalization. Neither enumerates a language or certifies its limits.
/// See reference/expressivity-contract-2026-10-09.md, section 3.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Expressibility {
    /// The front is open: purchases land, or the smoky
    /// streak has not yet survived a full re-election cycle.
    Open,
    /// More than LAW unsuccessful acquisition sittings after re-election.
    /// Evidence can motivate representation growth but does not distinguish
    /// inadequate data, search, objective, hidden state or grammar.
    Blind {
        /// the streak of smoky empty sittings
        smoky_sittings: u32,
        /// the depth wall's refusals (the tower's headroom)
        depth_wall: u32,
        /// the last full window's model misses (the smoke)
        misses: u32,
    },
    /// The window went silent: no variable keys, no model
    /// misses — expressed AS FAR AS LIVED.
    Expressed,
}

/// A PLANNING EDGE: from where, by what act, into where.
///
/// Both ends are `u64` addresses, so a positional call
/// `relax(s, e, n, ..)` lets them be swapped SILENTLY: the walk
/// still builds, `prev` links the nodes backwards, the unwind
/// yields a plan in reverse — and every value stays in range.
/// The pose names the ends.
#[derive(Clone, Copy)]
struct PlanEdge<A> {
    from: u64,
    act: A,
    into: u64,
}

/// A NODE POPPED OFF THE FRONTIER: its address and the price it
/// was expanded at.
#[derive(Clone, Copy)]
struct PlanStep {
    node: u64,
    hz: u64,
    len: u32,
}

/// HOW A PLAN LOOKS AT A NODE'S OFFERING.
///
/// `tabled` — the learnt act table (`table_acts`) ahead of the
/// lived `seen`. `deadly_cut` — a lethal ban tears the edge: the
/// `[BUILD-TEARS SCAR]` law (ft09/cd82: every plan died on its
/// very first act, `exam_hit == deaths` bit for bit).
///
/// TODAY the ring-to-root carries NEITHER, and the exam carries
/// both. The twin court uncovered the difference — before this
/// pose it stood as two look-alike bodies a thousand lines apart
/// and read as an accident of copying. It is NOT corrected here:
/// changing what the ring sees is a change of behaviour, and
/// behaviour is judged by the canon, not by a duplication census.
/// The pose only makes the difference LOUD — whoever reads
/// `deadly_cut: false` is obliged to ask why.
#[derive(Clone, Copy)]
struct PlanSight {
    tabled: bool,
    deadly_cut: bool,
}

/// THE PLANNING FRONTIER: Dijkstra over the lived map.
///
/// Three maps, seeding the root, popping the heap and discarding
/// the stale entry — twenty-one lines — stood TWICE: in the exam
/// (`plan_exam_pred_cut`) and in the ring-to-root
/// (`plan_ring_to_root`). The divergence here is SILENT: the
/// comparison key `(hz, len)` IS the currency of the walk, and
/// were one planner to start discarding on `<=` instead of `<` it
/// would take different roads at equal price — both prices stay
/// lawful, and the split would surface only as tape drift.
struct PlanFrontier<A> {
    prev: HashMap<u64, Option<(u64, A)>>,
    best: HashMap<u64, (u64, u32)>,
    heap: std::collections::BinaryHeap<
        std::cmp::Reverse<(u64, u32, u64)>,
    >,
}

impl<A: Copy> PlanFrontier<A> {
    /// An empty frontier seeded with the planning root.
    fn new(from: u64) -> Self {
        use std::cmp::Reverse;
        let mut f = Self {
            prev: HashMap::new(),
            best: HashMap::new(),
            heap: std::collections::BinaryHeap::new(),
        };
        f.prev.insert(from, None);
        f.best.insert(from, (0, 0));
        f.heap.push(Reverse((0, 0, from)));
        f
    }

    /// The nearest node; stale heap entries are skipped.
    ///
    /// The heap cannot decrease a key, so an improved node sits in
    /// it TWICE. Discarding by `best` is not a speed-up but a
    /// condition of correctness: without it the node is expanded at
    /// the WORSE of its prices and the road is built through it.
    fn pop(&mut self) -> Option<PlanStep> {
        use std::cmp::Reverse;
        while let Some(Reverse((hz, len, node))) =
            self.heap.pop()
        {
            if self
                .best
                .get(&node)
                .is_some_and(|&(bh, bl)| {
                    (bh, bl) < (hz, len)
                })
            {
                continue;
            }
            return Some(PlanStep { node, hz, len });
        }
        None
    }

    /// Take the edge — if it improves the price of its far end.
    fn relax(
        &mut self,
        edge: PlanEdge<A>,
        hz: u64,
        len: u32,
    ) {
        use std::cmp::Reverse;
        let better = self
            .best
            .get(&edge.into)
            .is_none_or(|&(bh, bl)| {
                (hz, len) < (bh, bl)
            });
        if better {
            self.best.insert(edge.into, (hz, len));
            self.prev.insert(
                edge.into,
                Some((edge.from, edge.act)),
            );
            self.heap
                .push(Reverse((hz, len, edge.into)));
        }
    }

    /// The road from the planning root to `s`: acts and nodes.
    ///
    /// There is one more node than act — nodes are the ENDS, and
    /// the cut at a level change reads `nodes[i + 1]`.
    fn unwind(&self, s: u64) -> (Vec<A>, Vec<u64>) {
        let mut acts = Vec::new();
        let mut nodes = vec![s];
        let mut cur = s;
        while let Some(Some((p, e))) =
            self.prev.get(&cur).copied()
        {
            acts.push(e);
            cur = p;
            nodes.push(cur);
        }
        acts.reverse();
        nodes.reverse();
        (acts, nodes)
    }

    /// Has the plan expanded this node.
    fn reached(&self, node: u64) -> bool {
        self.best.contains_key(&node)
    }
}

impl<
    A: Copy
        + Eq
        + std::hash::Hash
        + Ord
        + crate::worldmap::Wire,
> Organism<A>
{
    /// A newborn IN THE CONSCIOUS MODE (EL-185): gamma, dt
    /// and lambda are named core constants, not client
    /// magic.
    #[must_use]
    pub fn conscious() -> Self {
        Self::new()
            .with_regimen(CONSCIOUS_GAMMA, CONSCIOUS_DT, 1)
            .with_injection(CONSCIOUS_LAMBDA)
    }

    /// THE CANON OF LIFE (a NAMED door — the
    /// knob-and-name law; omega's naming: `conscious` is
    /// taken by the Γ-gate canon and would mislabel
    /// this): the composition the day's courts CERTIFY —
    /// the exhaustion organ with its language court, the
    /// patrol's revision, the lethal ledger's graves and
    /// the molt organ. Phase D's instrument proved the
    /// composition IS the gaze policy (patrol × ledger ×
    /// pose-floor × plan: the eye is open at the door
    /// 86-89% from the first quarter, an open walk dies
    /// at 4.7% vs 43% blind, life deaths ×20 down), and
    /// the bare config is the named negative — the
    /// COLD-START LOOP of attention (silent pose hall,
    /// three recency floors, zero sight). `Organism::
    /// new()` stays the bare stage ON PURPOSE: poverty
    /// stands are lawful courts; the canon is a named
    /// door, never a silent default. Certified by
    /// `the_canonical_life_is_the_certified_composition`.
    /// NAMED SEAM (molt × stochastic edge): the molt rule
    /// reads ANY surprise burst as «the world changed its
    /// law», but a stochastic edge (the blind door walk)
    /// surprises forever — under `with_molt` the canon
    /// stand re-molted all life and the door-eye never
    /// matured past ~64% (the certificate refused it).
    /// The molt stays an OPTION with its own court
    /// (`molt_heals_a_world_that_changed_its_law`); its
    /// entry into the canon awaits the seam's cure (a
    /// molt that does not count half-passable edges).
    #[must_use]
    pub fn canonical(window: usize) -> Self {
        Self::new()
            .with_exhaustion_climb(window).expect("fresh observer configuration")
            .with_patrol()
            .with_amortized_patrol()
            .with_lethal_ledger()
            // ПО СЛОВУ КНИГИ ОРГАНОВ (первый акт
            // самоулучшения, 02.09): валент Δ=−1.02
            // цены жизни (24.09<25.11) — с рынком
            // целей ось-V эксплуатируется; двойник
            // G1_NO_VALENT — архив
            .with_valent_maybe()
    }

    /// Валент по книге органов; G1_NO_VALENT=1 —
    /// архив-двойник (до-книжный канон).
    #[must_use]
    fn with_valent_maybe(self) -> Self {
        if std::env::var("G1_NO_VALENT").is_ok() {
            self
        } else {
            self.with_valent_rollout()
        }
    }

    /// Scale each bounded discovery request in native engineering-work units.
    /// Exact fractional and unused rights remain owned by the shared ledger.
    /// This policy does not change statistical name prices or physical work.
    /// No policy and a fraction of one preserve request grants and order.
    #[must_use]
    pub fn with_sitting_budget(
        mut self,
        frac: f64,
    ) -> Self {
        if let Some(ex) = &mut self.exhaust {
            ex.glass_budget_frac = Some(frac);
        }
        self
    }

    /// Snapshot cumulative reconciled discovery work from the current ledger.
    /// Includes partial/retained Automatic, Duel and explicit semantic-analysis work;
    /// excludes live physical execution and unmetered allocator/CPU costs.
    /// Unsettled or poisoned accounting is an explicit refusal, never zero.
    pub fn acquisition_work_receipt(&self) -> Result<AcquisitionWorkReceipt, AcquisitionWorkRefusal> {
        self.exhaust.as_ref().ok_or(AcquisitionWorkRefusal::Unarmed)?
            .acquisition_budget.receipt()
    }

    /// Arm Т-ЯРУС (the re-tokenization organ, prereg):
    /// LAW consecutive headroom refusals freeze the lived
    /// key atlas into a dense dictionary and the tower
    /// grows on over ordinals. An OPTION until its
    /// certificate (the molt/breathing precedent).
    #[must_use]
    pub fn with_tier_ladder(mut self) -> Self {
        if let Some(ex) = &mut self.exhaust {
            ex.tier_armed = true;
        }
        self
    }

    /// АВТОНОМИЯ-1 on: the organism may arm its own
    /// options by their unarmed trigger ledgers (v1 menu:
    /// the tier ladder). The arming act is ledgered
    /// (AUTONOMY-ARM with the evidence counter); the tier
    /// then births BY ITS OWN LAW reading THE SAME refusal
    /// ledger — the evidence is not consumed by the act.
    #[must_use]
    pub fn with_autonomy(mut self) -> Self {
        self.autonomy = true;
        self
    }

    /// Options the organism armed itself (glass).
    #[must_use]
    pub fn autonomy_arms(&self) -> u32 {
        self.exhaust
            .as_ref()
            .map_or(0, |e| e.autonomy_arms)
    }

    /// [ГРЁЗА ПРАВИЛАМИ] взвести орган программно
    /// (суды; внешний двойник — env G1_RULEDREAM).
    #[must_use]
    pub fn with_rule_dream(mut self) -> Self {
        self.rule_dream = true;
        self
    }

    /// Arm VALENCE v1 (the value rollout, prereg): among
    /// lawful acts the organism dreams each road over its
    /// OWN map and prefers the least-mortal one (toll =
    /// ban-ledger deaths along the dream; the dream ends
    /// where the map ends). Ties fall back to the old
    /// order — an empty ledger leaves behaviour
    /// bit-exact. THEORY's court: the valent organism
    /// dies less often than its valueless twin.
    #[must_use]
    pub fn with_valent_rollout(mut self) -> Self {
        self.valent = true;
        self
    }

    /// THE INTERVENTION DOCKET on (Ф-3.2 v1): the choice
    /// of which frozen verdict gets the window's one
    /// hearing becomes a COURT (least-heard first, the
    /// bank-of-forms gate on deadly cases) instead of the
    /// accident of the walk. Option until the certificate
    /// (the molt/breathing/tier/valence precedent).
    #[must_use]
    pub fn with_intervention_docket(mut self) -> Self {
        self.intervention = true;
        self
    }

    /// A newborn: empty geography, a fresh tower off the anchor.
    #[must_use]
    pub fn new() -> Self {
        let anchor = conscious_anchor();
        Self {
            action_failure: None,
            action_stop: None,
            terminal_receipts: Vec::new(),
            source_time: causal_coordinates::physical_time::Clock::new(),
            action_attempts: 0,
            declared_task: None,
            goal_attempts: Default::default(), goal_report: None,
            tower: CogTower::from_base(anchor),
            wheel: DuoWheel::new(),
            anchor,
            seen: HashMap::new(),
            glue_counts: HashMap::new(),
            glue_dirty: std::collections::HashSet::new(),
            glue_rep: HashMap::new(),
            glue_members: HashMap::new(),
            plan_goal: None,
            goal_graves:
                crate::holdings::Graves::new(30),
            plan_expect: None,
            pending_refusals: Vec::new(),
            plan_version: 0,
            cur_raw_key: 0,
            cur_sensory: None,
            root_raw: None,
            glass_on: false,
            glass_events: Vec::new(),
            coords: HashMap::new(),
            coin_ledger: HashMap::new(),
            coin_sold: std::collections::HashSet::new(),
            since_root: 0,
            coin_sat_at: 0,
            coin_tacts: 0,
            coin_births_at: 0,
            steer_w_map: 0,
            steer_w_exam: 0,
            steer_pending: None,
            steer_lane: [0; 4],
            steer_autopsy: [0; 4],
            world_tasks: Vec::new(),
            unmint: HashMap::new(),
            mk_cur_acts: 0,
            mk_cur_new: 0,
            mk_serve_acts: 0,
            mk_new_life: 0,
            mk_pays: 0,
            mk_pays_seen: 0,
            mk_pays_cur: 0,
            mk_pays_serve: 0,
            mk_kron: 0,

            mk_glass: [0; 5],
            mk_epoch_level: u32::MAX,
            hold_goal: None,
            hold_torn: 0,
            hold_fail: 0,
            fr_task_glass: [0; 4],
            fr_mk_glass: [0; 5],
            fr_knocks: 0,
            fr_marked: false,
            bored: false,
            barren: HashMap::new(),
            progress_seen: f64::MIN,
            combo_next: HashMap::new(),
            combo_queue:
                std::collections::VecDeque::new(),
            mile_dry: 0,
            pilgrim_glass: [0; 5],
            pilgrim_hold: 0,
            pilgrim_dry: 0,
            pilgrim_goal: None,
            world_road: false,
            world_road_ticks: 0,
            menu_stale: 0,
            world_try: None,
            exp_refuted: None,
            world_road_key: None,
            last_here: None,
            pilgrim_ripe: false,
            pilgrim_started: false,
            pilgrim_len0: 0,
            plan_step_lv: None,
            plan_step_reset: false,
            plan_step_pre: None,
            plan_phase_retry: 0,
            last_step_act: None,
            plan_step_ref: None,
            plan_step_court: None,
            plan_notes: false,
            notes_retry_hits: 0,
            notes_spent: 0,
            pilgrim_fails:
                std::collections::HashMap::new(),
            salt_seen: false,
            pilgrim_burn_cnt: 0,
            plan_refs: std::collections::VecDeque::new(),
            bore_glass: [0; 3],
            lived_pairs: HashMap::new(),
            bored_risk: false,
            exp_streak: 0,
            exp_cold: false,
            exp_glass: [0; 3],
            dry_breaks: 0,
            table_acts: HashMap::new(),
            hold_glass: [0; 6],
            tear_kinds: [0; 4],
            knocks: 0,
            dream_nodes: 0,
            dream_plans: 0,
            dream_last_buy: 0,
            dream_muted: 0,
            any_world_tasks: false,
            task_glass: [0; 4],
            plan_is_task: false,
            plan_from_map: false,
            ban_lang_clears: 0,
            deadly_bans: HashMap::new(),
            retest_streak: HashMap::new(),
            retest_simple: false,
            task_plan_death: [0; 4],
            task_goal_census:
                std::collections::HashMap::new(),
            task_attempts: HashMap::new(),
            task_graves:
                crate::holdings::Graves::new(30),
            task_plan_clock: 0,
            plan_edge: None,
            last_exam_cost: None,
            live_tape: std::collections::VecDeque::new(),
            choice_counts: [0; 12],
            moved_since_reset: true,
            novel_since_reset: true,
            goal_census: HashMap::new(),
            progress_goals:
                crate::holdings::Ledger::new(),
            goal_rate: Vec::new(),
            goal_rate_open: None,
            prev_progress: -1.0,
            progress_goals_on: true,
            goal_probe: [0; 7],
            pending_goal_fire: None,
            transfer_pending: None,
            tried_transfers:
                std::collections::HashSet::new(),
            walk_acts: Vec::new(),
            swap_pending: None,
            skill_counts: HashMap::new(),
            skill_bodies: HashMap::new(),
            skills: crate::holdings::Ledger::new(),
            walk_steps_total: 0,
            cur_walk: None,
            goal_regret: HashMap::new(),
            patrol_futile: HashMap::new(),
            map: crate::worldmap::WorldMap::new(),
            arrivals: HashMap::new(),
            act_dest: HashMap::new(),
            last_branch: 255,
            just_arrived: None,
            glue_on: false,
            sig_counts: HashMap::new(),
            sig_novel: HashMap::new(),
            belief_market:
                crate::beliefs::BeliefMarket::new(),
            rule_door: crate::rules::Door::new(),
            rule_model: None,
            rule_dream: false,
            goal_role_graves:
                crate::holdings::Graves::new(30),
            rule_goal_armed: None,
            road_rest: false,
            vte_plan: false,
            vte_failed_at: None,
            sig_len_use: HashMap::new(),
            sig_of: HashMap::new(),
            table: HashMap::new(),
            plan: VecDeque::new(),
            pending: None,
            organs: None,
            organ_feedback: 0.0,
            molt_rule: None,
            surprise_window: VecDeque::new(),
            surprises_total: 0,
            predictions_total: 0,
            molts: 0,
            patrol: false,
            patrol_licence: false,
            patrol_blocked: 0,
            patrol_amortized: false,
            cur_pose: 255,
            steps: 0,
            verified_at: HashMap::new(),
            attention: 0.0,
            attention_kind: LiftKind::Degeneracy,
            root: None,
            gamma: 1.0,
            dt: 0.01,
            feed_ticks: 1,
            injection: 0.0,
            unfold: 1,
            glass: None,
            rut: None,
            gaze: false,
            looks: 0,
            identity: None,
            identity_watch: false,
            breaks: 0,
            bans: None,
            ban_at: HashMap::new(),
            name_map: Vec::new(),
            exhaust: None,
            hunger: false,
            valent: false,
            appeals: HashMap::new(),
            appeal_gate: 0,
            intervention: false,
            autonomy: false,
            hearings: HashMap::new(),
            defers: HashMap::new(),
            docket_case: None,
            docket_heard: 0,
            defer_exhausted: 0,
            surprise_ring: VecDeque::new(),
            burn_glass:
                std::collections::BTreeMap::new(),
        }
    }

    /// Declare typed candidate schemas before recipient observations.
    /// Observer cards import closed native code under the recipient's byte and
    /// syntax bounds; admission and fresh validation use recipient evidence.
    /// Source-bound Local cards and unimportable Clock cards return explicit
    /// refusals; every accepted card supplies closed native code.
    #[must_use]
    pub fn with_name_map<C: Into<crate::letter::Schema>>(
        mut self,
        map: Vec<C>,
    ) -> Result<Self, LibraryConfigurationRefusal<A>> {
        let map = map.into_iter().map(Into::into).collect::<Vec<_>>();
        let declared = if let Some(agenda) = self.exhaust.as_mut().and_then(|ex| ex.program_agenda.as_mut()) {
            agenda.declare_library(&map)
        } else {
            observer_acceptance::Agenda::<A>::automatic(ObserverResources::default()).declare_library(&map)
        };
        if let Err(reason) = declared {
            return Err(LibraryConfigurationRefusal { reason, organism: Box::new(self) });
        }
        self.name_map = map;
        Ok(self)
    }


    /// THE LETHAL LEDGER on: deaths write frozen verdicts
    /// (freeze at LAW deaths, avoid while alternatives
    /// exist, lift only on refutation).
    #[must_use]
    pub fn with_lethal_ledger(mut self) -> Self {
        self.bans = Some(HashMap::new());
        self
    }

    /// [77b37a38] ПРОСТАЯ ПЕРЕОЦЕНКА (старый канон):
    /// тяжёлый бан опровержим одним живым проходом —
    /// для малых миров стендов, где мажоритарный
    /// замок (streak >= mass) морит фазы голодом и
    /// глушит лестницу смертей (банк/мета/этажи);
    /// боевые прогоны держат замок — число tu93.
    #[must_use]
    pub fn with_simple_retest(mut self) -> Self {
        self.retest_simple = true;
        self
    }

    /// THE LANGUAGE COURT on (Cor. 18.5(ii)): the second
    /// lawful climb signal beside the molt. The organism
    /// keeps a ring of `window` witnessed world-answers
    /// (context, age, variability against the FIRST
    /// answer); once per fresh window the pointwise court
    /// (Def. 18.6, selective grammar) sits — when a carrier
    /// mask and a period buy their two-part price, the eye
    /// CLIMBS TO the bought modulus on exactly the bought
    /// carriers; when nothing buys, the language stands,
    /// honestly exhausted for that window.
    #[must_use]
    pub fn with_exhaustion_climb(
        self,
        window: usize,
    ) -> Result<Self, ObserverConfigurationRefusal<A>> {
        self.with_exhaustion_resources(window, ObserverResources::default())
    }

    /// Declare the exact false-admission allocation before any observation.
    /// The default is 1/20; this is a research policy, not a task parameter or
    /// measured accuracy. Error guarantees additionally need the model's
    /// causal/predictable finite-experiment premises and null dominance.
    pub fn declare_observer_admission_risk(&mut self, risk: crate::program::code_mass::Mass)
        -> Result<(), ObserverAdmissionRefusal> {
        let ex=self.exhaust.as_mut().ok_or(ObserverAdmissionRefusal::Unarmed)?;
        let agenda=ex.program_agenda.as_mut().ok_or(ObserverAdmissionRefusal::Unarmed)?;
        agenda.declare_risk(risk)
    }

    /// Construct an observer under explicit allowances. Replacing a completed
    /// observer starts a new native lineage; an unfinished boundary or unknown
    /// delivery returns the original organism without replacement.
    #[must_use]
    pub fn with_exhaustion_resources(self, window: usize, resources: ObserverResources) -> Result<Self, ObserverConfigurationRefusal<A>> {
        self.with_exhaustion_resources_factory(window, resources, observer_acceptance::Agenda::automatic)
    }

    /// Opt in to the same scheduler's full-target predictive role before data.
    /// Owned native prefix callbacks require owned action types only here;
    /// categorical/borrowed construction retains its previous lifetime bounds.
    pub fn with_predictive_exhaustion_resources(self, window: usize, resources: ObserverResources)
        -> Result<Self, ObserverConfigurationRefusal<A>> where A: 'static {
        self.with_exhaustion_resources_factory(window, resources, observer_acceptance::Agenda::automatic_predictive)
    }

    fn with_exhaustion_resources_factory(mut self, window: usize, resources: ObserverResources,
        factory: fn(ObserverResources) -> observer_acceptance::Agenda<A>) -> Result<Self, ObserverConfigurationRefusal<A>> {
        if let Err(reason) = self.check_observer_lifecycle() {
            return Err(ObserverConfigurationRefusal { reason, organism: Box::new(self) });
        }
        let mut authority = match causal_coordinates::HistoryAuthority::new() {
            Ok(authority) => authority,
            Err(_) => return Err(ObserverConfigurationRefusal { reason: ObserverLifecycleRefusal::HistoryAuthorityCapacity, organism: Box::new(self) }),
        };
        let birth = match authority.birth() {
            Ok(birth) => birth,
            Err(_) => return Err(ObserverConfigurationRefusal { reason: ObserverLifecycleRefusal::HistoryAuthorityCapacity, organism: Box::new(self) }),
        };
        let agenda = match factory(resources).with_library(&self.name_map) {
            Ok(agenda) => agenda,
            Err(_) => return Err(ObserverConfigurationRefusal { reason: ObserverLifecycleRefusal::TransferLibraryCapacity, organism: Box::new(self) }),
        };
        self.exhaust = Some(ExhaustClimb {
            last_observed_cut: None,
            window,
            observer_history: causal_coordinates::Timeline::new(
                birth, 1, 1, resources.history_nodes),
            observer_work: resources.search_work,
            program_duel: std::cell::RefCell::new(observer_duel::program::Courts::default()),
            observer_capture_work: resources.capture_work,
            action_names: std::collections::BTreeMap::new(),
            base_input_epoch: 1,
            last_raze: None,
            domain_retirements: Vec::new(),
            #[cfg(all(test, feature = "serde"))]
            domain_retirement_audit: None,
            domain_retirement_limit: resources.history_nodes,
            domain_retirement_used: 0,
            pending_domain_retirement: None,
            after_act_continuation: None,
            before_act_continuation: None,
            proposal_cancellations: Vec::new(),
            input_links: std::collections::BTreeMap::new(),
            corpus: HashMap::new(),
            first_next: HashMap::new(),
            doubt_eye: HashMap::new(),
            doubt_world: HashMap::new(),
            bits_eye: 0.0,
            bits_world: 0.0,
            pend: None,
            baptism_strikes: 0,
            fresh: 0,
            witnessed: 0,
            floors: Vec::new(),
            program_agenda: Some(agenda),
            observer_current_raw: None,
            top_tally: HashMap::new(),
            ctx_tally: HashMap::new(),
            climbs: 0,
            demolitions: 0,
            suspect: None,
            miss_names:
                std::collections::HashMap::new(),
            window_model_misses: 0,
            last_window_model_misses: 0,
            window_log: VecDeque::new(),
            window_raw_misses: 0,
            closure_patience: 1,
            closure_patience_out: 1,
            in_commit: false,
            max_raw_bits: 0,
            exec_window: std::collections::VecDeque::new(),
            last_exec: (0, 0),
            razed: std::collections::BTreeMap::new(),
            foreign_climbs: 0,
            sat: 0,
            coined: 0,
            tier: None,
            tier_armed: false,
            headroom_streak: 0,
            tier_sits: 0,
            tier_cands: 0,
            tier_buys: 0,
            tier_forgets: 0,
            tier_court_entries: 0,
            tier_raze_returns: 0,
            wall_above: 0,
            wall_spoken_sat: 0,
            autonomy_arms: 0,
            headroom_refusals: 0,
            lower_raze_refusals: 0,
            shipments: 0,
            exhausted_streak: 0,
            blind_streak: 0,
            glass_budget_frac: None,
            acquisition_budget: acquisition_budget::Ledger::default(),
            displaced: 0,
            life_deaths: 0,
            life_refusals: 0,
            window_deaths:
                std::collections::HashSet::new(),
            window_moves:
                std::collections::HashSet::new(),
            foreign_log: Vec::new(),
        });
        Ok(self)
    }

    /// THE HUNGER FOR EVIDENCE on: the epistemic valence —
    /// an idle mind walks toward the thinnest-evidenced
    /// lawful context of its situation, feeding its own
    /// court. Requires the language court (the corpus IS
    /// the measure).
    #[must_use]
    pub fn with_evidence_hunger(mut self) -> Self {
        self.hunger = true;
        self
    }

    /// The hunger is a SWITCH, runtime included: a life has
    /// phases, and what paces one phase starves another
    /// (the tide court teaches bare — the hunger would
    /// dissolve the lesson — and ebbs hungry — the parked
    /// mind would never witness the change). The passport
    /// reports the switch either way.
    pub fn set_evidence_hunger(&mut self, on: bool) {
        self.hunger = on;
    }

    /// The bought wreath modulus of the TOP floor (0 = no
    /// events axis wound; the organ off reads 0 too).
    #[must_use]
    pub fn wreath_mod(&self) -> u32 {
        self.exhaust.as_ref().map_or(0, |e| {
            e.floors
                .last()
                .map_or(0, |f| f.events_mod)
        })
    }

    /// The tower's height in bought floors.
    #[must_use]
    pub fn tower_floors(&self) -> usize {
        self.exhaust
            .as_ref()
            .map_or(0, |e| e.floors.len())
    }

    /// THE ROLLOUT (P-4's organism organ, the
    /// pro-completion of time): re-read the road NOT YET
    /// lived — walk the organism's own transition map
    /// forward from a state, choosing at each step the
    /// FIRST verified action (the map's own habit), and
    /// STOP HONESTLY at the edge of knowledge (an
    /// unmapped pair returns the walk so far — a rollout
    /// never invents). The world is untouched; the trace
    /// is not written: this is the reading of a trace
    /// that does not exist, C36's twin turned forward.
    #[must_use]
    pub fn rollout(
        &self,
        from: u64,
        steps: usize,
    ) -> Vec<(u64, A, u64)> {
        let mut road = Vec::new();
        let mut state = from;
        for _ in 0..steps {
            let Some(acts) = self.seen.get(&state)
            else {
                break;
            };
            let Some((&(_, act), &next)) = acts
                .iter()
                .find_map(|&a| {
                    self.table
                        .get_key_value(&(state, a))
                })
            else {
                break;
            };
            road.push((state, act, next));
            state = next;
        }
        road
    }
    /// Read a branch of the same program tower. No separate arithmetic rules
    /// are allowed for imagined execution.
    fn eyed_programs(&self, raw: u64, observers: &[observer_runtime::FloorObserver<A>], age: u64,
        budget: &mut crate::program::observer::Budget<'_, ObserverWork>) -> Result<u64, String>
    {
        let Some(ex) = &self.exhaust else { return Ok(raw); };
        if observers.len() != ex.floors.len() { return Err("foreign observer tower".into()); }
        let mut key = raw;
        for (i, observer) in observers.iter().enumerate() {
            if let Some(tier) = &ex.tier {
                let (next, crossed) = tier.read_at_boundary(i, key);
                key = next;
            }
            let read = observer.read(observer_runtime::View { sensory: None,  raw, input: key, life_age: age,
                episode: self.source_time.episode().ok_or("missing native episode")?, pose: self.cur_pose }, budget)
                .map_err(|reason| format!("observer read: {reason:?}"))?;
            key = read.key;
        }
        if let Some(tier) = &ex.tier { key = tier.read_at_boundary(observers.len(), key).0; }
        Ok(key)
    }


    /// THE ROLLOUT IN TIME (P-4 complete for the
    /// organism): walk the map forward while TICKING
    /// virtual copies of the tower's clocks and the life
    /// age — exactly the witness's law (pack with the
    /// pre-act clock, then advance the carriers'). The
    /// next state is NEVER taken from the table's packed
    /// answer alone: its raw part is the world's
    /// deterministic road, its residues are RE-FOLDED
    /// under the virtual time — a recorded answer carries
    /// the clock of ITS moment, not of ours.
    ///
    /// # Panics
    /// Never in practice: the byte-width guards mirror
    /// the witness's own (action lists are short).
    #[must_use]
    pub fn rollout_in_time(
        &self,
        raw_from: u64,
        steps: usize,
    ) -> Vec<(u64, A, u64)> {
        let Some(ex) = &self.exhaust else {
            return self.rollout(raw_from, steps);
        };
        // A tier ordinal cannot recover the raw physical key without an
        // inverse dictionary. Keep that interpretation explicit below.
        let mut observers: Vec<_> = ex.floors.iter().map(|floor| floor.observer.fork()).collect();
        let mut work = ObserverWork { remaining: ex.observer_work };
        let mut budget = crate::program::observer::Budget::new(&mut work, crate::program::ExecutionLimit::Unlimited);
        let mut vage = self.source_time.life_age();
        let mut road = Vec::new();
        let Ok(mut state) = self.eyed_programs(raw_from, &observers, vage, &mut budget) else { return road; };
        let mut raw = raw_from;
        for _ in 0..steps {
            let Some(acts) = self.seen.get(&state)
            else {
                break;
            };
            // the habit is the FRESHEST verified act —
            // the map's living gait, not its oldest
            // entry (a first-verified pick walked the
            // dream into a phase the body had long
            // learnt to wait out)
            let Some((act, &packed_next)) = acts
                .iter()
                .filter_map(|&a| {
                    let n = self
                        .table
                        .get(&(state, a))?;
                    let receipt = self.verified_at.get(&(state, a))?;
                    if receipt.next() != Some(*n) {
                        return None;
                    }
                    Some((receipt.at, a, n))
                })
                .max_by_key(|&(v, _, _)| v)
                .map(|(_, a, n)| (a, n))
            else {
                break;
            };
            if !ex.action_names.contains_key(&act) { break; }
            let mut key = raw;
                let mut updates = Vec::with_capacity(observers.len());
            let mut complete = true;
            for (i, (floor, observer)) in ex.floors.iter().zip(&observers).enumerate() {
                if let Some(tier) = &ex.tier {
                    let (next, crossed) = tier.read_at_boundary(i, key);
                    key = next;
                    }
                let Some(episode) = self.source_time.episode() else { complete = false; break; };
                let input = observer_runtime::View { sensory: None,  raw, input: key, life_age: vage, episode, pose: self.cur_pose };
                let read = observer.read(input.clone(), &mut budget);
                let update = observer.prepare(input, act, &mut budget);
                let (Ok(read), Ok(update)) = (read, update) else { complete = false; break; };
                    key = read.key;
                updates.push(update);
            }
            if !complete { break; }
            for (observer, update) in observers.iter_mut().zip(updates) {
                observer.commit(update).expect("exclusive imagined branch");
            }
            let Some(age) = vage.checked_add(1) else { break; };
            vage = age;
            // This is the same conservative inverse used by relation queries.
            let Some(next_raw) = self.observed_raw_key(packed_next) else { break; };
            let Ok(next) = self.eyed_programs(next_raw, &observers, vage, &mut budget) else { break; };
            raw = next_raw;
            road.push((state, act, next));
            state = next;
        }
        road
    }

    /// P-RED-3 MODEL CLOSURE (§16): the language is CLOSED
    /// when the last `closure_patience` judged windows saw
    /// not one MODEL lie (events/time misses; raw novelty
    /// does not open the model — the world may move). The
    /// patience is BOUGHT by the strategy meta-trade on
    /// the registry trace (§16.6-а), never set by hand.
    #[must_use]
    pub fn model_closed(&self) -> bool {
        self.exhaust
            .as_ref()
            .is_some_and(|ex| ex.in_commit)
    }

    /// §16.6-а: one sitting's line in the registry trace —
    /// roll the window tallies into the chronicle and let
    /// the strategy meta-trade re-judge the patience.
    fn roll_the_chronicle(ex: &mut ExhaustClimb<A>) {
        ex.last_window_model_misses =
            ex.window_model_misses;
        let cap = (crate::law::LAW_OF_REPETITION
            * crate::law::LAW_OF_REPETITION)
            as usize;
        if ex.window_log.len() == cap {
            ex.window_log.pop_front();
        }
        ex.window_log.push_back((
            ex.window_model_misses,
            ex.window_raw_misses,
        ));
        ex.window_model_misses = 0;
        ex.window_raw_misses = 0;
        Self::strategy_trade(ex);
        // the automaton steps by the BOUGHT patiences
        let run = |clean: bool| -> u32 {
            u32::try_from(
                ex.window_log
                    .iter()
                    .rev()
                    .take_while(|&&(m, _)| {
                        (m == 0) == clean
                    })
                    .count(),
            )
            .expect("a LAW²-capped chronicle")
        };
        if ex.in_commit {
            if run(false) >= ex.closure_patience_out {
                ex.in_commit = false;
            }
        } else if run(true) >= ex.closure_patience {
            ex.in_commit = true;
        }
    }

    /// ПОЛИ-1: the public window of the virtual eye —
    /// the exact key the fold prints for a raw world
    /// state at THIS moment's clocks (the stand's tape
    /// writes it before every act).
    #[must_use]
    pub fn try_eyed_public(&self, raw: u64) -> Result<u64, String> { self.try_eyed(raw) }

    pub fn eyed_public(&self, raw: u64) -> Result<u64, String> { self.try_eyed(raw) }


    /// THE SHIPMENT ACT: hand the schemas out and WRITE
    /// THE RECORD — the lived `spores` witness (autogeny's
    /// sixth act: spawning beyond the subject). The
    /// glass read [`export_schemas`](Self::export_schemas)
    /// testifies nothing: a capability is not a record.
    pub fn ship_schemas(&mut self) -> Vec<crate::letter::Schema> {
        let cards = self.export_schemas();
        if !cards.is_empty()
            && let Some(ex) = &mut self.exhaust
        {
            ex.shipments += 1;
        }
        cards
    }

    /// Export executable hypotheses, with lexical code and semantic resources.
    /// Receiver admission and validation always use its own future evidence.
    #[must_use]
    pub fn export_schemas(&self) -> Vec<crate::letter::Schema> {
        self.exhaust.as_ref().map(|ex| ex.floors.iter().map(|floor| {
            match observer_acquired::portable::export(floor.observer.general().producer()) {
                Ok(bytes) => crate::letter::Schema::Observer(crate::letter::ObserverSchema { bytes }),
                Err(reason) => crate::letter::Schema::Local(format!("{reason:?}")),
            }
        }).collect()).unwrap_or_default()
    }

    /// §16.6-в STRATEGY HERITAGE: the bought patience is
    /// part of what a lineage hands down — the child
    /// STARTS from the parent's patience, and the fourth
    /// meta-trade keeps re-judging it on the child's own
    /// chronicle (heritage advises, the court rules — the
    /// same law as every other heritage organ).
    #[must_use]
    pub fn with_strategy_heritage(
        mut self,
        patience: u32,
    ) -> Self {
        if let Some(ex) = &mut self.exhaust {
            ex.closure_patience = patience.max(1);
        }
        self
    }

    /// The strategy heritage to hand down: the patience
    /// this life has bought (1 if no tower lives).
    #[must_use]
    pub fn strategy_heritage(&self) -> u32 {
        self.exhaust
            .as_ref()
            .map_or(1, |ex| ex.closure_patience)
    }

    /// §16.6-а THE STRATEGY META-TRADE (the fourth trade):
    /// the closure PATIENCE is bought on the registry
    /// trace. Candidate policies: close after 1 clean
    /// window, or after LAW consecutive clean windows.
    /// The price of a policy is the model lies it would
    /// have admitted UNDER COMMIT on the lived chronicle
    /// (a lie under a deep plan is the expensive one);
    /// the tie goes to the smaller patience (the cheaper
    /// name). Bought, printed, applied — never set.
    fn strategy_trade(ex: &mut ExhaustClimb<A>) {
        let cap = (crate::law::LAW_OF_REPETITION
            * crate::law::LAW_OF_REPETITION)
            as usize;
        if ex.window_log.len() < cap {
            return;
        }
        let price = |k: u32| -> u64 {
            let mut clean_run = 0u32;
            let mut cost = 0u64;
            for &(m, _) in &ex.window_log {
                // the policy was committed BEFORE this
                // window if the run of clean windows so
                // far had reached k
                if clean_run >= k {
                    cost += u64::from(m);
                }
                if m == 0 {
                    clean_run += 1;
                } else {
                    clean_run = 0;
                }
            }
            cost
        };
        let one = price(1);
        let law = price(crate::law::LAW_OF_REPETITION);
        let bought = if law < one {
            crate::law::LAW_OF_REPETITION
        } else {
            1
        };
        if bought != ex.closure_patience {
            eprintln!(
                "META-STRATEGY	patience {}->{bought} (commit-lies: k1={one} kLAW={law})",
                ex.closure_patience
            );
            ex.closure_patience = bought;
        }
        // §16.6-а' THE FIFTH TRADE: the exit hysteresis.
        // A policy's price on the lived chronicle = the
        // model lies it would admit while STILL committed
        // after dirt, plus its FALSE EXITS (an exit
        // followed immediately by a clean window evicted
        // a proven regime for one flash). Tie to the
        // cheaper name.
        let out_price = |k_out: u32| -> u64 {
            let k_in = ex.closure_patience;
            let mut clean_run = 0u32;
            let mut dirty_run = 0u32;
            let mut committed = false;
            let mut cost = 0u64;
            let log: Vec<u32> = ex
                .window_log
                .iter()
                .map(|&(m, _)| m)
                .collect();
            for (i, &m) in log.iter().enumerate() {
                if committed && m > 0 {
                    cost += u64::from(m);
                }
                if m == 0 {
                    clean_run += 1;
                    dirty_run = 0;
                } else {
                    dirty_run += 1;
                    clean_run = 0;
                }
                if committed {
                    if dirty_run >= k_out {
                        committed = false;
                        if log
                            .get(i + 1)
                            .is_some_and(|&n| n == 0)
                        {
                            cost += 1;
                        }
                    }
                } else if clean_run >= k_in {
                    committed = true;
                }
            }
            cost
        };
        let o1 = out_price(1);
        let olaw =
            out_price(crate::law::LAW_OF_REPETITION);
        let bought_out = if olaw < o1 {
            crate::law::LAW_OF_REPETITION
        } else {
            1
        };
        if bought_out != ex.closure_patience_out {
            eprintln!(
                "META-STRATEGY\thysteresis {}->{bought_out} (price: k1={o1} kLAW={olaw})",
                ex.closure_patience_out
            );
            ex.closure_patience_out = bought_out;
        }
    }

    /// THE STRATEGY IS A DEDUCTION, NOT A MODE (§16.6,
    /// the owner's doctrine: «predict-miss-model-plan-
    /// prove-experiment» must be a natural mechanism the
    /// cognition ENGAGES as strategy — so the strategy is
    /// a pure function of the registry's own numbers,
    /// never a knob):
    /// - an unjudged or lying model → "probe" (shallow
    ///   acts, buy classes; misses are the tuition);
    /// - a closed model → "commit" (deep valued plans —
    ///   depth belongs to the verified);
    /// - a closed model whose strict plan is EMPTY is the
    ///   caller's cue for the decisive probe ("decide" is
    ///   not deducible here: plan emptiness lives at the
    ///   planner, and the market already wires it).
    ///
    /// The strategy is READ, not set: any consumer (the
    /// arena, a stand, the meta-trade) asks and obeys the
    /// same deduction the depth gate already enforces.
    #[must_use]
    pub fn strategy(&self) -> &'static str {
        if self.model_closed() {
            "commit"
        } else {
            "probe"
        }
    }

    /// Compatibility projection of `reachability_report`. `Some(true)` means
    /// exhaustion of the declared observed ordinary-step relation only. It
    /// requires complete reachable rows; empirical calm alone is insufficient.
    /// This is not a proof that every possible world continuation is absent.
    #[must_use]
    pub fn prove_unreachable<F: Fn(u64) -> bool>(
        &self,
        raw_from: u64,
        horizon: usize,
        class: F,
    ) -> Option<bool> {
        match self.prove_reach(raw_from, horizon, class) {
            None => None,
            Some(None) => Some(true),
            Some(Some(_)) => Some(false),
        }
    }

    /// A deterministic witness in the same named observation relation used by
    /// dispatch, or its complete exhaustion. Missing observations, unresolved
    /// branches and exhausted resources return `None`, with concrete obligations
    /// available through `reachability_report`.
    #[must_use]
    pub fn prove_reach<F: Fn(u64) -> bool>(
        &self,
        raw_from: u64,
        horizon: usize,
        class: F,
    ) -> Option<Option<Vec<A>>> {
        match self.reachability_report(raw_from, horizon, class).verdict {
            ReachabilityVerdict::Witness { prefix, .. } => Some(Some(prefix)),
            ReachabilityVerdict::Exhausted => Some(None),
            ReachabilityVerdict::Unknown => None,
        }
    }

    /// Inspect proof obligations without mutating the model or hiding a cause
    /// inside an empty plan. A witnessed path can coexist with unknown rows
    /// elsewhere; only an exhaustive negative result requires their absence.
    #[must_use]
    pub fn reachability_report<F: Fn(u64) -> bool>(
        &self,
        raw_from: u64,
        horizon: usize,
        class: F,
    ) -> ReachabilityReport<u64, A> {
        use observed_relation::{BranchPolicy, Incomplete, Report};
        let Ok(start) = self.try_eyed(raw_from) else { return Report::unknown(raw_from, Incomplete::UnknownProjection); };
        if !self.model_closed() {
            return Report::unknown(start, Incomplete::OpenModel);
        }
        if self.observed_raw_key(start) != Some(raw_from) {
            return Report::unknown(start, Incomplete::UnknownProjection);
        }
        let Some(budget) = self.exhaust.as_ref().and_then(|ex| {
            ex.window
                .checked_mul(crate::law::LAW_OF_REPETITION as usize)
        }) else {
            return Report::unknown(start, Incomplete::NodeBudget);
        };
        observed_relation::search(
            start,
            |state| self.observed_raw_key(state).is_some_and(&class),
            |state| {
                let mut row = self.observed_relation_row(state, None);
                if self.observed_raw_key(state).is_none() {
                    row.gaps.push((None, Incomplete::UnknownProjection));
                }
                row
            },
            horizon,
            budget,
            BranchPolicy::Deterministic,
        )
    }

    /// Invert only the known part of the representation. Tier ordinals are
    /// dictionary names, not raw world keys. A sentinel or an ambiguous inverse
    /// cannot acquire a raw interpretation by bit shifting.
    fn observed_raw_key(&self, state: u64) -> Option<u64> {
        let Some(ex) = self.exhaust.as_ref() else {
            return Some(if self.unfold > 1 { state >> 8 } else { state });
        };
        if ex.floors.is_empty() && ex.tier.is_none() {
            return Some(if self.unfold > 1 { state >> 8 } else { state });
        }
        let mut key = state;
        for boundary in (0..=ex.floors.len()).rev() {
            if let Some(tier) = &ex.tier {
                for stage in tier.stages().into_iter().filter(|stage| stage.boundary == boundary) {
                    if key == stage.sentinel() { return None; }
                    let mut inputs = stage.dict.iter().filter_map(|(&input, &name)| (name == key).then_some(input));
                    let input = inputs.next()?;
                    if inputs.next().is_some() { return None; }
                    key = input;
                }
            }
            if boundary != 0 { key = ex.floors[boundary - 1].observer.input_of(key)?; }
        }
        Some(key)
    }

    /// Shared evidence adapter for exploration and deterministic reachability.
    /// Unknown actions remain explicit obligations. A ban restricts the policy;
    /// it is not a proof of world impossibility. Only caller-declared reset
    /// semantics add an edge without an ordinary transition observation.
    fn observed_relation_row(
        &self,
        state: u64,
        reset: Option<A>,
    ) -> observed_relation::Row<u64, A> {
        use observed_relation::{Incomplete, Row};
        let mut row = Row {
            gaps: Vec::new(),
            edges: Vec::new(),
        };
        if let Some(actions) = self.seen.get(&state) {
            for &action in actions {
                let Some(receipt) = self.verified_at.get(&(state, action)) else {
                    row.gaps
                        .push((Some(action), Incomplete::MissingObservation));
                    continue;
                };
                if receipt.outcomes.is_empty() {
                    row.gaps
                        .push((Some(action), Incomplete::MissingObservation));
                } else if receipt
                    .outcomes
                    .iter()
                    .all(|o| matches!(o, ObservedWorldOutcome::End(_)))
                {
                    // A known end has no ordinary successor in this episode.
                } else if self.banned(state, action) {
                    row.gaps.push((Some(action), Incomplete::PolicyBlocked));
                } else if receipt
                    .outcomes
                    .iter()
                    .all(|o| matches!(o, ObservedWorldOutcome::Next(_)))
                {
                    let nexts = receipt
                        .outcomes
                        .iter()
                        .filter_map(|o| match *o {
                            ObservedWorldOutcome::Next(next) => Some(next),
                            _ => None,
                        })
                        .collect();
                    row.edges.push((action, nexts));
                } else {
                    row.gaps
                        .push((Some(action), Incomplete::UnsupportedOutcome));
                }
            }
        } else {
            row.gaps.push((None, Incomplete::MissingObservation));
        }
        if let (Some(action), Some(root)) = (reset, self.root) {
            row.edges.push((action, vec![root]));
        }
        row
    }

    /// THE VALUED ROLLOUT (axis V, organ v1): pick the
    /// act whose dreamt road carries the FEWEST banned
    /// steps — the lethal ledger is the first currency,
    /// and P-4's dream becomes a PLAN the moment a value
    /// reads it. Ties fall back to the freshest habit
    /// (the dream's own pick); an empty map abstains.
    #[must_use]
    pub fn valued_act(
        &self,
        raw: u64,
        depth: usize,
    ) -> Option<A> {
        // P-RED-3 gate: only a CLOSED model has earned a
        // deep plan — an open one is still guessing and
        // probes at LAW² depth (their numbers: single
        // probes miss 37.1%, planned batches 2.9% — depth
        // belongs to the verified)
        let depth = if self.model_closed() {
            depth
        } else {
            depth.min(
                (crate::law::LAW_OF_REPETITION
                    * crate::law::LAW_OF_REPETITION)
                    as usize,
            )
        };
        let bans = self.bans.as_ref()?;
        let state = self.try_eyed(raw).ok()?;
        let acts = self.seen.get(&state)?;
        let mut best: Option<(u32, u32, A)> = None;
        for &a in acts {
            let Some(&next) =
                self.table.get(&(state, a))
            else {
                continue;
            };
            let mut cost = u32::from(
                bans.contains_key(&(state, a)),
            );
            let shift = self
                .exhaust
                .as_ref()
                .map_or(0, |ex| 16 * ex.floors.len());
            let road = self
                .rollout(next, depth.saturating_sub(1));
            let _ = shift;
            for &(s, ra, _) in &road {
                cost += u32::from(
                    bans.contains_key(&(s, ra)),
                );
            }
            // THE SECOND CURRENCY (EIG curiosity),
            // lexicographic under death: among the
            // least-deadly acts prefer the road that
            // reaches the EDGE OF KNOWLEDGE soonest — an
            // unmapped pair truncates the dream, so a
            // SHORT dream is a near frontier; curiosity
            // is walking toward one's own ignorance
            // without paying blood for it.
            let frontier = u32::try_from(road.len())
                .unwrap_or(u32::MAX);
            if best.is_none_or(|(c, f, _)| {
                cost < c || (cost == c && frontier < f)
            }) {
                best = Some((cost, frontier, a));
            }
        }
        best.map(|(_, _, a)| a)
    }

    /// P-RED-5: the REFUTED fact family — the named miss
    /// tallies and the closure witness are first-class
    /// self-description (their NOTES page grew the same
    /// section on its own; the form converged
    /// independently).
    fn refuted_facts(
        &self,
        ex: &ExhaustClimb<A>,
    ) -> Vec<(&'static str, u64)> {
        let g = |k: &str| {
            ex.miss_names.get(k).copied().unwrap_or(0)
        };
        vec![
            ("raw_novelty", g("raw")),
            ("events_lies", g("events")),
            ("time_lies", g("time")),
            ("observer_lies", g("observer")),
            ("origin_unknown", g("unknown")),
            ("byte_toll", g("byte-toll")),
            (
                "model_closed",
                u64::from(self.model_closed()),
            ),
            (
                "strategy_commit",
                u64::from(
                    self.strategy() == "commit",
                ),
            ),
        ]
    }

    /// THE REGISTRY (P-5's foundation, the meta-grammar's
    /// ground): the organism's own constructions as ONE
    /// typed self-description — every organ that holds
    /// state names itself and its numbers. The meta-court
    /// that will one day BUY compositions can only trade
    /// what is honestly listed; and the owner's mandate
    /// (limit-level detail, verifiable control) is
    /// exactly this list. Two courts hold it: the
    /// registry never lies (each number equals its direct
    /// reader) and the registry is complete (a stateful
    /// organ absent from the list is a defect by
    /// definition).
    /// THE REGISTRY (П-5): the organism's typed
    /// self-description — fact families with numbers, the
    /// meta-trade's ground truth (courted: never lies,
    /// speaks all of it).
    #[must_use]
    pub fn registry(
        &self,
    ) -> Vec<(&'static str, Vec<(&'static str, u64)>)>
    {
        let mut out: Vec<(
            &'static str,
            Vec<(&'static str, u64)>,
        )> = Vec::new();
        out.push((
            "map",
            vec![
                (
                    "transitions",
                    self.table.len() as u64,
                ),
                ("steps", self.steps),
                ("molts", u64::from(self.molts)),
                ("life_age", self.source_time.life_age()),
                (
                    "unfold",
                    u64::from(self.unfold.max(1)),
                ),
            ],
        ));
        if let Some(ex) = &self.exhaust {
            out.push((
                "refuted",
                self.refuted_facts(ex),
            ));
            out.push((
                "tower",
                vec![
                    (
                        "floors",
                        ex.floors.len() as u64,
                    ),
                    (
                        "climbs",
                        u64::from(ex.climbs),
                    ),
                    (
                        "demolitions",
                        u64::from(ex.demolitions),
                    ),
                    (
                        "guards",
                        ex.floors
                            .iter()
                            .filter(|f| f.guard)
                            .count()
                            as u64,
                    ),
                    (
                        "razed_families",
                        ex.razed.len() as u64,
                    ),
                    ("witnessed", ex.witnessed),
                    (
                        "sittings",
                        u64::from(ex.sat),
                    ),
                ],
            ));
            out.push((
                "schema",
                vec![
                    (
                        "foreign_climbs",
                        u64::from(ex.foreign_climbs),
                    ),
                    (
                        "purchase_log",
                        ex.foreign_log.len() as u64,
                    ),
                    (
                        "name_map_rungs",
                        self.name_map.len() as u64,
                    ),
                ],
            ));
        }
        if let Some(bans) = &self.bans {
            out.push((
                "lethal_ledger",
                vec![("bans", bans.len() as u64)],
            ));
        }
        out
    }

    /// The rollout from a RAW world key: the eye folds
    /// the tower first (the road is read in the language
    /// the map is written in).
    #[must_use]
    pub fn rollout_from_raw(
        &self,
        raw: u64,
        steps: usize,
    ) -> Vec<(u64, A, u64)> {
        self.try_eyed(raw).map(|state| self.rollout(state, steps)).unwrap_or_default()
    }

    /// The foreign purchase log: every foreign-clock
    /// installation ever made, as (witnessed tick, full carrier action
    /// context, age modulus, event modulus) —
    /// the S-theorem's chronometer (floors are absorbed
    /// into the gait and lawfully razed; purchases are
    /// forever).
    #[must_use]
    pub fn foreign_purchases(
        &self,
    ) -> Vec<(u64, Context, u32, u32)> {
        self.exhaust
            .as_ref()
            .map(|e| e.foreign_log.clone())
            .unwrap_or_default()
    }


    /// Floors retired by the demolition court.
    #[must_use]
    pub fn demolitions(&self) -> u32 {
        self.exhaust
            .as_ref()
            .map_or(0, |e| e.demolitions)
    }

    /// [СУД КРЕЩЕНИЯ, вердикт наружу] `Some((глаз_бит,
    /// мир_бит))` когда род глаза уличён кворумом LAW
    /// заседаний подряд: КТ-цена предсказания ОДНОГО
    /// исхода (сырого ответа мира) под глазным ключом
    /// ВЫШЕ, чем под собственным ключом мира. Общий исход
    /// обязателен: дай каждому языку свой — и тонкий
    /// платил бы за алфавит исхода, а не за обусловливание
    /// (М-49). Виновность значит: крещение либо склеило
    /// разные положения мира (слепой глаз платит энтропией
    /// исходов), либо внесло в ключ то, чего в мире нет
    /// (дрожащий глаз платит КТ-разбавлением счётчиков);
    /// сносить нечего — надо крестить заново. Организм не
    /// выбирает род глаза сам: мироспецифика живёт в
    /// адаптере, и покупка нового рода — дело рынка глаза,
    /// читающего этот вердикт. Оба числа кладутся рядом,
    /// чтобы рынок торговал ЗНАЯ ЦЕНУ, а не по факту
    /// обвинения.
    #[must_use]
    pub fn baptism_convicted(
        &self,
    ) -> Option<(f64, f64)> {
        let ex = self.exhaust.as_ref()?;
        if ex.baptism_strikes
            < crate::law::LAW_OF_REPETITION
        {
            return None;
        }
        Some((ex.bits_eye, ex.bits_world))
    }

    /// НАПРАВЛЕННОЕ-1, form (б) of the duel — THE
    /// DEFICIT PASSPORT AS A METER (the expressibility
    /// precedent: a pure reading of the standing
    /// ledgers, changes nothing): what the organism
    /// lacks BY NAME, priced from its own books — miss
    /// classes from the census (price = the lied count),
    /// ban families from the lethal ledger (price = the
    /// deaths paid), the Blind verdict as its own row
    /// (price = the smoky streak). Rows sort by price
    /// descending, name ascending — bit-deterministic
    /// (Н-4). Emission as a LETTER is a speech act and
    /// stays the school's court (ЛД-6); the meter only
    /// reads, so it is lawful before the pair duel.
    #[must_use]
    pub fn deficit_passport(&self) -> Vec<(String, f64)>
    where
        A: std::fmt::Debug,
    {
        let mut rows: Vec<(String, f64)> = Vec::new();
        if let Some(ex) = &self.exhaust {
            for (name, n) in &ex.miss_names {
                #[allow(
                    clippy::cast_precision_loss,
                    reason = "ledger tallies"
                )]
                rows.push((
                    format!("miss:{name}"),
                    *n as f64,
                ));
            }
            if ex.blind_streak
                > crate::law::LAW_OF_REPETITION
            {
                rows.push((
                    "blind:menu".to_string(),
                    f64::from(ex.blind_streak),
                ));
            }
        }
        if let Some(bans) = &self.bans {
            for ((state, act), n) in bans {
                rows.push((
                    format!(
                        "ban:{state:#x}/{act:?}"
                    ),
                    f64::from(*n),
                ));
            }
        }
        rows.sort_by(|a, b| {
            b.1.total_cmp(&a.1)
                .then_with(|| a.0.cmp(&b.0))
        });
        rows
    }

    /// The expressibility verdict (Ф-3.1) — a pure reading
    /// of the standing ledgers; changes nothing (the meter
    /// law). Blind strictly demands the streak to outlive
    /// the duel: the re-election sits at LAW, so a streak
    /// beyond LAW means it came and razed nothing.
    #[must_use]
    pub fn expressibility_verdict(
        &self,
    ) -> Expressibility {
        let Some(ex) = &self.exhaust else {
            return Expressibility::Open;
        };
        // the smoke citation reads the last COMPLETED
        // window's ledger pair (model + raw misses) — on a
        // floorless world the smoke is all raw, and a
        // model-only citation lied by zero (the first
        // court run caught it)
        let (m, r) = ex
            .window_log
            .back()
            .copied()
            .unwrap_or((
                ex.window_model_misses,
                ex.window_raw_misses,
            ));
        if ex.blind_streak
            > crate::law::LAW_OF_REPETITION
        {
            return Expressibility::Blind {
                smoky_sittings: ex.blind_streak,
                depth_wall: ex.headroom_refusals,
                misses: m + r,
            };
        }
        if ex.blind_streak == 0
            && m + r == 0
            && ex.witnessed > ex.window as u64
        {
            return Expressibility::Expressed;
        }
        Expressibility::Open
    }

    /// [МИЦЕЛИЙ U.5] Анастомоз организмов — слияние тел
    /// знаний одним зовом (пререг ЭА). Возвращает стекло;
    /// отказ типом ДО мутаций (ЭА-4). Кольцо сюрпризов —
    /// конкатенация с капом LAW² (лента прозрачности).
    pub fn anastomose(
        &mut self,
        other: &mut Self,
    ) -> Result<ExAnastomosisGlass, ExAnastomosisRefusal>
    {
        let (Some(receiver), Some(donor)) = (&self.exhaust, &other.exhaust) else {
            return Err(ExAnastomosisRefusal::Unarmed);
        };
        if [receiver, donor].iter().any(|ex| ex.before_act_continuation.is_some()
            || ex.after_act_continuation.is_some() || ex.pending_domain_retirement.is_some()) {
            return Err(ExAnastomosisRefusal::ObserverContinuation);
        }
        if self.check_observer_lifecycle().is_err() || other.check_observer_lifecycle().is_err() {
            return Err(ExAnastomosisRefusal::ObserverHistory);
        }
        let plan = observer_transport::MergePlan::prepare(receiver, donor)?;
        let donor = other.exhaust.take().expect("preflighted donor");
        let ex = self.exhaust.as_mut().expect("preflighted receiver");
        let glass = ex.apply_anastomose(donor, plan);

        let cap = (crate::law::LAW_OF_REPETITION
            * crate::law::LAW_OF_REPETITION)
            as usize;
        for s in other.surprise_ring.drain(..) {
            if self.surprise_ring.len() == cap {
                self.surprise_ring.pop_front();
            }
            self.surprise_ring.push_back(s);
        }
        eprintln!("ANASTOMOSE\twitnessed={}", glass.witnessed);
        Ok(glass)
    }

    /// Identity of the currently installed top floor, before any rollback.
    #[must_use]
    pub fn top_floor_identity(&self) -> Option<FloorIdentity> {
        let ex = self.exhaust.as_ref()?;
        let floor = ex.floors.last()?;
        // A dictionary above the floor owns the current top output instead.
        if ex.tier.as_ref().is_some_and(|tier| tier.boundary == ex.floors.len()) { return None; }
        Some(FloorIdentity { lineage: ex.observer_history.lineage(), input_epoch: floor.input_epoch,
            output_epoch: ex.observer_history.epoch() })
    }

    /// The latest completed rollback; retained in one bounded receipt slot.
    #[must_use]
    pub fn last_raze_receipt(&self) -> Option<&RazeReceipt> {
        self.exhaust.as_ref()?.last_raze.as_ref()
    }

    /// [L3-ТРАССА, стекло] длина живого плана
    /// (нот) — диагносту исполнения.
    #[must_use]
    pub fn plan_len(&self) -> usize {
        self.plan.len()
    }

    /// Rungs bought by the language court (0 when the organ
    /// is off; molt-driven climbs are counted by `molts`).
    #[must_use]
    pub fn climbs(&self) -> u32 {
        self.exhaust.as_ref().map_or(0, |e| e.climbs)
    }

    /// The life's vital record — (age, deaths, refusals):
    /// how long this body has lived since its last true
    /// death, how many times the world cut its episode,
    /// and how many gestures the world refused (the
    /// [`Cut`] voices, told apart). Glass-mind reading;
    /// refusals need the exhaustion organ to be counted.
    #[must_use]
    pub fn life_vitals(&self) -> (u64, u64, u64) {
        (
            self.source_time.life_age(),
            self.exhaust
                .as_ref()
                .map_or(0, |e| e.life_deaths),
            self.exhaust
                .as_ref()
                .map_or(0, |e| e.life_refusals),
        )
    }

    /// THE LIVED METER of autogeny (prereg
    /// prereg-autogeny-lived-meter): the six defining acts
    /// WITNESSED from records this life actually wrote —
    /// never from API capability. The witness-order law:
    /// the organism HAS a sleep function, but only a lived
    /// sleep testifies. Witnesses, by name:
    /// - reads — the witness tape has ticks
    ///   (`witnessed > 0`);
    /// - names — the coined ledger: shorthand cells this
    ///   life first opened (`coined > 0`; a ledger, never
    ///   cleared — the corpus itself is working state
    ///   and `forget()` wipes it on a language change);
    /// - `measures_self` — the language court SAT over this
    ///   life's own output (`sat > 0`);
    /// - `rewrites_self` — a lived molt or a razed floor
    ///   (`molts > 0 || !razed.is_empty()`);
    /// - `buys_organs` — a floor was climbed (the purchase
    ///   record, `climbs > 0`);
    /// - `spores` — the shipment ledger: schemas were
    ///   HANDED OUT by the lived act `ship_schemas`
    ///   (`shipments > 0`; `export_schemas` stays a glass
    ///   read and testifies nothing — a capability is not
    ///   a record).
    ///
    /// Feed the result to `synarc_autogeny::layer_of`; a
    /// torn ladder is a live diagnosis, not an error.
    #[must_use]
    pub fn lived_caps(&self) -> synarc_autogeny::Caps {
        let ex = self.exhaust.as_ref();
        synarc_autogeny::Caps {
            reads: ex
                .is_some_and(|e| e.witnessed > 0),
            names: ex.is_some_and(|e| e.coined > 0),
            measures_self: ex
                .is_some_and(|e| e.sat > 0),
            rewrites_self: self.molts > 0
                || ex.is_some_and(|e| {
                    !e.razed.is_empty()
                }),
            buys_organs: ex
                .is_some_and(|e| e.climbs > 0),
            spores: ex
                .is_some_and(|e| e.shipments > 0),
        }
    }

    /// Seats re-let by the re-election court (glass).
    #[must_use]
    pub fn displaced(&self) -> u32 {
        self.exhaust
            .as_ref()
            .map_or(0, |e| e.displaced)
    }

    /// Standing frozen verdicts (0 when the ledger is off).
    #[must_use]
    pub fn frozen_bans(&self) -> usize {
        self.bans.as_ref().map_or(0, |b| {
            b.values()
                .filter(|&&d| d >= crate::law::LAW_OF_REPETITION)
                .count()
        })
    }

    /// Whether this transition's verdict is frozen.
    /// THE HUNGER FOR EVIDENCE — the epistemic valence,
    /// priced in the court's own currency. With the
    /// language court present, an idle mind (no untried, no
    /// plan, no patrol) walks toward the THINNEST-evidenced
    /// lawful context of its situation: the act whose fair-
    /// corpus cell holds the fewest lived ticks. Zero new
    /// constants — the measure is the corpus itself. This
    /// is what cures the parked tail: knowing the door
    /// perfectly is no reason to stop feeding the court
    /// that made the knowing possible. Without the court
    /// the old behaviour stands (the first lawful act).
    fn hungriest(
        &self,
        state: u64,
        lawful: &[A],
    ) -> Option<A> {
        let Some(ex) = &self.exhaust else {
            return lawful.first().copied();
        };
        if !self.hunger {
            return lawful.first().copied();
        }
        lawful.iter().copied().min_by_key(|&a| {
            // The witness records the retained native-action name. Menu
            // position can change and is not that identity. An unnamed action
            // has no recorded context yet, so its witnessed count is zero.
            let context = Context::bind(state, &a, &ex.action_names);
            // the monotone context tally, not the windowed
            // corpus: the hunger's measure must survive the
            // court's own housekeeping (a suspect rotation
            // wipes the corpus, and a gait that goes blind
            // for a window wobbles — the body court caught
            // exactly that)
            context.and_then(|context| ex.ctx_tally.get(&context))
                .copied()
                .unwrap_or(0)
        })
    }

    /// VALENCE v1 — the dream's death toll: roll the road
    /// out over the organism's OWN table from (state,
    /// first) to the first unknown transition or a key
    /// repeat (the dream ends where the map ends; depth
    /// is not a constant), choosing at each dreamt step
    /// the least-mortal KNOWN act; the toll is the sum of
    /// ban-ledger death counts along the road.
    fn dream_death_toll(
        &self,
        state: u64,
        first: A,
    ) -> u64 {
        let Some(bans) = &self.bans else {
            return 0;
        };
        let mut toll = u64::from(
            bans.get(&(state, first))
                .copied()
                .unwrap_or(0),
        );
        let Some(&start_next) =
            self.table.get(&(state, first))
        else {
            return toll;
        };
        let mut cur = start_next;
        let mut visited: std::collections::HashSet<u64> =
            std::collections::HashSet::new();
        visited.insert(state);
        while visited.insert(cur) {
            let Some(acts) = self.seen.get(&cur) else {
                break;
            };
            let Some((a, w)) = acts
                .iter()
                .map(|&a| {
                    (
                        a,
                        u64::from(
                            bans.get(&(cur, a))
                                .copied()
                                .unwrap_or(0),
                        ),
                    )
                })
                .min_by_key(|&(_, w)| w)
            else {
                break;
            };
            toll += w;
            match self.table.get(&(cur, a)) {
                Some(&n) => cur = n,
                None => break,
            }
        }
        toll
    }

    /// [ПРЕРЕГ-19] леджер грёзы: свип — ПАТЧ MVT
    /// (узлы = такты кормления, планы = гашения):
    /// свип разрешён, пока ожидание следующей
    /// покупки не превысило средний межпокупочный
    /// интервал жизни (та же интервальная форма,
    /// что пререг-13/14; ни одной ручки). Крот
    /// тройки: узел = deepcopy мира на мосту,
    /// свип звался каждый пустоплановый такт —
    /// часы CPU без вопроса «окупается ли».
    /// [ЦЕЛЬ-ПАМЯТЬ] рвач при held: не попытка,
    /// но не бесплатен навсегда (кап LAW²).
    fn note_hold_torn(&mut self) {
        if self.exp_streak > 0 {
            // смерть-в-пути экспедиции (стекло)
            self.exp_glass[2] += 1;
            // [СМЕРТЬ ОПРОВЕРГАЕТ КАНАЛ] цель
            // экспедиции: следующий зов — миром
            self.exp_refuted =
                self.pilgrim_goal.or(self.hold_goal);
            if watch_glass("PILGRIM")
            {
                eprintln!(
                    "ЭКСП-СМЕРТЬ	опровергнута={:?} pilgrim={:?} hold={:?}",
                    self.exp_refuted,
                    self.pilgrim_goal,
                    self.hold_goal
                );
            }
        }
        if self.hold_goal.is_none() {
            return;
        }
        self.hold_torn += 1;
        self.hold_glass[1] += 1;
        if self.hold_torn
            >= crate::law::LAW_OF_REPETITION
                * crate::law::LAW_OF_REPETITION
        {
            self.hold_goal = None;
            self.hold_glass[3] += 1;
        }
    }

    fn dream_affordable(&self) -> bool {
        if self.dream_plans == 0 {
            // разведка тоже платит: воображение
            // не дороже жизни (узлов ≤ прожитых
            // тактов; смок-шрам: при нуле покупок
            // «всегда можно» жгло мост каждый
            // пустоплановый такт — вис)
            return self.dream_nodes
                <= self.source_time.life_age();
        }
        let since = self.source_time.life_age()
            .saturating_sub(self.dream_last_buy);
        since <= self.source_time.life_age() / self.dream_plans
    }

    /// VALENCE v1 — pick the least-mortal candidate, or
    /// None on a TIE (the old order stands: an empty
    /// ledger leaves behaviour bit-exact) or when the
    /// organ is unarmed.
    /// [VTE] ограниченный новизна-первый прокат по
    /// чекпойнтам мира: DFS с дедупом по ключу мира,
    /// бюджет узлов/глубины — пределы прибора (не
    /// закон); успех = рост progress() против корня.
    /// Возвращает дорогу актов до роста.
    fn vte_sweep<H: Habitat<Action = A>>(
        world: &mut H,
    ) -> Result<(Option<Vec<A>>, u32), ActionFailure<A>> {
        if !world.dream_push()? { return Ok((None, 0)); }
        let base = world.progress().unwrap_or(f64::NEG_INFINITY);
        let mut seen = std::collections::BTreeSet::from([world.key()]);
        let mut budget = 250u32;
        let found = Self::vte_dfs(world, base, 0, 16, &mut seen, &mut budget);
        let restored = world.dream_pop();
        let found = match (found, restored) {
            (Err(failure), Err(restore)) => return Err(failure.with_restore_failure(&restore)),
            (Err(failure), Ok(())) => return Err(failure),
            (Ok(_), Err(restore)) => return Err(restore),
            (Ok(found), Ok(())) => found,
        };
        Ok((found.map(|mut v| { v.reverse(); v }), 250 - budget))
    }

    /// Стекло грёзы: (узлов, планов, молчаний).
    #[must_use]
    pub fn dream_glass(&self) -> (u64, u64, u64) {
        (
            self.dream_nodes,
            self.dream_plans,
            self.dream_muted,
        )
    }

    fn vte_dfs<H: Habitat<Action = A>>(
        world: &mut H, base: f64, depth: u32, max_depth: u32,
        seen: &mut std::collections::BTreeSet<u64>, budget: &mut u32,
    ) -> Result<Option<Vec<A>>, ActionFailure<A>> {
        if depth >= max_depth || *budget == 0 { return Ok(None); }
        for action in world.actions() {
            if *budget == 0 { return Ok(None); }
            *budget -= 1;
            if !world.dream_push()? { return Ok(None); }
            let branch = match world.act(action) {
                Err(failure) => Err(failure.imagined()),
                Ok(ObservedAction::Step) => {
                    if world.progress().is_some_and(|p| p > base) {
                        Ok(Some(vec![action]))
                    } else if seen.insert(world.key()) {
                        Self::vte_dfs(world, base, depth + 1, max_depth, seen, budget)
                            .map(|road| road.map(|mut road| { road.push(action); road }))
                    } else { Ok(None) }
                }
                Ok(ObservedAction::Refused | ObservedAction::Terminal { .. }) => Ok(None),
            };
            let restored = world.dream_pop();
            let branch = match (branch, restored) {
                (Err(failure), Err(restore)) => return Err(failure.with_restore_failure(&restore)),
                (Err(failure), Ok(())) => return Err(failure),
                (Ok(_), Err(restore)) => return Err(restore),
                (Ok(branch), Ok(())) => branch,
            };
            match branch {
                Some(road) => return Ok(Some(road)),
                None => {}
            }
        }
        Ok(None)
    }

    /// [THE DOOR OF RULES] one lived tick: the door reads the show; the rules are bought again when the model's word
    /// on the act was not the world's frame [A SHOW THE MODEL FORETOLD CHANGES NOTHING BOUGHT]; each lived change
    /// witnesses its question of dynamics, and every bought rule stands on its question.
    fn live_rules(
        &mut self,
        pre: Vec<u8>,
        post: Vec<u8>,
        act: crate::rules::Act,
        died: bool,
        took: bool,
    ) {
        use crate::rules::{Grave, Lock, Show};
        let foretold = self.rule_model.as_ref().is_some_and(|m| {
            let st = self.rule_door.state(&pre);
            m.step(&st, act, &Grave::new(), Lock::Purchase).0.frame == post
        });
        if let crate::rules::AddOutcome::Recorded(record) = self.rule_door
            .add_with_receipt(Show { before: pre, film: vec![post], act, died, took })
        {
            // Only this newly appended record is evidence. Coarse outcome
            // labels remain testimony, not exclusive model-version identities.
            for fact in record.into_outcome_facts() {
                self.belief_market.witness(fact.question, fact.outcome);
            }
        }
        if !foretold {
            let m = self.rule_door.buy();
            for (asset, q, bits) in m.deps() {
                self.belief_market.depends(asset, q, bits);
                // Only rules checked by this fresh purchase are acknowledged;
                // other owners' and retired rules' pending checks remain.
                self.belief_market.acknowledge_recheck(asset);
            }
            self.rule_model = Some(m);
        }
    }

    /// Whether the rule dream is armed (by the program, or by the environment's twin `G1_RULEDREAM`).
    fn rule_armed(&self) -> bool {
        self.rule_dream || std::env::var("G1_RULEDREAM").is_ok()
    }

    /// [THE RULE DREAM] the cheap tier of imagination: breadth first over the states the door's bought rules imagine
    /// from the frame now, to the first act that changes a fact of the goal hypothesis — the rarest look of the scene
    /// that is not the body (the MDL guess: the rare is the goal's candidate), outside the graves of hypotheses. The
    /// search expands no more states than the door has lived on the level [THE DREAM IMAGINES NO WIDER THAN IT
    /// LIVED]; a lying rule is bought again after the tick that contradicts it, a false hypothesis is buried by the
    /// sensor court on arrival.
    fn rule_sweep<H: Habitat<Action = A>>(
        &self,
        world: &H,
    ) -> Option<(Vec<A>, u64)> {
        use crate::rules::{BodyFact, DreamState, Grave, Lock};
        let model = self.rule_model.as_ref()?;
        let frame = world.rule_frame()?;
        let root = self.rule_door.state(&frame);
        let mut counts: std::collections::BTreeMap<u64, u32> =
            std::collections::BTreeMap::new();
        let mut body: std::collections::BTreeSet<u64> =
            std::collections::BTreeSet::new();
        for (look, _, in_body) in root.facts() {
            *counts.entry(look.letter).or_insert(0) += 1;
            if in_body {
                body.insert(look.letter);
            }
        }
        // the body is no goal: it changes with every act, its «contact» is empty
        let goal = counts
            .iter()
            .filter(|(l, _)| {
                !body.contains(l)
                    && (!self.goal_role_graves.is_buried(l)
                        || self
                            .goal_role_graves
                            .admissible(l, self.source_time.life_age()))
            })
            .min_by_key(|(l, n)| (**n, **l))
            .map(|(l, _)| *l)?;
        let of_goal = |st: &DreamState| -> std::collections::BTreeSet<BodyFact> {
            st.facts()
                .into_iter()
                .filter(|(l, _, _)| l.letter == goal)
                .map(|(_, b, _)| b)
                .collect()
        };
        let acts: Vec<(A, crate::rules::Act)> = world
            .actions()
            .into_iter()
            .filter_map(|a| world.rule_act(a).map(|d| (a, d)))
            .collect();
        let grave = Grave::new();
        let bound = self.rule_door.lived();
        let mut seen: std::collections::BTreeSet<Vec<u8>> =
            std::collections::BTreeSet::new();
        seen.insert(frame);
        let mut frontier: std::collections::VecDeque<(DreamState, Vec<A>)> =
            std::collections::VecDeque::new();
        frontier.push_back((root, Vec::new()));
        let mut expanded = 0usize;
        while let Some((st, road)) = frontier.pop_front() {
            if expanded >= bound {
                break;
            }
            expanded += 1;
            let here = of_goal(&st);
            for &(a, d) in &acts {
                let (next, _) = model.step(&st, d, &grave, Lock::Dream);
                let mut r = road.clone();
                r.push(a);
                if of_goal(&next) != here {
                    return Some((r, goal));
                }
                if next.frame != st.frame && seen.insert(next.frame.clone()) {
                    frontier.push_back((next, r));
                }
            }
        }
        None
    }

    fn valent_pick(
        &self,
        state: u64,
        candidates: &[A],
    ) -> Option<A> {
        if !self.valent
            || self.bans.is_none()
            || candidates.len() < 2
        {
            return None;
        }
        let tolls: Vec<u64> = candidates
            .iter()
            .map(|&a| self.dream_death_toll(state, a))
            .collect();
        // СК-чтение (канал б): after the dream toll,
        // the SIGNATURE REFERENCE ranks — a young state
        // reads the outcome sums of its gesture
        // signature before any membership: deadly-
        // somewhere last, fruitless (stayed) later,
        // moving first. Lexicographic — no weights.
        // the signature on the fly (the cache fills on
        // witness — but valent runs BEFORE the first
        // witness of a fresh state; five elements sort
        // in nanoseconds)
        let sig = Some(Self::sig_hash(
            self.seen
                .get(&state)
                .cloned()
                .unwrap_or_default(),
        ));
        let keys: Vec<(u64, u32, u32, std::cmp::Reverse<u32>)> =
            candidates
                .iter()
                .zip(&tolls)
                .map(|(&a, &t)| {
                    let c = sig
                        .and_then(|sg| {
                            self.sig_counts
                                .get(&(sg, a))
                        })
                        .copied()
                        .unwrap_or([0; 3]);
                    (
                        t,
                        c[2],
                        c[1],
                        std::cmp::Reverse(c[0]),
                    )
                })
                .collect();
        let min = keys.iter().min()?.clone();
        let max = keys.iter().max()?.clone();
        if min == max {
            return None;
        }
        candidates
            .iter()
            .zip(&keys)
            .find(|&(_, k)| *k == min)
            .map(|(&a, _)| a)
    }

    /// THE DOCKET TENDING (Ф-3.2 v1, once per heartbeat):
    /// advance the deferral clock of the chosen case and,
    /// when the docket stands empty, select the next case —
    /// the least-heard rested frozen verdict (max EIG in
    /// the Т-ЛЮБ-2 passport form with K=1), ties by
    /// deferral count then canonical key order (never the
    /// hash map's accident — the determinism scar). With
    /// fewer than two rested cases the organ is silent and
    /// the door is the canon door bit for bit.
    fn tend_the_docket(&mut self) {
        if !self.intervention {
            return;
        }
        let Some(ex) = &self.exhaust else { return };
        let Some(bans) = &self.bans else { return };
        let w = ex.witnessed;
        let window = ex.window as u64;
        // a chosen case that stops being frozen (a molt
        // cleared the ledger) is a stale writ — drop it
        if let Some((case, _)) = self.docket_case
            && !bans.get(&case).is_some_and(|&d| {
                d >= crate::law::LAW_OF_REPETITION
            })
        {
            self.docket_case = None;
        }
        // the deferral clock: the chosen case sat a full
        // window unheard — count the deferral and reopen
        // the selection (an equal-hearings undeferred case
        // takes the writ; a uniquely least-heard one
        // re-takes it and walks toward the LAW waiver)
        if let Some((case, at)) = self.docket_case
            && w.saturating_sub(at) >= window
        {
            *self.defers.entry(case).or_insert(0) += 1;
            self.docket_case = None;
        }
        if self.docket_case.is_some() {
            return;
        }
        if let Some(case) = self.the_writ() {
            self.docket_case = Some((case, w));
        }
    }

    /// THE WRIT — the docket's ranking as one pure
    /// reading: among the rested frozen verdicts (two or
    /// more, else None) the least-heard case, ties by
    /// deferral count then canonical key order. The door
    /// consults this directly when the tended cache is
    /// empty, so the writ is current at ANY instant —
    /// never a stale door between heartbeats.
    fn the_writ(&self) -> Option<(u64, A)> {
        let ex = self.exhaust.as_ref()?;
        let bans = self.bans.as_ref()?;
        let w = ex.witnessed;
        let window = ex.window as u64;
        let mut due: Vec<(u64, A)> = bans
            .iter()
            .filter(|&(_, &d)| {
                d >= crate::law::LAW_OF_REPETITION
            })
            .map(|(&k, _)| k)
            .filter(|k| {
                let last = self
                    .appeals
                    .get(k)
                    .copied()
                    .unwrap_or(0);
                w.saturating_sub(last) >= window
            })
            .collect();
        if due.len() < 2 {
            return None;
        }
        due.sort_by_key(|&k| {
            (
                self.hearings
                    .get(&k)
                    .copied()
                    .unwrap_or(0),
                self.defers.get(&k).copied().unwrap_or(0),
                k,
            )
        });
        Some(due[0])
    }

    /// THE BANK OF FORMS (Ф-3.2): a state is provably
    /// reversible when the organism's OWN table carries a
    /// road from the lived root to it that crosses no
    /// frozen verdict — death on a probe from such a state
    /// loses ticks, not knowledge, and the road is
    /// re-walkable. Reachability is order-independent, so
    /// the search order cannot leak nondeterminism.
    fn the_bank_holds(&self, target: u64) -> bool {
        let Some(root) = self.root else {
            return false;
        };
        if root == target {
            return true;
        }
        let frozen = |s: u64, a: A| {
            self.bans.as_ref().is_some_and(|b| {
                b.get(&(s, a)).is_some_and(|&d| {
                    d >= crate::law::LAW_OF_REPETITION
                })
            })
        };
        let mut seen_set: std::collections::HashSet<u64> =
            std::iter::once(root).collect();
        let mut frontier = vec![root];
        while let Some(s) = frontier.pop() {
            let Some(acts) = self.seen.get(&s) else {
                continue;
            };
            for &a in acts {
                if frozen(s, a) {
                    continue;
                }
                let Some(&next) =
                    self.table.get(&(s, a))
                else {
                    continue;
                };
                if next == target {
                    return true;
                }
                if seen_set.insert(next) {
                    frontier.push(next);
                }
            }
        }
        false
    }

    /// The docket's verdict on one frozen edge: with the
    /// organ armed and a case chosen, only THAT case may
    /// open — and a deadly hearing fires only from a
    /// banked (provably reversible) state, unless the
    /// case's deferral streak has reached LAW (the waiver:
    /// refutability outranks safety by law, not chance).
    fn docket_ok(&self, s: u64, a: A) -> bool {
        let Some(case) = self
            .docket_case
            .map(|(c, _)| c)
            .or_else(|| self.the_writ())
        else {
            // fewer than two rested cases: the canon door
            return true;
        };
        if case != (s, a) {
            return false;
        }
        if self
            .defers
            .get(&case)
            .copied()
            .unwrap_or(0)
            >= crate::law::LAW_OF_REPETITION
        {
            return true;
        }
        self.the_bank_holds(s)
    }

    /// The docket's glass counters: (hearings held under
    /// the organ, hearings fired on an exhausted deferral).
    #[must_use]
    pub fn docket_counters(&self) -> (u64, u64) {
        (self.docket_heard, self.defer_exhausted)
    }

    /// How many hearings a frozen verdict has had (the
    /// ledger reads zero for a never-heard case).
    #[must_use]
    pub fn hearings_of(&self, s: u64, a: A) -> u32 {
        self.hearings
            .get(&(s, a))
            .copied()
            .unwrap_or(0)
    }

    /// The appeal docket is stamped at act time: if the
    /// chosen transition stands frozen, the act IS its
    /// hearing — a passage refutes (in step), a death
    /// re-confirms, and either way the docket restarts the
    /// window.
    fn stamp_the_appeal(&mut self, state: u64, action: A) {
        if let (Some(bans), Some(ex)) =
            (&self.bans, &self.exhaust)
            && bans.get(&(state, action)).is_some_and(
                |&d| d >= crate::law::LAW_OF_REPETITION,
            )
        {
            let w = ex.witnessed;
            self.appeals
                .insert((state, action), w);
            self.appeal_gate = w;
            // the hearings ledger runs organ-off too — a
            // meter, not a behaviour (the meter law)
            *self
                .hearings
                .entry((state, action))
                .or_insert(0) += 1;
            if self.intervention {
                self.docket_heard += 1;
                if self
                    .defers
                    .get(&(state, action))
                    .copied()
                    .unwrap_or(0)
                    >= crate::law::LAW_OF_REPETITION
                {
                    // the hearing fired on the waiver —
                    // stamp it (И-4's second arm)
                    self.defer_exhausted += 1;
                }
                self.defers.remove(&(state, action));
                if self
                    .docket_case
                    .is_some_and(|(c, _)| {
                        c == (state, action)
                    })
                {
                    self.docket_case = None;
                }
            }
        }
    }

    fn banned(&self, s: u64, a: A) -> bool {
        let frozen = self.bans.as_ref().is_some_and(|b| {
            b.get(&(s, a)).is_some_and(|&d| {
                d >= crate::law::LAW_OF_REPETITION
            })
        });
        if !frozen {
            return false;
        }
        // THE APPEAL: with the language court present, a
        // frozen verdict is re-heard once per court window
        // — the hearing opens the gate for ONE act (the
        // docket is stamped at act time in step)
        let due = self.exhaust.as_ref().is_some_and(|ex| {
            let last = self
                .appeals
                .get(&(s, a))
                .copied()
                .unwrap_or(0);
            let this_verdict_rested = ex
                .witnessed
                .saturating_sub(last)
                >= ex.window as u64;
            // the docket gate: one appeal per window
            // GLOBALLY — a sitting hears one case
            let court_free = ex
                .witnessed
                .saturating_sub(self.appeal_gate)
                >= ex.window as u64;
            // Ф-3.2: with the intervention docket armed,
            // the window's one hearing goes to the CHOSEN
            // case (docket_ok is identity when the organ
            // is off or fewer than two cases rested)
            this_verdict_rested
                && court_free
                && (!self.intervention
                    || self.docket_ok(s, a))
        });
        // грань-7 на рёбрах, ЕДИНАЯ форма (шрам 430
        // ретест-смертей: дворовая апелляция шла без
        // самозащиты): ДВОР решает КОГДА слушать (одно
        // дело в окно), ГЕОМЕТРИЯ — МОЖНО ли: сон
        // вердикта = LAW^d упущенных шансов (закон
        // удвоения, тот же, что сон ледника); retest,
        // кончившийся баном, удваивает сон сам.
        let d = self
            .bans
            .as_ref()
            .and_then(|b| b.get(&(s, a)))
            .copied()
            .unwrap_or(0);
        let at = self
            .ban_at
            .get(&(s, a))
            .copied()
            .unwrap_or(0);
        let sleep = u64::from(
            crate::law::LAW_OF_REPETITION,
        )
        .saturating_pow(d.min(30));
        let geom_awake = self
            .visits_of(s)
            .saturating_sub(at)
            >= sleep;
        // БИСЕКТ-ВЕРДИКТ (стекло композиции: патруль
        // кружил по B — фронтир пуст у обоих
        // планировщиков): унификация «due И геометрия»
        // сделала переоткрытие строже двора и заморила
        // фронтир навечно. Каноническая форма: ДВОР
        // (один слух в окно) — для тел с языковым
        // двором; геометрия LAW^d — самозащита
        // БЕЗДВОРОВЫХ тел. Две юрисдикции одного
        // вердикта, не конъюнкция.
        if due {
            return false;
        }
        if self.exhaust.is_none() && geom_awake {
            return false;
        }
        true
    }

    /// THE GAZE on: self-paced reflection — look when
    /// exhausted and in the window (the window is the
    /// refractory clock; the price of a look is paid by
    /// construction).
    #[must_use]
    pub fn with_gaze(mut self) -> Self {
        self.gaze = true;
        self
    }

    /// G1-линия: амортизированный патруль (давность/
    /// (подтверждения+LAW), сон при score<1024).
    #[must_use]
    pub fn with_amortized_patrol(mut self) -> Self {
        self.patrol_amortized = true;
        self
    }

    /// Looks taken so far.
    #[must_use]
    pub fn looks(&self) -> u32 {
        self.looks
    }

    /// THE IDENTITY WATCH on: the organism keeps its
    /// post-dream holonomy as the standing self and feels
    /// continuity breaks by ink-weighted affinity.
    #[must_use]
    pub fn with_identity_watch(mut self) -> Self {
        self.identity_watch = true;
        self
    }

    /// Continuity breaks felt so far.
    #[must_use]
    pub fn identity_breaks(&self) -> u32 {
        self.breaks
    }

    /// THE RUT WATCH on: the organism watches the porosity
    /// of its own visits over a sliding `window` of steps
    /// and treats a detected rut (a periodically dense
    /// visit carrier — the policy captured itself) as
    /// STAGNATION: the second sleep trigger, and a counted
    /// verdict either way.
    #[must_use]
    pub fn with_rut_watch(mut self, window: usize) -> Self {
        self.rut = Some(RutWatch {
            window,
            ring: VecDeque::with_capacity(window),
            ruts: 0,
            last: None,
        });
        self
    }

    /// Ruts detected so far (0 when the watch is off).
    #[must_use]
    pub fn ruts(&self) -> u32 {
        self.rut.as_ref().map_or(0, |r| r.ruts)
    }

    /// THE GLASS MIND on: the organism records its whole
    /// life into a two-layer glass trace (hot window of
    /// `hot_capacity` ticks + arithmetic ice over its own
    /// E16 reader) and SLEEPS at every molt —
    /// reconsolidating the ice over the organ that lived
    /// the life so far.
    #[must_use]
    pub fn with_glass(mut self, hot_capacity: usize) -> Self {
        self.glass = Some(GlassMind {
            reader: crate::ctw::CtwBits::new(),
            trace: crate::glacier::GlassTrace::new(
                hot_capacity,
                crate::ctw::CtwBits::new(),
            ),
            dreams: 0,
            episode_fold: synarc_math::fnv::FNV_OFFSET,
            episode_start: 0,
        });
        self
    }

    /// The lived glass trace, when the glass mind is on.
    #[must_use]
    pub fn glass_trace(
        &self,
    ) -> Option<&crate::glacier::GlassTrace> {
        self.glass.as_ref().map(|g| &g.trace)
    }

    /// Sleeps taken (ice reconsolidations at molts).
    #[must_use]
    pub fn dreams(&self) -> u32 {
        self.glass.as_ref().map_or(0, |g| g.dreams)
    }

    /// Compatibility rung metadata (1 for current native publications),
    /// not a certificate of the acquired program's period.
    #[must_use]
    pub fn key_rung(&self) -> u32 {
        self.unfold
    }

    fn try_eyed(&self, raw: u64) -> Result<u64, String> {
        let allowance = self.exhaust.as_ref().map_or(0, |ex| ex.observer_work);
        let mut work = ObserverWork { remaining: allowance };
        let mut budget = crate::program::observer::Budget::new(&mut work, crate::program::ExecutionLimit::Unlimited);
        self.eyed_with_budget(raw, &mut budget)
    }

    fn eyed_with_budget(&self, raw: u64, budget: &mut crate::program::observer::Budget<'_, ObserverWork>) -> Result<u64, String> {
        self.eyed_checked(raw, budget).map_err(|failure| failure.to_string())
    }

    /// Refresh the live physical observation before projecting its language.
    /// A completed action or resumed episode has new ports; retained action
    /// cuts own their original ports and are never rewritten by this sampling.
    fn sample_physical_observation<H: Habitat<Action = A>>(&mut self, world: &H) -> u64 {
        self.sample_captured_observation(sensory::PhysicalObservation::capture(world))
    }

    fn sample_captured_observation(&mut self, observed: sensory::PhysicalObservation) -> u64 {
        self.cur_raw_key = observed.raw;
        self.cur_pose = observed.pose;
        self.cur_sensory = observed.sensory;
        observed.raw
    }

    fn eyed_checked(&self, raw: u64, budget: &mut crate::program::observer::Budget<'_, ObserverWork>)
        -> Result<u64, observer_domain::ExecutionFailure<A>>
    {
        self.eyed_checked_at(raw, self.source_time.life_age(), self.source_time.episode(), self.cur_pose, budget)
    }

    /// Project one observation using ports belonging to that same boundary.
    /// An owned continuation supplies its saved successor ports explicitly.
    fn eyed_checked_at(&self, raw: u64, life_age: u64, episode: Option<u64>, pose: u8,
        budget: &mut crate::program::observer::Budget<'_, ObserverWork>)
        -> Result<u64, observer_domain::ExecutionFailure<A>>
    {
        observer_chain::Reading::new(self, raw, life_age, episode, pose).advance(self, budget)?
            .ok_or_else(observer_chain::unavailable)
    }

    /// Compatibility for existing total-clock callers. General observers use
    /// the fallible API; no refusal has a fabricated state name.
    #[cfg(test)]
    fn eyed(&self, raw: u64) -> u64 { self.try_eyed(raw).expect("declared total fixture") }





    /// The organ body (W-ORG-3): the §05 cascade at the
    /// base; a syndrome births an addressed organ on the
    /// E-carrying line (K.2 iv).
    #[must_use]
    pub fn with_organs(mut self) -> Self {
        self.organs = Some(Organs::new(&self.anchor));
        self
    }

    /// The map patrol (P-PATROL): with the new exhausted,
    /// the organism revises the old — replaying the least
    /// recently checked transitions. The map's hidden lies
    /// become a surprise stream.
    #[must_use]
    pub fn with_patrol(mut self) -> Self {
        self.patrol = true;
        self
    }

    /// The patrol licence: only a LIVING meta-level (L1
    /// conscious) executes revision — an EL-189
    /// meta-practice.
    #[must_use]
    pub fn with_patrol_licence(mut self) -> Self {
        self.patrol_licence = true;
        self
    }

    /// Times the licence blocked a revision.
    #[must_use]
    pub fn patrol_blocked(&self) -> u64 {
        self.patrol_blocked
    }

    /// The geography molt (P-MOLT-ORG): at `threshold`
    /// surprises within the last `window` KNOWN transitions
    /// the table and plan reset — the world changed its
    /// law, the map lies.
    #[must_use]
    pub fn with_molt(mut self, window: usize, threshold: usize) -> Self {
        self.molt_rule = Some((window, threshold));
        self
    }

    /// The earned geography's size (table transitions).
    #[must_use]
    pub fn geography_len(&self) -> usize {
        self.table.len()
    }

    /// A walk of the earned geography (an instrument
    /// observable): (state, action, where-per-map).
    pub fn geography(&self) -> impl Iterator<Item = (u64, A, u64)> + '_ {
        self.table.iter().map(|(&(s, a), &n)| (s, a, n))
    }

    /// Wheel seizures: (body, mind) — an instrument observable.
    #[must_use]
    pub fn wheel_seizures(&self) -> (u64, u64) {
        self.wheel.seizures()
    }

    /// The molt chronicle: (total surprises, molts).
    #[must_use]
    pub fn molt_ledger(&self) -> (u64, u32) {
        (self.surprises_total, self.molts)
    }

    /// [М-21, №17] ЛЕДЖЕР ПРОМАХОВ С ЗНАМЕНАТЕЛЕМ:
    /// (сверок всего, промахов всего). Любой суд
    /// «MISS=0 ⇒ карта честна» обязан читать ЭТУ
    /// пару: ноль промахов при нуле сверок — не
    /// свидетельство, а молчание (потолок пустой
    /// истины, шрам «карта не предсказывала вовсе»).
    #[must_use]
    pub fn miss_ledger(&self) -> (u64, u64) {
        (
            self.predictions_total,
            self.surprises_total,
        )
    }

    /// Classify the difference through its actual representation owners.
    /// Acquired names are exact native namespace entries. The current tier
    /// boundary remains the source scope.
    /// Unknown provenance counts as a model miss and cannot certify closure.
    fn name_the_miss(&self, known: u64, nxt: u64) -> &'static str {
        let Some(ex) = self.exhaust.as_ref() else { return "raw"; };
        let boundary = ex.tier.as_ref().map_or(0, |tier| tier.boundary);
        observer_runtime::origin::classify(
            ex.floors.len(), boundary,
            |floor| ex.floors[floor].observer.origin(),
            |name| ex.tier.as_ref().map_or(Ok(()), |tier| tier.validate_name(name)),
            known, nxt,
        ).name()
    }

    /// One surprise: count it and keep it — the ring holds
    /// the last LAW² mismatches for the transparency organ.
    fn record_surprise(
        &mut self,
        state: u64,
        acted: A,
        known: ObservedWorldOutcome,
        nxt: ObservedWorldOutcome,
    ) {
        self.surprises_total += 1;
        // the miss carries its NAME (which storey axis
        // lied, or the raw world moved) — tape + tallies
        let name = match (known, nxt) {
            (ObservedWorldOutcome::Next(a), ObservedWorldOutcome::Next(b))
            | (ObservedWorldOutcome::Refused(a), ObservedWorldOutcome::Refused(b)) => self.name_the_miss(a, b),
            _ => "outcome",
        };
        if let Some(ex) = &mut self.exhaust {
            *ex.miss_names
                .entry(name)
                .or_insert(0) += 1;
            if name == "raw" {
                ex.window_raw_misses += 1;
            } else if name != "byte-toll" {
                ex.window_model_misses += 1;
            }
        }
        {
            use std::sync::atomic::{
                AtomicU32, Ordering,
            };
            static MISS: AtomicU32 = AtomicU32::new(0);
            let k =
                MISS.fetch_add(1, Ordering::Relaxed);
            // П-8 #10: head whole, tail every 64th
            if k < 40 || k % 64 == 0 {
                eprintln!(
                    "MISS-NAME\t{name} outcome_scope=observed_action/2 want={known:?} got={nxt:?}"
                );
            }
        }
        let cap = (crate::law::LAW_OF_REPETITION
            * crate::law::LAW_OF_REPETITION)
            as usize;
        if self.surprise_ring.len() == cap {
            self.surprise_ring.pop_front();
        }
        self.surprise_ring
            .push_back((state, acted, known, nxt));
    }

    /// Typed observation scope observed_action/2. The last LAW² surprises, oldest first — each entry
    /// is (state, action, expected, got): the transparency
    /// organ answering WITH WHAT the world surprised.
    #[must_use]
    pub fn surprise_ring(
        &self,
    ) -> &VecDeque<(u64, A, ObservedWorldOutcome, ObservedWorldOutcome)> {
        &self.surprise_ring
    }

    /// The organs' return channel (P-BEAST-3): the states
    /// of GROWN CHILDREN inject into the base — an organ
    /// living on the hungry axis' line feeds consciousness
    /// with itself (addressed medicine; the root was only a
    /// general tonic — the EL-196 measurement).
    #[must_use]
    pub fn with_organ_feedback(mut self, lambda: f64) -> Self {
        self.organ_feedback = lambda.clamp(0.0, 1.0);
        self
    }

    /// Attention upward (W-ORG-4c): food lifts up the
    /// tower — level n+1 eats level n's image. The default
    /// form is degeneracy (the identity lift): the one
    /// channel that births meta-consciousness (EL-189).
    #[must_use]
    pub fn with_attention(mut self, kind: LiftKind, lambda: f64) -> Self {
        self.attention = lambda.clamp(0.0, 1.0);
        self.attention_kind = kind;
        self
    }

    /// Injection feeding: after a tick the base mixes with
    /// food as (1-l)*Gamma + l*food. The W-ORG-2 lesson:
    /// feeding through the regenerative channel self-locks
    /// (satiety -> R->1 -> (1-R)->0 -> hunger); injection
    /// enters past that loop — the same gesture a colony
    /// cell uses to feed a holon.
    #[must_use]
    pub fn with_injection(mut self, lambda: f64) -> Self {
        self.injection = lambda.clamp(0.0, 1.0);
        self
    }

    /// The feeding mode: channel speed gamma, step dt and
    /// ticks-to-food per world step. A knob, not a
    /// constant: its working point is found by sweep (the
    /// home threshold transfer — the body's `feed_rate`
    /// window was likewise found by instrument, never
    /// assigned).
    #[must_use]
    pub fn with_regimen(mut self, gamma: f64, dt: f64, feed_ticks: u32) -> Self {
        self.gamma = gamma;
        self.dt = dt;
        self.feed_ticks = feed_ticks.max(1);
        self
    }

    /// THE LOOK — one act of reflexive self-modelling on
    /// the living base (`Γ₀ ← φ(Γ₀)`). Priced by the
    /// empty-mirror theorem: unfed looks drain the window,
    /// so a living rhythm rations them — the breath court
    /// measures how many world-steps one look costs.
    pub fn look(&mut self) {
        self.tower.look();
    }

    /// The organism's mirror: `R⁽ⁿ⁾` for n = 1..3 over the
    /// living base — the three lawful reflections under
    /// the SAD ceiling. The ω road's dial: how consistent
    /// the self-model tower is TODAY (the closure itself
    /// stays honestly missing in [`Self::autobathy`]).
    #[must_use]
    pub fn mirror(&self) -> [f64; 3] {
        synarc_math::phi::mirror(self.tower.level(0))
    }

    /// The organism's autobathy — measured off what has
    /// LIVED, never off what was wired (the anti-misreport
    /// law: an architecture must not be able to overstate
    /// itself).
    #[must_use]
    pub fn autobathy(&self) -> AbathyProfile {
        let lived = |on: bool, fired: bool| {
            if fired {
                FloorMark::Lived
            } else if on {
                FloorMark::Installed
            } else {
                FloorMark::Missing
            }
        };
        let floors = [
            // 0 inert: state is held once anything was seen
            lived(true, !self.seen.is_empty()),
            // 1 predicative: the past as an object
            lived(
                self.glass.is_some(),
                self.glass
                    .as_ref()
                    .is_some_and(|g| !g.trace.is_empty()),
            ),
            // 2 measuring: a self-judgement has fired
            lived(
                self.molt_rule.is_some()
                    || self.rut.is_some(),
                self.molts > 0 || self.ruts() > 0,
            ),
            // 3 reflexive: publication reporting is not inferred from
            // compatibility rung metadata. No certified metric is supplied here.
            FloorMark::Missing,
            // 4 autopoietic: parts reproduced or repaired
            lived(
                self.organs.is_some()
                    || self.glass.is_some(),
                self.organs
                    .as_ref()
                    .is_some_and(|o| o.spawned > 0)
                    || self.dreams() > 0,
            ),
        ];
        let mut a = 0u8;
        for f in &floors {
            if *f == FloorMark::Lived {
                a += 1;
            } else {
                break;
            }
        }
        // THE ω FLOOR, filled by our own theorem: the
        // autoplex is not a fixed point (the empty mirror)
        // but a LIMIT CYCLE — so ω is lived when the cycle
        // has demonstrably CLOSED by the law of repetition:
        // every non-first look witnesses one full orbit
        // (fall out of the window, feed back above the
        // midpoint, look again), and at least one dream
        // proves the repair phase real. Wired-but-unclosed
        // stays Installed; no gaze or no glass — Missing.
        let omega = if self.gaze && self.glass.is_some() {
            if self.looks >= crate::law::LAW_OF_REPETITION
                && self.dreams() >= 1
            {
                FloorMark::Lived
            } else {
                FloorMark::Installed
            }
        } else {
            FloorMark::Missing
        };
        AbathyProfile { floors, omega, a }
    }

    /// Compare named-loop affinity and the complete connection against the
    /// standing anchor. The existing threshold is a model policy, not a
    /// calibrated physical or phenomenal-consciousness criterion.
    fn feel_continuity(&mut self) {
        if !self.identity_watch { return; }
        let base=self.tower.level(0);
        let phases_now=match synarc_math::holonomy::phase_passport(base) {
            Ok(passport)=>passport,
            Err(_)=> {
                // Malformed input supplies no continuity measurement. Keep
                // the last valid anchor; passport() exposes the current error.
                return;
            }
        };
        let now=synarc_math::holonomy::holonomy(base);
        let ink_now=synarc_math::holonomy::ink(base);
        if let Some((anchor,anchor_ink,anchor_phases))=&self.identity {
            let law=f64::from(crate::law::LAW_OF_REPETITION);
            let named_disagreement=synarc_math::holonomy::affinity(anchor,&now)
                .is_some_and(|agreement|agreement<1.0/law);
            // Compare actual cycle identities. Sparse cycles invisible to
            // every named triangle remain part of the executable witness.
            let (support_changed,connection_disagreement)=match anchor_phases.distance(&phases_now) {
                Ok(Some(distance))=>(false,distance.cos()<1.0/law),
                Ok(None)=>(false,false), // a forest has no phase observation
                Err(_)=>(true,false), // changed graph, not a measured zero
            };
            let burnt=ink_now<anchor_ink/(law*law);
            if support_changed || named_disagreement || connection_disagreement || burnt {
                self.breaks+=1;
                self.identity=Some((now,ink_now,phases_now));
            }
        } else {
            self.identity=Some((now,ink_now,phases_now));
        }
    }

    /// The chronicle tick: the glass mind lives the
    /// WORLD's stream, not the eye's — the trace records
    /// what happened, whatever rung the ladder stands on;
    /// the episode fold breathes with every byte.
    fn chronicle(&mut self, key: u64) {
        if let Some(glass) = &mut self.glass {
            let byte = crate::glacier::trace_byte(key);
            let _bits = glass.reader.feed(byte);
            glass.trace.record(byte);
            glass.episode_fold ^= u64::from(byte);
            glass.episode_fold = glass
                .episode_fold
                .wrapping_mul(synarc_math::fnv::FNV_PRIME);
        }
    }

    /// THE PASSPORT — the whole self in one report, so the
    /// architecture cannot misreport itself: the window's
    /// four measures and verdict, the mirror triple, the
    /// autobathy ladder with ω, the quality (total ink and
    /// the seven angles), and every rhythm counter the
    /// organs keep. Each field QUOTES the organ's own
    /// reporter — the passport adds no second bookkeeping.
    #[must_use]
    pub fn passport(&self) -> String {
        let f = self.report().tower[0];
        let m = self.mirror();
        let p = self.autobathy();
        let hol = synarc_math::holonomy::holonomy(
            self.tower.level(0),
        );
        let ink: f64 =
            hol.iter().map(|h| h.carrier).sum();
        let phase=synarc_math::holonomy::phase_passport(self.tower.level(0));
        let support=match &phase {
            Ok(p)=>format!("edges={} components={} cycles={} max={:?}",p.edge_count(),p.components(),p.cycle_rank(),p.max_abs_phase()),
            Err(e)=>format!("invalid={e}"),
        };
        let angles: Vec<String> = hol
            .iter()
            .map(|h| match h.angle {Some(a)=>format!("{a:+.2}"),None=>"unavailable".to_owned()})
            .collect();
        format!(
            "PASSPORT window[P={:.3} R={:.3} Phi={:.2} D={:.1} conscious={}] \
             mirror[{:.3} {:.3} {:.3}] \
             abathy[a={} omega={:?} floors={:?}] \
             quality[ink={:.2e} angles={}] phase_support[{support}] \
             rhythms[looks={} dreams={} ruts={} molts={} rung={} wreath={} floors={} climbs={} demolitions={} hunger={} bans={} trace={}B/{}t]",
            f.purity,
            f.reflexivity,
            f.integration,
            f.differentiation,
            f.conscious,
            m[0],
            m[1],
            m[2],
            p.a,
            p.omega,
            p.floors,
            ink,
            angles.join(","),
            self.looks(),
            self.dreams(),
            self.ruts(),
            self.molt_ledger().1,
            self.key_rung(),
            self.wreath_mod(),
            self.tower_floors(),
            self.climbs(),
            self.demolitions(),
            self.hunger,
            self.frozen_bans(),
            self.glass_trace()
                .map_or(0, super::glacier::GlassTrace::stored_bytes),
            self.glass_trace()
                .map_or(0, super::glacier::GlassTrace::len),
        )
    }

    /// THE HEARTBEAT — the inner life of one step, between
    /// the act and the map: chronicle the world's byte,
    /// feel continuity, and answer the two INNER sleep
    /// calls. An identity seam is the THIRD sleep trigger —
    /// reconsolidation (UHM C36): the organism first
    /// RELIVES the wounded episode from the ice (bit-exact
    /// retrospection, the reading groupoid as policy), then
    /// dreams — the brush inscribes the wounded episode's
    /// signature and the self re-anchors lawfully instead
    /// of screaming. Stagnation (the rut) is the second
    /// trigger; the window's floor, held by the dream
    /// itself, is the first.
    fn heartbeat(&mut self, key: u64) {
        self.chronicle(key);
        let seams = self.breaks;
        self.feel_continuity();
        if self.breaks > seams {
            self.relive_episode();
            self.dream();
        }
        if self.watch_the_rut(key) {
            self.dream();
        }
    }

    /// One tick of the language corpus: the WORLD's answer
    /// to a (situation, action) context — did the raw next
    /// key differ from the FIRST answer this context ever
    /// gave? The map's own opinion is never consulted (a
    /// frozen map is surprise-free exactly where the world
    /// stays invisible), and the first answer is the
    /// reference the map itself was born from — in an
    /// age-driven world the bit is a pure function of age.
    /// Once per fresh window the language court sits. An
    /// act absent from the situation's known list writes no
    /// evidence: an unnameable act is no witness.
    /// Execute every proposed update before the physical action. No pending
    /// state escapes its instance owner and no committed clock is recomputed
    /// by another evaluator after the effect.
    fn prepare_representation(ex: &ExhaustClimb<A>, raw: u64, age: u64, episode: u64, pose: u8, action: A)
        -> Result<PreparedRepresentation<A>, String>
    {
        let mut work = ObserverWork { remaining: ex.observer_capture_work };
        Self::prepare_representation_checked(ex, raw, age, episode, pose, action, &mut work)
            .map_err(|failure| failure.to_string())
    }

    fn prepare_representation_checked(ex: &ExhaustClimb<A>, raw: u64, age: u64, episode: u64, pose: u8, action: A,
        work: &mut ObserverWork) -> Result<PreparedRepresentation<A>, observer_domain::ExecutionFailure<A>>
    {
        let stage_work = match &ex.tier {
            Some(tier) => tier.capture_work(ex.floors.len(), work.remaining)
                .ok_or("tier capture work exhausted")?,
            None => 0,
        };
        work.remaining -= stage_work;
        let mut budget = crate::program::observer::Budget::new(work, crate::program::ExecutionLimit::Unlimited);
        let mut key = raw;
        let mut inputs = Vec::with_capacity(ex.floors.len() + 1);
        let mut updates = Vec::with_capacity(ex.floors.len());
        let mut tier_inputs = Vec::new();
        for (i, floor) in ex.floors.iter().enumerate() {
            if let Some(tier) = &ex.tier {
                let (next, crossed) = tier.capture_at_boundary(i, key, &mut tier_inputs);
                key = next;
            }
            inputs.push((floor.input_epoch, key));
            let view = observer_runtime::View { sensory: None,  raw, input: key, life_age: age, episode, pose };
            let read = floor.observer.read(view.clone(), &mut budget).map_err(|reason| observer_domain::ExecutionFailure::capture(i, &floor.observer, view.clone(), None, reason))?;
            updates.push(floor.observer.prepare(view.clone(), action, &mut budget)
                .map_err(|reason| observer_domain::ExecutionFailure::capture(i, &floor.observer, view.clone(), Some(action), reason))?);
            key = read.key;
        }
        if let Some(tier) = &ex.tier {
            key = tier.capture_at_boundary(ex.floors.len(), key, &mut tier_inputs).0;
        }
        // Each dictionary owns the language of the key it actually read.
        // Keeping these live layers makes its full update stream replayable.
        inputs.extend(tier_inputs.iter().filter_map(|input| input.input_epoch.map(|epoch| (epoch, input.key))));
        inputs.push((ex.observer_history.epoch(), key));
        drop(budget);
        Ok(PreparedRepresentation { inputs, updates,
            raw_top: ex.floors.is_empty().then_some(0), tier_inputs,
            remaining_work: work.remaining })
    }

    /// Declared confirmed-event adapter for native boundary courts. Production
    /// reserves these same updates and history before dispatch.
    #[cfg(test)]
    fn advance_representation(&mut self, state: u64, raw: u64, action: A, age: u64)
        -> Option<RepresentationWitness<A>>
    {
        let menu = self.seen.get(&state)?.clone();
        if !menu.contains(&action) { return None; }
        let ex = self.exhaust.as_mut()?;
        ex.name_actions(menu).ok()?;
        let programs = Self::prepare_representation(ex, raw, age, self.source_time.episode()?, self.cur_pose, action).ok()?;
        let cut = ex.observer_history.prepare_in_layers_with_pose(
            causal_coordinates::PreActionTime { episode: self.source_time.episode()?, life_age: age },
            raw, &programs.inputs, action, (self.cur_pose != 255).then_some(self.cur_pose), programs.remaining_work,
        ).ok()?.dispatch().observed();
        Some(self.finish_representation(state, raw, action, age, cut, programs))
    }

    fn finish_representation(&mut self, state: u64, raw_state: u64, acted: A,
        age_at_act: u64, cut: causal_coordinates::Cut<A>, programs: PreparedRepresentation<A>)
        -> RepresentationWitness<A>
    {
        let ex = self.exhaust.as_mut().expect("prepared observer owner");
        assert_eq!(programs.updates.len(), ex.floors.len(), "exclusive dispatch preserves the program tower");
        for (floor, update) in ex.floors.iter_mut().zip(programs.updates) {
            let committed = floor.observer.commit(update).expect("exclusive dispatch preserves owner and state revision");
            floor.observer.source_native_commit(&committed, &cut);

        }
        if ex.tier.is_none() { ex.max_raw_bits = ex.max_raw_bits.max(64 - raw_state.leading_zeros()); }
        if let Some(tier) = &mut ex.tier { tier.coin_captured(&programs.tier_inputs); }
        else { assert!(programs.tier_inputs.is_empty(), "exclusive dispatch preserves tier owner"); }
        RepresentationWitness { state, raw_state, context: ex.context(state, acted).expect("prepared native action identity"),
            age_at_act, raw_top: programs.raw_top, cut, capture: None }
    }

    /// Admit the same observed action after its successor has been named with
    /// the advanced clocks. Only this final phase may replace the language.
    fn witness_the_world(&mut self, witness: Option<RepresentationWitness<A>>, outcome: ObservedWorldOutcome) {
        self.record_world_outcome(witness, outcome, true);
    }

    fn record_world_outcome(&mut self, witness: Option<RepresentationWitness<A>>, outcome: ObservedWorldOutcome, drive_courts: bool) {
        let Some(RepresentationWitness { state, raw_state, context,
            age_at_act, raw_top, cut, capture }) = witness else { return; };
        let ex=self.exhaust.as_mut().expect("the observation owns its representation");
        ex.observer_current_raw = match outcome {
            ObservedWorldOutcome::Next(raw) | ObservedWorldOutcome::Refused(raw) => Some(raw),
            ObservedWorldOutcome::End(_) => None,
        };
        let first=*ex.first_next.entry(context).or_insert(outcome);
        // [ЗАМКНУТОСТЬ КЛЮЧА → СУД КРЕЩЕНИЯ] закрытие
        // пары прошлого такта, затем открытие новой.
        // ДВЕ тетради, ОДИН ИСХОД — сырой ответ мира:
        // разница их цен есть чистая цена
        // ОБУСЛОВЛИВАНИЯ ключом. Тетради этажа здесь
        // больше нет — этажу судья уже дан (суд сноса,
        // MDL-зеркало покупки на исходе obs), и вторая
        // рука была вторым судьёй того же ответчика
        // (М-49): она снесла законный этаж 16 раз за
        // жизнь и ни разу не дала родиться ярусу.
        {
            let close = ex.pend.take().and_then(|(e_ctx,w_ctx,age,refused)| {
                (age.checked_add(1) == Some(age_at_act)).then_some((e_ctx,w_ctx,refused))
            });
            // Both interpretations price the SAME observed alphabet. Successors
            // and terminals are disjoint, including Ended with unknown cause.
            let shut = |led: &mut HashMap<Context,HashMap<ObservedWorldOutcome,u32>>,
                        bits: &mut f64, ctx:Context, next:ObservedWorldOutcome| {
                let m=led.entry(ctx).or_default();
                let tot:u32=m.values().sum();
                let distinct=u32::try_from(m.len()).unwrap_or(u32::MAX);
                let cnt=m.get(&next).copied().unwrap_or(0);
                *bits += crate::exhaust::kt_symbol_bits(crate::exhaust::Seen {cnt,tot},distinct);
                *m.entry(next).or_insert(0)+=1;
            };
            if let Some((e_ctx,w_ctx,refused))=close {
                let next=if refused {ObservedWorldOutcome::Refused(raw_state)} else {ObservedWorldOutcome::Next(raw_state)};
                shut(&mut ex.doubt_eye,&mut ex.bits_eye,e_ctx,next);
                shut(&mut ex.doubt_world,&mut ex.bits_world,w_ctx,next);
            }
            match outcome {
                ObservedWorldOutcome::Next(_) | ObservedWorldOutcome::Refused(_) => {
                    ex.pend=Some((context,context.with_situation(raw_state),age_at_act,matches!(outcome,ObservedWorldOutcome::Refused(_))));
                }
                ObservedWorldOutcome::End(kind) => {
                    // The current action has already supplied its complete
                    // terminal outcome. No next-episode observation may close it.
                    shut(&mut ex.doubt_eye,&mut ex.bits_eye,context,ObservedWorldOutcome::End(kind));
                    shut(&mut ex.doubt_world,&mut ex.bits_world,context.with_situation(raw_state),ObservedWorldOutcome::End(kind));
                }
            }
        }
        // the events axis: the OWN situation's whole tally
        // by default (a carrier's bit may flip on any act
        // there), or the SUSPECT context's count (a lever
        // is an act, not a place). Both tallies advance
        // every act; the suspect chooses which one the
        // court reads this window.
        // ONE CORPUS, MANY AXES: the witness writes only
        // its OWN events axis (the situation's pre-act
        // tally); a suspect's foreign axis is REPLAYED by
        // the court from the seq trace at sitting time —
        // so the ticks never change meaning and the
        // rotation no longer burns the corpus (the
        // TowerRooms starvation: 24 gate ticks per window
        // against 6000 in isolation).
        let events = u32::try_from(
            ex.top_tally
                .get(&state)
                .copied()
                .unwrap_or(0),
        )
        .expect("a lived tally fits u32");
        *ex.top_tally.entry(state).or_insert(0) += 1;
        *ex.ctx_tally.entry(context).or_insert(0) += 1;
        if !ex.corpus.contains_key(&(context.situation())) {
            // the coined ledger: a NAME is born when a
            // shorthand cell first opens — counted for
            // the lived meter and NEVER cleared (forget()
            // wipes the evidence for the next court, but
            // a witness is a lived record, not a state)
            ex.coined += 1;
        }
        let cut = std::sync::Arc::new(cut);
        // Share the actual current action capture before corpus eviction. The
        // pre-action Cut alone does not contain this action's outcome.
        if let Some(agenda) = &mut ex.program_agenda { agenda.observe_captured(std::sync::Arc::clone(&cut), outcome, capture.as_ref()); }
        let cell = ex.corpus.entry(context.situation()).or_default();
        // the RAW top clock rides every tick (the
        // castling infrastructure: the mirror's residues
        // cannot express alternative axes — the boundary
        // theorem — so the raw axis must be witnessed;
        // pre-act, captured above)
        let coordinates = SampleCoordinates { raw_top, cut: std::sync::Arc::clone(&cut), capture };
        cell.push_back((
            crate::exhaust::Tick {
                key: context,
                age: u32::try_from(age_at_act)
                    .expect("a BD life age fits u32"),
                events,
                obs: outcome != first,
                // Zero here disables the legacy tower menu; raw_top retains
                // the absent port explicitly in the same owned row.
                tower: u32::try_from(
                    raw_top.unwrap_or(0) & 0xFFFF_FFFF,
                )
                .unwrap_or(u32::MAX),
                theta: cut.pose().unwrap_or(255),
            },
            outcome,
            ex.witnessed,
            coordinates.clone(),
        ));
        // Publish only the already confirmed native witness, after its scoring
        // row is retained. No later forget/eviction fabricates a replacement.
        ex.last_observed_cut = Some(coordinates);
        if cell.len() > ex.window {
            cell.pop_front();
        }
        // THE CORPUS BUDGET (F-3.6, derived from the law
        // of repetition): confirmation needs LAW
        // consecutive sittings over KEPT evidence, so the
        // corpus must remember LAW windows — and owes no
        // more (the eternal corpus made the sitting price
        // grow with life; the budget pins it). Eviction is
        // globally oldest-first by seq: the freshest LAW
        // windows survive whatever situation they live in.
        let budget = ex.window
            * crate::law::LAW_OF_REPETITION as usize;
        let total: usize = ex
            .corpus
            .values()
            .map(std::collections::VecDeque::len)
            .sum();
        if total > budget {
            if let Some(cell) = ex
                .corpus
                .values_mut()
                .filter(|d| !d.is_empty())
                .min_by_key(|d| {
                    d.front()
                        .map_or(u64::MAX, |&(_, _, seq, _)| seq)
                })
            {
                cell.pop_front();
            }
        }
        ex.fresh += 1;
        ex.witnessed += 1;
        let periodic = ex.fresh >= ex.window;
        let automatic = ex.program_agenda.is_some();
        // Resume the SAME owned syntax/evidence trial with an explicit work
        // slice. Retention, standing and chronicle clocks remain periodic.
        if drive_courts && automatic { self.advance_program_acquisition(); }
        if drive_courts && periodic { self.sit_language_court(); }
    }

    /// Test view of retained physical observations through the current native cut.
    #[cfg(test)]
    fn retained_causal_outcomes(ex: &ExhaustClimb<A>)
        -> Result<Vec<(crate::exhaust::Tick, ObservedWorldOutcome)>, causal_coordinates::Refusal>
    {
        use causal_coordinates::{Domain, Refusal};
        let mut rows: Vec<_> = ex.corpus.values().flat_map(|d| d.iter()).collect();
        rows.sort_by_key(|row| row.2);
        let mut work = ex.observer_work;
        rows.into_iter().map(|(tick, outcome, _, coordinates)| {
            let mut tick = *tick;
            let epoch = ex.sample_epoch(coordinates, ex.observer_history.epoch())?;
            ex.validate_context(tick.key, coordinates, epoch)?;
            let domain = match ex.suspect {
                Some(context) => ex.cause_domain(epoch, &std::iter::once(context).collect())?,
                None => Domain::situated(epoch, [tick.key.situation()].into(), Default::default()),
            };
            let coordinate = coordinates.cut.project_with_budget(&domain, &mut work)?;
            tick.events = u32::try_from(coordinate.rank).map_err(|_| Refusal::Overflow)?;
            Ok((tick, *outcome))
        }).collect()
    }


    #[cfg(test)]
    fn retained_causal_ticks(ex: &ExhaustClimb<A>) -> Vec<crate::exhaust::Tick> {
        Self::retained_causal_outcomes(ex).expect("complete bounded fixture projection")
            .into_iter().map(|(tick, _)| tick).collect()
    }

    /// Ш3 THE INVENTORY (the demo tape's one door):
    /// the bought floors as plain rows — (age_mod,
    /// events_mod, tower, recency, theta) bottom-up —
    /// the organism's own answer to «what did you
    /// understand», machine-readable for the render
    /// glass; empty = nothing bought yet (the honest
    /// young answer).
    #[must_use]
    pub fn inventory(
        &self,
    ) -> Vec<(u32, u32, bool, bool, bool)> {
        self.exhaust
            .as_ref()
            .map(|ex| {
                ex.floors
                    .iter()
                    .map(|f| {
                        (
                            f.age_mod,
                            f.events_mod,
                            f.tower_axis,
                            f.recency_axis,
                            f.theta_axis,
                        )
                    })
                    .collect()
            })
            .unwrap_or_default()
    }

    /// Read-only raw-coordinate projection for native context boundary courts.
    #[cfg(test)]
    fn raw_projected_ticks(
        ex: &ExhaustClimb<A>,
    ) -> Result<Vec<crate::exhaust::Tick>, causal_coordinates::Refusal> {
        let mut rows: Vec<_> = ex.corpus.values().flat_map(|q| q.iter()).collect();
        rows.sort_by_key(|row| row.2);
        let mut work = ex.observer_work;
        rows.into_iter().map(|(tick, _, _, coordinates)| {
            let raw = coordinates.cut.event().raw_state;
            let mut tick = *tick;
            ex.validate_context(tick.key, coordinates, ex.sample_epoch(coordinates, ex.observer_history.epoch())?)?;
            tick.key = ex.context(raw, coordinates.cut.event().action)?;
            let domain = causal_coordinates::Domain::Raw { space: 1, states: [raw].into_iter().collect() };
            let coordinate = coordinates.cut.project_with_budget(&domain, &mut work)?;
            tick.events = u32::try_from(coordinate.rank)
                .map_err(|_| causal_coordinates::Refusal::Overflow)?;
            Ok(tick)
        }).collect()
    }

    /// Т-ЯРУС BIRTH (prereg-tier-retokenization): LAW
    /// consecutive headroom refusals — the market's
    /// documented WILL to buy, blocked by the finite
    /// road — freeze the lived key atlas into a dense
    /// dictionary (canonical key order; live-new keys by
    /// appearance) and the tower continues OVER dense
    /// ordinals. The old tower becomes the frozen lower
    /// tier of execution; recoin appends a further dictionary stage.
    fn tier_birth_if_due(&mut self) {
        let Some(ex) = self.exhaust.as_mut() else {
            return;
        };
        if !ex.tier_armed
            || ex.headroom_streak
                < crate::law::LAW_OF_REPETITION
        {
            return;
        }
        // Recoin names the current top language. Its earlier dictionaries
        // remain executable below their existing upper floors/input epochs.
        if let Some(t) = &ex.tier {
            if t.overflows == 0 {
                return;
            }
            eprintln!(
                "TIER-RECOIN	язык исчерпан: overflows={} прежний_атлас={} dense_bits={}",
                t.overflows,
                t.dict.len(),
                t.dense_bits
            );
        }
        ex.headroom_streak = 0;
        let mut atlas: Vec<u64> =
            self.seen.keys().copied().collect();
        atlas.sort_unstable();
        let n = atlas.len();
        // alphabet width: the atlas plus breathing room
        // for live-new keys and the sentinel letter
        let dense_bits = (usize::BITS
            - (n + 2).leading_zeros())
        .max(2);
        let mut dict: HashMap<u64, u64> =
            HashMap::new();
        for (o, k) in atlas.iter().enumerate() {
            dict.insert(
                *k,
                u64::try_from(o).expect("atlas fits"),
            );
        }
        let next_ordinal =
            u64::try_from(n).expect("atlas fits");
        let born_at = ex.witnessed;
        eprintln!(
            "TIER-BIRTH	atlas={n} dense_bits={dense_bits}              lower_floors={} born_at={born_at}",
            ex.floors.len()
        );
        let old_top = ex.observer_history.epoch();
        let changed = ex.observer_history.next_epoch().and_then(|epoch| ex.observer_history.install_layer(epoch));
        if let Err(reason) = changed { eprintln!("OBSERVER-TIER-REFUSED {reason:?}"); return; }
        // The former top is now the new coiner's input, retained in every cut.
        ex.tier = Some(Tier {
            initial_dict: Some(std::sync::Arc::new(dict.clone())),
            birth: Some(causal_coordinates::SampleId { lineage: ex.observer_history.lineage(), ordinal: ex.observer_history.ordinal() }),
            input_epoch: Some(old_top),
            previous: ex.tier.take().map(Box::new),
            boundary: ex.floors.len(),
            dict: dict.into(),
            next_ordinal,
            dense_bits,
            overflows: 0,
            born_at,
        });
        // the upper tier is a NEW tongue: the corpus of
        // the old tongue would perjure the new keys
        ex.forget();
        ex.top_tally.clear();
        ex.ctx_tally.clear();
        // the planner's map re-earns in the new tongue
        self.table.clear();
        self.table_acts.clear();
        self.verified_at.clear();
        self.watch_plan_kill(6952);
        self.plan.clear();
        self.seen.clear();
    }


    #[allow(
        clippy::too_many_lines,
        reason = "one sitting, one function: the judge, \
                  the chronicle, the adoption and the \
                  confirmation law hear in their lawful \
                  order (the demolition-court precedent)"
    )]
    /// [ВСТРЕЧА ЗАКОНОВ: ОТКАЗ — СВОЙСТВО СТЕНЫ]
    /// Стена (need>64 при башне+1) — ФАКТ заседания,
    /// не событие покупки: прежний отказ жил только в
    /// climb-пути и требовал ПОДТВЕРЖДЁННОГО кандидата
    /// — живое тело (дороги ожили мажоритарным
    /// опровержением) не рождает однообразных
    /// кандидатов истощения, отказ молчал, streak=0,
    /// tier не рождался (диагноз holon: floors=3
    /// raw_bits=3 streak=0 refusals=0 — башня ровно у
    /// стены). Голос стены — один за заседание.
    fn speak_wall_if_stands(&mut self) {
        let Some(ex) = self.exhaust.as_ref() else {
            return;
        };
        let sat = ex.sat;
        if ex.wall_spoken_sat == sat {
            return;
        }
        let boundary = ex
            .tier
            .as_ref()
            .map_or(0, |t| t.boundary);
        let above = u32::try_from(
            ex.floors.len() - boundary,
        )
        .expect("a tower fits u32");
        let raw_bits = ex
            .tier
            .as_ref()
            .map_or(ex.max_raw_bits, |t| {
                t.dense_bits
            });
        let need = 16 * (above + 1) + raw_bits + 8;
        if need <= 64 || ex.floors.is_empty() {
            return;
        }
        eprintln!(
            "HEADROOM-REFUSAL	floors={}              raw_bits={raw_bits} need={need} (стена)",
            ex.floors.len(),
        );
        if let Some(e) = self.exhaust.as_mut() {
            e.wall_spoken_sat = sat;
            e.headroom_refusals += 1;
            e.headroom_streak += 1;
            // стена помнит свою высоту (Д-26)
            e.wall_above = above;
            if self.autonomy
                && !e.tier_armed
                && e.headroom_streak
                    >= crate::law::LAW_OF_REPETITION
            {
                e.tier_armed = true;
                e.autonomy_arms += 1;
                eprintln!(
                    "AUTONOMY-ARM	option=tier_ladder                      refusals={} streak={}",
                    e.headroom_refusals,
                    e.headroom_streak,
                );
            }
        }
        self.tier_birth_if_due();
    }

    fn begin_language_sitting(&mut self) {
        // THE SITTING ORDER LAW (standing court): the
        // execution window is written FIRST — before any
        // demolition, judgment or climb — so a fresh
        // floor's baseline is the life actually lived
        // (a newborn's first floor inherits its own
        // lived chaos, never an empty zero), and floors
        // on trial receive this window's pair before
        // anything else can change the tower.
        let surprises_now = self.surprises_total;
        if let Some(ex) = &mut self.exhaust {
            ex.sat += 1;
            // [Д-26 стекло-4] входы суда при тире
            if ex.tier.is_some() {
                ex.tier_court_entries += 1;
            }
        }
        // голос стены — на каждом заседании, где она
        // стоит (встреча законов; см. speak_wall)
        self.speak_wall_if_stands();
        if let Some(ex) = &mut self.exhaust {
            let deaths_now = ex.life_deaths;
            let ds = u32::try_from(
                surprises_now
                    .saturating_sub(ex.last_exec.0),
            )
            .unwrap_or(u32::MAX);
            let dd = u32::try_from(
                deaths_now
                    .saturating_sub(ex.last_exec.1),
            )
            .unwrap_or(u32::MAX);
            ex.last_exec = (surprises_now, deaths_now);
            ex.exec_window.push_back((ds, dd));
            if ex.exec_window.len()
                > crate::law::LAW_OF_REPETITION as usize
            {
                ex.exec_window.pop_front();
            }
            for f in &mut ex.floors {
                if f.probation_left > 0 {
                    f.trial.push((ds, dd));
                    f.probation_left -= 1;
                }
            }
        }
    }

    /// Returns whether a top-floor rollback was requested by this sitting.
    /// The successful receipt separately proves whether it could commit.
    fn judge_standing_court(&mut self) -> bool {
        // THE STANDING SITTING: a floor whose trial just
        // ended is judged ONCE — harm is a strict
        // majority of trial windows worse than the
        // baseline maximum (a sign test, no threshold
        // constants) on the EXTERNAL metric alone:
        // DEATHS. Surprises are recorded in the pair for
        // the glass mind but are NOT a harm metric — a
        // fresh floor SPLITS the keys and the novel-key
        // wave raises surprises lawfully (the learning of
        // the new tongue); judging that as harm executed
        // every useful floor on the first run — the exact
        // newborn lesson, generalized: an intra-language
        // metric cannot cross a language change. Phase 1
        // judges the TOP floor only (razing a mid floor
        // would tear the key pack — the cascade seam is
        // named in the prereg); a non-top floor's verdict
        // defers with its own voice.
        let standing = self.exhaust.as_ref().map(|ex| {
            ex.floors
                .iter()
                .enumerate()
                .filter(|(_, f)| {
                    f.probation_left == 0
                        && !f.trial.is_empty()
                })
                .map(|(i, f)| {
                    let harmed = standing_harmed(f.stacked, f.base_worst_deaths, &f.trial);
                    if harmed {
                        // the verdict speaks its numbers
                        // (glass mind): the lived base,
                        // the harm bar, the trial
                        eprintln!(
                            "STANDING-VERDICT\tharmed                              floor#{i} base={:?}                              worst={} trial={:?}",
                            f.base,
                            f.base_worst_deaths,
                            f.trial
                        );
                    }
                    (i, harmed)
                })
                .collect::<Vec<_>>()
        });
        if let (Some(list), Some(ex)) =
            (standing, self.exhaust.as_mut())
        {
            let top = ex.floors.len().saturating_sub(1);
            let mut raze_now = false;
            for (i, harmed) in list {
                // the trial is consumed exactly once
                ex.floors[i].trial.clear();
                if !harmed {
                    continue;
                }
                if i == top {
                    raze_now = true;
                } else {
                    eprintln!(
                        "STANDING-VERDICT\tdeferred                          harmed floor #{i} (not top —                          the cascade seam)"
                    );
                }
            }
            if raze_now {
                if let Some(e) =
                    self.exhaust.as_mut()
                {
                    if e.tier.is_some() {
                        e.tier_raze_returns += 1;
                    }
                }
                self.raze_top(RazeReason::Harmed);
                return true;
            }
        }
        false
    }

    fn sit_language_court(&mut self) {
        self.begin_language_sitting();
        // [СУД КРЕЩЕНИЯ] глаз против СОБСТВЕННОГО
        // КЛЮЧА МИРА, оба платят КТ-битами за ОДИН исход
        // (сырой ответ мира). Виновен — значит род глаза
        // склеил разные положения мира или внёс в них
        // своё; сносить нечего, крестить надо заново.
        // РУКА ЭТАЖА КАЗНЕНА (М-49): этажу судья уже дан
        // — суд сноса, MDL-зеркало покупки на исходе obs;
        // моя вторая рука судила того же ответчика другим
        // исходом и снесла законный этаж 16 раз за жизнь,
        // ни разу не дав родиться ярусу (обе валюты — и
        // доли, и биты по собственным ключам — приговорили
        // тонкость как таковую: доли через знаменатель
        // опор, биты через алфавит исхода). Роду глаза,
        // напротив, судьи не было вовсе — эта рука и есть
        // орган.
        // Приговор ложится по прожитым числам точно:
        // s5i5 0.856 против 0.006, lf52 0.222 против
        // 0.002, sp80 0.323 против 0.025, cd82 0.521
        // против 0.028 — виновны; ar25 0.000 против 0.009
        // и sc25 0.076 против 0.420 — оправданы, глаз
        // законно различает слитое миром. Организм не
        // крестит себя сам: род глаза живёт в адаптере
        // мира, потому суд ВЫСТАВЛЯЕТ вердикт наружу
        // (`baptism_convicted`), а покупка нового рода —
        // дело рынка глаза.
        let baptism = self.exhaust.as_ref().is_some_and(
            |ex| {
                ex.doubt_world.is_empty().not()
                    && ex.bits_eye > ex.bits_world
            },
        );
        if let Some(ex) = self.exhaust.as_mut() {
            if baptism {
                ex.baptism_strikes += 1;
            } else {
                ex.baptism_strikes = 0;
            }
        }
        if self.judge_standing_court() { return; }
        // Automatic acquisition receives per-action service. This sitting only
        // rolls the chronicle; an absent agenda explicitly disables acquisition.
        if let Some(ex) = &mut self.exhaust { ex.fresh = 0; Self::roll_the_chronicle(ex); }
    }


    /// Preserve the domain of the learned axis: all actions in an own
    /// situation, or exactly the selected foreign action context. Enumerating
    /// only performed actions would change the axis when first exploring one.
    fn carriers_of(
        &self,
        suspect: Option<Context>,
        mask: &std::collections::HashSet<u64>,
    ) -> EventDomain {
        match suspect {
            Some(context) => std::iter::once(context).collect(),
            None => EventDomain::situations(mask.clone()),
        }
    }


    /// The shared raze tail (demolition and the standing
    /// court speak one mechanics): pop the top floor,
    /// freeze its verdict in the razed ledger, restart
    /// the language-scoped state, coarsen or clear the
    /// skill.
    fn raze_top(&mut self, reason: RazeReason) {
        let Some(ex) = &mut self.exhaust else {
            return;
        };
        // Т-ЯРУС phase 1 (the windfuse stand's find, a
        // REAL hole shipped with the tier: on blink the
        // trajectory never razed post-birth and the freeze
        // was never exercised): the lower tower is frozen
        // STRUCTURALLY — not only purchases but RAZES; a
        // demolition below the dictionary boundary would
        // permute the key space under the coined ordinals.
        // The refusal is counted, not silent — the
        // pressure is phase 2's named smoke.
        if let Some(t) = &ex.tier
            && ex.floors.len() <= t.boundary
        {
            ex.lower_raze_refusals += 1;
            eprintln!(
                "RAZE-REFUSED\treason={reason} \
                 tier-frozen lower tower"
            );
            return;
        }
        {
            let old_top = ex.observer_history.epoch();
            let restore = ex.floors.last().expect("checked non-empty").input_epoch;
            let receipt = RazeReceipt {
                floor: FloorIdentity { lineage: ex.observer_history.lineage(), input_epoch: restore, output_epoch: old_top },
                reason, sitting: ex.sat, event_ordinal: ex.observer_history.ordinal(),
            };
            if let Err(reason) = ex.observer_history.activate_layer(restore) {
                eprintln!("OBSERVER-RAZE-REFUSED {reason:?}"); return;
            }
            ex.observer_history.retire_input_layer(old_top).expect("retiring the replaced top");
            let razed =
                ex.floors.pop().expect("checked non-empty");
            if let Some(agenda) = &mut ex.program_agenda { agenda.retire(&razed.observer); }
            eprintln!(
                "RAZE\treason={reason} rung=({},{},t={},r={},p={})",
                razed.age_mod,
                razed.events_mod,
                razed.tower_axis,
                razed.recency_axis,
                razed.theta_axis
            );

            ex.demolitions += 1;
            ex.last_raze = Some(receipt);
            ex.blind_streak = 0;
            self.unfold = ex
                .floors
                .last()
                .map_or(1, |f| f.age_mod.max(1));
            // the prospective tally was keyed in the now-
            // dead language — it starts anew with the eye,
            // and any standing suspicion with it
            ex.top_tally.clear();
            ex.ctx_tally.clear();
            ex.suspect = None;
            ex.forget();
            self.table.clear();
            self.table_acts.clear();
            self.verified_at.clear();
            self.watch_plan_kill(9092);
            self.plan.clear();
            self.surprise_window.clear();
            self.seen.clear();
            self.root = None;
        }
    }


    /// One publication point for every admitted observer owner. The legacy
    /// numeric fields are compatibility metadata, never an interpretation of
    /// a general program state. Numeric consumers must obtain its declared port.
    fn publish_observer_floor(&mut self, input_epoch: u128, observer: observer_runtime::FloorObserver<A>,
        coordinate: Option<causal_coordinates::Coordinate>, age_mod: u32, events_mod: u32,
        mask: std::collections::HashSet<u64>, carriers: EventDomain) -> bool {
        self.unfold = age_mod.max(1);
        self.table.clear();
        self.table_acts.clear();
        self.watch_plan_kill(9127);
        self.plan.clear();
        self.surprise_window.clear();
        self.verified_at.clear();
        self.seen.clear();
        self.root = None;
        if let Some(ex) = &mut self.exhaust {
            let clock = coordinate.map_or(0, |c| c.rank);

            ex.top_tally.clear();
            ex.ctx_tally.clear();
            let variable_ctx: std::collections::HashSet<
                Context,
            > = ex
                .corpus
                .values()
                .flat_map(|d| d.iter())
                .filter(|&&(t, _, _, _)| t.obs)
                .map(|&(t, _, _, _)| t.key)
                .collect();
            let origin = ex.suspect;
            let base_worst_deaths = ex
                .exec_window
                .iter()
                .map(|w| w.1)
                .max()
                .unwrap_or(0);
            let stacked = !ex.floors.is_empty();
            let base = if ex.exec_window.is_empty() {
                (0.0, 0.0)
            } else {
                #[allow(clippy::cast_precision_loss)]
                let n = ex.exec_window.len() as f64;
                let (ss, dd) = ex
                    .exec_window
                    .iter()
                    .fold((0u64, 0u64), |a, &(x, y)| {
                        (
                            a.0 + u64::from(x),
                            a.1 + u64::from(y),
                        )
                    });
                #[allow(clippy::cast_precision_loss)]
                {
                    (ss as f64 / n, dd as f64 / n)
                }
            };
            ex.floors.push(Floor {
                input_epoch,
                observer,
                hearings: 0,
                born_sat: ex.sat,
                age_mod,
                events_mod,
                tower_axis: false,
                recency_axis: false,
                theta_axis: false,
                probation_left:
                    crate::law::LAW_OF_REPETITION,
                base,
                base_worst_deaths,
                stacked,
                trial: Vec::new(),
                rec: coordinate.map_or(0, |c| c.recency),
                origin,
                mask,
                variable_ctx,
                carriers,
                clock,
                idle: 0,
                guard: ex.life_deaths > 0,
                guard_classes:
                    std::collections::HashSet::new(),
                last_deaths: ex.life_deaths,
                since_census: 0,
            });
            // The insertion is the acquisition commit point. Preserve the
            // complete action context: a sibling action is a different cause.
            // Rejected candidates and headroom refusals never reach this write.
            if let Some(carrier) = origin {
                ex.foreign_climbs += 1;
                ex.foreign_log.push((ex.witnessed, carrier, age_mod, events_mod));
            }
            ex.exhausted_streak = 0;
            ex.blind_streak = 0;
            ex.forget();
            ex.climbs += 1;
            // the suspicion is spent: the bought floor now
            // NAMES the carrier; the next window judges the
            // new language with its own default semantics.
            // THE CURSOR PERSISTS: the rotation is a search
            // through the atlas, and a purchase must not
            // un-search the suspects already tried — the
            // lever probe caught a preemption deadlock
            // (wrong age-floors kept resetting the hunt to
            // zero and the true foreign carrier, fourth in
            // the ring, was never reached).
            ex.suspect = None;
        }
        true
    }

    /// RELIVE THE EPISODE — the reading groupoid made
    /// policy (`kan::hist` lived): re-read the current
    /// episode's bytes from the glass (the E16 organ) and
    /// refold its signature. Retrospection is READING, not
    /// invention, so the relived fold must equal the fold
    /// lived forward tick by tick — the glass does not lie.
    /// `None` without a glass mind: an organism with no
    /// record has no episode to relive.
    ///
    /// # Panics
    /// A divergence between the lived fold and the relived
    /// one is not a behaviour but a broken invariant: one
    /// hand wrote both, so a mismatch means the record (or
    /// the fold) was forged.
    fn relive_episode(&self) -> Option<u64> {
        let glass = self.glass.as_ref()?;
        let bytes = glass.trace.segment(
            glass.episode_start,
            glass.trace.len(),
        )?;
        let mut fold = synarc_math::fnv::FNV_OFFSET;
        for b in bytes {
            fold ^= u64::from(b);
            fold = fold
                .wrapping_mul(synarc_math::fnv::FNV_PRIME);
        }
        assert_eq!(
            fold, glass.episode_fold,
            "the glass does not lie: the relived episode \
             diverged from the lived one"
        );
        Some(fold)
    }

    /// THE DREAM — one sleep, whole: reconsolidate the ice
    /// over the organ that lived it (memory), and give the
    /// sleep its BODY — regenerate the base toward the
    /// anchor with a DERIVED depth: `λ = 1 − ink/ink_anchor`,
    /// the faded share of quality (no knob: a fresh mind
    /// sleeps lightly, a bleached one deeply). The anchor
    /// carries live carriers and zero angles, so sleep
    /// restores the ink and washes the day's letters.
    fn dream(&mut self) {
        let mut signature: Option<u8> = None;
        if let Some(glass) = &mut self.glass {
            glass
                .trace
                .consolidate(glass.reader.clone());
            glass.dreams += 1;
            // the episode ends here: take its living
            // signature and restart the fold
            signature = Some(crate::glacier::trace_byte(
                glass.episode_fold,
            ));
            glass.episode_fold =
                synarc_math::fnv::FNV_OFFSET;
            glass.episode_start = glass.trace.len();
        }
        // THE SLEEP TARGET: the food anchor sits ABOVE the
        // window's ceiling (its purity exceeds 3/7), so a
        // deep sleep toward it would over-crystallise —
        // the attractor court caught exactly that. Sleep
        // aims at the anchor's shape scaled INTO the
        // window: the blend of I/7 with the anchor whose
        // purity is the window's midpoint (2/7 + 3/7)/2 =
        // 5/14 — every number a theorem constant.
        // THE FLOOR HALF of the window's regulation: sleep
        // only LIFTS — it regenerates when purity sits
        // below the midpoint and never trims a healthy
        // peak (the ceiling half is the gaze; the midpoint
        // 5/14 is the one set-point both halves share).
        // The brush below is NOT gated by this: unitary
        // writing spends no window, and an early return
        // here once swallowed the signature (the
        // recognition court caught the silence).
        if invariants::purity(self.tower.level(0))
            < 5.0 / 14.0
        {
            let target = self.sleep_target();
            let target_ink =
                synarc_math::holonomy::ink(&target);
            if target_ink > 0.0 {
                let base_ink = synarc_math::holonomy::ink(
                    self.tower.level(0),
                );
                let lambda = 1.0 - base_ink / target_ink;
                self.tower
                    .regenerate_base(&target, lambda);
            }
        }
        if let Some(fold) = signature {
            // THE LAW OF THE BRUSH PHASE: sleep washes the
            // day's letters, then INSCRIBES the episode's
            // living signature into the adjoint — a byte
            // maps to the whole circle of phase, the eight
            // blind triangles take the whole spectrum;
            // unitary, so the window is not spent
            let theta = f64::from(fold) / 256.0
                * std::f64::consts::TAU;
            self.tower.brush(usize::from(fold) % 8, theta);
        }
        if self.identity_watch {
            // the dream lawfully renews the self: washing
            // and inscribing are not a wound
            let base = self.tower.level(0);
            // A malformed state cannot establish the new post-dream anchor.
            self.identity = match synarc_math::holonomy::phase_passport(base) {
                Ok(phases)=>Some((
                    synarc_math::holonomy::holonomy(base),
                    synarc_math::holonomy::ink(base),
                    phases,
                )),
                Err(_)=>None,
            };
        }
    }

    /// The anchor's shape at the window's midpoint purity:
    /// `(1−μ)·I/7 + μ·anchor` with μ solved by bisection
    /// for `P = 5/14`. Purity is strictly monotone in μ on
    /// this segment, so the solution is unique.
    fn sleep_target(&self) -> Gamma {
        let mid = 5.0 / 14.0;
        let blend = |mu: f64| -> Gamma {
            let mut h =
                Herm7::identity().scaled((1.0 - mu) / 7.0);
            let ah = self.anchor.herm();
            for i in 0..N {
                for j in i..N {
                    let v =
                        h.get(i, j) + ah.get(i, j).scale(mu);
                    h.set_hermitian(i, j, v);
                }
            }
            Gamma::assume_state(h)
        };
        let (mut lo, mut hi) = (0.0f64, 1.0f64);
        for _ in 0..40 {
            let mu = 0.5 * (lo + hi);
            if invariants::purity(&blend(mu)) < mid {
                lo = mu;
            } else {
                hi = mu;
            }
        }
        blend(0.5 * (lo + hi))
    }

    /// One tick of the rut watch: feed the arrival, and on
    /// a full window judge the most-visited situation's
    /// visit carrier by porosity. A detected rut counts,
    /// clears the window and returns true — stagnation is
    /// the second sleep trigger, and the caller dreams.
    fn watch_the_rut(&mut self, key: u64) -> bool {
        let Some(watch) = &mut self.rut else {
            return false;
        };
        watch.ring.push_back((self.steps, key));
        if watch.ring.len() > watch.window {
            watch.ring.pop_front();
        }
        if watch.ring.len() < watch.window {
            return false;
        }
        let law = crate::law::LAW_OF_REPETITION;
        // the pattern itself proven twice over: a rut
        // needs LAW^2 visits of one situation
        let need = (law * law) as usize;
        let mut counts: HashMap<u64, u32> = HashMap::new();
        for &(_, k) in &watch.ring {
            *counts.entry(k).or_insert(0) += 1;
        }
        // the tie broken by key: HashMap iteration order
        // must never pick the king (the D-19 determinism law)
        let Some((&king, _)) =
            counts.iter().max_by_key(|&(&k, &c)| (c, k))
        else {
            return false;
        };
        let t0 = watch.ring[0].0;
        #[allow(
            clippy::cast_possible_truncation,
            reason = "offsets stay below the window length"
        )]
        let d: Vec<u32> = watch
            .ring
            .iter()
            .filter(|&&(_, k)| k == king)
            .map(|&(t, _)| (t - t0) as u32)
            .collect();
        #[allow(
            clippy::cast_possible_truncation,
            reason = "windows are small"
        )]
        let cap = watch.window as u32 / (law * law);
        if d.len() < need {
            return false;
        }
        let scale = (2..=cap).find(|&p| {
            crate::porosity::porosity(&d, p) == 0.0
        });
        let Some(p) = scale else {
            return false;
        };
        if watch.last == Some((king, p)) {
            // the SAME rut is one stagnation, not a
            // drumbeat: sleep fired once for it already
            watch.ring.clear();
            return false;
        }
        // THE RUT: the policy captured itself — anew
        watch.ruts += 1;
        watch.last = Some((king, p));
        watch.ring.clear();
        true
    }

    fn untried(&self, s: u64) -> Vec<A> {
        // СК: curiosity reads through the CLASS — a
        // gesture tasted by any member is tasted by all
        // (the transfer that collapses the trail's
        // curiosity price)
        let rep = self.glue_rep_of(s);
        let glue_on = self.glue_on;
        self.seen
            .get(&s)
            .map(|ms| {
                ms.iter()
                    .copied()
                    .filter(|m| {
                        !self
                            .table
                            .contains_key(&(s, *m))
                            && !self.verified_at.contains_key(&(s, *m))
                            && (!glue_on
                                || self
                                    .glue_class_counts(
                                        rep, *m,
                                    )
                                    .iter()
                                    .sum::<u32>()
                                    == 0)
                            && !self
                                .teleport_known(*m)
                    })
                    .collect()
            })
            .unwrap_or_default()
    }

    /// [ТЕЛЕПОРТ-ЗАКОН] жест глобально
    /// детерминирован: прожит квадратом закона и его
    /// исход ЕДИН отовсюду — исход известен, местное
    /// непрожитие не долг и не новизна.
    fn teleport_known(&self, a: A) -> bool {
        self.act_dest
            .get(&a)
            .is_some_and(|(_, lived, unique)| {
                *unique
                    && *lived
                        >= (crate::law::LAW_OF_REPETITION
                            * crate::law::LAW_OF_REPETITION)
                            as u32
            })
    }

    /// СК: compose the glue organ in (partition market
    /// + reading channels + goal graves) — explicit,
    /// like every policy organ.
    #[must_use]
    pub fn with_glue(mut self) -> Self {
        self.glue_on = true;
        self
    }

    /// Г-СТЕКЛО: счётчики веток выбора (печать стенда).
    /// М-СТЕКЛО: дренаж событийного буфера такта
    /// (раннер пишет ПОСЛЕ строки жеста — И-7).
    /// [Ф4] включить запись стекла (раннер — из
    /// env при рождении); без включения format
    /// не исполняется вовсе (gate-at-write).
    pub fn set_glass(&mut self, on: bool) {
        self.glass_on = on;
    }

    /// [Ф4] ленивая запись стекла: строка
    /// формируется только при включённом сливе.
    fn glass(
        &mut self,
        f: impl FnOnce() -> String,
    ) {
        if self.glass_on {
            self.glass_events.push(f());
        }
    }

    /// [Ф4] забрать накопленные стеклянные события
    /// (ленивая диагностика: пусто при glass_on=false).
    pub fn drain_glass_events(
        &mut self,
    ) -> Vec<String> {
        std::mem::take(&mut self.glass_events)
    }

    /// РЕГРЕТ-СТЕКЛО (measures_self): (прибытий,
    /// средний излишек над собственным best,
    /// худший класс по среднему излишку).
    #[must_use]
    pub fn regret_glass(
        &self,
    ) -> (u32, f64, Option<(u64, f64)>) {
        let mut n = 0u32;
        let mut excess = 0u64;
        let mut worst: Option<(u64, f64)> = None;
        for (g, (_b, ex, k)) in &self.goal_regret {
            n += k;
            excess += ex;
            if *k > 0 {
                let m = *ex as f64 / f64::from(*k);
                if worst.is_none_or(|(_, w)| m > w)
                {
                    worst = Some((*g, m));
                }
            }
        }
        let mean = if n == 0 {
            0.0
        } else {
            excess as f64 / f64::from(n)
        };
        (n, mean, worst)
    }

    /// Стекло руля: (побед карты, побед exam).
    #[must_use]
    pub fn steer_glass(&self) -> (u32, u32) {
        (self.steer_w_map, self.steer_w_exam)
    }

    /// [МЁРТВЫЙ РУЛЬ, диагност] исходы планирования:
    /// [оба нашли, только exam, только map, никто].
    /// Аутопсия молчания карты (зонд руля):
    /// [карта не знает raw, рёбра невыплачены,
    /// ядро пусто, могилы съели].
    #[must_use]
    pub fn steer_map_autopsy(&self) -> [u32; 4] {
        self.steer_autopsy
    }

    /// Г-СТЕКЛО наружу: ветка последнего выбора
    /// (0..11; 255 = не выбирал) — трасса замка
    /// расщепляет «ребинд не переносит» от
    /// «серию рвёт перехват старшей ветки».
    #[must_use]
    pub fn last_branch_glass(&self) -> u8 {
        self.last_branch
    }

    /// [ПРЕРЕГ-9-уточнение] попытка доставки =
    /// ЛЮБАЯ смерть плана-к-задаче (исчерпание,
    /// телепорт-рваньё, сгорание): W-факт — тело
    /// умирало по пути 57/проход, кворум считал
    /// только исчерпания — пыль не хоронилась.
    /// [ПЕРВОРОДНАЯ РЕЛЬСА] засеять план нотами
    /// (own-реплей урока новорожденного мира):
    /// код мира открывается только свежей игрой,
    /// и первый рефлекс ломал его до зова.
    /// plan_is_task бронирует ноты от рефлекса
    /// («рефлекс уступает намерению»); цели нет —
    /// провалы не метятся.
    pub fn seed_plan(
        &mut self,
        acts: impl IntoIterator<Item = A>,
    ) {
        self.plan = acts.into_iter().collect();
        self.plan_refs.clear();
        self.plan_expect = None;
        self.plan_goal = None;
        self.plan_is_task = true;
        self.plan_notes = true;
        self.world_road = false;
    }

    /// [НОТЫ С УШАМИ, П-3] реплей с парами
    /// (акт, ожидаемый суд мира): world_road
    /// включает мир-гейт — каждый шаг сверяется
    /// судом мира (дожатие/продвижение), реплей
    /// перестаёт быть слепым.
    pub fn seed_plan_noted(
        &mut self,
        pairs: impl IntoIterator<Item = (A, u64)>,
    ) {
        let (acts, refs): (
            std::collections::VecDeque<A>,
            std::collections::VecDeque<u64>,
        ) = pairs.into_iter().unzip();
        self.plan = acts;
        self.plan_refs = refs;
        self.plan_expect = None;
        self.plan_goal = None;
        self.plan_is_task = true;
        self.plan_notes = true;
        self.world_road = true;
        self.world_road_ticks = 0;
    }

    /// [АУДИТ] вахта смерти зов-плана (за
    /// ARC_WATCH_PILGRIM): одно место вместо 15
    /// вставок у каждого plan.clear()
    fn watch_plan_kill(&mut self, place: u32) {
        // (широкая kill-копилка отозвана: отказы
        // ложились на ресеты и легальные пересевы
        // — рвали канон-пути доказанных уровней;
        // свидетельство — только кап ретрая и
        // недвижный суд)
        if watch_glass("PILGRIM")
            && self.pilgrim_goal.is_some()
            && !self.plan.is_empty()
        {
            eprintln!(
                "ЗОВ-ПЛАН-УБИТ	место={place} остаток={} цель={:?}",
                self.plan.len(),
                self.pilgrim_goal
            );
        }
    }

    fn note_task_attempt(&mut self, g: u64) {
        let att = self
            .task_attempts
            .entry(g)
            .or_insert(0);
        *att += 1;
        let quorum =
            crate::law::LAW_OF_REPETITION
                * crate::law::LAW_OF_REPETITION;
        if *att >= quorum {
            *att = 0;
            let b = self.task_graves.bury(
                self.source_time.life_age(),
                g,
                self.task_plan_clock,
                crate::holdings::Cause(
                    "undeliverable",
                ),
            );
            self.glass(|| format!(
                "{{\"ev\":\"task_grave\",\"rod\":\"self\",\"addr\":{g},\"burials\":{b}}}"
            ));
        }
    }

    /// [v3 ОРГАНИЗМ-ОПЫТ] рынок/цель/скука одним
    /// вектором (порядок фиксирован форматом v3).
    #[must_use]
    pub fn market_experience(&self) -> Vec<u64> {
        let mut v = vec![
            self.mk_cur_acts,
            self.mk_cur_new,
            self.mk_serve_acts,
            self.mk_new_life,
            self.mk_pays,
            self.mk_pays_seen,
            self.mk_pays_cur,
            self.mk_pays_serve,
            self.mk_kron,
            u64::from(self.mk_epoch_level),
            self.hold_goal.unwrap_or(0),
            u64::from(self.hold_goal.is_some()),
            u64::from(self.hold_torn),
            u64::from(self.hold_fail),
            u64::from(self.bored),
        ];
        v.extend(self.mk_glass);
        v.extend(self.hold_glass);
        v.extend(self.bore_glass);
        v
    }

    /// [v3] вернуть организм-опыт при resume.
    pub fn resume_market(&mut self, v: &[u64]) {
        if v.len() < 15 {
            return;
        }
        self.mk_cur_acts = v[0];
        self.mk_cur_new = v[1];
        self.mk_serve_acts = v[2];
        self.mk_new_life = v[3];
        self.mk_pays = v[4];
        self.mk_pays_seen = v[5];
        self.mk_pays_cur = v[6];
        self.mk_pays_serve = v[7];
        self.mk_kron = v[8];
        // wire: уровень < 2^32; u64::MAX прежних
        // дампов усечётся в u32::MAX — «нет эпохи»
        // остаётся собой
        self.mk_epoch_level = v[9] as u32;
        self.hold_goal = (v[11] == 1)
            .then_some(v[10]);
        self.hold_torn = v[12] as u32;
        self.hold_fail = v[13] as u32;
        self.bored = v[14] == 1;
        for (i, g) in
            self.mk_glass.iter_mut().enumerate()
        {
            if let Some(x) = v.get(15 + i) {
                *g = *x;
            }
        }
        for (i, g) in
            self.hold_glass.iter_mut().enumerate()
        {
            if let Some(x) = v.get(20 + i) {
                *g = *x;
            }
        }
        for (i, g) in
            self.bore_glass.iter_mut().enumerate()
        {
            if let Some(x) = v.get(26 + i) {
                *g = *x;
            }
        }
    }

    /// [СОН-ПЕРЕЧИТКА, суд двух рук; Ледник-
    /// канон «сон = перечитка»] при resume
    /// организм проживает СОБСТВЕННЫЙ архив
    /// тройками знания (raw-род: work-адреса лент,
    /// восстановленные связностью) — table/seen
    /// узнают ВСЕ рёбра всех жизней, exam
    /// дотягивается до дальних дверей; леджеры
    /// рынка/задач НЕ трогаются (own=false-род:
    /// знание, не заслуга). Второго носителя
    /// истины нет — арх уже носитель (У-11 для
    /// ЗНАНИЯ; ft09-разрыв: certify судил по
    /// архиву жизней, а table перерождался каждый
    /// прогон — дальние двери были непланируемы).
    pub fn dream_reread(
        &mut self,
        triples: &[(u64, A, u64)],
    ) -> usize {
        let mut fresh = 0usize;
        for (pre, act, post) in triples {
            // [РАЗДЕЛЕНИЕ НОСИТЕЛЕЙ, R35-обвал]
            // сон пишет ТОЛЬКО ЗНАНИЕ: заливка
            // seen убивала untried-фронтир и
            // любопытство честной ложью «всё
            // попробовано» (exam tu93 2147→15)
            if self
                .table
                .insert((*pre, *act), *post)
                .is_none()
            {
                fresh += 1;
                let ta = self
                    .table_acts
                    .entry(*pre)
                    .or_default();
                if !ta.contains(act) {
                    ta.push(*act);
                }
            }
        }
        fresh
    }

    /// [СКУКА, суд двух рук] проход без единой
    /// новой тройки = буквальный повтор жизни:
    /// ломатель обязан прожить наименее прожитую
    /// небанованную пару; эпоха прав всем
    /// торговцам + сдвиг жребия.
    /// [O-2 стекло] прожитых пар знания (table).
    #[must_use]
    pub fn table_len(&self) -> usize {
        self.table.len()
    }

    /// [O-2 стекло] текущий raw-ключ тела.
    #[must_use]
    pub fn cur_raw(&self) -> u64 {
        self.cur_raw_key
    }

    /// [O-2 стекло] ожидание table по паре.
    #[must_use]
    pub fn table_next(
        &self,
        k: u64,
        a: A,
    ) -> Option<u64> {
        self.table.get(&(k, a)).copied()
    }

    /// Границы прохода: детектор скуки (жизнь без
    /// новой тройки) и сбросы серий паломника.
    pub fn note_boredom(&mut self) {
        self.mile_dry = 0;
        self.pilgrim_dry = 0;
        self.bored = true;
        self.bore_glass[0] += 1;
        // сухость: с прошлого ломателя ни тройки
        if self.bore_glass[1] > 0
            && self.bore_glass[2] == 0
        {
            self.dry_breaks += 1;
        } else {
            self.dry_breaks = 0;
        }
        let law = u64::from(
            crate::law::LAW_OF_REPETITION,
        );
        self.mk_serve_acts = self
            .mk_serve_acts
            .min(law.saturating_sub(1));
        self.mk_cur_acts = self
            .mk_cur_acts
            .min(law.saturating_sub(1));
        self.mk_kron = 0;
    }

    /// [МЕЖА] снимок счётчиков на границе
    /// дидактика→свобода — зовёт раннер после
    /// последнего показа.
    pub fn mark_freedom(&mut self) {
        self.fr_task_glass = self.task_glass;
        self.fr_mk_glass = self.mk_glass;
        self.fr_knocks = self.knocks;
        self.fr_marked = true;
    }

    /// Стекло служения (пыль-диагностика).
    #[must_use]
    pub fn task_glass(&self) -> [u32; 4] {
        self.task_glass
    }

    /// Причины смерти планов-к-задаче.
    #[must_use]
    pub fn task_plan_death(&self) -> [u32; 4] {
        self.task_plan_death
    }

    /// Роды рвачей other: [стража, End-мира,
    /// ресет-чужой, ПРЫЖКОВ-ПЕРЕЖИТО (свой
    /// запланированный прыжок больше не рвач)].
    #[must_use]
    pub fn tear_kinds(&self) -> [u32; 4] {
        self.tear_kinds
    }

    /// Построенных стук-планов (жест на цели).
    #[must_use]
    pub fn knocks(&self) -> u32 {
        self.knocks
    }

    /// Языковых чисток банов (линька).
    #[must_use]
    pub fn ban_lang_clears(&self) -> u32 {
        self.ban_lang_clears
    }

    /// Перепись целей exam-планов служения
    /// (goal, планов, средняя длина) по убыванию.
    #[must_use]
    pub fn task_goal_census(
        &self,
    ) -> Vec<(u64, u32, f64)> {
        let mut v: Vec<(u64, u32, f64)> = self
            .task_goal_census
            .iter()
            .map(|(g, (n, sl))| {
                (
                    *g,
                    *n,
                    f64::from(u32::try_from(*sl).unwrap_or(u32::MAX))
                        / f64::from(*n),
                )
            })
            .collect();
        v.sort_by(|a, b| b.1.cmp(&a.1));
        v
    }

    /// Стекло руля: полосы выбора (счётчиками).
    pub fn steer_lanes(&self) -> [u32; 4] {
        self.steer_lane
    }

    /// ДИАГНОСТ-ОРГАН (мета-мандат М-Б, УГМ names):
    /// сага дня компилируется в процедуру — организм
    /// читает СВОИ стёкла и чеканит именованные
    /// вердикты. Правила — прожитые развязки:
    /// МЁРТВАЯ ВЕТВЬ (М-20-детектор: счётчик-ноль при
    /// живом входе — трижды за сутки: рынок в руке под
    /// флагом, руль 0:0, id_step без вязки), ГОЛОДНАЯ
    /// ДОРОГА (вызовы есть, покупок нет), СПЯЩАЯ
    /// МОГИЛА при живой цели, ДОМИНИРУЮЩАЯ РУКА руля.
    /// Пустой отчёт = структурных травм не видно.
    #[must_use]
    pub fn diagnose(&self) -> Vec<String> {
        let mut v = Vec::new();
        // [НОЭЗИС-МОСТ М-1: суд называет ХУДШУЮ
        // ЯЧЕЙКУ] средняя цена уничтожает адрес дыры;
        // самый частый адрес удивления = крупнейшая
        // ложь карты = родильня следующего органа
        // (кольцо бинарно — величина остатка здесь
        // частота, не биты)
        {
            let mut freq: HashMap<
                (u64, A),
                (u32, ObservedWorldOutcome, ObservedWorldOutcome),
            > = HashMap::new();
            for &(s, a, want, got) in
                &self.surprise_ring
            {
                let e = freq
                    .entry((s, a))
                    .or_insert((0, want, got));
                e.0 += 1;
            }
            if let Some(((s, _a), (n, want, got))) =
                freq.iter().max_by_key(
                    |((s, _), (n, _, _))| {
                        (*n, std::cmp::Reverse(*s))
                    },
                )
            {
                if *n >= 2 {
                    v.push(format!(
                        "ХУДШАЯ-ЯЧЕЙКА: ключ {s:x} \
                         удивляет x{n} (ждали {want:?}, \
                         мир отвечает {got:?}) — адрес \
                         рождения следующего органа"
                    ));
                }
            }
        }
        // [СУД ПРОТИВОРЕЧИЯ] стекло убеждений
        {
            let (qs, vs, srcs) =
                self.belief_market.glass();
            if qs > 0 {
                v.push(format!(
                    "УБЕЖДЕНИЯ: вопросов {qs},                      версий {vs}, источников                      {srcs}, рёбер {}",
                    self.belief_market
                        .glass_deps()
                ));
            }
        }
        // [THE DOOR OF RULES] glass: the rules bought of the candidates weighed on the door's shows
        if let Some(m) = &self.rule_model {
            v.push(format!(
                "RULES: bought {} of {} candidates on {} shows",
                m.len(),
                m.candidates(),
                self.rule_door.shows()
            ));
        }
        // [КУРС-ЛЕДЖЕР] стекло прожитых строк обмена
        // (курс не выводится — печатается интервал)
        if !self.goal_rate.is_empty() {
            let n = self.goal_rate.len();
            let (mut lo, mut hi) =
                (u64::MAX, 0u64);
            for &(_, _, pairs) in &self.goal_rate {
                lo = lo.min(pairs);
                hi = hi.max(pairs);
            }
            v.push(format!(
                "КУРС: {n} взятий, открыто пар \
                 карты за взятие [{lo}..{hi}] — \
                 чеканка курса законна при узком \
                 интервале"
            ));
        }
        let calls = self.goal_probe[6];
        let bought =
            self.goal_probe[0] + self.goal_probe[1];
        let no_road = self.goal_probe[2];
        if self.progress_goals_on
            && !self.progress_goals.is_empty()
        {
            if calls == 0 && self.goal_probe[4] > 0
            {
                v.push(format!(
                    "МЁРТВАЯ ВЕТВЬ: рынок целей не                      заседал ни разу при {} входах                      планирования и {} живых целях —                      гейт выше по каскаду",
                    self.goal_probe[4],
                    self.progress_goals.len()
                ));
            } else if calls > 0 && bought == 0 {
                v.push(format!(
                    "ГОЛОДНАЯ ДОРОГА: рынок целей                      заседал {calls} раз, купил 0                      (дорог нет: {no_road}) — карта                      бедна к источникам прогресса"
                ));
            }
        }
        let (wm, we) = self.steer_glass();
        if Self::map_plan_on()
            && wm + we == 0
            && self.goal_probe[4] > 50
        {
            v.push(format!(
                "МЁРТВЫЙ СУД: руль не заседал ни                  разу при {} входах планирования —                  пара предсказаний не встречается",
                self.goal_probe[4]
            ));
        }
        // [ЭКСПЕДИЦИЯ-СТЕКЛО]
        if self.exp_glass[0] > 0 {
            v.push(format!(
                "ЭКСПЕДИЦИЯ-СТЕКЛО	[построек,доездов,смертей-в-пути]={:?} cold={}",
                self.exp_glass, self.exp_cold
            ));
        }
        // [ПАЛОМНИК-СТЕКЛО]
        if self.pilgrim_glass[0] > 0 {
            v.push(format!(
                "ПАЛОМНИК-СТЕКЛО	[зовов,до-ресета,хвост,доезд,own]={:?} dry={} hold={} ноты[дожал,спето]=[{},{}]",
                self.pilgrim_glass,
                self.pilgrim_dry,
                self.pilgrim_hold,
                self.notes_retry_hits,
                self.notes_spent
            ));
        }
        // [Д-27 вахта] штамп витрины врал N раз
        if self.menu_stale > 0 {
            v.push(format!(
                "ВИТРИНА-ШТАМП	расхождений={}",
                self.menu_stale
            ));
        }
        // [СКУКА-СТЕКЛО]
        if self.bore_glass[0] > 0 {
            v.push(format!(
                "СКУКА-СТЕКЛО\t[скучных,ломателей,троек-после]={:?} bored={}",
                self.bore_glass, self.bored
            ));
        }
        // [МЕЖА-СТЕКЛО] дидактика vs свобода
        if self.fr_marked {
            let f_task: Vec<u32> = self
                .task_glass
                .iter()
                .zip(self.fr_task_glass.iter())
                .map(|(t, d)| t - d)
                .collect();
            let f_mk: Vec<u64> = self
                .mk_glass
                .iter()
                .zip(self.fr_mk_glass.iter())
                .map(|(t, d)| t - d)
                .collect();
            v.push(format!(
                "МЕЖА-СТЕКЛО	дидактика: задачи={:?} рынок={:?} стуков={} | свобода: задачи={f_task:?} рынок={f_mk:?} стуков={}",
                self.fr_task_glass,
                self.fr_mk_glass,
                self.fr_knocks,
                self.knocks - self.fr_knocks
            ));
        }
        // [РЫНОК-СТЕКЛО] торги юрисдикций
        if self.mk_glass[0] > 0 {
            v.push(format!(
                "РЫНОК-СТЕКЛО	[входов,капель,серв,cur,LAW-прав]={:?} yields=(s:{} c:{})",
                self.mk_glass,
                self.mk_pays_serve,
                self.mk_pays_cur
            ));
        }
        // [ЦЕЛЬ-СТЕКЛО] жизнь намерения
        if self.hold_glass.iter().sum::<u64>() > 0
        {
            v.push(format!(
                "ЦЕЛЬ-СТЕКЛО	[выбрана,рвачей-при-held,LAW-отпуск,кап-рвачей,уровень,ушла]={:?} держится={:?}",
                self.hold_glass,
                self.hold_goal.map(|g| g % 100000)
            ));
        }
        // [Г-СТЕКЛО-ВЫБОРА] гистограмма веток —
        // прибор обжоры каскада (ft09-род: entry
        // планирования съедала ветка выше; номер
        // ветки называет узел числом)
        if self.choice_counts.iter().sum::<u64>()
            > 0
        {
            v.push(format!(
                "Г-СТЕКЛО-ВЫБОРА	{:?}",
                self.choice_counts
            ));
        }
        if self.choice_counts[0] == 0
            && self
                .choice_counts
                .iter()
                .sum::<u64>()
                > 1000
        {
            v.push(format!(
                "МЁРТВАЯ ВЕТВЬ: валент (ось-V) не                  заседал ни разу за {} выборов",
                self
                    .choice_counts
                    .iter()
                    .sum::<u64>()
            ));
        }
        for (g, h) in self.progress_goals.iter() {
            if self.goal_graves.is_buried(&g.0)
                && h.confirmations == 0
            {
                v.push(format!(
                    "СПЯЩАЯ МОГИЛА при живой цели:                      класс {} похоронен ({} раз) —                      проверь валюту сна",
                    g.0,
                    self.goal_graves.burials(&g.0)
                ));
            }
        }
        v
    }

    /// Двойник судов: выключить рынок целей.
    pub fn goals_off(&mut self) {
        self.progress_goals_on = false;
    }

    /// Симметричный двойник: включить рынок целей
    /// обратно (чередование фаз — направленный проход
    /// целями / любопытный проход доплаты фронтира).
    pub fn goals_on(&mut self) {
        self.progress_goals_on = true;
    }

    /// [СУД ПРОТИВОРЕЧИЯ] стеклянный зонд убеждений:
    /// (вопросов прожито, открытых вопросов после
    /// суда конфликтов). Суд зовётся здесь же: каждый
    /// вопрос с версиями судится против цены дороги
    /// перепроверки (конвенция зонда: 1 бит — сам
    /// зонд не канон).
    pub fn belief_glass_probe(
        &mut self,
    ) -> (usize, usize) {
        let (qs, _, _) =
            self.belief_market.glass();
        let questions: Vec<u64> = self
            .belief_market
            .questions();
        for q in questions {
            let _ = self
                .belief_market
                .question_court(q, 1.0);
        }
        (
            qs,
            self.belief_market
                .open_questions
                .len(),
        )
    }

    /// Registered dependent assets still requiring their owners' recheck.
    /// These are conservative obligations over the existing dependency graph,
    /// not proofs of falsehood, invalidity or normalized hypothesis likelihood.
    /// Reading this diagnostic snapshot does not acknowledge any obligation.
    #[must_use]
    pub fn belief_rechecks(&self) -> Vec<u64> {
        self.belief_market.pending_rechecks().collect()
    }

    /// Последний выбор: (ветка, цель, длина плана).
    pub fn last_choice(&self) -> (u8, Option<u64>, usize) {
        (
            self.last_branch,
            self.plan_goal,
            self.plan.len(),
        )
    }

    #[must_use]
    /// Г-СТЕКЛО-ВЫБОРА: гистограмма 12 веток.
    pub fn choice_glass(&self) -> [u64; 12] {
        self.choice_counts
    }

    /// Г-СТЕКЛО: топ-K целей плана с числом построек и
    /// похоронами — вечный фронтир поимённо.
    #[must_use]
    pub fn goal_census_top(
        &self,
        k: usize,
    ) -> Vec<(u64, u32, u32)> {
        let mut v: Vec<(u64, u32, u32)> = self
            .goal_census
            .iter()
            .map(|(&g, &n)| {
                (
                    g,
                    n,
                    self.goal_graves.burials(&g),
                )
            })
            .collect();
        // [М-84, находка 32-го] полный ключ: ничья
        // по счёту решалась хэш-порядком HashMap —
        // невоспроизводимая печать отравляет
        // побитовые сравнения стёкол, а truncate
        // мог выкидывать разные цели от прогона к
        // прогону; адрес цели — тотальный добой
        v.sort_by_key(|&(g, n, _)| {
            (std::cmp::Reverse(n), g)
        });
        v.truncate(k);
        v
    }

    /// СК glass: how many states were folded into
    /// classes (the bought merges).
    #[must_use]
    pub fn glue_folded(&self) -> usize {
        self.glue_rep.len()
    }

    /// СК: the class representative (identity if free).
    fn glue_rep_of(&self, s: u64) -> u64 {
        let mut cur = s;
        while let Some(&r) = self.glue_rep.get(&cur) {
            if r == cur {
                break;
            }
            cur = r;
        }
        cur
    }

    /// СК v2: record an immediate outcome at the MEMBER
    /// ledger — the class is a lazy SUM over members, so
    /// the market can also SPLIT a dissenting member out
    /// (the one two-signed partition market of У-3; the
    /// merge-only market proved irreversible and deadly:
    /// deaths 6→51 in G-1 when young fork phases glued
    /// on noop evidence before their door differences
    /// were lived).
    fn glue_witness(
        &mut self,
        state: u64,
        action: A,
        out: GlueOutcome,
    ) {
        if !self.glue_on {
            return;
        }
        let e = self
            .glue_counts
            .entry((state, action))
            .or_insert([0; 3]);
        e[out as usize] += 1;
        self.glue_dirty.insert(state);
        let sig = self.glue_sig_of(state);
        let se = self
            .sig_counts
            .entry((sig, action))
            .or_insert([0; 3]);
        se[out as usize] += 1;
        let lu = self
            .sig_len_use
            .entry((sig, action))
            .or_insert((0, 0));
        lu.0 += 1;
        lu.1 += self.source_time.life_age();
    }

    /// СК-чтение: the state's gesture-signature hash
    /// (FNV over the sorted action dictionary).
    fn glue_sig_of(&mut self, state: u64) -> u64 {
        if let Some(&h) = self.sig_of.get(&state) {
            return h;
        }
        let h = Self::sig_hash(
            self.seen
                .get(&state)
                .cloned()
                .unwrap_or_default(),
        );
        self.sig_of.insert(state, h);
        h
    }

    fn sig_hash(mut ms: Vec<A>) -> u64 {
        ms.sort_unstable();
        let mut h = synarc_math::fnv::FNV_OFFSET;
        for m in &ms {
            let mut hasher =
                std::collections::hash_map::DefaultHasher::new();
            std::hash::Hash::hash(m, &mut hasher);
            let hv =
                std::hash::Hasher::finish(&hasher);
            for b in hv.to_le_bytes() {
                h ^= u64::from(b);
                h = h.wrapping_mul(
                    synarc_math::fnv::FNV_PRIME,
                );
            }
        }
        h
    }

    /// СК v2: the class outcome table — the sum over
    /// the class's members (identity class = the member
    /// itself).
    fn glue_class_counts(
        &self,
        rep: u64,
        action: A,
    ) -> [u32; 3] {
        let mut sum = self
            .glue_counts
            .get(&(rep, action))
            .copied()
            .unwrap_or([0; 3]);
        if let Some(members) =
            self.glue_members.get(&rep)
        {
            for m in members {
                if let Some(c) = self
                    .glue_counts
                    .get(&(*m, action))
                {
                    sum[0] += c[0];
                    sum[1] += c[1];
                    sum[2] += c[2];
                }
            }
        }
        sum
    }

    /// СК: KT code length (bits) of one outcome-count
    /// table under the Dirichlet-half prior — the one
    /// currency of the partition market.
    fn glue_kt_bits(c: &[u32; 3]) -> f64 {
        // sequential KT over the 3-outcome alphabet
        // (count-exchangeable — the sum is order-free)
        let mut bits = 0.0f64;
        let mut tot = 0.0f64;
        for &cnt in c {
            for k in 0..cnt {
                bits -= (f64::from(k) + 0.5).log2();
                bits += (tot + 1.5).log2();
                tot += 1.0;
            }
        }
        bits
    }

    /// СК THE PARTITION MARKET (sits on boredom): greedy
    /// agglomeration over same-gesture-set states by the
    /// sign of bits(apart) − bits(merged); a merge is
    /// bought only when it saves bits (У-2: the death
    /// outcome makes a deadly member expensive to any
    /// merge by the KT arithmetic itself).
    /// Г4: the incremental sitting — only groups touched
    /// by a dirty ledger are re-judged (Б2-О1: untouched
    /// pairs hold their sign; О3: dirty ≡ full).
    fn glue_market(&mut self) {
        self.glue_market_impl(true);
    }

    /// The full sitting — the court's reference twin
    /// (never called on the lived path; the Г4 court
    /// proves dirty ≡ full against it).
    #[cfg(test)]
    fn glue_market_full(&mut self) {
        self.glue_market_impl(false);
    }

    fn glue_market_impl(&mut self, only_dirty: bool) {
        use std::collections::BTreeMap;
        // Г4: the set of representatives touched since
        // the last sitting (a dirty member touches its
        // whole class through the class sums)
        let mut dirty_reps: std::collections::HashSet<u64> =
            if only_dirty {
                let ds: Vec<u64> = self
                    .glue_dirty
                    .iter()
                    .copied()
                    .collect();
                ds.into_iter()
                    .map(|s| self.glue_rep_of(s))
                    .collect()
            } else {
                std::collections::HashSet::new()
            };
        // ---- the MERGE side: representatives grouped
        // by gesture signature, greedy agglomeration by
        // the bit sign over CLASS SUMS ----
        let mut groups: BTreeMap<Vec<A>, Vec<u64>> =
            BTreeMap::new();
        for (&s, ms) in &self.seen {
            let rep = self.glue_rep_of(s);
            if rep != s {
                continue;
            }
            let mut sig = ms.clone();
            sig.sort_unstable();
            groups.entry(sig).or_default().push(rep);
        }
        for (_, mut reps) in groups {
            if reps.len() < 2 {
                continue;
            }
            // Г4: an untouched group keeps its lived
            // verdict — every pair's class sums are
            // unchanged, so every KT sign stands (О1)
            if only_dirty
                && !reps
                    .iter()
                    .any(|r| dirty_reps.contains(r))
            {
                continue;
            }
            reps.sort_unstable();
            reps.dedup();
            let mut anchor = reps[0];
            for &cand in &reps[1..] {
                if cand == anchor {
                    continue;
                }
                let acts: Vec<A> = self
                    .seen
                    .get(&anchor)
                    .cloned()
                    .unwrap_or_default();
                let mut apart = 0.0f64;
                let mut merged = 0.0f64;
                let mut shared = 0u32;
                for a in &acts {
                    let ca = self
                        .glue_class_counts(anchor, *a);
                    let cb = self
                        .glue_class_counts(cand, *a);
                    let na: u32 = ca.iter().sum();
                    let nb: u32 = cb.iter().sum();
                    if na > 0 && nb > 0 {
                        shared += 1;
                    }
                    let cm = [
                        ca[0] + cb[0],
                        ca[1] + cb[1],
                        ca[2] + cb[2],
                    ];
                    apart += Self::glue_kt_bits(&ca)
                        + Self::glue_kt_bits(&cb);
                    merged += Self::glue_kt_bits(&cm);
                }
                // юность (У-3, the deadly lesson): судим
                // только зрелые пары — БОЛЬШИНСТВО
                // жестов прожито обоими (a noop-only
                // overlap glued fork phases and killed)
                #[allow(
                    clippy::cast_possible_truncation,
                    reason = "action sets are small"
                )]
                let need = acts.len() as u32;
                if shared < need {
                    continue;
                }
                if merged < apart {
                    // Г4: the merged class is new — the
                    // split court of THIS sitting must
                    // see it even if the anchor's own
                    // ledger was clean
                    dirty_reps.insert(anchor);
                    self.glue_rep
                        .insert(cand, anchor);
                    let cand_members = self
                        .glue_members
                        .remove(&cand)
                        .unwrap_or_default();
                    let e = self
                        .glue_members
                        .entry(anchor)
                        .or_default();
                    e.push(cand);
                    e.extend(cand_members);
                } else {
                    anchor = cand;
                }
            }
        }
        // ---- the SPLIT side: a member whose OWN ledger
        // now disagrees with the rest of its class walks
        // out (the two-signed market — merges stay
        // refutable) ----
        let reps: Vec<u64> = self
            .glue_members
            .keys()
            .copied()
            .collect();
        for rep in reps {
            // Г4: a class no ledger touched cannot have
            // changed any member's walk-out sign (О1)
            if only_dirty && !dirty_reps.contains(&rep)
            {
                continue;
            }
            let members = self
                .glue_members
                .get(&rep)
                .cloned()
                .unwrap_or_default();
            if members.is_empty() {
                continue;
            }
            let acts: Vec<A> = self
                .seen
                .get(&rep)
                .cloned()
                .unwrap_or_default();
            let mut expel: Vec<u64> = Vec::new();
            for &m in &members {
                let mut with = 0.0f64;
                let mut without = 0.0f64;
                for a in &acts {
                    let cm = self
                        .glue_counts
                        .get(&(m, *a))
                        .copied()
                        .unwrap_or([0; 3]);
                    let call =
                        self.glue_class_counts(rep, *a);
                    let rest = [
                        call[0] - cm[0],
                        call[1] - cm[1],
                        call[2] - cm[2],
                    ];
                    with +=
                        Self::glue_kt_bits(&call);
                    without += Self::glue_kt_bits(
                        &rest,
                    ) + Self::glue_kt_bits(
                        &cm,
                    );
                }
                if without < with {
                    expel.push(m);
                }
            }
            if !expel.is_empty() {
                if let Some(ms) =
                    self.glue_members.get_mut(&rep)
                {
                    ms.retain(|m| !expel.contains(m));
                }
                for m in expel {
                    self.glue_rep.remove(&m);
                }
            }
        }
        // Г4: the sitting judged every touched ledger —
        // the slate is clean until the next lived change
        self.glue_dirty.clear();
    }

    /// BFS over the earned geography to the nearest
    /// situation with an untried action; the reset action
    /// is a teleport to the root.
    /// А1-кремний (заказ holon, дуга восьми прогонов;
    /// теорема двух органов): разведка = ПЛАН к
    /// недоплаченному ключу по ЛЕКСИКОГРАФИЧЕСКОМУ
    /// экзамену остатка, не блуждание. Три грани формы:
    /// (1) цена пути — пара (Σ ML-смертность переходов,
    /// длина), БЕЗ прайора юности в валюте (грань-4:
    /// KT-прайор морозил свежий 13-путь); (2) фронтир —
    /// ситуация с untried-жестом ИЛИ жестом, прожитым
    /// меньше LAW_OF_REPETITION раз (LAW=2-долг:
    /// недоплаченный ключ); (3) старый BFS остаётся
    /// двойником М-4-щита (G1_PLAN_BFS=1). Дейкстра по
    /// квантованной паре; ML = death/total прожитого
    /// леджера склейки (непрожитое не обвиняется).
    fn plan_to_frontier(
        &mut self,
        from: u64,
        reset: Option<A>,
    ) {
        // ШАГ-2/3 СОВЕТА ЖЕСТОВ: СУД РУЛЯ (эталон holon
        // GREEN 4/4) — обе руки предсказывают цену
        // остатка в единой валюте c = m + λ·L; KT-счёт
        // побед решает руль (лог-оддсы (w_map+½)/(w_exam
        // +½)); юная карта не получает руля прайором.
        // G1_NO_STEER=1 — двойник (карта-первой без
        // суда); G1_PLAN_BFS=1 — старый BFS.
        self.goal_probe[4] += 1;
        if std::env::var("G1_PLAN_BFS").is_ok() {
            self.goal_probe[5] += 1;
            self.plan_to_frontier_bfs(from, reset);
            return;
        }
        if !self.glue_on {
            self.goal_probe[5] += 1;
            self.plan_to_frontier_bfs(from, reset);
            if self.plan.is_empty() {
                self.plan_to_frontier_relation(from, reset, true);
            }
            return;
        }
        {
            let raw = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            if self.plan_to_progress_goal(raw) {
                return;
            }
        }
        if !Self::map_plan_on() {
            self.plan_to_frontier_exam(from, reset);
            return;
        }
        if std::env::var("G1_NO_STEER").is_ok() {
            let raw = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            self.plan_by_map_to_frontier(raw);
            if !self.plan.is_empty() {
                return;
            }
            self.plan_to_frontier_exam(from, reset);
            if self.plan.is_empty() {
                let _ = self
                    .try_goal_transfer(raw);
            }
            return;
        }
        // [ЕДИНОВЛАСТИЕ НАМЕРЕНИЯ, суд двух рук]
        // «порядок слушания» внутри планировщика
        // КАЗНЁН — он был последним бастионом
        // первенства: три c-раунда жили такт-в-такт
        // одной жизнью МИМО рынка и hold (ft09
        // дельты ровно +35932; цель-память
        // крутилась вхолостую над чужими планами).
        // Задачные планы строит ТОЛЬКО намерение
        // (рынок → hold → узкая постройка); общий
        // планировщик строит фронтир.
        self.last_exam_cost = None;
        self.plan_to_frontier_exam(from, reset);
        let exam_cost = self.last_exam_cost;
        let raw = self.coined_key(
            self.cur_raw_key,
            self.since_root,
        );
        let lex = crate::worldmap::LexMortalityFirst;
        let lethal = |t: &u8| *t == 1;
        // [ЕДИНОВЛАСТИЕ] map-к-задаче казнён
        // здесь же (двоевластие обеими руками);
        // map-дорога к held-цели вернётся узкой
        // постройкой V2 — стекло map_hit до тех
        // пор честно молчит.
        // [ЛЕСТНИЦА ДЕРЖАНИЯ → ПЛАНИРОВАНИЕ КАРТЫ,
        // машина пассов probe-10] resume-карта
        // строила планы к ПРИЗРАКАМ — целям глубоких
        // уровней прошлой жизни — в свежем мире дна
        // (26К плановых шагов пасса-1 в никуда; два
        // пасса выжигания капами). Тот же закон, что
        // у world_tasks (retain lv≤here+1),
        // поднимается на карту: протокольная
        // лестница — выше следующего уровня мир
        // недостижим без флипа.
        let here_lv =
            crate::optimality::level_of(raw);
        let map_found = {
            self.map.plan(
                raw,
                |k| {
                    let Ok(e) = self.try_eyed(*k) else { return false; };
                    *k != raw
                        && crate::optimality::level_of(*k)
                            <= here_lv + 1
                        && ((!self
                            .untried(e)
                            .is_empty()
                            && self
                                .debt_collectable(
                                    e,
                                ))
                            || self
                                .map_thin_act(*k)
                                .is_some())
                        && self.goal_admissible(e)
                },
                &lex,
                lethal,
            )
        };
        let lam = self.death_rate_per_step();
        let quant = (1u64 << 20) as f64;
        #[allow(
            clippy::cast_possible_truncation,
            clippy::cast_sign_loss,
            reason = "bounded currency"
        )]
        let unify = |hz: u64, len: u32| -> u64 {
            hz + (lam * f64::from(len) * quant)
                .round() as u64
        };
        let c_exam =
            exam_cost.map(|(h, l)| unify(h, l));
        let c_map = map_found
            .as_ref()
            .map(|(_, _, (h, l))| unify(*h, *l));
        match (c_map, c_exam) {
            (None, None) => {
                self.steer_lane[3] += 1;
            }
            _ => {}
        }
        match (c_map, c_exam) {
            (Some(cm), Some(ce)) => {
                self.steer_lane[0] += 1;
                // пара предсказаний — суд откроется
                // на разрешении плана
                self.steer_pending = Some((
                    cm,
                    ce,
                    self.source_time.life_age(),
                    0,
                ));
                let odds = (f64::from(
                    self.steer_w_map,
                ) + 0.5)
                    .ln()
                    - (f64::from(
                        self.steer_w_exam,
                    ) + 0.5)
                        .ln();
                if odds > 0.0
                    && let Some((
                        acts,
                        goal_raw,
                        _,
                    )) = map_found
                {
                    let micro = self
                        .map
                        .unroll_plan(raw, &acts);
                    if !micro.is_empty() {
                        let Ok(goal) = self.try_eyed(goal_raw) else { return; };
                        self.plan_from_map = true;
                        self.plan = micro.into();
                        self.plan_goal =
                            Some(goal);
                        self.plan_version =
                            self.map.version();
                        let (wm, we) = (
                            self.steer_w_map,
                            self.steer_w_exam,
                        );
                        self.glass(||
                            format!(
                                "{{\"ev\":\"steer\",\"rod\":\"self\",\"hand\":\"map\",\"odds\":{odds:.3},\"w_map\":{wm},\"w_exam\":{we}}}"
                            ),
                        );
                    }
                }
            }
            (Some(_), None) => {
                self.steer_lane[2] += 1;
                // exam голоден — карта фолбэком (без
                // суда: одиночное предсказание)
                if let Some((acts, goal_raw, _)) =
                    map_found
                {
                    let micro = self
                        .map
                        .unroll_plan(raw, &acts);
                    if !micro.is_empty() {
                        let Ok(goal) = self.try_eyed(goal_raw) else { return; };
                        self.plan_from_map = true;
                        self.plan = micro.into();
                        self.plan_goal =
                            Some(goal);
                        self.plan_version =
                            self.map.version();
                        *self
                            .goal_census
                            .entry(goal)
                            .or_insert(0) += 1;
                    }
                }
            }
            _ => {
                if c_exam.is_some() {
                    self.steer_lane[1] += 1;
                    // аутопсия молчания карты:
                    // достижим ли ХОТЬ КТО-ТО, и на
                    // каком сите умерла цель
                    let p_any = self.map.plan(
                        raw,
                        |k| *k != raw,
                        &lex,
                        lethal,
                    );
                    if p_any.is_none() {
                        if self
                            .map
                            .acts_of(raw)
                            .is_empty()
                        {
                            self.steer_autopsy
                                [0] += 1;
                        } else {
                            self.steer_autopsy
                                [1] += 1;
                        }
                    } else {
                        let projection_refusal = std::cell::RefCell::new(None);
                        let p_core = self
                            .map
                            .plan(
                                raw,
                                |k| {
                                    let e = match self.try_eyed(*k) {
                                        Ok(value) => value,
                                        Err(reason) => {
                                            *projection_refusal.borrow_mut() = Some(reason);
                                            return false;
                                        }
                                    };
                                    *k != raw
                                        && ((!self
                                            .untried(e)
                                            .is_empty()
                                            && self
                                                .debt_collectable(e))
                                            || self
                                                .map_thin_act(*k)
                                                .is_some())
                                },
                                &lex,
                                lethal,
                            );
                        if let Some(reason) = projection_refusal.into_inner() {
                            self.glass(|| format!("observer projection unavailable in planning autopsy: {reason}"));
                        } else if p_core.is_none() {
                            self.steer_autopsy
                                [2] += 1;
                        } else {
                            self.steer_autopsy
                                [3] += 1;
                        }
                    }
                }
            }
        }
        // ЖЕСТ ГОЛОДА (ступень-2): обе руки пусты —
        // перенос акта доказанной плательщицы
        if self.plan.is_empty() {
            let raw = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            let _ = self.try_goal_transfer(raw);
        }
        // ТАКТ-2 СТУПЕНИ-3: СВОП ПО ЦЕНЕ — план
        // куплен любой рукой, но у цели есть навык
        // КОРОЧЕ плана: исполняй дешевейшее из
        // известных тел (Т-ЦЕНА на планах; ставка
        // lp85: 67 навыков куплено, 0 сыграно —
        // игра жила только в статье рынка)
        if std::env::var("G1_SKILL_SWAP").is_ok()
            && let Some(g) = self.plan_goal
            && !self.plan.is_empty()
        {
            let body: Option<((u64, u64), Vec<A>)> =
                self.skills
                    .iter()
                    .filter(|((sg, _), h)| {
                        *sg == g
                            && h.value.len()
                                < self.plan.len()
                    })
                    .min_by_key(|(_, h)| {
                        h.value.len()
                    })
                    .map(|(k, h)| {
                        (*k, h.value.clone())
                    });
            if let Some((key, b)) = body {
                self.plan = b.into();
                self.swap_pending = Some((g, key));
                self.glass(|| format!(
                    "{{\"ev\":\"skill_play\",\"rod\":\"self\",\"goal\":{g},\"swap\":true}}"
                ));
            }
        }
    }

    /// План по карте: цель — фронтир-предикат (та же
    /// тройка законов: невзыскуемость терминалов,
    /// недоплата классом, могилы с давностью); макро-
    /// план разворачивается в микро-жесты — исполнитель
    /// и опровержимость фактом не меняются.
    /// РЫНОК ЦЕЛЕЙ — СТАРШИЙ ПРЕТЕНДЕНТ планирования
    /// (общая точка всех рук: прогресс главнее
    /// фронтира). Цель — пара (класс-источник, акт):
    /// план = дорога картой к источнику прогресса +
    /// повторение купленного акта; в источнике — акт
    /// сразу. true = план куплен. G1_GOALS_OFF /
    /// goals_off() — двойники-щиты.
    fn plan_to_progress_goal(
        &mut self,
        from_raw: u64,
    ) -> bool {
        if !self.progress_goals_on
            || std::env::var("G1_GOALS_OFF")
                .is_ok()
            || self.progress_goals.is_empty()
        {
            return false;
        }
        self.goal_probe[6] += 1;
    // РЫНОК ЦЕЛЕЙ ПЕРВЫМ: если прожитые цели
    // прогресса достижимы картой — план к
    // тяжелейшей допустимой (могилы судят);
    // G1_GOALS_OFF=1 — двойник-щит.
        let lex =
            crate::worldmap::LexMortalityFirst;
        let lethal = |t: &u8| *t == 1;
        // Т-ЦЕНА-ОСТАТКА: ценность цели = вес /
        // (дистанция до источника + 1) — ближний
        // платящий правит (ретро-суд su15 в ядре;
        // недостижимые волной падают в хвост и
        // отсеются «нет дороги» как прежде)
        let Ok(wave) = self.map.try_class_dist_wave(
            from_raw,
            |k| self.try_eyed(*k),
            64,
        ) else { return false; };
        let mut order: Vec<((u64, A), f64)> =
            self.progress_goals
                .iter()
                .map(|(k, h)| {
                    let d = wave
                        .get(&k.0)
                        .copied()
                        .unwrap_or(u32::MAX);
                    let v = if d == u32::MAX {
                        -1.0
                    } else {
                        h.value
                            / f64::from(d + 1)
                    };
                    (*k, v)
                })
                .collect();
        order.sort_by(|a, b| {
            b.1.partial_cmp(&a.1)
                .unwrap_or(
                    std::cmp::Ordering::Equal,
                )
        });
        for ((gk, gact), _w) in order {
            // долговая могила (goal_graves) НЕ судит
            // прогресс-цели: их валюта — рост сенсора,
            // опровержение — суд обещания (см.
            // pending_goal_fire), не пустой долг
            let _ = &self.goal_probe[6];
            // КУПЛЕННЫЙ НАВЫК цели — играть телом
            // (подпрограмма вместо перепланирования;
            // суд обещания судит исполнение как
            // всякий план рынка)
            let skill_body: Option<Vec<A>> = self
                .skills
                .iter()
                .filter(|((g, _), _)| *g == gk)
                .max_by_key(|(_, h)| {
                    h.confirmations
                })
                .map(|(_, h)| h.value.clone());
            // Т-ЦЕНА и здесь: навык играет, только
            // когда его тело НЕ ДОРОЖЕ дороги картой
            // (стенд-регресс 24->50: первый длинный
            // поход играл вечно против короткой
            // карты); недостижимость волной (перенос)
            // — навык единственная рука
            let road = wave
                .get(&gk)
                .copied()
                .unwrap_or(u32::MAX);
            if let Some(body) = skill_body
                && (road == u32::MAX
                    || body.len()
                        <= road as usize)
            {
                self.goal_probe[1] += 1;
                self.pending_goal_fire =
                    Some((gk, gact));
                self.plan = body.into();
                self.plan_goal = Some(gk);
                self.plan_version =
                    self.map.version();
                *self
                    .goal_census
                    .entry(gk)
                    .or_insert(0) += 1;
                self.glass(|| format!(
                    "{{\"ev\":\"skill_play\",\"rod\":\"self\",\"goal\":{gk}}}"
                ));
                return true;
            }
            // уже в источнике прогресса —
            // повторить купленный акт
            if self.try_eyed(from_raw).is_ok_and(|key| key == gk) {
                self.goal_probe[0] += 1;
                self.pending_goal_fire =
                    Some((gk, gact));
                self.plan =
                    vec![gact].into();
                self.plan_goal = Some(gk);
                self.plan_version =
                    self.map.version();
                *self
                    .goal_census
                    .entry(gk)
                    .or_insert(0) += 1;
                return true;
            }
            let found = self.map.plan(
                from_raw,
                |k| {
                    *k != from_raw
                        && self.try_eyed(*k).is_ok_and(|key| key == gk)
                },
                &lex,
                lethal,
            );
            if found.is_none() {
                self.goal_probe[2] += 1;
            }
            if let Some((acts, goal_raw, _)) =
                found
            {
                let mut micro = self
                    .map
                    .unroll_plan(
                        from_raw, &acts,
                    );
                if micro.is_empty() {
                    self.goal_probe[3] += 1;
                }
                if !micro.is_empty() {
                    self.goal_probe[1] += 1;
                    self.pending_goal_fire =
                        Some((gk, gact));
                    let age = self.source_time.life_age();
                    self.glass(|| format!(
                        "{{\"ev\":\"goal_buy\",\"rod\":\"self\",\"k\":{gk},\"len\":{},\"from\":{from_raw},\"to\":{goal_raw},\"t\":{age}}}",
                        micro.len() + 1
                    ));
                    micro.push(gact);
                    let Ok(goal) = self.try_eyed(goal_raw) else { return false; };
                    self.plan = micro.into();
                    self.plan_goal =
                        Some(goal);
                    self.plan_version =
                        self.map.version();
                    *self
                        .goal_census
                        .entry(goal)
                        .or_insert(0) += 1;
                    return true;
                }
            }
        }
        false
    }

    /// СТУПЕНЬ-2 МАКРО-ШВА (жест ГОЛОДА —
    /// последняя статья планирования, после
    /// фронтир-планов обеих рук: в ветви рынка
    /// переносы жгли жизнь стенда 24.09→26.08):
    /// перенос акта доказанной плательщицы в
    /// текущий класс; суд обещанием, один
    /// эксперимент на (класс, пара).
    fn try_goal_transfer(
        &mut self,
        from_raw: u64,
    ) -> bool {
        if !self.progress_goals_on
            || std::env::var("G1_GOALS_OFF")
                .is_ok()
        {
            return false;
        }
        // СТУПЕНЬ-2 МАКРО-ШВА: ПЕРЕНОС АКТА ЦЕЛИ —
        // класс-источник недостижим (новый уровень
        // или мир), но акт ДОКАЗАННОЙ ПЛАТЕЛЬЩИЦЫ
        // (confirmations>0) есть в текущем меню:
        // сыграть его экспериментом переноса; суд
        // обещания оценит — рост родит новую пару
        // текущего источника, провал похоронит
        // ЗАПИСЬ переноса (не пару-донора). Один
        // эксперимент на (класс, пара).
        let Ok(cur) = self.try_eyed(from_raw) else { return false; };
        let menu: Vec<A> = self
            .seen
            .get(&cur)
            .cloned()
            .unwrap_or_default();
        if !menu.is_empty() {
            let mut cands: Vec<((u64, A), u32)> =
                self.progress_goals
                    .iter()
                    .filter(|(k, h)| {
                        h.confirmations > 0
                            && menu
                                .contains(&k.1)
                            && !self
                                .tried_transfers
                                .contains(&(
                                    cur, **k,
                                ))
                            && !self
                                .banned(cur, k.1)
                    })
                    .map(|(k, h)| {
                        (*k, h.confirmations)
                    })
                    .collect();
            cands.sort_by_key(|&(_, c)| {
                std::cmp::Reverse(c)
            });
            if let Some((pair, _)) =
                cands.first().copied()
            {
                self.transfer_pending =
                    Some((cur, pair));
                self.plan =
                    vec![pair.1].into();
                self.plan_goal = Some(cur);
                self.plan_version =
                    self.map.version();
                self.glass(|| format!(
                    "{{\"ev\":\"goal_transfer\",\"rod\":\"self\",\"from\":{},\"at\":{cur}}}",
                    pair.0
                ));
                return true;
            }
        }
        false
    }

    fn plan_by_map_to_frontier(
        &mut self,
        from_raw: u64,
    ) {
        // НАСТОЯЩАЯ СКУКА: exam-рука голодна (вход в
        // фолбэк) — момент сидки рынка координат
        self.coin_coords_market();
        // Фаза-2, переезд-6: ФРОНТИР органом. Что
        // есть фронтир (три юрисдикции долга + допуск
        // целей) — предикат-замыкание организма; как
        // дойти — закон карты в органе. Леджеры плана
        // (версия, перепись целей) — у владельца.
        // Старый блок ниже — двойник М-4-щита.
        if Self::motor_on() {
            let picked = {
                let frontier = |k: u64| {
                    let Ok(e) = self.try_eyed(k) else { return false; };
                    ((!self
                        .untried(e)
                        .is_empty()
                        && self.debt_collectable(e))
                        || self
                            .map_thin_act(k)
                            .is_some())
                        && self.goal_admissible(e)
                };
                let no_ban = |_a: A| false;
                let empty: [A; 0] = [];
                let ctx =
                    crate::motor::MotorCtx {
                        key: from_raw,
                        raw: from_raw,
                        root_raw: None,
                        menu: &empty,
                        map: &self.map,
                        takeover: false,
                        just_arrived: false,
                        banned: &no_ban,
                    };
                let mut organ =
                    crate::motor::FrontierOrgan {
                        frontier: &frontier,
                    };
                organ.propose_plan(&ctx)
            };
            if let Some(p) = picked {
                if let Some(graw) = p.goal {
                    let Ok(goal) = self.try_eyed(graw) else { return; };
                    self.plan_from_map = true;
                    self.plan = p.micro.into();
                    self.plan_goal = Some(goal);
                    self.plan_version =
                        self.map.version();
                    *self
                        .goal_census
                        .entry(goal)
                        .or_insert(0) += 1;
                }
            }
            return;
        }
        let lex =
            crate::worldmap::LexMortalityFirst;
        let lethal = |t: &u8| *t == 1;
        let found = self.map.plan(
            from_raw,
            |k| {
                let Ok(e) = self.try_eyed(*k) else { return false; };
                *k != from_raw
                    && ((self
                        .untried(e)
                        .first()
                        .is_some()
                        && self.debt_collectable(e))
                        || self
                            .map_thin_act(*k)
                            .is_some())
                    && self.goal_admissible(e)
            },
            &lex,
            lethal,
        );
        if let Some((acts, goal_raw, _)) = found {
            let micro = self
                .map
                .unroll_plan(from_raw, &acts);
            if !micro.is_empty() {
                let Ok(goal) = self.try_eyed(goal_raw) else { return; };
                self.plan_from_map = true;
                self.plan = micro.into();
                self.plan_goal = Some(goal);
                self.plan_version =
                    self.map.version();
                *self
                    .goal_census
                    .entry(goal)
                    .or_insert(0) += 1;
            }
        }
    }

    /// Грань-7 в ШАНСАХ: посещения ситуации (Σ по
    /// жестам леджера склейки) — сон могилы/бана меряется
    /// упущенными ШАНСАМИ retest-а, не временем (редкие
    /// похороны делали «средний интервал» длиннее жизни —
    /// вечность возвращалась чёрным ходом).
    fn visits_of(&self, s: u64) -> u64 {
        self.seen
            .get(&s)
            .map(|ms| {
                ms.iter()
                    .map(|a| {
                        let c = self
                            .glue_counts
                            .get(&(s, *a))
                            .copied()
                            .unwrap_or([0; 3]);
                        u64::from(c[0] + c[1] + c[2])
                    })
                    .sum()
            })
            .unwrap_or(0)
    }

    /// А1/А3: прожитый смертный темп НА ШАГ — вторая
    /// смертность (вина длины [В-1]) в ЕДИНОЙ валюте с
    /// ML переходов: жёсткая лексикографика (смертность,
    /// длина) вечно платила +6 шагов за ε-историю (хвост
    /// {24} тропой A против B-18 c ML=2/2900); единая
    /// ось = ML + rate×1 на ребро — курс длины ВЫВЕДЕН
    /// из леджера, не назначен.
    fn death_rate_per_step(&self) -> f64 {
        let d: u64 = self
            .glue_counts
            .values()
            .map(|c| u64::from(c[2]))
            .sum();
        #[allow(clippy::cast_precision_loss)]
        {
            d as f64 / (self.source_time.life_age().max(1) as f64)
        }
    }

    /// А1: ML-смертность перехода из прожитого леджера
    /// (без прайора: непрожитый жест не обвиняется).
    fn ml_death(&self, s: u64, a: A) -> f64 {
        let c = self
            .glue_counts
            .get(&(s, a))
            .copied()
            .unwrap_or([0; 3]);
        let n = c[0] + c[1] + c[2];
        if n == 0 {
            0.0
        } else {
            f64::from(c[2]) / f64::from(n)
        }
    }

    /// А1-грань-7: цель допустима, если могилы нет ИЛИ
    /// давность выкупила retest — сон могилы =
    /// (похороны+LAW) × средний межпохоронный интервал
    /// собственного леджера (самокалибровка без ручек;
    /// каждая новая смерть удлиняет сон — самозащита).
    /// G1_GRAVE_ETERNAL=1 — вечная могила (двойник М-4).
    fn goal_admissible(&self, s: u64) -> bool {
        if !self.goal_graves.is_buried(&s) {
            return true;
        }
        if std::env::var("G1_GRAVE_ETERNAL").is_ok() {
            return false;
        }
        // часы носителя фронтир-цели — её визиты
        // (закон соизмеримости: сон меряется валютой,
        // которая у носителя ТЕЧЁТ)
        self.goal_graves
            .admissible(&s, self.visits_of(s))
    }

    /// Терминальный ключ: LAW и более приходов без
    /// единого СВОЕГО жеста — мир не даёт шанса (гол,
    /// смерть-клетка); untried-долг там невзыскуем и
    /// фронтиру не цель.
    fn debt_collectable(&self, s: u64) -> bool {
        if std::env::var("G1_NO_TERMINAL_LAW")
            .is_ok()
        {
            return true;
        }
        let arr = self
            .arrivals
            .get(&s)
            .copied()
            .unwrap_or(0);
        u64::from(arr)
            < u64::from(
                crate::law::LAW_OF_REPETITION,
            )
            || self.visits_of(s) > 0
    }

    /// А1: недоплаченный ключ — жест этой ситуации,
    /// прожитый меньше закона повторения (untried = долг
    /// нуля проживаний, тот же закон).
    fn underpaid(&self, s: u64) -> bool {
        // КАНОН ПО БИСЕКТ-ТАБЛИЦЕ (25.08): долг — СЫРОЙ
        // леджер. Классовая юрисдикция долга (архивный
        // двойник G1_CLASS_UNDERPAID=1) раздавала
        // фантомные долги всюду, куда дотягивалась
        // склейка (95/1500, caps 1240 — единственный
        // убийца из шести подсудимых) и стоила O(членов)
        // в предикате Дейкстры; лгунью-82 решает
        // ТЕРМИНАЛЬНЫЙ закон. Шрам: перенос юрисдикции
        // (любопытство→долг) требует своего суда.
        if std::env::var("G1_CLASS_UNDERPAID")
            .is_err()
        {
            return self
                .seen
                .get(&s)
                .is_some_and(|ms| {
                    ms.iter().any(|&a| {
                        !self.banned(s, a) && {
                            let c = self
                                .glue_counts
                                .get(&(s, a))
                                .copied()
                                .unwrap_or([0; 3]);
                            c[0] + c[1] + c[2]
                                < crate::law::LAW_OF_REPETITION
                        }
                    })
                });
        }
        let rep = self.glue_rep_of(s);
        self.seen.get(&s).is_some_and(|ms| {
            ms.iter().any(|&a| {
                !self.banned(s, a)
                    && self
                        .glue_class_counts(rep, a)
                        .iter()
                        .sum::<u32>()
                        < crate::law::LAW_OF_REPETITION
            })
        })
    }

    /// А1: Дейкстра по лексикографической паре
    /// (Σ ML-смертность ×2²⁰ квантом, длина).
    fn plan_to_frontier_exam(
        &mut self,
        from: u64,
        reset: Option<A>,
    ) {
        self.plan_to_frontier_exam_pred(
            from, reset, false,
        );
    }

    /// tasks_only=true: экзамен слышит ТОЛЬКО адреса
    /// служения (порядок слушания суда, не вес)
    fn plan_to_frontier_exam_pred(
        &mut self,
        from: u64,
        reset: Option<A>,
        tasks_only: bool,
    ) {
        self.plan_exam_pred_to(
            from, reset, tasks_only, None,
        );
    }

    /// [ЦЕЛЬ-ПАМЯТЬ] узкая постройка: target =
    /// Some(g) строит ТОЛЬКО к g (re-plan held-цели
    /// вне рынка).
    fn plan_exam_pred_to(
        &mut self,
        from: u64,
        reset: Option<A>,
        tasks_only: bool,
        target: Option<u64>,
    ) {
        self.plan_exam_pred_cut(
            from, reset, tasks_only, target,
            false,
        );
    }

    /// uncut=true: план обрезке не подсуден
    /// (ресет-паломничество строит от корня БЕЗ
    /// reset-ребра и клеит префикс после — R71:
    /// historic-гейт не видел ресета, обрезка
    /// резала урок на первом стыке, префикс
    /// клеился к обрубку)
    fn plan_exam_pred_cut(
        &mut self,
        from: u64,
        reset: Option<A>,
        tasks_only: bool,
        target: Option<u64>,
        uncut: bool,
    ) {
        // [ПОСТРОЙКА-ВАХТА] ARC_WATCH_REACH=<dec>:
        // раскрывает ли Дейкстра watch-узел и чем
        // он одет в носителях (суд (а)/(б)/(в):
        // ребро-в-носителе / достижимость / ложная
        // ранняя цель)
        let watch_reach: Option<
            std::collections::HashSet<u64>,
        > = watch_val("REACH")
            .map(|v| {
                v.split(',')
                    .filter_map(|k| {
                        k.trim().parse().ok()
                    })
                    .collect()
            });
        let mut fr: PlanFrontier<A> =
            PlanFrontier::new(from);
        let rate = self.death_rate_per_step();
        while let Some(PlanStep {
            node: s,
            hz,
            len,
        }) = fr.pop()
        {
            let is_goal = if let Some(g) = target
            {
                s == g
            } else if tasks_only {
                // [ЗАДАЧА-ДЕРЖАНИЕ] порядок
                // слушания: только адреса служения
                self.world_tasks
                    .iter()
                    .any(|(a, _)| *a == s)
                    && self.task_graves.admissible(
                        &s,
                        self.task_plan_clock,
                    )
            } else {
                (!self
                    .untried(s)
                    .is_empty()
                    && self.debt_collectable(s))
                    || self.underpaid(s)
            };
            if s != from
                && is_goal
                && (!self.glue_on
                    || self.goal_admissible(s))
            {
                let (mut rev, nodes) = fr.unwind(s);
                // [ВХОД ЗАВЕРШАЕТ ПЛАН, шестой род
                // s42/s43+R49] дорога «за дверью»
                // построена из кадров сна, а
                // приземление кадром
                // недетерминировано (130 raw
                // одного суда): акты за прыжком
                // исполнялись с чужого кадра — план
                // доигрывался мимо (ft09:
                // exhausted при burn=0) или в
                // смерть (tu93: смерти-в-пути
                // 0→121 при флип-не-жжёт без
                // обрезки). Межуровневый план
                // обрезается прыжком — прыжок =
                // ПОСЛЕДНИЙ шаг (родня качелей
                // последнего жеста); жизнь наверху
                // планируется пере-планом от
                // живого кадра прибытия (hold жив,
                // сгорание прыжка подавлено
                // флип-каноном — цель доживает до
                // узкой постройки от факта).
                // [ПОВТОР УРОКА = РЕСЕТ-ДОРОГА,
                // девятый род] дидактическая ветка
                // живёт в СВОЕЙ истории (вход в
                // глубину own=0, кадры
                // воспроизводимы только от старта
                // игры — 25 прожитий дидактики
                // тому свидетель): прожить урок
                // своей волей можно лишь
                // непрерывным планом ОТ РЕСЕТА —
                // история проигрывается с первой
                // ноты (родня закона второй
                // жизни). Такой план обрезке не
                // подсуден: обрезка сводит тело с
                // исторической колеи, пере-план от
                // живого кадра колею не находит
                // (29 коротких планов R52 — все
                // мимо). Прыжки страхует
                // флип-канон, кадры совпадают
                // историей — сгорание молчит.
                let historic = uncut
                    || (std::env::var(
                        "G1_NO_HISTORIC",
                    )
                    .is_err()
                        && reset.is_some_and(|r| {
                            rev.first()
                                == Some(&r)
                        }));
                if !historic {
                    for i in 0..rev.len() {
                        if crate::optimality::level_of(nodes[i])
                            != crate::optimality::level_of(
                                nodes[i + 1],
                            )
                        {
                            rev.truncate(i + 1);
                            break;
                        }
                    }
                }
                // [ЖЕСТ-ОБЪЕКТ] эталоны шагов —
                // выдача ребиндит каждый по живому
                // кадру
                // [A/B s48, диагност e9]
                // G1_NO_PLANREFS=1 отключает
                // сборку рефов (всё прочее
                // вагона живёт) — раскладка
                // рефы/остальное за один прогон
                if std::env::var("G1_NO_PLANREFS")
                    .is_err()
                {
                    self.plan_refs = nodes
                        .iter()
                        .take(rev.len())
                        .copied()
                        .collect();
                } else {
                    self.plan_refs.clear();
                }
                if tasks_only {
                    let e = self
                        .task_goal_census
                        .entry(s)
                        .or_insert((0, 0));
                    e.0 += 1;
                    e.1 += rev.len() as u64;
                }
                if let Some(ws) = &watch_reach {
                    eprintln!(
                        "ПОСТРОЙКА-ВАХТА	цель={s} len={} from={from} watch_раскрыт={} watch_цель={}",
                        rev.len(),
                        ws.iter().any(|wk| {
                            fr.reached(*wk)
                        }),
                        ws.contains(&s)
                    );
                }
                self.plan_from_map = false;
                self.plan = rev.into();
                self.plan_goal = Some(s);
                self.plan_version =
                    self.map.version();
                self.last_exam_cost =
                    Some((hz, len));
                *self
                    .goal_census
                    .entry(s)
                    .or_insert(0) += 1;
                return;
            }
            let mut nexts = self.plan_nexts(
                s,
                PlanSight {
                    tabled: true,
                    deadly_cut: true,
                },
            );
            let reset_pair = match (
                reset, self.root,
            ) {
                (Some(r), Some(root)) => {
                    nexts.push((
                        r,
                        root,
                        self.ml_death(s, r),
                    ));
                    Some((r, root))
                }
                _ => None,
            };
            for (e, n, hzd) in nexts {
                let nh =
                    self.hazard_step(hz, hzd, rate);
                // [ЦЕНА РЕСЕТА = ВЫСОТА, s48-род]
                // ресет-ребро за 1 шаг — ложь
                // экономики: жертвуется ВСЯ
                // высота (телепорт в корень).
                // Бесплатный ресет затопил ft09
                // вечными ресет-дорогами (жизнь
                // L2 +229 против +29908, прыжки
                // 33 против 932): Дейкстра
                // предпочитала «через корень
                // ближе». Цена = прожитая высота
                // от корня (since_root) — на
                // старте паломничество дёшево,
                // с высоты жертва чувствуется.
                let reset_toll = if reset_pair
                    == Some((e, n))
                {
                    self.since_root
                } else {
                    0
                };
                let nl = len + 1 + reset_toll;
                fr.relax(
                    PlanEdge {
                        from: s,
                        act: e,
                        into: n,
                    },
                    nh,
                    nl,
                );
            }
        }
        if let Some(ws) = &watch_reach {
            // постройка выдохлась без цели: одёжка
            // каждого watch-узла по носителям
            for wk in ws {
                let wk = *wk;
                let acts: Vec<String> = self
                    .table_acts
                    .get(&wk)
                    .or_else(|| self.seen.get(&wk))
                    .map(|ms| {
                        ms.iter()
                            .map(|m| {
                                let mut ab = Vec::new();
                                crate::worldmap::Wire::w(m, &mut ab);
                                format!(
                                    "акт{ab:?}:post={:?}:ban={}:deadly={}",
                                    self.table.get(&(wk, *m)),
                                    self.banned(wk, *m),
                                    self.deadly_bans
                                        .get(&(wk, *m))
                                        .copied()
                                        .unwrap_or(0)
                                )
                            })
                            .collect()
                    })
                    .unwrap_or_default();
                eprintln!(
                    "ПОСТРОЙКА-ВАХТА	пусто from={from} узел={wk} раскрыт={} одёжка=[{}]",
                    fr.reached(wk),
                    acts.join(" ")
                );
            }
        }
    }

    /// THE HAZARD STEP: an edge's price in the frontier's currency.
    ///
    /// Hazard is a fraction in [0,1]; the frontier counts in
    /// integers, and the quantum `Q` converts one into the other.
    /// The law stood twice, together with its `#[allow]` and its
    /// scar, and the divergence is silent: change the quantum in
    /// one planner and both roads stay roads, but the exam and the
    /// ring start weighing death differently.
    ///
    /// `hzd` and `rate` are ADDED, so swapping them changes
    /// nothing — they need no pose.
    #[allow(
        clippy::cast_possible_truncation,
        clippy::cast_sign_loss,
        reason = "hazard in [0,1], quantized"
    )]
    fn hazard_step(
        &self,
        hz: u64,
        hzd: f64,
        rate: f64,
    ) -> u64 {
        const Q: f64 = (1u64 << 20) as f64;
        if self.bored_risk {
            // [BREAKER-ROAD] boredom pays for risk: steps
            // without the death penalty
            hz
        } else {
            hz + ((hzd + rate) * Q).round() as u64
        }
    }

    /// A NODE'S OFFERING TO THE PLAN: acts, their posts, hazards.
    ///
    /// The body stood twice and had DIVERGED; in what exactly is
    /// said by [`PlanSight`], and said at the call site rather than
    /// in two look-alike bodies.
    fn plan_nexts(
        &self,
        s: u64,
        sight: PlanSight,
    ) -> Vec<(A, u64, f64)> {
        sight
            .tabled
            .then(|| self.table_acts.get(&s))
            .flatten()
            .or_else(|| self.seen.get(&s))
            .map(|ms| {
                ms.iter()
                    .filter(|&&m| !self.banned(s, m))
                    .filter(|&&m| {
                        !sight.deadly_cut
                            || self
                                .deadly_bans
                                .get(&(s, m))
                                .copied()
                                .unwrap_or(0)
                                < crate::law::LAW_OF_REPETITION
                    })
                    .filter_map(|m| {
                        self.table.get(&(s, *m)).map(
                            |&n| {
                                (
                                    *m,
                                    n,
                                    self.ml_death(
                                        s, *m,
                                    ),
                                )
                            },
                        )
                    })
                    .collect()
            })
            .unwrap_or_default()
    }

    /// Т-КЛЮЧ-ФРОНТИР: жест максимального долга карты у
    /// чеканенного ключа (ветвление ≥2 при массе ≥LAW =
    /// измеренная неопределённость; ЕЁ выплата покупает
    /// биты карты — сырые счётчики звали в океан
    /// микро-долгов: 456 смертей, caps 2058, и не сохли).
    fn map_thin_act(&self, coined: u64) -> Option<A> {
        // ВЫПЛАЧИВАЕМОЕ НОГАМИ: тонкое ребро (0 < масса
        // < LAW) — прогулка платит его; ветвящийся долг
        // ≥LAW НЕ выплачивается жестом (ветку решает
        // скрытая координата мира — фронтир гонял к нему
        // вечные 1-шаговые планы-фантомы) — он пища
        // РЫНКА координат, не ног.
        self.map
            .acts_of(coined)
            .into_iter()
            .find(|&a| {
                let mass: u32 = self
                    .map
                    .outcomes(coined, a)
                    .map(|m| m.values().sum())
                    .unwrap_or(0);
                mass > 0
                    && u64::from(mass)
                        < u64::from(
                            crate::law::LAW_OF_REPETITION,
                        )
            })
    }

    /// СУД РУЛЯ: разрешение пары предсказаний прожитым
    /// остатком (died — смерть оборвала план). Меньшая
    /// |ĉ−c_lived| побеждает; ничья не двигает счёт.
    /// КАРТА ДЕФОЛТОМ (финал фазы-2, мандат
    /// совершенства): руль судов 790:19 за карту,
    /// сходимость регрета 2.86 против 18.56 exam.
    /// G1_EXAM_SOLO=1 — архив-двойник (бывший дефолт).
    fn map_plan_on() -> bool {
        std::env::var("G1_EXAM_SOLO").is_err()
    }

    /// Мотор-органы дефолтом (та же развязка);
    /// G1_NO_MOTOR=1 — архив-двойник.
    fn motor_on() -> bool {
        std::env::var("G1_NO_MOTOR").is_err()
    }

    /// Плодотворность ресета: новизна с прошлого
    /// ресета (v2); G1_MOVED_RESET=1 — архив
    /// (движение ключа, вечно истинное в мирах
    /// сборки — шторм su15 4178).
    fn reset_fruitful(&self) -> bool {
        if std::env::var("G1_MOVED_RESET").is_ok() {
            self.moved_since_reset
        } else {
            self.novel_since_reset
        }
    }

    fn steer_judge(&mut self, died: bool) {
        let Some((cm, ce, age0, _)) =
            self.steer_pending.take()
        else {
            return;
        };
        let lam = self.death_rate_per_step();
        let quant = (1u64 << 20) as f64;
        let steps = self.source_time.life_age().saturating_sub(age0);
        #[allow(
            clippy::cast_possible_truncation,
            clippy::cast_sign_loss,
            reason = "bounded currency"
        )]
        let c_lived = if died {
            quant as u64
        } else {
            0
        } + (lam * steps as f64 * quant).round()
            as u64;
        let dm = cm.abs_diff(c_lived);
        let de = ce.abs_diff(c_lived);
        let win = match dm.cmp(&de) {
            std::cmp::Ordering::Less => {
                self.steer_w_map += 1;
                "map"
            }
            std::cmp::Ordering::Greater => {
                self.steer_w_exam += 1;
                "exam"
            }
            std::cmp::Ordering::Equal => "tie",
        };
        self.glass(|| format!(
            "{{\"ev\":\"steer_judge\",\"rod\":\"self\",\"win\":\"{win}\",\"c_lived\":{c_lived},\"c_map\":{cm},\"c_exam\":{ce}}}"
        ));
    }

    /// Т-КЛЮЧ: чеканенный ключ = сырой ^ купленные
    /// координаты (значение часов по модулю периода).
    fn coined_key(&self, raw: u64, tick: u32) -> u64 {
        let Some(ps) = self.coords.get(&raw) else {
            return raw;
        };
        let mut k = raw;
        for (i, &p) in ps.iter().enumerate() {
            let v = u64::from(tick % p) + 1;
            k ^= v
                << (40
                    + 8 * u64::try_from(i)
                        .unwrap_or(0));
        }
        k
    }

    /// Т-КЛЮЧ-РЫНОК НА ЖИВОЙ ЛЕНТЕ (граница скуки/сна,
    /// как glue_market): кандидаты — фазы органных
    /// часов (периоды 2..6; истинный чеканится законом);
    /// prequential-гейн (канон П-2); покупка активирует
    /// координату ключа — карта чеканит с этого момента.
    fn coin_coords_market(&mut self) {
        // рынок слушает карту: сидка при новых
        // рождениях ветвлений ЛИБО по каденции удвоения
        let births = self.map.branch_births();
        let by_birth =
            births > self.coin_births_at;
        let by_double = self.coin_tacts
            >= self.coin_sat_at.max(32)
                * u64::from(
                    crate::law::LAW_OF_REPETITION,
                );
        if self.live_tape.len() < 64
            || (!by_birth && !by_double)
        {
            return;
        }
        self.coin_births_at = births;
        self.coin_sat_at = self.coin_tacts;
        // [Ф13-1] ВЛАДЕНИЕ ЛЕДЖЕРОМ (суд двух часов
        // GREEN 4/4: оконный пере-суд убивал редкое
        // настоящее между эпизодами; леджер копит и
        // замораживается без улик): свежий гейн ленты
        // по СВОИМ строкам ключа ±, смерть при ≤
        // −цены рождения, проданное продано.
        let owned: Vec<(u64, Vec<u32>)> = self
            .coords
            .iter()
            .map(|(k, v)| (*k, v.clone()))
            .collect();
        for (k, ps) in owned {
            let rows: Vec<(
                u64,
                A,
                crate::worldmap::Outcome<u64, u8>,
                u32,
            )> = self
                .live_tape
                .iter()
                .filter(|&&(rk, ..)| rk == k)
                .copied()
                .collect();
            if rows.is_empty() {
                // Г1-2 половина-2: живое окно ключа
                // ПУСТО — суд воскрешения по архивным
                // маргиналам карты (ровно ветвь финала
                // GAME-1: улики истекли, статистики
                // честно записаны в живое время).
                // G1_NO_RESURRECT=1 — двойник-щит.
                if std::env::var("G1_NO_RESURRECT")
                    .is_err()
                {
                    for act in self.map.acts_of(k) {
                        let Some((_o, ci, gain)) =
                            self.map.resurrect(
                                k, act,
                            )
                        else {
                            continue;
                        };
                        let Some(pp) =
                            crate::worldmap::marg_clock_period(ci)
                        else {
                            continue;
                        };
                        let pu =
                            u32::try_from(pp)
                                .unwrap_or(0);
                        if pu < 2
                            || self
                                .coin_sold
                                .contains(&(k, pu))
                        {
                            continue;
                        }
                        let e = self
                            .coords
                            .entry(k)
                            .or_default();
                        if !e.contains(&pu) {
                            e.push(pu);
                            self.coin_ledger.insert(
                                (k, pu),
                                gain.min(50.0),
                            );
                            self.glass(|| format!(
                                "{{\"ev\":\"coin_resurrect\",\"rod\":\"self\",\"k\":{k},\"period\":{pu},\"gain\":{gain:.1}}}"
                            ));
                        }
                    }
                }
                continue; // заморожен без улик
            }
            for p in ps {
                let tape: Vec<(
                    u64,
                    A,
                    crate::worldmap::Outcome<
                        u64,
                        u8,
                    >,
                )> = rows
                    .iter()
                    .map(|&(rk, a, o, _)| {
                        (rk, a, o)
                    })
                    .collect();
                let cand =
                    vec![crate::worldmap::Candidate {
                        name: format!("phase{p}"),
                        values: rows
                            .iter()
                            .map(|&(_, _, _, t)| {
                                t % p
                            })
                            .collect(),
                    }];
                let fresh: f64 =
                    crate::worldmap::coin_market(
                        &tape, &cand,
                    )
                    .into_iter()
                    .filter(|pch| pch.key == k)
                    .map(|pch| pch.net_bits)
                    .sum::<f64>()
                    .max(-8.0);
                let led = self
                    .coin_ledger
                    .entry((k, p))
                    .or_insert(0.0);
                *led = (*led + fresh - 0.0)
                    .clamp(-50.0, 50.0);
                if *led <= 0.0 {
                    if let Some(v) =
                        self.coords.get_mut(&k)
                    {
                        v.retain(|&x| x != p);
                        if v.is_empty() {
                            self.coords.remove(&k);
                        }
                    }
                    self.coin_sold.insert((k, p));
                    self.glass(|| format!(
                        "{{\"ev\":\"coin_sell\",\"rod\":\"self\",\"k\":{k},\"period\":{p}}}"
                    ));
                }
            }
        }
        let tape: Vec<(
            u64,
            A,
            crate::worldmap::Outcome<u64, u8>,
        )> = self
            .live_tape
            .iter()
            .map(|&(k, a, o, _)| (k, a, o))
            .collect();
        let cands: Vec<crate::worldmap::Candidate> =
            (2u32..=6)
                .map(|p| crate::worldmap::Candidate {
                    name: format!("phase{p}"),
                    values: self
                        .live_tape
                        .iter()
                        .map(|&(_, _, _, t)| t % p)
                        .collect(),
                })
                .collect();
        for pch in
            crate::worldmap::coin_market(&tape, &cands)
        {
            let period = 2
                + u32::try_from(pch.idx)
                    .unwrap_or(0);
            if self
                .coin_sold
                .contains(&(pch.key, period))
            {
                continue; // продано — продано
            }
            let e = self
                .coords
                .entry(pch.key)
                .or_default();
            if !e.contains(&period) {
                e.push(period);
                self.coin_ledger.insert(
                    (pch.key, period),
                    pch.net_bits,
                );
                self.glass(|| format!(
                    "{{\"ev\":\"coin\",\"rod\":\"self\",\"k\":{},\"period\":{period},\"net_bits\":{:.1}}}",
                    pch.key, pch.net_bits
                ));
                // [Ф13-2] РЫНОК БУДИТ МОГИЛЫ: если у
                // купленного расщепления есть ЧИСТАЯ
                // варианта (масса ≥ LAW, смертельных 0)
                // — вина ключа объяснена скрытой
                // координатой, могила/баны снимаются
                // ПРЕДСТАВЛЕНИЕМ (не часами — лавина
                // глобальных часов прожита
                // контрпримером)
                let mut clean_variant = false;
                let mut split: HashMap<
                    u32,
                    (u32, u32),
                > = HashMap::new();
                for &(rk, _, o, t) in
                    &self.live_tape
                {
                    if rk == pch.key {
                        let e2 = split
                            .entry(t % period)
                            .or_insert((0, 0));
                        e2.0 += 1;
                        if matches!(
                            o,
                            crate::worldmap::Outcome::End(1u8)
                        ) {
                            e2.1 += 1;
                        }
                    }
                }
                for (_, (m, d)) in split {
                    if u64::from(m)
                        >= u64::from(
                            crate::law::LAW_OF_REPETITION,
                        )
                        && d == 0
                    {
                        clean_variant = true;
                    }
                }
                if clean_variant {
                    let Ok(g) = self.try_eyed(pch.key) else { continue; };
                    if self.goal_graves.forgive(
                        self.source_time.life_age(),
                        g,
                        crate::holdings::Cause(
                            "coin_refutes",
                        ),
                    ) {
                        self.glass(|| format!(
                            "{{\"ev\":\"coin_refutes_grave\",\"rod\":\"self\",\"goal\":{g}}}"
                        ));
                    }
                    if let Some(b) = &mut self.bans
                    {
                        // [ПРЕРЕГ-7] прощение не
                        // воскрешает СМЕРТНОЕ ребро
                        // массой >= LAW (письмо мира
                        // прочитано дважды); судит
                        // СМЕРТНЫЙ леджер — отказные
                        // баны чистятся как прежде
                        // (ярусы живут отказами)
                        let acts: Vec<A> = b
                            .keys()
                            .filter(|(sk, a)| {
                                *sk == g
                                    && self
                                        .deadly_bans
                                        .get(&(
                                            *sk, *a,
                                        ))
                                        .copied()
                                        .unwrap_or(0)
                                        < crate::law::LAW_OF_REPETITION
                            })
                            .map(|(_, a)| *a)
                            .collect();
                        for a in acts {
                            b.remove(&(g, a));
                        }
                    }
                }
            }
        }
    }

    /// А1-кольцо: плановый жест выдаётся с ОЖИДАНИЕМ
    /// (табличный next) — опровержимость плана фактом.
    fn take_planned<
        H: Habitat<Action = A>,
    >(
        &mut self,
        state: u64,
        world: &H,
    ) -> Option<A> {
        // [ПРЕРЕГ-7в] СТРАЖА ВЫДАЧИ, смягчённая
        // ЗАКОНОМ ПОВТОРЕНИЯ: план не выдаёт акт
        // под баном массы >= LAW (вахта R: убийца
        // с массой 566 выдавался — карта банов не
        // знает, чеканка прячет смерти по фазам);
        // лёгкий бан (< LAW) опровержим проживанием
        // — ретест Cor.18.9 жив (свод v5: стража-
        // абсолют убила опровержимость: 11 стендов).
        if std::env::var("G1_NO_DELIVERY_GUARD")
            .is_err()
            && let Some(&a0) = self.plan.front()
            && !self.plan_notes
            && self
                .deadly_bans
                .get(&(state, a0))
                .copied()
                .unwrap_or(0)
                >= crate::law::LAW_OF_REPETITION
            // [СТРАЖА СПРАШИВАЕТ МИР, tn36-лок 4:
            // канон-зона набрала смертную массу
            // за 143k тактов — ЛЮБОЙ план сквозь
            // ресет рвался стражей (task_plan_
            // death[3]), доезд=0 навечно; но
            // дорога мира УЖЕ оплатила риск
            // Дейкстрой (смерти, длина), а рельса
            // — ноты учителя] свежее свидетельство
            // мира (жизнь погасила смерти ребра)
            // опровергает бан.
            && !world.act_absolved(state, a0)
        {
            self.watch_plan_kill(12119);
            self.plan.clear();
            self.plan_expect = None;
            self.plan_goal = None;
            if self.plan_is_task {
                self.task_plan_death[3] += 1;
                self.tear_kinds[0] += 1;
                self.plan_is_task = false;
                // [ЦЕЛЬ-ПАМЯТЬ] стража-рвач — не
                // попытка; кап LAW² общий
                self.note_hold_torn();
            }
            return None;
        }
        let a = self.plan.pop_front()?;
        if self.plan.is_empty() {
            if self.plan_notes {
                self.notes_spent += 1;
            }
            self.plan_notes = false;
        }
        if self.plan.is_empty()
            && self.plan_is_task
        {
            if watch_glass("PILGRIM")
            {
                eprintln!(
                    "ПЛАН-ДОИГРАН	цель={:?} кадр={} len0={}",
                    self.plan_goal,
                    self.cur_raw_key,
                    self.pilgrim_len0
                );
            }
            // [ДОИГРЫШ БЕЗ ДОЕЗДА ОПРОВЕРГАЕТ
            // ДОРОГУ, tn36-вахта-3: сгорания
            // сняты законами ресета и отпущения
            // — планы доигрывались в никуда БЕЗ
            // метки, и рельса-первой опять не
            // получала хода] зов-план, доигранный
            // не на теле цели, — то же
            // опровержение, что сгорание: факт
            // опроверг память дороги.
            if self.pilgrim_goal.is_some()
                && self.pilgrim_goal
                    == self.plan_goal
                && !self.body_at(
                    world,
                    self.plan_goal
                        .unwrap_or_default(),
                )
            {
                self.exp_refuted =
                    self.plan_goal;
                if let Some(g) = self.plan_goal
                {
                    *self
                        .pilgrim_fails
                        .entry(g)
                        .or_insert(0) += 1;
                }
            }
            self.task_plan_death[2] += 1;
            self.plan_is_task = false;
            // [V1-долг закрыт] последний акт плана
            // теперь досчитан служению (флаг гас до
            // учёта исхода — r_serve был слегка
            // завышен занижением знаменателя)
            self.mk_serve_acts += 1;
            // [ЦЕЛЬ-ПАМЯТЬ, граница (i)] доигранный
            // -недоехавший — настоящая попытка:
            // LAW таких — цель отпущена рынку
            if self.hold_goal.is_some()
                && self.hold_goal
                    == self.plan_goal
            {
                self.hold_fail += 1;
                if self.hold_fail
                    >= crate::law::LAW_OF_REPETITION
                {
                    self.hold_goal = None;
                    self.hold_glass[2] += 1;
                }
            }
            // [ПРЕРЕГ-18] попытка захоронения =
            // ДОЕЗД-И-НЕОПЛАТА: план доигран до
            // конца (тело дошло по нему) и цель
            // не выкуплена own-актом — только
            // такой факт свидетельствует «на
            // месте»; смерти по дороге исключены
            // судом двоих
            if let Some(g) = self.plan_goal {
                self.note_task_attempt(g);
            }
        }
        self.plan_expect =
            self.table.get(&(state, a)).copied();
        self.plan_edge = Some((
            self.cur_raw_key,
            self.since_root,
            a,
        ));
        Some(a)
    }

    /// А1-кольцо жизни: план к root по лексикографике
    /// (Σ ML-смертность, длина) — хвост жизни при полном
    /// знании ведётся кратчайшим безопасным циклом к
    /// истоку (таблица знает рёбра через гол — Дейкстра
    /// сама выберет короткую тропу с чистой фазой; ключи
    /// несут фазу, banned-рёбра отрезаны).
    fn plan_ring_to_root(&mut self, from: u64) {
        let Some(root) = self.root else {
            return;
        };
        if root == from {
            return;
        }
        if Self::map_plan_on() {
            if Self::motor_on() {
                // ФАЗА-2: кольцо органом (то же тело:
                // план карты к root_raw от чеканенного)
                let raw = self.coined_key(
                    self.cur_raw_key,
                    self.since_root,
                );
                let menu: Vec<A> = Vec::new();
                let banned_f = |_a: A| false;
                let ctx = crate::motor::MotorCtx {
                    key: raw,
                    raw: self.cur_raw_key,
                    root_raw: Some(
                        self.root_raw
                            .unwrap_or(root),
                    ),
                    menu: &menu,
                    map: &self.map,
                    takeover: false,
                    just_arrived: false,
                    banned: &banned_f,
                };
                let mut ring =
                    crate::motor::RingOrgan;
                if let Some(p) =
                    ring.propose_plan(&ctx)
                {
                    self.plan = p.micro.into();
                    self.plan_goal = p.goal;
                    return;
                }
            } else {
                let lex =
                    crate::worldmap::LexMortalityFirst;
                let lethal = |t: &u8| *t == 1;
                let raw = self.coined_key(
                    self.cur_raw_key,
                    self.since_root,
                );
                let root_raw =
                    self.root_raw.unwrap_or(root);
                if raw != root_raw
                    && let Some((acts, _, _)) =
                        self.map.plan(
                            raw,
                            |k| *k == root_raw,
                            &lex,
                            lethal,
                        )
                {
                    let micro = self
                        .map
                        .unroll_plan(raw, &acts);
                    if !micro.is_empty() {
                        self.plan = micro.into();
                        self.plan_goal = None;
                        return;
                    }
                }
            }
            // юная карта молчит — старое кольцо
        }
        let mut fr: PlanFrontier<A> =
            PlanFrontier::new(from);
        let rate = self.death_rate_per_step();
        while let Some(PlanStep {
            node: s,
            hz,
            len,
        }) = fr.pop()
        {
            if s == root {
                let (rev, _) = fr.unwind(s);
                self.plan = rev.into();
                // кольцо — не фронтир-цель: могильная
                // механика целей его не судит
                self.plan_goal = None;
                return;
            }
            let nexts = self.plan_nexts(
                s,
                PlanSight {
                    tabled: false,
                    deadly_cut: false,
                },
            );
            for (e, n, hzd) in nexts {
                let nh =
                    self.hazard_step(hz, hzd, rate);
                let nl = len + 1;
                fr.relax(
                    PlanEdge {
                        from: s,
                        act: e,
                        into: n,
                    },
                    nh,
                    nl,
                );
            }
        }
    }

    fn plan_to_frontier_bfs(&mut self, from: u64, reset: Option<A>) {
        self.plan_to_frontier_relation(from, reset, false);
    }

    /// Search the retained relation in the dispatch language. A path through
    /// multiple observed Next outcomes is exploratory: execute only through
    /// its first branching action, then observe before selecting a suffix.
    /// Terminal/refused outcomes cannot authorize an ordinary road. Neither
    /// map-key renaming nor a probability threshold is imported into this view.
    fn plan_to_frontier_relation(&mut self, from: u64, reset: Option<A>, branching: bool) {
        use observed_relation::{BranchPolicy, Verdict};
        let report = observed_relation::search(
            from,
            |state| {
                state != from
                    && !self.untried(state).is_empty()
                    && (!self.glue_on || !self.goal_graves.is_buried(&state))
            },
            |state| self.observed_relation_row(state, reset),
            usize::MAX,
            usize::MAX,
            if branching {
                BranchPolicy::ObserveBeforeContinuation
            } else {
                BranchPolicy::Deterministic
            },
        );
        if let Verdict::Witness {
            target,
            prefix,
            branch_boundary,
        } = report.verdict
        {
            let length = prefix.len();
            self.plan = prefix.into();
            self.plan_goal = Some(target);
            self.plan_from_map = false;
            self.plan_is_task = false;
            self.plan_refs.clear();
            self.plan_expect = None;
            self.glass(|| format!(
                "{{\"ev\":\"frontier_prefix\",\"carrier\":\"named_observations\",\"goal\":{target},\"length\":{length},\"branch_boundary\":{branch_boundary}}}"));
        }
    }

    /// The step's action choice: wheel seizure ("switch
    /// context IF there is a door" — doorless life goes on)
    /// -> untried -> plan -> BFS to the frontier -> the
    /// life's tail (patrol revision or first-action spam).
    fn choose_action<H: Habitat<Action = A>>(
        &mut self,
        state: u64,
        takeover: bool,
        world: &H,
    ) -> Option<Decision<A>> {
        let a = self.choose_action_inner(
            state, takeover, world,
        );
        // М-СТЕКЛО v1.0: протокол заседания — одна
        // jsonl-строка на выбор (last_branch честен
        // во всех 10 ветках после штормовой саги;
        // passed восстановим из канонического
        // порядка веток). G1_SEANCE=1 — включение.
        if std::env::var("G1_SEANCE").is_ok() {
            let lb = self.last_branch;
            self.glass(|| format!(
                "{{\"ev\":\"seance\",\"k\":{state},\"branch\":{lb},\"chose\":{}}}",
                u8::from(a.is_some())
            ));
        }
        a
    }

    #[allow(
        clippy::too_many_lines,
        reason = "выбор — одно заседание совета; \
                  распад на органы идёт фазой-2"
    )]
    /// [ПОСЛЕДНЯЯ МИЛЯ, суд двух рук + s31-чинка]
    /// двери фазового кворума (мир отдаёт их только
    /// при долге уровня 0) выигрывают выбор РАНЬШЕ
    /// рынка межуровневых задач — s29-гвоздь:
    /// последний кворум L1 жил вечно в тени чужих
    /// дверей; s31-печать: миля, посаженная ВНУТРИ
    /// bored-ветки, не звалась ни разу — рынок
    /// съедал такт выше по каскаду. Кап: LAW сухих
    /// построек подряд (кворум не дожит, цели не
    /// исчезли) возвращает обычный порядок до новой
    /// эпохи (note_boredom сбрасывает). true =
    /// план мили положен.
    fn try_phase_mile<H: Habitat<Action = A>>(
        &mut self,
        state: u64,
        world: &H,
    ) -> bool {
        let mile = world.phase_targets();
        if mile.is_empty() {
            // ноль фазовых целей: кворумы дожиты
            // или мир держит милю до долга 0 —
            // кап отпускается
            self.mile_dry = 0;
            return false;
        }
        if self.mile_dry
            >= crate::law::LAW_OF_REPETITION
        {
            return false;
        }
        let watch = watch_glass("MILE");
        for (g, a) in mile {
            if watch {
                let mut ab = Vec::new();
                crate::worldmap::Wire::w(
                    &a, &mut ab,
                );
                eprintln!(
                    "МИЛЯ-ВАХТА	цель={g} акт-байт={ab:?} на-двери={} сухих={}",
                    self.cur_raw_key == g,
                    self.mile_dry
                );
            }
            if self.body_at(world, g) {
                // тело на двери: стук АКТОМ РЕБРА
                // (один закон зачёта — body_at)
                self.watch_plan_kill(12513);
                self.plan.clear();
                self.plan_refs.clear();
                self.plan.push_back(a);
                self.plan_goal = Some(g);
                self.plan_expect = None;
                self.mile_dry += 1;
                return true;
            }
            self.plan_exam_pred_to(
                state,
                world.reset_action(),
                false,
                Some(g),
            );
            if !self.plan.is_empty() {
                // хвост плана = акт ребра
                self.plan.push_back(a);
                self.mile_dry += 1;
                return true;
            }
        }
        false
    }

    /// [ЖЕСТ-ОБЪЕКТ, выдача] взять шаг плана; если
    /// это ПОСЛЕДНИЙ шаг обрезанного плана (прыжок
    /// с эталоном), мир пере-вычисляет байт по
    /// объекту живого кадра (rebind_act; None —
    /// жать как есть: двигательные миры/незнакомый
    /// словарь не тронуты).
    fn take_planned_rebound<
        H: Habitat<Action = A>,
    >(
        &mut self,
        state: u64,
        world: &H,
    ) -> Option<Decision<A>> {
        let synced = self.plan_refs.len()
            == self.plan.len();
        let n =
            self.take_planned(state, world)?;
        self.plan_step_lv = Some(crate::optimality::level_of(
            self.cur_raw_key,
        ));
        self.plan_step_reset = world
            .reset_action()
            .is_some_and(|r| r == n);
        if self.plan_step_pre
            .is_some_and(|p| p != state)
        {
            self.plan_phase_retry = 0;
        }
        self.plan_step_pre = Some(state);
        self.plan_step_court =
            world.court_now();
        // Retry owns the original gesture; rebind produces the delivered action below.
        self.last_step_act = Some(n);
        if self.plan_is_task
            && watch_glass("ROAD")
        {
            eprintln!(
                "ШАГ	court={:?} остаток={} ref={:?} retry={}",
                world.court_now(),
                self.plan.len(),
                self.plan_refs.front(),
                self.plan_phase_retry
            );
        }
        if synced {
            if let Some(rr) =
                self.plan_refs.pop_front()
            {
                // [РОД УЗЛА — СУД МИРА] узел
                // текущего шага мировой дороги:
                // сверка исполнения миром
                self.plan_step_ref = if self
                    .world_road
                {
                    Some(rr)
                } else {
                    None
                };
                // [ЗРЯЧИЙ ХВОСТ, s62-слепота +
                // s63-грань (б)] экспект шага =
                // СЛЕДУЮЩИЙ УЗЕЛ ПЛАНА, и теперь
                // ВСЯКОЙ дороге. Прежде зрячесть
                // давали только задачным, потому
                // что она несла ДВА права разом —
                // свидетельство и сожжение, — и
                // на кадрово-недетерминированном
                // ft09 всеобщая зрячесть жгла
                // всякий план почти каждым шагом
                // (35117 пере-планов, жизнь +49
                // тактов: шторм «строй-разойдись-
                // перестрой»). Права разведены
                // ниже (СВИДЕТЕЛЬСТВО ≠ СОЖЖЕНИЕ):
                // жжёт по-прежнему только задачная
                // дисциплина доставки, а видеть и
                // класть факт в леджер вправе и
                // фронтирное любопытство — иначе
                // рельса-сессия ходит слепой и
                // призрак не опровергается ничем
                // (tn36-L4: refused_posts=0 при
                // живой рельсе длины 11).
                self.plan_expect =
                    self.plan_refs.front().copied();
                // [ЦЕНА РЕБИНДА, s46-костёр]
                // ребинд зовётся ТОЛЬКО при
                // несовпадении эталона с живым
                // кадром: на исторической колее
                // (ресет-дорога) кадры совпадают
                // — цена ноль; словарный скан
                // мира платится лишь там, где
                // жест реально переносится.
                // Рассинхрон длин = жать сырой
                // байт (душение хуже промаха:
                // промах учит, немота слепа).
                if rr != self.cur_raw_key {
                    return Some(Decision::PlanStep(
                        world
                            .rebind_act(rr, n)
                            .unwrap_or(n),
                    ));
                }
            }
        } else {
            self.plan_refs.clear();
        }
        Some(Decision::PlanStep(n))
    }

    /// [ТЕЛО НА ДВЕРИ — один закон зачёта]
    /// прибытие/стук/миля судят одним родом:
    /// точный адрес ИЛИ веер дверей задачи
    /// ({wa}∪капли) ИЛИ суд кадра (same_court —
    /// свежий кадр того же суда ещё не в веере).
    /// Три потребителя держали комбинацию тремя
    /// копиями (аудит 28.08: предельное обобщение
    /// по слову владельца).
    fn body_at<H: Habitat<Action = A>>(
        &self,
        world: &H,
        goal: u64,
    ) -> bool {
        if goal == self.cur_raw_key
            || world.same_court(
                goal,
                self.cur_raw_key,
            )
        {
            return true;
        }
        let doors = world.task_doors_of(goal);
        doors.contains(&self.cur_raw_key)
            || doors.iter().any(|d| {
                world.same_court(
                    *d,
                    self.cur_raw_key,
                )
            })
    }

    /// THE FALLBACK RESET, ELSE THE AVOIDANCE BRANCH (branches 8, 9).
    ///
    /// [FIXED-POINT LAW] (the DeadPose storm, 116/120: the fallback
    /// pressed reset OUT OF root forever, uncounted — the trace lied
    /// with its last branch): the reset of «life under full
    /// knowledge» is lawful only when NOT at the reset's fixed
    /// point; out of root it is avoidance.
    ///
    /// The body stood TWICE, in both arms of the motor fork, and the
    /// second one was even signed «at the twin» — that is, the
    /// divergence was KNOWN and still left on a promise. It is
    /// silent BY NUMBER: the glass reads `last_branch`, and had one
    /// arm shifted 8/9, the trace would name one cause by two
    /// branches — the digits would stay lawful and the branch census
    /// would drift apart without a sound.
    ///
    /// `Some` — branch 8 was taken and the caller must return it
    /// outward. `None` — branch 9's counters are ALREADY settled and
    /// the caller is left with its own avoidance.
    fn fallback_reset<H: Habitat<Action = A>>(
        &mut self,
        world: &H,
    ) -> Option<A> {
        if let Some(r) = world.reset_action()
            && self.reset_fruitful()
            && !self.any_world_tasks
        {
            self.choice_counts[8] += 1;
            self.last_branch = 8;
            return Some(r);
        }
        self.choice_counts[9] += 1;
        self.last_branch = 9;
        None
    }

    fn choose_action_inner<H: Habitat<Action = A>>(
        &mut self,
        state: u64,
        takeover: bool,
        world: &H,
    ) -> Option<Decision<A>> {
        // [ПАЛОМНИК, доезд] тело на дальней цели:
        // паломничество плодотворно — кап отпущен
        if self.pilgrim_goal.is_some()
            && !self.pilgrim_started
            && self.plan.len() < self.pilgrim_len0
        {
            // первый шаг плана исполнен фактом
            // выдачи — зрелость единой меткой для
            // жёстких и мягких миров
            self.pilgrim_started = true;
            self.pilgrim_ripe = true;
            self.pilgrim_glass[1] += 1;
        }
        if let Some(g) = self.pilgrim_goal
            && self.body_at(world, g)
            && !world
                .exact_at(g, self.cur_raw_key)
            && let Some(road) = world.plan_to(g)
            && !road.is_empty()
        {
            // [ТОЧНЫЙ ПОСЛЕДНИЙ ШАГ, p161w] тень
            // прибытия рядом с судом — дожать шаг
            // В сам суд (арх-долг платится только
            // точным проездом); бюджет ticks жжёт
            // суд невозможности как всегда.
            let (acts, refs): (
                std::collections::VecDeque<A>,
                std::collections::VecDeque<u64>,
            ) = road.into_iter().unzip();
            self.plan = acts;
            self.plan_refs = refs;
            self.plan_expect = None;
            self.world_road = true;
        } else if self
            .pilgrim_goal
            .is_some_and(|g| self.body_at(world, g))
        {
            // [ЗАЧЁТ ТЕНИ ПРИБЫТИЮ, s61-род +
            // ЧЕТВЁРТАЯ ИПОСТАСЬ СУДОМ, t9w-род]
            // прибытие судится ВЕЕРОМ кадров суда
            // цели И судом кадра (свежий кадр того
            // же суда — капля ещё не вписана в
            // веер, а прибытие уже случилось:
            // ft09-t9w — 25 планов exhausted на
            // цели при слепом веере): тот же
            // зачёт, что кворуму, оплате и зову —
            // теперь доезду ПОЛНЫМ родом
            self.pilgrim_glass[3] += 1;
            if watch_glass("PILGRIM")
            {
                let g0 =
                    self.pilgrim_goal.unwrap_or(0);
                eprintln!(
                    "ПАЛОМНИК-ПРИБЫТИЕ	цель={g0} кадр={} задача-в-снимке={} branch={}",
                    self.cur_raw_key,
                    self.world_tasks
                        .iter()
                        .any(|(a, _)| *a == g0),
                    self.last_branch
                );
            }
            if self.last_branch == 3 {
                // пришёл собственным планом
                self.pilgrim_glass[4] += 1;
            }
            self.pilgrim_goal = None;
            self.world_road = false;
            self.world_road_ticks = 0;
            self.world_try = None;
            self.world_road_key = None;
            self.pilgrim_ripe = false;
            self.pilgrim_dry = 0;
            self.pilgrim_burn_cnt = 0;
        }
        // [ФЛИП — ПРИБЫТИЕ В МИР ЗАДАЧ, ft09-
        // разрез: 162 own-флипа умирали в юном
        // уровне за 1-3 такта до зова] смена
        // уровня ВВЕРХ при живых задачах нового
        // уровня — немедленная дорога мира к
        // ближайшей двери (не ждать скуки/
        // старшинства: рождение в мир долгов —
        // само зов).
        let here_lv =
            crate::optimality::level_of(self.cur_raw_key);
        let rose = self
            .last_here
            .is_some_and(|p| here_lv > p);
        self.last_here = Some(here_lv);
        if rose
            && self.plan.is_empty()
            && self.pilgrim_goal.is_none()
        {
            let door = self
                .world_tasks
                .iter()
                .find(|(a, _)| {
                    crate::optimality::level_of(*a) == here_lv
                })
                .map(|(a, _)| *a);
            if let Some(g) = door
                && let Some(road) =
                    world.plan_to(g)
                && !road.is_empty()
            {
                let (acts, refs): (
                    std::collections::VecDeque<A>,
                    std::collections::VecDeque<u64>,
                ) = road.into_iter().unzip();
                self.plan = acts;
                self.plan_refs = refs;
                self.plan_expect = None;
                self.plan_is_task = true;
                self.pilgrim_goal = Some(g);
                self.pilgrim_len0 =
                    self.plan.len();
                self.pilgrim_started = false;
                self.world_road = true;
                self.world_road_ticks = 0;
                self.pilgrim_glass[0] += 1;
            }
        }
        // [ЖИВОЙ КОНТУР ДОРОГИ МИРА] пере-
        // прокладка от ФАКТИЧЕСКОГО суда каждый
        // такт: исходы актов дрожат (кадровый
        // недетерминизм ft09), слепое исполнение
        // exhausted-илось мимо цели (t10-t12);
        // немота свежего места — хвост доедет
        // старой дорогой до прожитого (fallback).
        if self.world_road
            && !self.plan.is_empty()
            && let Some(g) = self.pilgrim_goal
            && self.world_road_key
                != Some(self.cur_raw_key)
        {
            // [ПАРА «ЖДАТЬ+ЖАТЬ» НЕДЕЛИМА, f9:
            // тело вечно ждало — пере-прокладка
            // на непере-двинувшемся кадре снова
            // строила дорогу с ожиданием] пере-
            // прокладка только на СМЕНЕ кадра;
            // стояние (idle-такт) исполняет план
            // дальше.
            self.world_road_key =
                Some(self.cur_raw_key);
            self.world_road_ticks += 1;
            if self.world_road_ticks <= 40
                && watch_glass("PILGRIM")
            {
                eprintln!(
                    "ДОРОГА-ШАГ	тик={} кадр={} план={} цель={g}",
                    self.world_road_ticks,
                    self.cur_raw_key,
                    self.plan.len()
                );
            }
            let budget = crate::law::LAW_OF_REPETITION
                as usize
                * self.pilgrim_len0.max(1);
            if self.world_road_ticks > budget {
                // [СУД НЕВОЗМОЖНОСТИ] дорога
                // прожжена бюджетом — цель
                // фактически недостижима отсюда:
                // зов сгорает жертвенной механике
                self.watch_plan_kill(12809);
                self.plan.clear();
                self.plan_refs.clear();
                self.plan_expect = None;
                self.world_road = false;
                self.world_road_ticks = 0;
                self.pilgrim_burn_cnt =
                    self.pilgrim_burn_cnt
                        .saturating_add(1);
                self.pilgrim_goal = None;
            } else if let Some(road) =
                world.plan_to(g)
            {
                // [ПЕРЕЖДАТЬ ПОЕЗД, u42-u44:
                // двойка L4 стоит и при
                // мультиграфе] фронт-ребро
                // двусмысленно (два фазовых
                // слота) и прошлый заход этим
                // актом с этого суда ушёл не тем
                // слотом — вставить ОЖИДАНИЕ
                // узла (недвигающий акт мира):
                // сдвиг фазы на такт; бюджет
                // ожиданий уже жжёт суд
                // невозможности.
                let cur = self.cur_raw_key;
                let (mut plan, mut refs): (
                    std::collections::VecDeque<A>,
                    std::collections::VecDeque<u64>,
                ) = road.into_iter().unzip();
                if let Some(&front) = plan.front()
                    && world.edge_is_phased(
                        cur, front,
                    )
                {
                    if self
                        .world_try
                        .is_some_and(|(c, _)| {
                            c == cur
                        })
                        && let Some(idle) =
                            world.idle_of(cur)
                    {
                        plan.push_front(idle);
                        // ждущий шаг: узел==pre
                        refs.push_front(cur);
                    }
                    self.world_try = Some((
                        cur,
                        self.world_road_ticks
                            as u64,
                    ));
                } else {
                    self.world_try = None;
                }
                self.plan = plan;
                self.plan_refs = refs;
                self.plan_expect = None;
            }
        }
        // [МИЛЯ-АКТ, наивысший после burn-суда]
        // мир велит кворум С МЕСТА — один такт
        // важнее шага любого плана (гейт «фронтир
        // пуст» стреляет считанные разы за жизнь;
        // m0r0: планы-ноты душили выдачу при 346
        // посещениях суда)
        if let Some(a) = world.mile_act()
            && !self.banned(state, a)
        {
            self.choice_counts[6] += 1;
            self.last_branch = 6;
            return Some(Decision::WorldRequest(a));
        }
        // [ЦЕЛЕВОЙ КОНТУР — исполнение] пустой
        // план + мир знает дорогу к старшей
        // задаче: сесть нотами с ушами (сгорание
        // — миро-гейтом; исследование живо там,
        // где карта дороги не знает)
        if self.plan.is_empty()
            && let Some(rail) = world.goal_route()
            && !rail.is_empty()
        {
            let (acts, refs): (
                std::collections::VecDeque<A>,
                std::collections::VecDeque<u64>,
            ) = rail.into_iter().unzip();
            self.plan = acts;
            self.plan_refs = refs;
            self.plan_expect = None;
            self.plan_is_task = true;
            self.plan_notes = true;
            self.world_road = true;
            self.world_road_ticks = 0;
            // сев + первый шаг ОДНИМ тактом:
            // план, отданный каскаду ниже, гиб до
            // исполнения (зонд: сев повторялся
            // каждый такт — 24 сева нулевого
            // продвижения)
            if let Some(n) = self
                .take_planned_rebound(state, world)
            {
                self.choice_counts[7] += 1;
                self.last_branch = 7;
                return Some(n);
            }
        }
        // [ПАЛОМНИК, приоритет хвоста] вторая
        // жизнь плана исполняется РАНЬШЕ рефлекса:
        // намерение, пережившее смерть, не висит
        // (казнь зомби R54 — механикой)
        if self.pilgrim_hold > 0 {
            if let Some(n) = self
                .take_planned_rebound(state, world)
            {
                self.pilgrim_hold -= 1;
                if self.plan.is_empty() {
                    self.pilgrim_hold = 0;
                    self.pilgrim_glass[2] += 1;
                }
                self.choice_counts[3] += 1;
                self.last_branch = 3;
                return Some(n);
            }
            // план умер стражей — приоритет снят
            self.pilgrim_hold = 0;
        }
        // ФАЗА-2 СОВЕТА ЖЕСТОВ (М-4-двойник G1_MOTOR=1):
        // ветки захвата/недоплаты/избегания живут
        // каскадом MotorOrgan — семантика бит-в-бит со
        // старым трактом (суд пары обязателен)
        let motor_on =
            Self::motor_on();
        if motor_on {
            let coined = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            let menu: Vec<A> = self
                .seen
                .get(&state)
                .cloned()
                .unwrap_or_default();
            let ja = self.just_arrived
                == Some(state);
            let banned_f =
                |a: A| self.banned(state, a);
            let ctx = crate::motor::MotorCtx {
                key: coined,
                raw: self.cur_raw_key,
                root_raw: self.root_raw,
                menu: &menu,
                map: &self.map,
                takeover,
                just_arrived: ja,
                banned: &banned_f,
            };
            let mut tko =
                crate::motor::TakeoverOrgan {
                    reset: world.reset_action(),
                };
            if let Some(p) = tko.propose(&ctx)
                && !(self.plan_is_task
                    && !self.plan.is_empty())
            {
                // [РЕФЛЕКС УСТУПАЕТ НАМЕРЕНИЮ]
                // takeover не рвёт живой план-к-
                // задаче (R21: 763 захвата = главный
                // убийца доставки после казни
                // прыжка); рефлекс отработает на
                // не-задачных тактах
                self.watch_plan_kill(12929);
                self.plan.clear();
                self.plan_expect = None;
                self.choice_counts[7] += 1;
                self.last_branch = 7;
                return Some(Decision::Takeover(p.act));
            }
            if takeover {
                self.watch_plan_kill(12936);
                self.plan.clear();
                self.plan_expect = None;
            }
            let _ = ja;
        } else if takeover
            && !(self.plan_is_task
                && !self.plan.is_empty())
        {
            self.watch_plan_kill(12944);
            self.plan.clear();
            self.plan_expect = None;
            // захват НЕ ресетит из неподвижной точки
            // ресета (ls20: reset у root = identity →
            // вечный takeover-цикл 357/400) — из root
            // захват проваливается в обычный выбор
            if self.root_raw != Some(self.cur_raw_key)
                && let Some(r) = world.reset_action()
            {
                self.choice_counts[7] += 1;
                self.last_branch = 7;
                return Some(Decision::Takeover(r));
            }
        }
        // А1-кольцо: план опровержим ФАКТОМ — мир пришёл
        // не туда (ресет посреди пути, фазовый сдвиг) —
        // план сгорает, слепое исполнение запрещено
        // (вечный план-к-недостижимому держал 18-цикл)
        // СУД СГОРАНИЯ: расхождение с ожиданием жжёт
        // план ТОЛЬКО если карта не знает этой ветки —
        // приход в известную ветку ребра = уплаченная
        // неопределённость (len/prob), не ложь
        // [prereg-5 ОТКАЧЕН ЧИСЛОМ: M дал ноль-
        // эффект на tu93 (его работу сделал
        // телепорт-рвач пререг-6), v5 дал вред
        // (шумные миры жгли exam-планы на каждом
        // ветре — ярусы без отказов планов)]
        // [ФАЗОВЫЙ ШАГ ДЕРЖИТ ТЕЛО, tn36-ценз:
        // канон — мир кнопок, переходные рёбра
        // фазовые (клик: {переход, ничего});
        // план жал фазовый шаг ОДИН раз слепо —
        // несработка = самопетля, known_branch
        // глушил сгорание, план уходил вперёд
        // смещённым: 4500 доигрышей мимо цели]
        // тело осталось в суде выдачи шага =
        // фазовое несрабатывание: тот же шаг
        // возвращается в план (ждать+жать в
        // ИСПОЛНЕНИИ, не только в прокладке);
        // кап LAW² повторов — дальше цепь судит
        // как прежде.
        // [РОД УЗЛА — СУД МИРА] мировой шаг
        // сверяется МИРОМ: узел-назначение шага
        // достигнут (сам или склейкой) — шаг
        // сработал; нет — фазовое дожатие тем же
        // актом (кап LAW²), потом общий суд.
        if self.world_road
            && self.plan_is_task
            && let Some(rr) = self.plan_step_ref
        {
            if watch_glass("ROAD")
            {
                eprintln!(
                    "ШАГ-МИР	ref={rr} at_court={} retry={}",
                    world.at_court(rr),
                    self.plan_phase_retry
                );
            }
            if world.at_court(rr) {
                if self.plan_notes
                    && self.plan_phase_retry > 0
                {
                    // дожал: фазовое свидетельство
                    self.notes_retry_hits += 1;
                }
                self.plan_phase_retry = 0;
                self.plan_step_ref = None;
                self.plan_expect = None;
            } else if self.plan_notes
                && world.strict_code()
            {
                // [НОТЫ ХРУПКИ, tn36: реплей
                // доигрывался до конца (остаток
                // →1), а WIN не случался —
                // дожатие повторами ЛОМАЕТ
                // строгий код (лишнее нажатие =
                // ошибка); шанс чистого прохода
                // ~0.34 на пасс — пассы возьмут]
                // первый несовпавший шаг гасит
                // реплей целиком: тихо, без
                // повторов и капов; свежий пасс
                // пробует заново другой фазой
                self.plan.clear();
                self.plan_refs.clear();
                self.plan_notes = false;
                self.plan_is_task = false;
                self.plan_step_ref = None;
                self.plan_expect = None;
                self.plan_phase_retry = 0;
                self.notes_spent += 1;
            } else if !self.plan.is_empty()
                && let Some(a0) =
                    self.last_step_act
            {
                if self.plan_phase_retry
                    < crate::law::LAW_OF_REPETITION
                        * crate::law::LAW_OF_REPETITION
                {
                    self.plan_phase_retry += 1;
                    self.plan_expect = None;
                    self.plan_edge = None;
                    self.plan.push_front(a0);
                    self.plan_refs
                        .push_front(rr);
                } else {
                    self.plan_phase_retry = 0;
                    self.plan_step_ref = None;
                }
            }
        }
        // [«НА МЕСТЕ» СУДИТ МИР] глазной ключ
        // несёт акт — самопетля меняет state и
        // слепит сравнение; судья — суд мира без
        // акта: мир не сдвинулся = фазовое
        // несрабатывание (канальные планы тоже)
        if !self.plan.is_empty()
            && self
                .plan_expect
                .is_some_and(|e| e != state)
            && self.plan_step_court.is_some()
            && self.plan_step_court
                == world.court_now()
            && let Some(a0) = self.last_step_act
        {
            // [СВИДЕТЕЛЬСТВО ≠ СОЖЖЕНИЕ] знание о
            // несбывшемся не обязано менять
            // поведение — но обязано лечь в
            // леджер. Незадачная дорога (рельса-
            // сессия, фронтирное любопытство)
            // видит расхождение, кладёт факт и
            // идёт дальше НЕТРОНУТОЙ: ни ретрая,
            // ни возврата шага, ни костра — шторм
            // s63 воспроизводиться нечему. Кворум
            // держит сам леджер (LAW² вхождений),
            // потому честно писать каждый раз.
            if !self.plan_is_task {
                if let Some(c) = self.plan_step_court
                {
                    world.note_refused(c, a0);
                }
                self.plan_expect = None;
            } else if self.plan_phase_retry
                < crate::law::LAW_OF_REPETITION
                    * crate::law::LAW_OF_REPETITION
            {
                self.plan_phase_retry += 1;
                // расхождение поглощено: ожидание
                // и ребро шага умирают, шаг
                // возвращается в план — поток
                // выдаст его обычным путём со
                // свежим ожиданием
                self.plan_expect = None;
                self.plan_edge = None;
                self.plan.push_front(a0);
            } else {
                // [КАП = СВИДЕТЕЛЬСТВО + СГОРАНИЕ]
                // ребро молчит LAW² подряд: мир
                // запоминает отказ (маршруты
                // объезжают), план жгётся честно —
                // прежний «общий суд» щадил тенью
                // и цикл был вечен (tn36-L4:
                // призрак-11 против 40 честных
                // сессий по 12)
                if let Some(c) =
                    self.plan_step_court
                {
                    world.note_refused(c, a0);
                }
                self.watch_plan_kill(13485);
                self.plan.clear();
                self.plan_refs.clear();
                self.plan_expect = None;
                self.plan_phase_retry = 0;
            }
        }
        let known_branch = self
            .plan_edge
            .take()
            .is_some_and(|(rk, tk, a)| {
                let ck = self.coined_key(rk, tk);
                self.map
                    .outcomes(ck, a)
                    .is_some_and(|m| {
                        m.len() >= 2
                            && m.keys().any(|o| {
                                matches!(o,
                                    crate::worldmap::Outcome::Next(n)
                                    if self.try_eyed(*n).is_ok_and(|key| key == state)
                                )
                            })
                    })
            });
        // [ОТКАЗ ПОСТ-ВЕТКИ НА ДВИЖНОМ МИРЕ]
        // два законных глушителя сгорания —
        // известный веер (known_branch) и
        // «движение мира — оплата шага»
        // (task-план, суд ушёл) — оба ГЛУШИЛИ И
        // СВИДЕТЕЛЬСТВО: несбывшийся пост не
        // писался никуда, и кворум веток не
        // копился вовсе (tn36-r1: refused_posts
        // = 0 при живом призраке-11). План жить
        // вправе — но факт «мир обещал exp, дал
        // иное при движении» обязан лечь в
        // леджер ветки; ожидание шага снимается
        // (исполнено фактом — не тем).
        if let Some(exp) = self.plan_expect
            && exp != state
            && !world.same_court(exp, state)
            && self.plan_step_lv
                == Some(crate::optimality::level_of(
                    self.cur_raw_key,
                ))
            && !self.plan_step_reset
            && let (Some(c), Some(a0)) = (
                self.plan_step_court,
                self.last_step_act,
            )
            && world.reset_action() != Some(a0)
            && (known_branch
                || self.plan_step_court
                    != world.court_now())
        {
            // [СВИДЕТЕЛЬСТВО НЕ РАЗБИРАЕТ РОДА
            // ПЛАНА] несбывшийся пост есть
            // несбывшийся пост: прежний гейт
            // писал отказ только для ЗАДАЧНЫХ
            // планов, и рельса-сессия (последний
            // источник намерения рода sess>lex)
            // молчала — tn36-L4 держал призрака
            // при ЖИВОЙ рельсе длины 11 и нулевом
            // фронтире: планы шли, не сбывались и
            // не свидетельствовали.
            world.note_refused_post(c, a0, exp);
            self.plan_expect = None;
        }
        // [ИНВАРИАНТ ИСТИНЫ ПЛАНА, аудит 28.08]
        // носитель один — plan_expect; законных
        // писателей ровно ТРИ: table-род внутри
        // take_planned, узел-род в
        // take_planned_rebound (только task-
        // планам, грань (б)), None при planned_
        // reset (приземление корня). Четвёртому
        // писателю родиться негде: новая чинка
        // истины плана обязана войти в один из
        // трёх родов или казнить этот коммент.
        if std::env::var("G1_NO_PLAN_BURN")
            .is_err()
            && !known_branch
            && let Some(exp) =
                self.plan_expect.take()
            && exp != state
            // [ТЕНЬ-ШАГА, пятая ипостась зачёта
            // тени: кворум→оплата→зов→прибытие→
            // ШАГ] расхождение поста — не
            // расхождение, когда фактический кадр
            // ТОГО ЖЕ СУДА, что узел: глаз склеил
            // кадры — все пять судов склеивают
            // вердикты (s65/R76: обе воронки
            // стояли в этом метре — веерный
            // недетерминизм кадров у назначения)
            && !world.same_court(exp, state)
            // [ФЛИП НЕ ЖЖЁТ ПЛАН, родня закона
            // запланированного прыжка] приземление
            // фазовой двери недетерминировано
            // кадром (R47: 130 приземлений — 130
            // raw одного суда, один вахтенный
            // визит): межуровневый шаг сгоранию
            // не подсуден — дорога продолжается
            // от живого кадра
            && self.plan_step_lv
                == Some(crate::optimality::level_of(
                    self.cur_raw_key,
                ))
            // [РЕСЕТ НЕ ЖЖЁТ ПЛАН, tn36-разрез:
            // exp из прошлой жизни, факт этой —
            // стабильно иной: кадр ресет-
            // приземления несёт сессионную соль,
            // рёбра ресета непереносимы между
            // жизнями; каждый план — канальный и
            // мировой — горел на ПЕРВОМ шаге
            // (burn=5, доезд=0)] ресет —
            // межпопыточная дверь, родня флипа
            // (R47): приземление недетерминировано
            // кадром — сгоранию не подсудно,
            // дорога продолжается от живого кадра
            // (ожидание шага умирает — план живёт)
            && {
                if self.plan_step_reset {
                    // [СОЛЬ-СВИДЕТЕЛЬСТВО] ресет
                    // разошёлся с памятью — кадры
                    // несут сессионную соль
                    self.salt_seen = true;
                }
                !self.plan_step_reset
            }
            // [ДВИЖЕНИЕ МИРА — ОПЛАТА ШАГА,
            // tn36-финал: 53 ДВИГАЛ мир (312/312
            // послересетных переходов фактом
            // ленты), но канальный экспект из
            // древних глазных ключей жёг план на
            // третьем такте — ноль доездов при
            // живой машине] задачный шаг,
            // сдвинувший суд мира, не подсуден
            // глазному расхождению: глазная
            // память стара, факт мира свеж;
            // стоящий мир судится гейтом
            // дожатия, кап — общим судом
            && !(self.plan_is_task
                && self.plan_step_court.is_some()
                && self.plan_step_court
                    != world.court_now())
        {
            if watch_glass("BURN")
            {
                eprintln!(
                    "СГОРАНИЕ	exp={exp} state={state} план-остаток={} цель={:?} паломник={}",
                    self.plan.len(),
                    self.plan_goal,
                    self.pilgrim_goal.is_some()
                );
            }
            // [КОНТЕКСТ ЗОВА, не равенство
            // plan_goal: его перебивают смежные
            // механизмы — часть сгораний зова
            // шла без счёта провалов] задачный
            // план при живом зове = зов-контекст
            if self.pilgrim_goal.is_some()
                && self.plan_is_task
            {
                self.pilgrim_burn_cnt += 1;
                if let Some(g) =
                    self.pilgrim_goal
                {
                    *self
                        .pilgrim_fails
                        .entry(g)
                        .or_insert(0) += 1;
                }
                // [СГОРАНИЕ ОПРОВЕРГАЕТ ДОРОГУ,
                // tn36: канал и мир держат
                // мёртвые соль-планы и вечно
                // перехватывают зов у рельсы]
                // сгоревшая цель зова метится —
                // следующий зов идёт РЕЛЬСОЙ
                // ПЕРВОЙ (тот же род, что смерть
                // экспедиции: факт опроверг
                // память)
                self.exp_refuted =
                    self.pilgrim_goal;
            }
            // [ФАЗОВЫЙ ОТКАЗ И НА СГОРАНИИ]
            // многократное сгорание одного шага
            // мировой дороги — то же свидетельство
            // отказа (tn36: залип шёл общим судом,
            // 393 пересева одного 9-плана — кап
            // ретрая не видел ни одного)
            if self.world_road
                && !self.plan_step_reset
                && let (Some(c), Some(a0)) = (
                    self.plan_step_court,
                    self.last_step_act,
                )
                && world
                    .reset_action()
                    != Some(a0)
            {
                world.note_refused(c, a0);
                // [ОТКАЗ ПОСТ-ВЕТКИ] то же
                // сгорание свидетельствует и о
                // ВЕТКЕ: обещанный пост exp не
                // сбылся при движном мире —
                // фантомная композиция теряет
                // оптимизм кворумом (tn36-L4:
                // призрак-11 жил в опт-Дейкстре
                // при 40 честных 12-сессиях)
                world.note_refused_post(
                    c, a0, exp,
                );
            }
            self.watch_plan_kill(13069);
            self.plan.clear();
            if self.plan_is_task {
                self.task_plan_death[0] += 1;
                self.plan_is_task = false;
            }
            // сгорание плана фактом: хоронит цель ТОЛЬКО
            // не-научившее сгорание (версия карты та же
            // — вечный цикл без знания); научившее уже
            // оплачено картой (version вырос — дорога
            // перестроится сама)
            self.steer_judge(false);
            let taught = std::env::var(
                "G1_BURN_ALWAYS",
            )
            .is_err()
                && self.map.version()
                    != self.plan_version;
            *self
                .burn_glass
                .entry(self.plan.len())
                .or_insert(0) += 1;
            let g_burn = self.plan_goal.take();
            self.pending_goal_fire = None;
            self.transfer_pending = None;
            if let Some((sg, skey)) =
                self.swap_pending.take()
                && g_burn == Some(sg)
                && self
                    .skills
                    .die(
                        self.source_time.life_age(),
                        skey,
                        crate::holdings::Cause(
                            "body_burn",
                        ),
                    )
                    .is_some()
            {
                self.skill_counts.remove(&skey);
                self.skill_bodies.remove(&skey);
                self.glass(|| format!(
                    "{{\"ev\":\"skill_die\",\"rod\":\"self\",\"goal\":{sg},\"cause\":\"body_burn\"}}"
                ));
            }
            self.glass(|| format!(
                "{{\"ev\":\"plan_burn\",\"rod\":\"self\",\"expect\":{exp},\"got\":{state},\"taught\":{taught},\"goal\":{}}}",
                g_burn.unwrap_or(0)
            ));
            if let Some(g) = g_burn
                && !taught
            {
                let vg = self.visits_of(g);
                let b = self.goal_graves.bury(
                    self.source_time.life_age(),
                    g,
                    vg,
                    crate::holdings::Cause(
                        "plan_burn",
                    ),
                );
                self.glass(|| format!(
                    "{{\"ev\":\"burial\",\"rod\":\"self\",\"goal\":{g},\"cause\":\"plan_burn\",\"burials\":{b}}}"
                ));
            }
        }
        let mut u = self.untried(state);
        // ЮРИСДИКЦИЯ ЛЮБОПЫТСТВА (архив под флагом):
        // фильтр ресета из untried лечил шторм g50t
        // (2639→53), но СТОИЛ УРОВНЕЙ ls20/tu93 (1→0):
        // ресет-свип был живым телепорт-обходом
        // (Т-КОРЗИНА: reset — обычное ребро свипа).
        // ИСТИННАЯ ДЫРА ШТОРМА — класс-канал не
        // списывает жест-0 (2639 проживаний невидимы
        // glue_class_counts) — лечить ЗАПИСЬ, не
        // любопытство. G1_NO_CURIOUS_RESET=1 —
        // экспериментальный фильтр (не дефолт).
        if std::env::var("G1_NO_CURIOUS_RESET")
            .is_ok()
            && let Some(r) = world.reset_action()
        {
            u.retain(|&a| a != r);
        }
        // [ЕДИНЫЙ СУД ДОРОГ, G1_ROAD-двойник] выбор
        // МЕСТА прежде жеста (анатомия bp35: ветка
        // любопытства монополизировала 2956/3000 —
        // кликовые меню неисчерпаемы локально, план не
        // созывался ни разу). Суд молчит (None) —
        // текущее место победило и любопытство сидит
        // как сегодня: юрисдикция дарована судом, не
        // позицией в каскаде. Без флага — путь прежний
        // бит-в-бит.
        if std::env::var("G1_ROAD").is_ok()
            && self.road_rest
        {
            // щель: суд молчит один такт — органы
            // ритма живут каноном
            self.road_rest = false;
        } else if std::env::var("G1_ROAD").is_ok() {
            let reset_a = world.reset_action();
            let road = {
                let reset_f = |s: u64| {
                    let r = reset_a?;
                    if self.banned(s, r) {
                        return None;
                    }
                    self.root.map(|rt| {
                        (
                            r,
                            rt,
                            self.ml_death(s, r),
                        )
                    })
                };
                // смертность ребра: прожитая парная
                // ML где прожита; НЕПРОЖИТОЕ ребро
                // платит прожитую ГЛОБАЛЬНУЮ
                // смертность тела (база-риск — тоже
                // прожитое свидетельство, не прайор;
                // вердикт девяти: суд без налога
                // неведения ходил сквозь непрожитые
                // дверные рёбра «безопасно по
                // незнанию» — смерти ×2.1 на Blink;
                // прожито-безопасные коридоры
                // остаются дешёвыми — лечение bp35
                // сохранено)
                let base_rate =
                    self.death_rate_per_step();
                let edge_ml = |s: u64, m: A| {
                    let c = self
                        .glue_counts
                        .get(&(s, m))
                        .copied()
                        .unwrap_or([0; 3]);
                    let n = c[0] + c[1] + c[2];
                    if n > 0 {
                        return f64::from(c[2])
                            / f64::from(n);
                    }
                    // [вердикт девяти, корень]
                    // glueless суд был СЛЕП к
                    // смертности (glue-леджер пуст →
                    // все дороги «безопасны», дверь
                    // Blink убивала ×2.1): прожитая
                    // смертность живёт и в
                    // ЛЕТАЛЬ-ЛЕДЖЕРЕ — бан-казни
                    // считаются KT-долей
                    if let Some(b) = self
                        .bans
                        .as_ref()
                        .and_then(|b| {
                            b.get(&(s, m))
                        })
                    {
                        return (f64::from(*b)
                            + 0.5)
                            / (f64::from(*b)
                                + 1.0);
                    }
                    base_rate
                };
                let nexts = |s: u64| -> Vec<(
                    A,
                    u64,
                    f64,
                )> {
                    self.seen
                        .get(&s)
                        .map(|ms| {
                            ms.iter()
                                .filter(|&&m| {
                                    !self
                                        .banned(
                                            s, m,
                                        )
                                })
                                .filter_map(|m| {
                                    self.table
                                        .get(&(
                                            s, *m,
                                        ))
                                        .map(|&n| {
                                            (
                                        *m,
                                        n,
                                        edge_ml(
                                            s, *m,
                                        ),
                                    )
                                        })
                                })
                                .collect()
                        })
                        .unwrap_or_default()
                };
                // [ЦЕЛЕВОЙ СУД ДОРОГ] валюта доставки:
                // Σ ценностей допустимых прогресс-пар
                // места (могилы судят; валюты НЕ
                // смешиваются — доставка ярусом выше
                // новизны в лексикографике суда)
                // юрисдикция целевой руки = юрисдикция
                // канонического целевого плана (glue):
                // вердикт девяти — glueless целевая
                // рука включалась там, где канон
                // никогда не планировал к целям, и её
                // законная бесконечная эксплуатация
                // (проходы растут → пара вечно
                // подтверждена) душила ритм жизни
                // (смерти ×2.1, взгляд 1 look);
                // ar25-1 не теряет ничего — взятие
                // было новизной
                let goals_live = self
                    .progress_goals_on
                    && self.glue_on
                    && std::env::var("G1_GOALS_OFF")
                        .is_err();
                let goal_sum = |s: u64| -> f64 {
                    if !goals_live
                        || !self.goal_admissible(s)
                    {
                        return 0.0;
                    }
                    self.progress_goals
                        .iter()
                        .filter(|((gs, ga), h)| {
                            *gs == s
                                && h.value > 0.0
                                && !self
                                    .banned(s, *ga)
                        })
                        .map(|(_, h)| h.value)
                        .sum()
                };
                // фронтир суда = КАНОНИЧЕСКИЙ закон
                // фронтира экзамена (вердикт девяти:
                // «любое непробованное» было ШИРЕ
                // закона — суд гонялся за фронтирами,
                // которые Т-КЛЮЧ-экономика законно
                // игнорирует (долг не взыскуем),
                // фронтир не иссякал и взгляд/скука
                // голодали: 1 look, окно 0.00)
                let is_frontier = |s: u64| {
                    let lawful = ((!self
                        .untried(s)
                        .is_empty()
                        && self
                            .debt_collectable(s))
                        || self.underpaid(s))
                        && (!self.glue_on
                            || self
                                .goal_admissible(
                                    s,
                                ));
                    lawful || goal_sum(s) > 0.0
                };
                // [РЫНОК ГОЛОДОВ] единый доход в
                // валюте открытий: доставка целей
                // переводится ПРОЖИТЫМ курсом обмена
                // (goal_rate: сколько новых мест
                // покупала единица прироста прогресса
                // — закрытые строки плюс открытая:
                // после первого взятия курс уже жив;
                // до первого взятия целей нет — рынок
                // согласован сам, немого новичка нет).
                // Лексикографика доставка-над-новизной
                // казнена прожитым дефектом (v9/v14:
                // направленная жизнь не платила
                // фронтирный долг — чинили расписанием
                // фаз, подгон).
                let rate = {
                    let (mut dv, mut pl) =
                        (0.0f64, 0u64);
                    for &(d, p, _) in
                        &self.goal_rate
                    {
                        dv += d;
                        pl += p;
                    }
                    if let Some((d, s0, _)) =
                        self.goal_rate_open
                    {
                        dv += d;
                        pl += (self.seen.len()
                            - s0.min(
                                self.seen.len(),
                            ))
                            as u64;
                    }
                    if dv > 0.0 {
                        pl as f64 / dv
                    } else {
                        0.0
                    }
                };
                let yield_of = |s: u64| -> f64 {
                        let sg = Self::sig_hash(
                            self.seen
                                .get(&s)
                                .cloned()
                                .unwrap_or_default(
                                ),
                        );
                        // [ЗАКОН ПЛОТНОГО ПОКРЫТИЯ]
                        // (этологический род ARS —
                        // area-restricted search:
                        // найденное обследуется до
                        // насыщения, потом дальше).
                        // Прожитый механизм блуждания
                        // (cd82: долг 211 за 6000
                        // актов): untried пустеет
                        // после ПЕРВОГО акта, а
                        // фронтир требует LAW — доход
                        // места гас раньше выплаты, и
                        // тело уходило, плодя
                        // недоплату. Теперь доход =
                        // Σ остаточный сырой долг акта
                        // × классовая доля открытий:
                        // место доходно до ПОЛНОЙ
                        // выплаты (untried — частный
                        // случай с остатком 1).
                        let law = f64::from(
                            crate::law::LAW_OF_REPETITION,
                        );
                        let novelty = self
                            .seen
                            .get(&s)
                            .map(|ms| {
                                ms.iter()
                                    .map(|&a| {
                                        if self
                                            .banned(
                                                s, a,
                                            )
                                            || self
                                            .teleport_known(
                                                a,
                                            )
                                        {
                                            return 0.0;
                                        }
                                        let c = self
                                            .glue_counts
                                            .get(&(
                                                s, a,
                                            ))
                                            .copied()
                                            .unwrap_or(
                                                [0; 3],
                                            );
                                        let lived_raw =
                                            c[0] + c[1]
                                                + c[2];
                                        let resid =
                                            (law - f64::from(
                                                lived_raw,
                                            ))
                                            .max(0.0)
                                                / law;
                                        if resid
                                            == 0.0
                                        {
                                            return 0.0;
                                        }
                                        let (nv, lv) =
                                            self.sig_novel
                                                .get(&(
                                                    sg, a,
                                                ))
                                                .copied()
                                                .unwrap_or(
                                                    (0, 0),
                                                );
                                        resid
                                            * (f64::from(
                                                nv,
                                            ) + 0.5)
                                            / (f64::from(
                                                lv,
                                            ) + 1.0)
                                    })
                                    .sum::<f64>()
                            })
                            .unwrap_or(0.0);
                        // [ЗАДАЧА-ДЕРЖАНИЕ] доход
                        // служения — ТА ЖЕ валюта
                        // недожитых актов: Σ
                        // дефицитов задач адреса /
                        // LAW (resid задачи «доживи
                        // меня»; торг с новизной
                        // без новой лексикографики)
                        let task_due = self
                            .world_tasks
                            .iter()
                            .filter(|(a, _)| {
                                *a == s
                            })
                            .map(|(_, d)| {
                                f64::from(*d)
                            })
                            .sum::<f64>()
                            / law;
                        goal_sum(s) * rate
                            + novelty
                            + task_due
                    };
                // лучший акт цели места (детерминизм:
                // наибольшая ценность, затем меньший
                // жест — никогда порядок хэш-карты)
                let goal_act_of =
                    |s: u64| -> Option<A> {
                        if !goals_live
                            || !self
                                .goal_admissible(s)
                        {
                            return None;
                        }
                        let mut best: Option<(
                            f64,
                            A,
                        )> = None;
                        for ((gs, ga), h) in
                            self.progress_goals
                                .iter()
                        {
                            if *gs != s
                                || h.value <= 0.0
                                || self.banned(
                                    s, *ga,
                                )
                            {
                                continue;
                            }
                            let better =
                                match best {
                                    None => true,
                                    Some((
                                        bv,
                                        ba,
                                    )) => {
                                        h.value
                                            > bv
                                            || (h.value == bv
                                                && *ga < ba)
                                    }
                                };
                            if better {
                                best = Some((
                                    h.value, *ga,
                                ));
                            }
                        }
                        best.map(|(_, a)| a)
                    };
                let court =
                    crate::motor::RoadCourt {
                        nexts: &nexts,
                        is_frontier: &is_frontier,
                        yield_of: &yield_of,
                        reset: &reset_f,
                    };
                let road =
                    court.propose_road(state);
                let dest_act = road
                    .as_ref()
                    .and_then(|p| p.goal)
                    .and_then(&goal_act_of);
                let local_act =
                    if road.is_none() {
                        goal_act_of(state)
                    } else {
                        None
                    };
                (road, dest_act, local_act)
            };
            let (road, dest_act, local_act) = road;
            if let Some(mut p) = road {
                // [ЦЕЛЕВОЙ СУД] дорога к целевому
                // месту завершается КУПЛЕННЫМ актом
                // цели (канон-зеркало: «дорога к
                // источнику + повторение акта»);
                // сенсор-суд пары взводится — цель
                // живёт под опровержением
                if let (Some(g), Some(ga)) =
                    (p.goal, dest_act)
                {
                    p.micro.push(ga);
                    self.pending_goal_fire =
                        Some((g, ga));
                    *self
                        .goal_census
                        .entry(g)
                        .or_insert(0) += 1;
                }
                if std::env::var("G1_SEANCE")
                    .is_ok()
                {
                    self.glass(|| format!(
                        "{{\"ev\":\"road\",\"k\":{state},\"goal\":{},\"len\":{},\"delivers\":{}}}",
                        p.goal.unwrap_or(0),
                        p.micro.len(),
                        dest_act.is_some()
                    ));
                }
                self.plan = p.micro.into();
                self.plan_goal = p.goal;
                self.plan_version =
                    self.map.version();
                if let Some(next) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[10] += 1;
                    self.last_branch = 10;
                    if self.plan.is_empty() {
                        self.road_rest = true;
                    }
                    return Some(next);
                }
            } else if let Some(ga) = local_act {
                // [ЦЕЛЕВОЙ СУД] «в источнике — акт
                // сразу» (канон-зеркало): местная
                // победа валютой доставки играет
                // купленный акт немедленно
                self.pending_goal_fire =
                    Some((state, ga));
                *self
                    .goal_census
                    .entry(state)
                    .or_insert(0) += 1;
                self.plan = vec![ga].into();
                self.plan_goal = Some(state);
                self.plan_version =
                    self.map.version();
                if let Some(next) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[10] += 1;
                    self.last_branch = 10;
                    if self.plan.is_empty() {
                        self.road_rest = true;
                    }
                    return Some(next);
                }
            } else if self.last_branch == 10 {
                // суд пере-решил в пользу местного
                // любопытства — дорога, положенная
                // судом прошлым тактом, сгорает (иначе
                // ветка-3 пойдёт чужим планом с чужого
                // места)
                self.watch_plan_kill(13612);
                self.plan.clear();
                self.plan_goal = None;
                self.plan_expect = None;
            }
        }
        // [ВХОД РЫНКА, cd82-игла] рынок судит на
        // границе планов НЕЗАВИСИМО от untried
        // текущего ключа: он жил внутри u-блока и
        // на исчерпанных ключах не входил вовсе
        // (34596 актов планов, ноль выборов серва
        // при доле жребия ≈¼).
        if self.plan.is_empty()
            && !self.world_tasks.is_empty()
            && let Some(g) = self.hold_goal
            && self.body_at(world, g)
        {
            // [СТУК В ДВЕРЬ, ft09-замок 85=85]
            // тело НА цели: узкая постройка была
            // нема (план к себе запрещён s!=from),
            // 89 доездов/цикл без единого жеста —
            // мой же V1-долг «последний акт» стал
            // последним замком. План = ОДИН ЖЕСТ:
            // минимально прожитый небанованный акт
            // ключа («постучать»); оплата — обычным
            // pay_lived судом.
            let knock = self
                .seen
                .get(&state)
                .and_then(|ms| {
                    ms.iter()
                        .copied()
                        .filter(|a| {
                            !self.banned(state, *a)
                        })
                        .min_by_key(|a| {
                            // [V1-долг закрыт]
                            // настоящий аргмин
                            // прожитости (было
                            // 0/1 — первый
                            // попавшийся)
                            self.lived_pairs
                                .get(&(state, *a))
                                .copied()
                                .unwrap_or(0)
                        })
                });
            if let Some(a) = knock {
                // [ВАХТА СТУКА] грубый лог work-
                // пространства (r3-тупик: три судных
                // канала, ноль оплат при own-стуках)
                if watch_glass("KNOCK") {
                    eprintln!(
                        "СТУК-ВАХТА\tg={g} raw={} state={state}",
                        self.cur_raw_key
                    );
                }
                self.knocks += 1;
                self.watch_plan_kill(13671);
                self.plan.clear();
                self.plan_refs.clear();
                self.plan.push_back(a);
                self.plan_goal = Some(g);
                self.plan_expect = None;
                self.plan_is_task = true;
                if let Some(n) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[3] += 1;
                    self.last_branch = 3;
                    return Some(n);
                }
            }
        } else if self.plan.is_empty()
            && !self.world_tasks.is_empty()
            && let Some(g) = self.hold_goal
        {
            // [ЦЕЛЬ-ПАМЯТЬ] намерение живёт —
            // re-plan к held вне рынка; немота
            // постройки отдаёт такт вниз, hold
            // стоит до своих границ
            self.plan_exam_pred_to(
                state,
                world.reset_action(),
                true,
                Some(g),
            );
            if self.last_exam_cost.is_some() {
                self.task_glass[2] += 1;
                self.plan_is_task = true;
                if let Some(n) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[3] +=
                        1;
                    self.last_branch = 3;
                    return Some(n);
                }
                if self.plan.is_empty() {
                    self.plan_is_task = false;
                }
            } else if let Some(road) =
                world.plan_to(g)
            {
                // [ДОРОГА МИРА] канал нем — память
                // мира знает дорогу (прожитые
                // тройки; суд L* её уже видел):
                // own в конце дороги родит
                // exam-цепь, которой не хватало
                // вечному кругу последнего метра.
                let (acts, refs): (
                    std::collections::VecDeque<A>,
                    std::collections::VecDeque<u64>,
                ) = road.into_iter().unzip();
                self.plan = acts;
                self.plan_refs = refs;
                self.plan_expect = None;
                self.plan_is_task = true;
                self.world_road = true;
                self.world_road_ticks = 0;
                self.task_glass[2] += 1;
                if let Some(n) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[3] +=
                        1;
                    self.last_branch = 3;
                    return Some(n);
                }
                if self.plan.is_empty() {
                    self.plan_is_task = false;
                }
            } else {
                self.task_glass[3] += 1;
                // [ревью-блокер (I)] немая
                // узкая постройка — та же
                // граница (i): вечная немая
                // цель блокировала бы рынок
                // навсегда + Дейкстра-свип
                // каждую границу планов;
                // отпускаем НАМЕРЕНИЕ (задача
                // жива, рынок переизберёт при
                // дороге) — пререг-18 цел.
                // [ВОСЬМОЙ РОД, R51: немота
                // свежего корня] при ЖИВОМ
                // любопытстве места (untried
                // непуст) немота НЕ платится:
                // такт вниз честен — пробы
                // родят рёбра, следующая узкая
                // поедет; fail только на
                // мёртвом месте (истинный
                // тупик). Лестница пере-планов
                // перестаёт терять цель в одном
                // шаге от глубины (LAW=2 немот
                // убивал её быстрее, чем
                // любопытство рожало рёбра).
                if self.untried(state).is_empty()
                {
                    self.hold_fail += 1;
                    if self.hold_fail
                        >= crate::law::LAW_OF_REPETITION
                    {
                        self.hold_goal = None;
                        self.hold_glass[2] += 1;
                    }
                }
            }
        } else if self.plan.is_empty()
            && !self.world_tasks.is_empty()
        {
            // [ПОСЛЕДНЯЯ МИЛЯ] сертификатная
            // близость — валюта приоритета: миля
            // выигрывает выбор до торгов рынка
            if self.try_phase_mile(state, world)
                && let Some(n) =
                    self.take_planned_rebound(state, world)
            {
                self.choice_counts[3] += 1;
                self.last_branch = 3;
                return Some(n);
            }
            let pays = self.mk_pays;
            let course = if pays > 0 {
                (self.mk_new_life / pays)
                    .max(1)
            } else {
                1
            };
            // [V2] доход юрисдикции = её
            // гашения×курс + её новые тройки
            let inc_serve = self
                .mk_pays_serve
                .saturating_mul(course);
            let inc_cur = self
                .mk_pays_cur
                .saturating_mul(course)
                + self.mk_cur_new;
            #[allow(
                clippy::cast_precision_loss,
                reason = "market rates"
            )]
            let r_serve = (inc_serve as f64
                + 0.5)
                / (self.mk_serve_acts as f64
                    + 1.0);
            #[allow(
                clippy::cast_precision_loss,
                reason = "market rates"
            )]
            let r_cur = (inc_cur as f64 + 0.5)
                / (self.mk_cur_acts as f64
                    + 1.0);
            let law =
                u64::from(crate::law::LAW_OF_REPETITION);
            let serve_first = if self
                .mk_serve_acts
                < law
            {
                // [R17-круг] ПРОБА ПЛАТИТ
                // ВЫБОРОМ: рвач убивал план до
                // первого акта, serve_acts не
                // рос, LAW-право было вечным
                // (1691 выбор в морг тем же
                // битом, что R16) — род
                // «воображение не дороже
                // жизни»
                self.mk_serve_acts += 1;
                true
            } else if self.mk_cur_acts < law {
                false
            } else if {
                // [НЕВЫМИРАНИЕ] жребий
                // Кронекера: доля серва
                // капает в аккумулятор;
                // перелив кванта = проба
                const Q: u64 = 1 << 20;
                #[allow(
                    clippy::cast_possible_truncation,
                    clippy::cast_sign_loss,
                    reason = "share in [0,1]"
                )]
                let share = ((r_serve
                    / (r_serve + r_cur))
                    * Q as f64)
                    .round()
                    as u64;
                self.mk_kron += share;
                self.mk_glass[1] += 1;
                if self.mk_kron >= Q {
                    self.mk_kron -= Q;
                    true
                } else {
                    false
                }
            } {
                true
            } else if inc_serve == 0
                && inc_cur == 0
            {
                // [V2] обоюдный нуль доходов
                // ПОСЛЕ проб — фронтир-дефолт:
                // мир без выплат = эпоха
                // разведки; серв без дохода не
                // имеет права на такты (R16:
                // суд шумом двух нулей отдал
                // 1691 выбор мрущим планам и
                // убил попутную оплату езды)
                false
            } else {
                r_serve >= r_cur
            };
            self.mk_glass[0] += 1;
            if serve_first {
                self.mk_glass[2] += 1;
            } else {
                self.mk_glass[3] += 1;
            }
            self.mk_glass[4] = u64::from(
                crate::law::LAW_OF_REPETITION,
            )
            .saturating_sub(self.mk_serve_acts);
            let expedition = !self.exp_cold
                && !self.world_tasks.is_empty()
                && {
                    let here =
                        crate::optimality::level_of(state);
                    self.world_tasks.iter().all(
                        |(a, _)| {
                            crate::optimality::level_of(*a)
                                == here + 1
                        },
                    )
                };
            if serve_first && expedition {
                // [ЖЕРТВЕННЫЙ ТРАНЗИТ, грань (i)]
                // все цели — соседний уровень:
                // экспедиция строится ценой риска
                self.bored_risk = true;
                self.exp_glass[0] += 1;
                self.exp_streak += 1;
                if self.exp_streak
                    >= crate::law::LAW_OF_REPETITION
                {
                    // грань (iii): кап азарта
                    self.exp_cold = true;
                }
            }
            if serve_first {
                self.plan_to_frontier_exam_pred(
                    state,
                    world.reset_action(),
                    true,
                );
                self.bored_risk = false;
                if self
                    .last_exam_cost
                    .is_some()
                {
                    self.task_glass[2] += 1;
                    self.plan_is_task = true;
                    // [ЦЕЛЬ-ПАМЯТЬ] намерение
                    // выбрано рынком
                    if self.hold_goal
                        != self.plan_goal
                    {
                        self.hold_goal =
                            self.plan_goal;
                        self.hold_torn = 0;
                        self.hold_fail = 0;
                        self.hold_glass[0] +=
                            1;
                    }
                } else {
                    self.task_glass[3] += 1;
                    // попытка — тоже расход
                    // служения (немота видна
                    // рынку, не вечное право)
                    self.mk_serve_acts += 1;
                }
                if let Some(n) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[3] +=
                        1;
                    self.last_branch = 3;
                    return Some(n);
                }
                if self.plan.is_empty() {
                    // гигиена ревью: план
                    // съеден банами — флаг
                    // задачи не висит
                    self.plan_is_task = false;
                }
            }
        }

        if (self.bored
            || world.stale_overdue())
            && self.plan.is_empty()
        {
            // [ПЕРЕЗРЕЛЫЙ ДОЛГ ПРОЖИГАЕТ СКУКУ,
            // p25w] вход и без скуки — долг
            // двойной выдержки купил такт
            // (валюта предмета, не голод тела).
            // [ЖЕРТВЕННАЯ ДОРОГА — И ПАЛОМНИКУ]
            // скука оплачивает риск всех своих
            // жестов: миля, зов, ломатель (зов
            // стоял выше строки bored_risk и
            // платил смертельный штраф на
            // 60-шаговых дорогах)
            self.bored_risk = true;
            self.try_phase_mile(state, world);
            // [ПАЛОМНИК, ЗОВ СТАРШИНСТВОМ] валюта
            // зова — ВОЗРАСТ ДОЛГА, не голод тела
            // (три прожития рода сытости: тройки,
            // гашения tu93, гашения ft09 — на
            // живом мире любой голод тела вечно
            // сыт крошками); зовёт ЗАДАЧА, чей
            // дефицит не тронут own-ом дольше
            // порога мира (MVT наоборот: долг
            // застарел — иди). Мир судит старость
            // (stale_tasks: порог, достижимость,
            // фаза), организм — прожитость и
            // место; кап LAW бесплодных подряд.
            {
                let stale = world.stale_tasks();
                if self.plan.is_empty()
                    && !stale.is_empty()
                    && self.pilgrim_dry
                        < crate::law::LAW_OF_REPETITION
                {
                    if watch_glass("PILGRIM")
                    {
                        // [СУД ГЕЙТА] топ stale:
                        // этаж и вердикт могил —
                        // кто прячет ближнюю
                        // ступень от зова
                        for (a, age) in
                            stale.iter().take(5)
                        {
                            eprintln!(
                                "ПАЛОМНИК-STALE	адрес={a} этаж={} возраст={age} могила={}",
                                crate::optimality::level_of(*a),
                                !self
                                    .task_graves
                                    .admissible(
                                        a,
                                        self.task_plan_clock,
                                    )
                            );
                        }
                    }
                    if self.pilgrim_goal.is_some()
                    {
                        // прошлый зов не доехал:
                        // бесплодность к капу
                        // ТОЛЬКО если план дожил
                        // до ресета (иначе —
                        // сырость постройки)
                        if self.pilgrim_ripe {
                            self.pilgrim_dry += 1;
                        }
                        self.pilgrim_ripe = false;
                        self.pilgrim_goal = None;
                    }
                    // [ВОЗРАСТ ПЕРВИЧЕН, R62-дыра
                    // выбора] аргмин прожитости
                    // убивал сортировку старшинства
                    // мира: из 127 застарелых он
                    // брал нулевые никогда-не-житые
                    // адреса глубин (дороги к ним —
                    // чистая фикция), а шестёрка с
                    // 25 прожитиями вечно
                    // проигрывала. Паломник идёт к
                    // СТАРЕЙШЕМУ допустимому долгу
                    // (порядок мира); прожитость —
                    // не судья.
                    // [ЛЕСТНИЦА ПАЛОМНИКА, s54-
                    // развилка (б)] очередь
                    // принадлежит ПАКТУ: сертификаты
                    // растут снизу (О-10: полнота от
                    // нуля) — зов идёт к старейшему
                    // долгу БЛИЖАЙШЕГО уровня с
                    // застарелыми (паломник не
                    // перепрыгивает ступени; min_by
                    // стабилен — внутри уровня
                    // побеждает порядок мира =
                    // возраст)
                    // [ЛЕСТНИЦА ШАГАЕТ ЧЕРЕЗ
                    // НЕМЫХ, R65] немая ближняя
                    // цель (дорога не строится)
                    // вечно заслоняла живую
                    // дальнюю (немота не платит
                    // кап — и не должна): зов
                    // пробует кандидатов по
                    // порядку лестницы до первой
                    // ЖИВОЙ дороги, не более LAW
                    // построек за зов
                    // [МОГИЛА ОТПУСКАЕТСЯ
                    // СТАРШИНСТВОМ, s57] ft09-
                    // шестёрка была похоронена
                    // доезжавшими фейлами древних
                    // экспедиций и навеки скрыта от
                    // зова; застарелость (порог
                    // мира: LAW²×t_avg без own)
                    // СТАРШЕ могилы (LAW-эпоха) —
                    // паломничья лестница могилами
                    // не фильтруется: его мельницу
                    // капит зрелость, не могила;
                    // рынок и обычные постройки
                    // могилы чтут как прежде
                    // (пререг-18 цел)
                    let mut ladder: Vec<u64> =
                        stale
                            .iter()
                            .map(|(a, _)| *a)
                            .collect();
                    // [ЛЕСТНИЦА ПЛАТИТ
                    // ПРОВАЛАМИ, tn36: 204/205
                    // зовов жгла мёртвая старуха
                    // — одноразовая метка
                    // сбрасывалась ветками]
                    // порядок = (провалы цели
                    // этой жизни, старшинство):
                    // счёт растёт фактами и
                    // умирает с жизнью
                    ladder.sort_by_key(|a| {
                        (
                            self.pilgrim_fails
                                .get(a)
                                .copied()
                                .unwrap_or(0),
                            crate::optimality::level_of(*a),
                        )
                    });
                    // [ОПРОВЕРГНУТАЯ УСТУПАЕТ
                    // ЛЕСТНИЦУ, tn36: мёртвая
                    // старуха (эпохи, которой нет)
                    // вечно первая старшинством —
                    // её мёртвый план давал break,
                    // живые свежие цели не
                    // зывались НИКОГДА] цель с
                    // опровергнутой дорогой идёт
                    // в хвост порядка — не
                    // похоронена (пере-суд её
                    // казнит своим чередом), но
                    // очередь живым.

                    // [УРОК ЦЕЛИКОМ ВТОРЫМ ЗОВОМ]
                    // зрелая неудача (план доигран,
                    // цель не взята — dry ≥ 1) —
                    // живая сокращёнка не платит:
                    // второй зов идёт от корня;
                    // счёт сгораний остался для
                    // жёстких миров, где план
                    // горит, не доигрываясь
                    let via_root = self
                        .pilgrim_burn_cnt
                        >= crate::law::LAW_OF_REPETITION
                        || self.pilgrim_dry >= 1;
                    let mut called = None;
                    for g in ladder
                        .into_iter()
                        .take(
                            crate::law::LAW_OF_REPETITION
                                as usize,
                        )
                    {
                        // [ПРОВАЛ ПЕРЕДАЁТ
                        // РУКУ, tn36: канальные
                        // планы перестали гореть
                        // (дожатия) и жрали ВСЕ
                        // зовы — мир не спрошен
                        // никогда] рука дороги по
                        // числу провалов цели:
                        // 0=канал (дёшев), 1=мир
                        // (канал солгал), 2+=
                        // рельса (ноты) первой
                        let hand = self
                            .pilgrim_fails
                            .get(&g)
                            .copied()
                            .unwrap_or(0)
                            .min(2);
                        // [СМЕРТЬ ОПРОВЕРГАЕТ
                        // КАНАЛ] цель, чья
                        // канальная дорога убила
                        // экспедицию, зовётся
                        // сначала ДОРОГОЙ МИРА
                        // (мир видит смертные
                        // рёбра — канал нет)
                        if self.exp_refuted
                            == Some(g)
                        {
                            if watch_glass("PILGRIM")
                            {
                                eprintln!(
                                    "ОПРОВЕРГ-ЗОВ	цель={g} дорога-мира={:?}",
                                    world
                                        .plan_to(g)
                                        .map(|r| r.len())
                                );
                            }
                        }
                        // [МАКРО-ДОРОГА, В-3]
                        // купленный субплан с
                        // хвостом-целью — раньше
                        // рельсы урока: живой
                        // own-опыт короче нот
                        if (via_root
                            || hand >= 2
                            || self.salt_seen
                            || world.salt_shift()
                            || self.exp_refuted
                                == Some(g))
                            && let Some(rail) =
                                world
                                    .macro_rail(g)
                        {
                            let (acts, refs): (
                                std::collections::VecDeque<A>,
                                std::collections::VecDeque<u64>,
                            ) = rail
                                .into_iter()
                                .unzip();
                            self.plan = acts;
                            self.plan_refs = refs;
                            self.plan_expect =
                                None;
                            self.plan_is_task =
                                true;
                            self.plan_notes =
                                true;
                            self.world_road =
                                true;
                            self.world_road_ticks = 0;
                            called = Some(g);
                            break;
                        }
                        // [РЕЛЬСА ПЕРВОЙ У
                        // СГОРЕВШИХ, r2: мир жив
                        // дидактикой и вечно не
                        // доводит — рельса за ним
                        // не получала хода] цель,
                        // чьи дороги уже горели
                        // (via_root/опровергнута),
                        // идёт ПО НОТАМ раньше
                        // мира и корня.
                        if (via_root
                            || hand >= 2
                            || self.salt_seen
                            || world.salt_shift()
                            || self.exp_refuted
                                == Some(g))
                            && let (
                                Some(rail),
                                Some(r),
                            ) = (
                                world
                                    .lesson_rail(g),
                                world
                                    .reset_action(),
                            )
                        {
                            self.plan = rail
                                .into_iter()
                                .collect();
                            self.plan
                                .push_front(r);
                            self.plan_refs.clear();
                            self.plan_expect =
                                None;
                            self.plan_is_task =
                                true;
                            self.exp_refuted =
                                None;
                            called = Some(g);
                            break;
                        }
                        // [СМЕРТЬ ОПРОВЕРГАЕТ
                        // КАНАЛ → мир ВТОРЫМ,
                        // tn36: соль-мёртвые
                        // мировые планы вечно
                        // перехватывали зов у
                        // рельсы — ноты
                        // соль-иммунны и идут
                        // первыми]
                        if self.exp_refuted
                            == Some(g)
                            && let Some(road) =
                                world.plan_to(g)
                        {
                            // [ЗРЯЧАЯ ДОРОГА] акты и узлы
                            // из одного носителя
                            let (acts, refs): (
                                std::collections::VecDeque<A>,
                                std::collections::VecDeque<u64>,
                            ) = road.into_iter().unzip();
                            self.plan = acts;
                            self.plan_refs = refs;
                            self.plan_expect =
                                None;
                            self.world_road = true;
                            self.world_road_ticks =
                                0;
                            self.exp_refuted =
                                None;
                            called = Some(g);
                            break;
                        }
                        if via_root
                            && let (
                                Some(root),
                                Some(r),
                            ) = (
                                self.root,
                                world.reset_action(),
                            )
                        {
                            // [РЕСЕТ-ПАЛОМНИЧЕСТВО]
                            // живая сокращёнка
                            // отгорела LAW раз —
                            // урок целиком: дорога
                            // от корня, ресет
                            // префиксом (плановая
                            // смерть взведёт вторую
                            // жизнь и приоритет)
                            self.plan_exam_pred_cut(
                                root,
                                None,
                                false,
                                Some(g),
                                true,
                            );
                            if !self
                                .plan
                                .is_empty()
                            {
                                self.plan
                                    .push_front(r);
                                self.plan_refs
                                    .clear();
                                self.plan_expect =
                                    None;
                                called = Some(g);
                                break;
                            }
                        }
                        if hand == 0 {
                            self.plan_exam_pred_to(
                                state,
                                world.reset_action(),
                                false,
                                Some(g),
                            );
                        }
                        if !self.plan.is_empty() {
                            called = Some(g);
                            break;
                        }
                        // [ДОРОГА МИРА] канал нем
                        // от корня и от тела —
                        // память мира последней:
                        // прожитая дорога без
                        // жертвы (ресет не нужен,
                        // рёбра уже прожиты).
                        if let Some(road) =
                            world.plan_to(g)
                        {
                            // [ЗРЯЧАЯ ДОРОГА] акты и узлы
                            // из одного носителя
                            let (acts, refs): (
                                std::collections::VecDeque<A>,
                                std::collections::VecDeque<u64>,
                            ) = road.into_iter().unzip();
                            self.plan = acts;
                            self.plan_refs = refs;
                            self.plan_expect =
                                None;
                            self.world_road = true;
                            self.world_road_ticks = 0;
                            called = Some(g);
                            break;
                        }
                        // [ДОРОГА ПО НОТАМ] мир и
                        // канал немы — рельса
                        // урока жертвенным родом
                        // (см. и перехват выше).
                        if let (
                            Some(rail),
                            Some(r),
                        ) = (
                            world.lesson_rail(g),
                            world.reset_action(),
                        ) {
                            self.plan = rail
                                .into_iter()
                                .collect();
                            self.plan
                                .push_front(r);
                            self.plan_refs.clear();
                            self.plan_expect =
                                None;
                            self.plan_is_task =
                                true;
                            called = Some(g);
                            break;
                        }
                        if watch_glass("PILGRIM")
                        {
                            eprintln!(
                                "ПАЛОМНИК-НЕМОТА	цель={g} root={:?} reset={}",
                                self.root,
                                world
                                    .reset_action()
                                    .is_some()
                            );
                        }
                    }
                    if let Some(g) = called {
                        self.pilgrim_glass[0] +=
                            1;
                        if !self.plan.is_empty()
                        {
                            if watch_glass("PILGRIM")
                            {
                                let fr = self
                                    .plan
                                    .front()
                                    .map(|a| {
                                        let mut b = Vec::new();
                                        crate::worldmap::Wire::w(a, &mut b);
                                        b
                                    });
                                let src =
                                    if self
                                        .world_road
                                    {
                                        "мир"
                                    } else if self
                                        .plan_is_task
                                    {
                                        "рельса"
                                    } else {
                                        "канал"
                                    };
                                eprintln!(
                                    "ПАЛОМНИК-ЗОВ	цель={g} len={} перв-байт={fr:?} возраст-мест={} род={src}",
                                    self.plan.len(),
                                    stale.len()
                                );
                                if watch_glass("ROAD") {
                                    let pb: Vec<Vec<u8>> = self
                                        .plan
                                        .iter()
                                        .map(|a| {
                                            let mut b = Vec::new();
                                            crate::worldmap::Wire::w(a, &mut b);
                                            b
                                        })
                                        .collect();
                                    eprintln!(
                                        "ДОРОГА-ПОЛНАЯ	план={pb:?} рефы={:?}",
                                        self.plan_refs
                                    );
                                }
                            }
                            self.pilgrim_goal =
                                Some(g);
                            // [ЦЕЛЬ У ПЛАНА] зов-
                            // план несёт СВОЮ цель:
                            // без этого доигрыш/
                            // сгорание судили чужую
                            // (учёты шли мимо)
                            self.plan_goal =
                                Some(g);
                            self.pilgrim_len0 =
                                self.plan.len();
                            self.pilgrim_started =
                                false;
                            self.plan_is_task =
                                true;
                            self.hold_goal =
                                Some(g);
                            self.hold_torn = 0;
                            self.hold_fail = 0;
                        }
                    }
                }
            }
            // [ЛОМАТЕЛЬ-ДОРОГА, R28-суд] настоящая
            // новизна на цикле — только маршрутом
            // (прожитая пара на месте не рождает
            // тройки по определению): фронтир-
            // Дейкстра ШАГАМИ БЕЗ СМЕРТНОГО ШТРАФА
            // — скука оплачивает риск (жертвенная
            // дорога; три лица одного рода:
            // exhausted-обрывы ft09, смертельное
            // ребро tu93, фазовые дали cd82).
            if self.dry_breaks
                >= crate::law::LAW_OF_REPETITION
                && !self.world_tasks.is_empty()
            {
                // [СУХОЙ ФРОНТИР → ДВЕРИ ЗАДАЧ,
                // s-слом ft09] exam-фронтир
                // организма сух (LAW ломателей без
                // тройки), а достижимые двери живут
                // в world_tasks — два носителя
                // одного рода становятся ОДНИМ
                // фронтиром скуки: та же жертвенная
                // дорога, цель из задач (оплата —
                // обычным судом, plan_is_task).
                self.plan_to_frontier_exam_pred(
                    state,
                    world.reset_action(),
                    true,
                );
                if self.last_exam_cost.is_some() {
                    self.plan_is_task = true;
                }
            }

            if self.plan.is_empty() {
                self.plan_to_frontier_exam(
                    state,
                    world.reset_action(),
                );
            }
            self.bored_risk = false;
            if !self.plan.is_empty() {
                self.bored = false;
                self.bore_glass[1] += 1;
                self.bore_glass[2] = 0;
                if let Some(n) =
                    self.take_planned_rebound(state, world)
                {
                    self.choice_counts[9] += 1;
                    self.last_branch = 9;
                    return Some(n);
                }
            }
            // фолбэк дороги — прежний один акт:
            // наименее прожитая небанованная пара
            // этого ключа (deadly<LAW буквой).
            let brk = self
                .seen
                .get(&state)
                .and_then(|ms| {
                    ms.iter()
                        .copied()
                        .filter(|a| {
                            !self.banned(state, *a)
                        })
                        .filter(|a| {
                            self.deadly_bans
                                .get(&(state, *a))
                                .copied()
                                .unwrap_or(0)
                                < crate::law::LAW_OF_REPETITION
                        })
                        .min_by_key(|a| {
                            self.lived_pairs
                                .get(&(state, *a))
                                .copied()
                                .unwrap_or(0)
                        })
                });
            if let Some(a) = brk {
                self.bored = false;
                self.bore_glass[1] += 1;
                self.bore_glass[2] = 0;
                self.choice_counts[9] += 1;
                self.last_branch = 9;
                return self.rent_free_fallback(state, a, world);
            }
        }
        if !u.is_empty()
            && self.plan.is_empty()
        {
            // [ПРЕРЕГ-23 РЫНОК ЖЕЛАНИЙ, V1]
            // порядок — внутри юрисдикции, РЫНОК —
            // между: служение и любопытство торгуют
            // предельной отдачей (KT+½; курс =
            // новых троек за гашение; LAW первых
            // проб каждому; суд только на границе
            // планов — при живом плане рынок
            // молчит и не звался бы: план забрал
            // бы такт ниже). Шрамы R10/R11: любое
            // ПЕРВЕНСТВО (запрет; очередь-
            // постройкой) глушило одного из
            // торговцев насмерть.
            // [НОТЫ СВЯТЫ, probe-11 СТАРТ-СЕРИИ:
            // (3,11)…(3,2)→(0,2)(0,0) — валент
            // рвал серию ломтя в ДВУХ нотах от
            // WIN] инвариант этого дока («при
            // живом плане рынок молчит») был
            // нарушен фактом — восстановлен
            // гейтом plan.is_empty(): серия
            // рельсы — атом, любопытство живёт
            // на границах планов.
            // (рынок вынесен выше — см. [ВХОД РЫНКА])
            // ЛЮБОПЫТСТВО ОРГАНОМ (переезд фазы-2,
            // последний inline-кусок каскада): валент-
            // претендент оси-V решается организмом
            // (его башня), статьи СК-справки и тишины
            // — у органа (motor::CuriosityOrgan);
            // стекло веток 0/1/2 прежнее.
            let valent = self.valent_pick(state, &u);
            let sig = Self::sig_hash(
                self.seen
                    .get(&state)
                    .cloned()
                    .unwrap_or_default(),
            );
            let ctx = crate::motor::CuriosityCtx {
                untried: &u,
                valent,
                glue_on: self.glue_on,
                sig,
                sig_counts: &self.sig_counts,
                sig_len_use: &self.sig_len_use,
                len_axis_off: std::env::var(
                    "G1_NO_LEN_AXIS",
                )
                .is_ok(),
            };
            if let Some((a, br)) =
                crate::motor::CuriosityOrgan::propose(
                    &ctx,
                )
            {
                self.choice_counts
                    [usize::from(br)] += 1;
                self.last_branch = br;
                return Some(Decision::Exploration(a));
            }
        }
        // ВЕТКА НЕДОПЛАТЫ (семантический разрыв тракта:
        // жест, тронутый классом один раз, невидим
        // untried-ветке, но вечно тянет фронтир-Дейкстру;
        // дойдя — плати LAW=2 сам): недоплаченный жест
        // этого ключа пробуется прежде плана
        if Self::motor_on()
            && self.glue_on
            && std::env::var(
                "G1_NO_UNDERPAID_BRANCH",
            )
            .is_err()
            && self.just_arrived.take()
                == Some(state)
        {
            // ФАЗА-2: недоплата органом (та же
            // семантика места и гейта)
            let coined = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            let menu: Vec<A> = self
                .seen
                .get(&state)
                .cloned()
                .unwrap_or_default();
            let banned_f =
                |a: A| self.banned(state, a);
            let ctx = crate::motor::MotorCtx {
                key: coined,
                raw: self.cur_raw_key,
                root_raw: self.root_raw,
                menu: &menu,
                map: &self.map,
                takeover: false,
                just_arrived: true,
                banned: &banned_f,
            };
            let mut thin =
                crate::motor::ThinDebtOrgan;
            if let Some(p) = thin.propose(&ctx) {
                self.choice_counts[6] += 1;
                self.last_branch = 6;
                return Some(Decision::Exploration(p.act));
            }
        } else if self.glue_on
            && std::env::var(
                "G1_NO_UNDERPAID_BRANCH",
            )
            .is_err()
            && self.just_arrived.take()
                == Some(state)
        {
            let _rep = self.glue_rep_of(state);
            // ЮРИСДИКЦИЯ ПРОБЫ = ДОЛГ КАРТЫ (Т-КЛЮЧ:
            // выплата покупает биты — ветвление ≥LAW у
            // чеканенного ключа; сырые счётчики звали в
            // океан микро-долгов: 486/3000, 456 смертей;
            // классовые молчали при живом сыром — обе
            // старые юрисдикции мертвы, долг карты один)
            let coined = self.coined_key(
                self.cur_raw_key,
                self.since_root,
            );
            let up: Option<A> = self
                .map_thin_act(coined)
                .filter(|&a| {
                    !self.banned(state, a)
                });
            if let Some(a) = up {
                self.choice_counts[6] += 1;
                self.last_branch = 6;
                return Some(Decision::Exploration(a));
            }
        }
        if let Some(next) = self.take_planned_rebound(state, world) {
            let br = if self.vte_plan { 11 } else { 3 };
            self.choice_counts[br] += 1;
            self.last_branch = br as u8;
            if self.plan.is_empty() {
                self.vte_plan = false;
                // прибытие: следующая точка выбора —
                // щель (ритм по построению)
                self.road_rest = true;
            }
            return Some(next);
        }
        self.vte_plan = false;
        self.plan_to_frontier(state, world.reset_action());
        if self.plan.is_empty() && self.glue_on {
            // СК: boredom — the lived moment of
            // generalization; the partition market sits
            self.coin_coords_market();
            self.glue_market();
            self.plan_to_frontier(
                state,
                world.reset_action(),
            );
        }
        if self.gaze
            && self.plan.is_empty()
            && self.tower.frame()[0].conscious
            && invariants::purity(self.tower.level(0))
                > 5.0 / 14.0
        {
            // THE CEILING HALF of the window's regulation:
            // truly exhausted, in the window AND above its
            // midpoint — the gaze trims from the top only
            // (sleep lifts from the bottom; 5/14 is their
            // shared set-point), so the two halves never
            // saw against each other at the border
            self.look();
            self.looks += 1;
        }
        let patrol_ok = self.patrol
            && (!self.patrol_licence || self.tower.frame()[1].conscious);
        if self.patrol && !patrol_ok {
            self.patrol_blocked += 1;
        }
        if let Some(n) = self.take_planned_rebound(state, world) {
            self.choice_counts[3] += 1;
                self.last_branch = 3;
            return Some(n);
        }
        {
            if patrol_ok {
                // Revision: the least recently checked
                // transition — among the UNBURIED first.
                // The maze probe caught the patrol
                // ignoring the graveyard: with the lethal
                // ledger armed it still bumped every wall
                // x24 forever (LRU treats a frozen verdict
                // as any other stale edge). Two queues
                // keep both laws: the living are revised
                // by age; the banned are touched only when
                // no living edge remains — the forced
                // retest stays the one door refutation can
                // enter through, at the starvation rhythm,
                // not the round-robin one.
                let ms: Vec<A> = self
                    .seen
                    .get(&state)
                    .cloned()
                    .unwrap_or_default();
                // Фаза-2 совета жестов, переезд-5:
                // ревизия — PatrolOrgan. Леджеры
                // (verified_at/glue_counts/bans) не
                // мигрируют — орган видит их
                // замыканиями-взглядами; владелец —
                // организм (М-18: юрисдикция не
                // наследуется). Старый блок ниже —
                // двойник М-4-щита.
                let motor_rev: Option<A> = if Self::motor_on() {
                    let verified = |a: A| {
                        self.verified_at
                            .get(&(state, a))
                            .map_or(0, ObservationReceipt::last_observed_at)
                    };
                    let lived = |a: A| {
                        let c = self
                            .glue_counts
                            .get(&(state, a))
                            .copied()
                            .unwrap_or([0; 3]);
                        u64::from(c[0] + c[1] + c[2])
                    };
                    let banned =
                        |a: A| self.banned(state, a);
                    let ctx = crate::motor::MotorCtx {
                        key: self.cur_raw_key,
                        raw: self.cur_raw_key,
                        root_raw: None,
                        menu: &ms,
                        map: &self.map,
                        takeover: false,
                        just_arrived: false,
                        banned: &banned,
                    };
                    let mut organ =
                        crate::motor::PatrolOrgan {
                            amortized: self
                                .patrol_amortized
                                && std::env::var(
                                    "G1_PATROL_LRU",
                                )
                                .is_err(),
                            now: self.steps,
                            verified_at: &verified,
                            lived_n: &lived,
                        };
                    organ
                        .propose_rev(&ctx)
                        .map(|p| p.act)
                } else {
                    None
                };
                let patrol_pick = if Self::motor_on()
                {
                    motor_rev
                } else {
                    (!ms.is_empty())
                    .then(|| {
                    let lawful: Vec<A> = ms
                        .iter()
                        .copied()
                        .filter(|&a| {
                            !self.banned(state, a)
                        })
                        .collect();
                    let pool: Vec<A> =
                        if lawful.is_empty() {
                            ms.clone()
                        } else {
                            lawful
                        };
                    // А1-хвост (списание давностью —
                    // кандидат-3 формы оплаты фронтира):
                    // голый LRU ревизовал КАЖДЫЙ эпизод
                    // (хвост {26: 200} = 13 пути + 13
                    // крюка); закон Виллемса: право на
                    // ревизию = давность/(подтверждения
                    // + LAW) — подтверждённый мир спит,
                    // давность будит редко; G1_PATROL_LRU
                    // = старый двойник М-4-щита
                    if !self.patrol_amortized
                        || std::env::var(
                            "G1_PATROL_LRU",
                        )
                        .is_ok()
                    {
                        pool.into_iter().min_by_key(
                            |&a| {
                                self.verified_at
                                    .get(&(state, a))
                                    .map_or(0, ObservationReceipt::last_observed_at)
                            },
                        )
                    } else {
                        let now = self.steps;
                        let picked = pool.into_iter()
                            .map(|a| {
                                let v = self
                                    .verified_at
                                    .get(&(state, a))
                                    .map_or(0, ObservationReceipt::last_observed_at);
                                let c = self
                                    .glue_counts
                                    .get(&(state, a))
                                    .copied()
                                    .unwrap_or([0; 3]);
                                let n = u64::from(
                                    c[0] + c[1] + c[2],
                                );
                                // ревизия — юрисдикция
                                // ПРОЖИТОГО: n=0 отдан
                                // фронтиру (патруль с
                                // n=0-жаждой съел жизнь:
                                // 430 смертей, 35345
                                // ревизий на 3000)
                                if n == 0 {
                                    return (0, a);
                                }
                                let age = now
                                    .saturating_sub(v);
                                let score = age
                                    .saturating_mul(1024)
                                    / (n + u64::from(
                                        crate::law::LAW_OF_REPETITION,
                                    ));
                                (score, a)
                            })
                            .filter(|&(sc, a)| {
                                // spaced-гейт: порог
                                // ребра удвоен его
                                // бесплодными ревизиями
                                // (двойник — фикс 1024)
                                // ОПТ-ИН (опровергнут
                                // как дефолт: патруль —
                                // несущая exam-руки,
                                // спейсинг рушит жизнь
                                // 609->45; леджер жив
                                // стеклом диагностики)
                                let k = if std::env::var(
                                    "G1_SPACED_PATROL",
                                )
                                .is_ok()
                                {
                                    self.patrol_futile
                                        .get(&(
                                            state, a,
                                        ))
                                        .copied()
                                        .unwrap_or(0)
                                        .min(30)
                                } else {
                                    0
                                };
                                sc >= 1024u64 << k
                            })
                            .max_by_key(|&(s, _)| s)
                            .map(|(_, a)| a);
                        picked
                    }
                    })
                    .flatten()
                };
                if patrol_pick.is_some() {
                    self.choice_counts[4] += 1;
                self.last_branch = 4;
                    return patrol_pick.map(Decision::Recheck);
                }
                // A retained route is an intent even when taking its final step
                // empties the queue. Only the fallthrough below is a free choice.
                if std::env::var("G1_NO_ROOT_RING").is_err() {
                    self.plan_ring_to_root(state);
                    if let Some(decision) = self.take_planned_rebound(state, world) {
                        self.choice_counts[5] += 1;
                        self.last_branch = 5;
                        return Some(decision);
                    }
                }
                let candidate = self.fallback_reset(world).or_else(|| {
                    if Self::motor_on() {
                        let menu = self.seen.get(&state).cloned().unwrap_or_default();
                        let banned = |action: A| self.banned(state, action);
                        let context = crate::motor::MotorCtx {
                            key: 0,
                            raw: self.cur_raw_key,
                            root_raw: self.root_raw,
                            menu: &menu,
                            map: &self.map,
                            takeover: false,
                            just_arrived: false,
                            banned: &banned,
                        };
                        let mut avoidance = crate::motor::AvoidanceOrgan;
                        return avoidance.propose(&context).map(|proposal| proposal.act);
                    }
                    self.seen.get(&state).and_then(|menu| {
                        menu.iter().copied().find(|&action| !self.banned(state, action))
                            .or_else(|| menu.first().copied())
                    })
                });
                candidate.and_then(|action| self.rent_free_fallback(state, action, world))
            } else {
                let candidate = self.fallback_reset(world).or_else(|| {
                    self.seen.get(&state).and_then(|menu| {
                        let lawful: Vec<A> = menu.iter().copied()
                            .filter(|&action| !self.banned(state, action)).collect();
                        if lawful.is_empty() {
                            return menu.first().copied();
                        }
                        self.valent_pick(state, &lawful)
                            .or_else(|| self.hungriest(state, &lawful))
                    })
                });
                candidate.and_then(|action| self.rent_free_fallback(state, action, world))
            }
        }
    }

    /// One life step in the task: choose an action (wheel
    /// -> curiosity -> plan -> frontier), execute, eat the
    /// frame with the tower base, show the pulse. `None` —
    /// nothing to move with.
    #[allow(
        clippy::too_many_lines,
        reason = "the one heartbeat of the organism: act, \
                  death, molt, sleep — a lived tick is one \
                  indivisible law"
    )]
    pub fn step<H: Habitat<Action = A>>(
        &mut self,
        world: &mut H,
    ) -> Result<StepOutcome<A>, ActionFailure<A>> {
        self.check_action_status()?;
        if let Some((action, terminal)) = self.action_stop {
            return Ok(StepOutcome::Stopped { action, terminal });
        }
        // [ФАЗОВЫЙ ОТКАЗ — СЛИВ В МИР] копилка
        // kill-точки (она не видит мира)
        for (c, a0) in
            std::mem::take(&mut self.pending_refusals)
        {
            world.note_refused(c, a0);
        }
        self.step_inner(world, None)
    }

    /// The VALENT step (axis-V v1): live one tick with a
    /// GIVEN act — the valued rollout's hand on the body.
    /// Every law of the ordinary step runs unchanged
    /// (witness, courts, molts, sleep): valence chooses,
    /// the organism lives.
    pub fn step_forced<H: Habitat<Action = A>>(
        &mut self,
        world: &mut H,
        act: A,
    ) -> Result<StepOutcome<A>, ActionFailure<A>> {
        self.step_inner(world, Some(act))
    }

    #[allow(
        clippy::too_many_lines,
        reason = "the one heartbeat of the organism: act, \
                  death, molt, sleep — a lived tick is one \
                  indivisible law (the forced twin adds \
                  only the choice's source)"
    )]
    fn step_inner<H: Habitat<Action = A>>(
        &mut self,
        world: &mut H,
        forced: Option<A>,
    ) -> Result<StepOutcome<A>, ActionFailure<A>> {
        self.step_inner_observed(world, forced, None)
    }

    fn step_inner_observed<H: Habitat<Action = A>>(
        &mut self,
        world: &mut H,
        forced: Option<A>,
        mut boundary: Option<&mut dyn experiment::ActBoundary<H>>,
    ) -> Result<StepOutcome<A>, ActionFailure<A>> {
        if self.source_time.episode().is_none() {
            let failure = ActionFailure::begin(ActionStage::Budget, "observer episode identity exhausted");
            self.action_failure = Some(failure.clone());
            return Err(failure);
        }
        self.check_action_status()?;
        if let Some((action, terminal)) = self.action_stop {
            return Ok(StepOutcome::Stopped { action, terminal });
        }
        // [ЗАДАЧИ] снимок адресов служения на тик;
        // [ПРЕРЕГ-11] служение слушает ТОЛЬКО
        // ТЕКУЩИЙ уровень (порядок, не вес): чужой
        // черёд придёт на своём уровне — иначе
        // дальние задачи вечно держат очередь и
        // WIN уровня не берётся (V-плато 128)
        self.world_tasks = world.task_addrs();
        {
            // [ЦЕЛЬ-ПАМЯТЬ] границы намерения на
            // снимке: смена уровня тела; уход цели
            // из мира (гашена / снята витриной —
            // оба честно отпускают рынку)
            {
                // [ГРАНИЦА ЭПОХИ ПРАВ] смена уровня
                // тела возвращает LAW-права проб:
                // мир изменился — серв заслуживает
                // новой пробы (суд по f-листу cd82)
                let here =
                    crate::optimality::level_of(world.key());
                if self.mk_epoch_level != here {
                    self.mk_epoch_level = here;
                    // новая эпоха размораживает
                    // жертвенный азарт (грань iii)
                    self.exp_cold = false;
                    self.exp_streak = 0;
                    self.mk_serve_acts = self
                        .mk_serve_acts
                        .min(
                            u64::from(crate::law::LAW_OF_REPETITION)
                                .saturating_sub(1),
                        );
                }
            }
            if let Some(g) = self.hold_goal {
                let here =
                    crate::optimality::level_of(world.key());
                let lv = crate::optimality::level_of(g);
                // [ЛЕСТНИЦА ДЕРЖАНИЯ, R50-дыра
                // пары] цель ВЫШЕ тела законна на
                // любом расстоянии: дорога вверх
                // существует прыжками, пара «вход
                // завершает план / жизнь начинается
                // пере-планом» несёт её лестницей
                // пере-планов через уровни; рвётся
                // только цель НИЖЕ тела (прошлый
                // мир — вернуться нельзя, RESET
                // рожает в корне)
                if lv < here {
                    self.hold_goal = None;
                    self.hold_glass[4] += 1;
                } else if !world
                    .raw_task_doors()
                    .contains(&g)
                {
                    // [ДВЕРЬ МЕРТВА, обмен двух
                    // рук] сырой канал дверей без
                    // MVT (мигать нечему): g вне
                    // {wa}∪drops живых задач —
                    // hold держал дверь, которой
                    // юридически нет (ft09-вахта:
                    // 38 стуков в пустоту при
                    // вечном hold). Витринная
                    // «ушла» казнена R23-судом —
                    // сырой канал стал свидетелем.
                    self.hold_goal = None;
                    self.hold_glass[5] += 1;
                }
            }
            // [ревью-грань-(г)] дельта-съём гашений
            let cur = world.task_confirms();
            if cur < self.mk_pays_seen {
                // мир младше (перерождение)
                self.mk_pays_seen = 0;
            }
            let delta =
                cur - self.mk_pays_seen;
            self.mk_pays += delta;
            if delta > 0
                && self.exp_streak > 0
                && self.plan_is_task
                && !self.plan.is_empty()
            {
                // [R42-чинка капа] сброс серии —
                // только доездом ЭКСПЕДИЦИИ (гашение
                // при живом её плане); чужие
                // попутные гашения обходили кап:
                // 1580 жертвенных построек, 0
                // доездов, 304 смерти — цена без
                // предела
                self.exp_glass[1] += delta;
                self.exp_streak = 0;
            }
            // приписка по прожитому акту
            match self.last_branch {
                0 | 1 | 2 => {
                    self.mk_pays_cur += delta;
                }
                3 | 11 => {
                    self.mk_pays_serve += delta;
                }
                _ => {}
            }
            self.mk_pays_seen = cur;
        }
        self.any_world_tasks =
            !self.world_tasks.is_empty();
        {
            // [ПРЕРЕГ-16d] дверь соседа видна с
            // порога: цель корня СЛЕДУЮЩЕГО уровня
            // — законная тяга транзита (план мира
            // включает флип-акт шагом); дальние —
            // чужой черёд (пререг-11 в силе)
            let here =
                crate::optimality::level_of(world.key());
            self.world_tasks.retain(|(a, _)| {
                let lv = crate::optimality::level_of(*a);
                lv == here || lv == here + 1
            });
        }
        if let Some(task) = world.declared_task() {
            match &self.declared_task {
                Some(current) if !current.matches(&task) => {
                    // A changed task needs an explicit new owner, not an implicit
                    // threshold reset during a paused/continued physical life.
                    let failure = ActionFailure::begin(ActionStage::Dispatch, "declared task changed without a new session");
                    self.action_failure = Some(failure.clone()); return Err(failure);
                }
                None => self.declared_task = Some(declared_task::TaskSession::new(task)),
                _ => {},
            }
        } else if self.declared_task.is_some() {
            let failure = ActionFailure::begin(ActionStage::Dispatch, "declared task disappeared during its session");
            self.action_failure = Some(failure.clone()); return Err(failure);
        }
        let raw_state = self.sample_physical_observation(world);
        if self.root_raw.is_none() {
            self.root_raw = Some(raw_state);
        }
        // ОРГАННЫЕ ЧАСЫ: сброс по КЛАССУ root (фазовые
        // глифы развилки — один класс склейки; сырой
        // root-ключ сбрасывал часы раз в ~3 эпизода и
        // рынок фаз слеп); класс для ЧАСОВ — законная
        // юрисдикция (орган, не долг: М-18)
        if let Some(rr) = self.root_raw
            && self.try_eyed(raw_state).ok().zip(self.try_eyed(rr).ok()).is_some_and(|(a, b)| a == b)
        {
            self.since_root = 0;
        }
        self.tend_the_docket();
        let takeover = self.pending.take();
        let dispatch = observer_domain::before::Dispatch {
            raw: raw_state, initial_forced: forced,
            command: forced.map(|action| (Decision::CallerCommand(action), Some(action))), takeover,
            read: ObserverWork { remaining: self.exhaust.as_ref().map_or(0, |ex| ex.observer_work) },
            capture: ObserverWork { remaining: self.exhaust.as_ref().map_or(0, |ex| ex.observer_capture_work) },
            reobserve: false, require_menu: false, selection_prefix_done: false,
            granted_read: 0, granted_capture: 0,
            reading: None, deliberation: None, forecasts: Vec::new(), preparing: None, programs: None, reserving: None, reservation: None, registration: None, prepared_for: None, resource_reconsidered: false, request: None, state: None, menu: None, proposal: None,
        };
        self.continue_step_observed(world, dispatch, boundary)
    }

    /// Latest prospective action comparison, before the selected physical outcome.
    pub fn goal_decision(&self) -> Option<&GoalDecisionReport<A>> { self.goal_report.as_ref() }
    pub fn declared_goal(&self) -> Option<GoalSnapshot> { self.declared_task.as_ref().map(|task| task.snapshot()) }
    pub fn declared_takings(&self) -> u64 { self.declared_task.as_ref().map_or(0, |task|task.takings()) }

    /// Entry after the one-time task/docket accounting. A resumed dispatch owns
    /// its command and paid meters; no queue or physical action is replayed.
    fn continue_step_observed<H: Habitat<Action = A>>(&mut self, world: &mut H,
        mut dispatch: observer_domain::before::Dispatch<A>,
        mut boundary: Option<&mut dyn experiment::ActBoundary<H>>,
    ) -> Result<StepOutcome<A>, ActionFailure<A>> {
        use observer_domain::before::{Held, Lane};
        match (&self.declared_task, world.declared_task()) {
            (None,None)=>{}, (Some(task),Some(current)) if task.matches(&current)=>{},
            _=>{let failure=ActionFailure::begin(ActionStage::Dispatch,"task changed during retained deliberation");
                self.action_failure=Some(failure.clone());return Err(failure);},
        }
        let forced = dispatch.initial_forced;
        let takeover = dispatch.takeover;
        let mut raw_state = dispatch.raw;
        let (state, decision, forced, action, age_at_act, acted, rule_pre, programs, reservation) = loop {
        if dispatch.reobserve {
            raw_state = self.sample_physical_observation(world); dispatch.raw = raw_state;
            // Refresh current selector inputs without re-crediting task payments,
            // tending the docket, or consuming another wheel takeover.
            self.world_tasks = world.task_addrs();
            let here = crate::optimality::level_of(raw_state);
            self.world_tasks.retain(|(address,_)| { let level=crate::optimality::level_of(*address); level==here || level==here+1 });
            self.any_world_tasks = !self.world_tasks.is_empty();
            dispatch.reobserve = false;
            let obsolete = dispatch.reading.as_ref().is_some_and(|reading|
                !reading.matches(self, raw_state, self.source_time.life_age(), self.source_time.episode(), self.cur_pose))
                || dispatch.menu.as_ref().is_some_and(|menu| *menu != world.actions())
                || dispatch.request.is_some_and(|request| request != world.mile_act());
            if obsolete {
                let mut cancellation = dispatch.proposal.take();
                if let Err(held) = self.commit_proposal_cancellation(&mut cancellation, &mut dispatch.read.remaining) {
                    return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), BeforeActPhase::CancelProposal,
                        Lane::Read, cancellation, held));
                }
                dispatch.discard_obsolete();
            }
        }
        if dispatch.reading.is_none() {
            dispatch.reading = Some(observer_chain::Reading::new(self, raw_state,
                self.source_time.life_age(), self.source_time.episode(), self.cur_pose).with_sensory(self.cur_sensory.clone()));
        }
        let result = dispatch.reading.as_mut().unwrap().advance(self, &mut crate::program::observer::Budget::new(
            &mut dispatch.read, crate::program::ExecutionLimit::Unlimited))
            .and_then(|value| value.ok_or_else(observer_chain::unavailable));
        let state = match result {
            Ok(state) => { dispatch.state = Some(state); state },
            Err(observer_domain::ExecutionFailure::Native(fault)) => {
                let mut cancellation = None;
                if let Err((phase, held)) = self.retire_before_retry(fault, &mut dispatch, Lane::Read, &mut cancellation) {
                    return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), phase, Lane::Read, cancellation, held));
                }
                continue;
            }
            Err(reason) if matches!(&reason, observer_domain::ExecutionFailure::Unavailable(r) if r.resource()) => {
                return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), BeforeActPhase::Reobserve,
                    Lane::Read, None, Held::Execution(reason)));
            }
            Err(reason) => { let failure = ActionFailure::begin(ActionStage::Decode, reason.to_string());
                self.action_failure = Some(failure.clone()); return Err(failure); }
        };
        self.root.get_or_insert(state);
        self.seen.entry(state).or_insert_with(|| world.actions());
        // [Д-27 ПРЕРЕГ-ВАХТА: штампованная
        // витрина] расхождение штампа с живым
        // меню — числом ДО чинки (шестая
        // ипостась: menu-существенное вне ключа;
        // М-33 — прибор рода обязателен до казни)
        if watch_glass("MENU")
        {
            let live = world.actions();
            if self
                .seen
                .get(&state)
                .is_some_and(|st| *st != live)
            {
                self.menu_stale =
                    self.menu_stale
                        .saturating_add(1);
                if self.menu_stale <= 8 {
                    // генерик A без Debug — числа
                    // размеров говорят достаточно
                    eprintln!(
                        "ВИТРИНА-ШТАМП	ключ={state} штамп-длина={:?} живое-длина={}",
                        self.seen
                            .get(&state)
                            .map(Vec::len),
                        live.len()
                    );
                }
            }
        }
        // Ф-3.2: the docket court sits before the choice —
        // the writ (which frozen verdict may be heard) is
        // tended once per heartbeat
        // Docket and takeover were captured once outside the retry loop.
        if !dispatch.selection_prefix_done {
        // [VTE, G1_VTE-двойник] грёза на чекпойнте
        // мира ПЕРЕД советом (Redish-род: forward
        // sweep; прокат идёт МИМО тела — воображение
        // не свидетельство). Дорога кладётся планом,
        // исполнение печатается веткой 11.
        if forced.is_none()
            && std::env::var("G1_VTE").is_ok()
            && self.plan.is_empty()
            && self.vte_failed_at
                != Some(state)
        {
            // [ПРЕРЕГ-19] грёза — тоже патч MVT
            if self.dream_affordable() {
                let (found, spent) = match Self::vte_sweep(world) {
                    Ok(result) => result,
                    Err(failure) => {
                        self.action_failure = Some(failure.clone());
                        return Err(failure);
                    }
                };
                self.dream_nodes +=
                    u64::from(spent);
                if let Some(acts) = found {
                    self.vte_failed_at = None;
                    self.plan = acts.into();
                    self.plan_goal = None;
                    self.plan_expect = None;
                    self.plan_version =
                        self.map.version();
                    self.vte_plan = true;
                    self.dream_plans += 1;
                    self.dream_last_buy =
                        self.source_time.life_age();
                } else {
                    self.vte_failed_at = Some(
                        state,
                    );
                }
            } else {
                self.dream_muted += 1;
            }
        }
        // [ГРЁЗА ПРАВИЛАМИ, G1_RULEDREAM] дешёвый
        // ярус: дорога воображается купленными
        // правилами (без чекпойнта мира); гипотеза
        // взводится — сенсор-суд на прибытии
        if forced.is_none()
            && self.rule_armed()
            && self.plan.is_empty()
        {
            if let Some((road, goal)) =
                self.rule_sweep(world)
            {
                self.plan = road.into();
                self.plan_goal = None;
                self.plan_expect = None;
                self.plan_version =
                    self.map.version();
                self.vte_plan = true;
                self.rule_goal_armed = Some((
                    goal,
                    world
                        .progress()
                        .unwrap_or(0.0),
                ));
            }
        }
        // сенсор-суд гипотезы: план грёзы дожит —
        // вырос ли прогресс? нет → роль в могилу
        // (гипотеза казнена, редкость не была целью)
        if self.plan.is_empty()
            && let Some((role, p0)) =
                self.rule_goal_armed.take()
        {
            let grew = world
                .progress()
                .unwrap_or(0.0)
                > p0 + 1e-12;
            if !grew {
                let _ = self
                    .goal_role_graves
                    .bury(
                        self.source_time.life_age(),
                        role,
                        self.source_time.life_age(),
                        crate::holdings::Cause(
                            "dream_no_growth",
                        ),
                    );
            }
        }
        dispatch.selection_prefix_done = true;
        }
        // Classify caller input before touching the continuation queue. Both
        // the first macro step and its tail have the same semantic origin.
        // `forced` retains the existing outcome-accounting contract: a macro's
        // tail remains externally scheduled for Rent accounting in this change.
        let (decision, forced) = if let Some(command) = dispatch.command {
            command
        } else if let Some(action) = self.combo_queue.pop_front() {
            let command = (Decision::MacroProbe(action), Some(action));
            dispatch.command = Some(command);
            command
        } else if self.declared_task.is_some() && self.exhaust.as_ref().and_then(|ex|ex.program_agenda.as_ref()).is_some_and(|agenda|agenda.goal_directed()) {
            if let Some(request) = world.mile_act() {
                (Decision::WorldRequest(request),None)
            } else {
                if dispatch.menu.is_none() { dispatch.menu=Some(world.actions()); }
                if dispatch.menu.as_ref().unwrap().is_empty() { return Ok(StepOutcome::NoAction); }
                if dispatch.deliberation.is_none() {
                    dispatch.deliberation=Some(goal_selection::Deliberation::new(dispatch.menu.as_ref().unwrap().clone(),
                        self.declared_task.as_ref().unwrap().snapshot()));
                }
                let selection=dispatch.deliberation.as_mut().unwrap().advance(self,raw_state,&mut dispatch.capture,&mut dispatch.read);
                match selection {
                    Ok(Some(selected))=>{
                        dispatch.programs=Some(selected.programs); dispatch.prepared_for=Some(selected.action);
                        dispatch.forecasts=selected.forecasts;self.goal_report=Some(selected.report);
                        dispatch.deliberation=None;(Decision::GoalForecast(selected.action),None)
                    },
                    Ok(None)=>return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),BeforeActPhase::Reobserve,
                        Lane::Capture,None,Held::Execution(observer_chain::unavailable()))),
                    Err(observer_domain::ExecutionFailure::Native(fault))=>{
                        let mut cancellation=None;
                        if let Err((phase,held))=self.retire_before_retry(fault,&mut dispatch,Lane::Capture,&mut cancellation) {
                            return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),phase,Lane::Capture,cancellation,held));
                        }
                        continue;
                    },
                    Err(reason) if matches!(&reason,observer_domain::ExecutionFailure::Unavailable(r) if r.resource())=>
                        return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),BeforeActPhase::Reobserve,
                            Lane::Capture,None,Held::Execution(reason))),
                    Err(reason)=>{let failure=ActionFailure::begin(ActionStage::Decode,reason.to_string());
                        self.action_failure=Some(failure.clone());return Err(failure);},
                }
            }
        } else {
            match self.choose_action(state, takeover.is_some(), world) {
                Some(decision) => (decision, None),
                None => return Ok(StepOutcome::NoAction),
            }
        };
        dispatch.command = Some((decision, forced));
        if dispatch.menu.is_none() {
            dispatch.menu = Some(world.actions());
        }
        if !matches!(decision, Decision::CallerCommand(_) | Decision::MacroProbe(_)) {
            dispatch.request = Some(world.mile_act());
        }
        if dispatch.proposal.is_none() {
            dispatch.proposal = self.cancellation_for(decision, raw_state, state,
                ProposalCancellationReason::ReobserveAfterResource);
        }
        let action = decision.action();
        if dispatch.require_menu && !world.actions().contains(&action) {
            let cancellation = self.cancellation_for(decision, raw_state, state, ProposalCancellationReason::ReobserveAfterResource);
            return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), BeforeActPhase::CancelProposal,
                Lane::Read, cancellation, Held::MenuUnavailable(action)));
        }

        let physical_time = match self.source_time.point() {
            Ok(point) => point,
            Err(reason) => {
                let failure = ActionFailure::new(action, ActionStage::Budget, format!("source time preflight: {reason:?}"));
                self.action_failure = Some(failure.clone()); return Err(failure);
            },
        };
        let age_at_act = physical_time.metadata().life_age;
        // [СТЕКЛО-ВАХТА] ARC_WATCH_KEY=<dec>: полное
        // стекло каждого выбора на подозреваемом
        // ключе (кто привёл, что выбрал, баны/могила)
        if let Some(wk) = watch_val("KEY")
            && wk.split(',')
                .any(|k| k.trim().parse::<u64>() == Ok(raw_state))
        {
            let banned_now =
                self.banned(state, action);
            let ban_mass_now = self
                .bans
                .as_ref()
                .and_then(|b| {
                    b.get(&(state, action))
                })
                .copied()
                .unwrap_or(0);
            let adm =
                self.goal_admissible(state);
            let burials = self
                .goal_graves
                .burials(&state);
            eprintln!(
                "ВАХТА-КЛЮЧ\tstate={state:x} branch={} act_planned={} plan_len={} banned={banned_now} ban_mass={ban_mass_now} clears={} admissible={adm} burials={burials} tasks={}",
                self.last_branch,
                self.plan_is_task,
                self.plan.len(),
                self.ban_lang_clears,
                self.world_tasks.len()
            );
        }
        let acted = action;
        // [THE DOOR OF RULES] the frame before the gesture and the gesture's name for the door (a world without a
        // frame, or an organism whose rule dream is not armed, feeds nothing)
        let rule_pre = if self.rule_armed() {
            world
                .rule_frame()
                .zip(world.rule_act(action))
                .map(|(f, a)| (f, a, crate::optimality::level_of(world.key())))
        } else {
            None
        };
        if dispatch.prepared_for.is_some_and(|old| old != action) {
            dispatch.preparing = None;
            dispatch.programs = None;
            dispatch.reserving = None;
            dispatch.reservation = None; dispatch.registration = None;
            dispatch.prepared_for = None;
            dispatch.resource_reconsidered = false;
        }
        if self.exhaust.is_some() && dispatch.programs.is_none() {
            let menu = self.seen.get(&state).cloned().unwrap_or_default();
            let result = self.exhaust.as_mut().unwrap().name_actions(menu.into_iter().chain(std::iter::once(action)))
                .map_err(|reason| observer_domain::ExecutionFailure::Other(format!("action binding: {reason:?}")))
                .and_then(|()| {
                    if dispatch.preparing.is_none() {
                        dispatch.preparing = Some(observer_chain::Preparing::new(self, raw_state, age_at_act,
                            self.source_time.episode(), self.cur_pose, action)?);
                        dispatch.prepared_for = Some(action);
                    }
                    let preparing = dispatch.preparing.as_mut().unwrap();
                    if !preparing.matches(self, raw_state, age_at_act, self.source_time.episode(), self.cur_pose, action) {
                        return Err("changed representation preparation input".into());
                    }
                    preparing.advance(self, &mut dispatch.capture)
                        .and_then(|programs| programs.ok_or_else(observer_chain::unavailable))
                });
            match result {
                Ok(programs) => { dispatch.programs = Some(programs); dispatch.preparing = None; },
                Err(observer_domain::ExecutionFailure::Native(fault)) => {
                    let mut cancellation = self.cancellation_for(decision, raw_state, state, ProposalCancellationReason::UndefinedRepresentation);
                    if let Err((phase, held)) = self.retire_before_retry(fault, &mut dispatch, Lane::Capture, &mut cancellation) {
                        return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), phase, Lane::Capture, cancellation, held));
                    }
                    continue;
                }
                Err(reason) if matches!(&reason, observer_domain::ExecutionFailure::Unavailable(r) if r.resource()) => {
                    // A selected forecast owns its already-paid native Ticket. A plain
                    // resource pause does not invalidate that selection; current
                    // port/menu/owner changes still pass through discard_obsolete.
                    let retain_selected_goal = matches!(decision, Decision::GoalForecast(_));
                    let cancellation = (!(dispatch.resource_reconsidered || retain_selected_goal)).then(||
                        self.cancellation_for(decision, raw_state, state, ProposalCancellationReason::ReobserveAfterResource)).flatten();
                    let phase = if dispatch.resource_reconsidered || retain_selected_goal { BeforeActPhase::Reobserve } else { BeforeActPhase::CancelProposal };
                    return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), phase,
                        Lane::Capture, cancellation, Held::Execution(reason)));
                }
                Err(reason) => { let failure = ActionFailure::new(action, ActionStage::Budget, reason.to_string());
                    self.action_failure = Some(failure.clone()); return Err(failure); }
            }
        }
        if let (Some(ex), Some(programs)) = (&self.exhaust, &dispatch.programs) {
            let time=causal_coordinates::PreActionTime {episode:self.source_time.episode().expect("checked native episode"),life_age:age_at_act};
            if dispatch.reservation.as_ref().is_some_and(|r|!r.matches_pre_action(&ex.observer_history,time,
                raw_state,&programs.inputs,action,(self.cur_pose!=255).then_some(self.cur_pose),self.cur_sensory.as_ref())) {
                // Reobserved input is a new invocation. Dropping the old inner
                // guard cancels its registration, never a delivered action.
                dispatch.reservation=None;dispatch.registration=None;
            }
        }
        if dispatch.reservation.is_none() && let (Some(ex), Some(programs)) = (&self.exhaust, &dispatch.programs) {
            let reserved = (|| {
                if dispatch.reserving.is_none() {
                    dispatch.reserving = Some(ex.observer_history.reserving_in_layers_with_sensory(
                        physical_time.clone(),
                        raw_state, &programs.inputs, action, (self.cur_pose != 255).then_some(self.cur_pose), self.cur_sensory.clone())
                        .map_err(causal_coordinates::ReservationRefusal::History)?);
                }
                while !dispatch.reserving.as_mut().unwrap().advance(&ex.observer_history, &mut dispatch.capture.remaining)? {}
                Ok::<_, causal_coordinates::ReservationRefusal>(match dispatch.reserving.take().unwrap().finish() {
                    Ok(reservation) => reservation,
                    Err(_) => unreachable!("completed owned reservation"),
                })
            })();
            match reserved {
                Ok(reservation) => dispatch.reservation=Some(reservation),
                Err(reason) => {
                    // A selected forecast owns its already-paid native Ticket. A plain
                    // resource pause does not invalidate that selection; current
                    // port/menu/owner changes still pass through discard_obsolete.
                    let retain_selected_goal = matches!(decision, Decision::GoalForecast(_));
                    let cancellation = (!(dispatch.resource_reconsidered || retain_selected_goal)).then(||
                        self.cancellation_for(decision, raw_state, state, ProposalCancellationReason::ReobserveAfterResource)).flatten();
                    let phase = if dispatch.resource_reconsidered || retain_selected_goal { BeforeActPhase::Reobserve } else { BeforeActPhase::CancelProposal };
                    return Err(self.suspend_before_dispatch(dispatch, boundary.is_some(), phase,
                        Lane::Capture, cancellation, Held::Reservation(reason)));
                }
            }
        }
        if let (Some(ex),Some(reservation))=(&mut self.exhaust,&dispatch.reservation) {
            if let Some(agenda)=&mut ex.program_agenda {
                match agenda.register_goal_forecasts(&reservation.pre_action(),&mut dispatch.forecasts,&mut dispatch.capture) {
                    Ok(true)=>{},
                    Ok(false)=>return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),BeforeActPhase::Reobserve,
                        Lane::Capture,None,Held::Capacity("selected forecast registration work"))),
                    Err(reason)=>{let failure=ActionFailure::begin(ActionStage::Dispatch,reason);
                        self.action_failure=Some(failure.clone());return Err(failure);},
                }
                let registered=agenda.register_before(&reservation.pre_action(),
                    &mut dispatch.registration,&mut dispatch.capture);
                match registered {
                    Ok(true)=>{},
                    Ok(false)|Err(observer_acceptance::RegistrationStop::Work)=>{
                        return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),BeforeActPhase::Reobserve,
                            Lane::Capture,None,Held::Capacity("pre-action registration work exhausted")));
                    },
                    Err(observer_acceptance::RegistrationStop::Capacity)=>{
                        return Err(self.suspend_before_dispatch(dispatch,boundary.is_some(),BeforeActPhase::Reobserve,
                            Lane::Capture,None,Held::Capacity("pre-action registration retention capacity")));
                    },
                    Err(observer_acceptance::RegistrationStop::ChangedInvocation)=>{
                        let failure=ActionFailure::new(action,ActionStage::Dispatch,"changed pre-action registration owner");
                        self.action_failure=Some(failure.clone());return Err(failure);
                    },
                }
            }
        }
        break (state, decision, forced, action, age_at_act, acted, rule_pre, dispatch.programs.take(), dispatch.reservation.take());
        };
        if let Some(boundary) = boundary.as_mut()
            && !boundary.before(self, world, action)
        { return Ok(StepOutcome::NoAction); }
        self.stamp_the_appeal(state, action);
        let prepared = if let (Some(ex), Some(reservation)) = (&mut self.exhaust, reservation) {
            // The guard borrowed &Organism and the appeal stamp does not change
            // Timeline. Binding only checks identity; all resource work is paid.
            match reservation.bind(&mut ex.observer_history) {
                Ok(prepared) => Some(prepared.dispatch()),
                Err(_) => {
                    let failure = ActionFailure::new(action, ActionStage::Dispatch, "changed pre-dispatch reservation owner");
                    self.action_failure = Some(failure.clone()); return Err(failure);
                }
            }
        } else { None };
        self.action_attempts += 1;
        let captured_dispatch = match prepared {
            Some(pending) => causal_coordinates::CapturedDispatch::invoke_physical(pending, &mut self.source_time, |action| world.act_captured(action)),
            None => causal_coordinates::CapturedDispatch::untracked_physical(action, &mut self.source_time, |action| world.act_captured(action)),
        };
        let captured_dispatch = match captured_dispatch {
            Ok(dispatch) => dispatch,
            Err(reason) => {
                let failure = ActionFailure::new(action, ActionStage::Dispatch, format!("source time binding: {reason:?}"));
                self.action_failure = Some(failure.clone()); return Err(failure);
            },
        };
        let capture = captured_dispatch.capture();
        if capture.action() != &action {
            let failure = ActionFailure::new(action, ActionStage::Receive, "adapter returned foreign action evidence");
            self.action_failure = Some(failure.clone());
            return Err(failure);
        }
        let physical_after = matches!(capture.result(), Ok(ObservedAction::Step | ObservedAction::Refused |
            ObservedAction::Terminal { resumption: Resumption::Resumed, .. }))
            .then(|| sensory::PhysicalObservation::capture(world));
        let observed = if capture.check_successor(physical_after.as_ref().and_then(|s| s.sensory.as_ref())).is_err() {
            let cause = "captured successor contradicts the continuing physical observation";
            Err(match capture.result() {
                Ok(ObservedAction::Terminal { kind, .. }) =>
                    ActionFailure::after_action_terminal(action, ActionStage::Restart, cause, *kind),
                _ => ActionFailure::new(action, ActionStage::Receive, cause),
            })
        } else { capture.result().clone() };
        if let Some(boundary) = boundary.as_mut() {
            boundary.after(world, action, &observed);
        }
        // A restart may fail after the environment has already reported an
        // end. Keep that observed end and the infrastructure failure together:
        // it teaches no successor, and the run still returns the sticky error.
        let (observed, terminal_failure) = match observed {
            Ok(observed) => (observed, None),
            Err(failure) => match failure.observed_terminal(&action) {
                Some(terminal) => (terminal, Some(failure)),
                None => {
                    self.action_failure = Some(failure.clone());
                    return Err(failure);
                }
            },
        };
        let (observer_cut, capture, time_receipt) = match captured_dispatch.observed_physical() {
            Ok(completed) => completed,
            Err(_) => {
                let failure = ActionFailure::new(action, ActionStage::Receive,
                    "captured outcome does not belong to the reserved invocation");
                self.action_failure = Some(failure.clone());
                return Err(failure);
            }
        };
        if let Some(task) = &mut self.declared_task {
            if let Ok(actual) = capture.captured_outcome() {
                task.observe(&actual);
                let attempts=self.goal_attempts.entry(action).or_default();*attempts=attempts.saturating_add(1);
            }
        }
        let terminal = match observed {
            ObservedAction::Terminal { kind, resumption } => {
                self.terminal_receipts.push(TerminalReceipt { state: raw_state, age: age_at_act, action, kind, resumption });
                Some((kind, resumption))
            }
            ObservedAction::Step | ObservedAction::Refused => None,
        };
        let mut representation_witness = observer_cut.zip(programs).map(|(cut, programs)| self.finish_representation(state, raw_state, acted, age_at_act, cut, programs));
        if let Some(witness) = &mut representation_witness { witness.capture = Some(capture); }
        let act_res = observed.semantic_cut().map_or(Ok(()), Err);
        // [АКТ-УГАСАНИЕ — УЧЁТ] бесплодность =
        // мир не сдвинулся ИЛИ откатился в
        // корень (не из корня); подряд-счёт,
        // плодный сброс.
        // [МОГИЛА — ЗАКОН СВОБОДНОГО ВЫБОРА]
        // судная ветка (валентная раскатка,
        // проба опровержимости, любой
        // эксперимент тела над собой) — не
        // свободный выбор, а ИНСТРУМЕНТ СУДА:
        // инструменту могила не судья, иначе
        // тело теряет право проверять себя
        // (род «сон бесплатен каналу»: платится
        // сказанное, не кандидат). Счётчик
        // движется ТОЛЬКО на актах своей жизни.
        // Mortality is an observed action outcome even when no successor exists.
        // A clock expiry or unspecified completion is not evidence of mortality;
        // the resumed/reset state is never inspected to price this terminal.
        if forced.is_none()
            && matches!(observed, ObservedAction::Terminal { kind: TerminalKind::Death, .. })
        {
            self.barren.entry((state, action)).or_default().died(
                u32::from(crate::law::LAW_OF_REPETITION),
            );
        }
        if forced.is_none() && terminal.is_none() {
            let after = world.key();
            let rootish = self
                .root
                .is_some_and(|r| {
                    after == r
                        && raw_state != r
                });
            // [СМЕРТЬ ХОРОНИТ СРАЗУ] гибель —
            // бесплодность высшего рода: одно
            // свидетельство достаточно, цена
            // жизни выше цены пробы (ka59 с
            // макро-парами: deaths 3→106 при
            // том же множестве состояний —
            // пары исследовались ценой гибели).
            let died = matches!(observed, ObservedAction::Refused);
            // [ПЛАТА ОТМЕНЯЕТ БЕСПЛОДНОСТЬ]
            // возврат в корень бывает НАГРАДОЙ:
            // в эпизодическом мире достижение
            // цели телепортирует в старт, и такой
            // «откат» — не пустота, а оплаченный
            // успех (суд коридора: 245 хитов
            // упали до 5, потому что каждый хит
            // читался как бесплодный возврат).
            // Мир платит прогрессом — рост
            // прогресса есть новизна высшего
            // рода, как гибель есть бесплодность
            // высшего рода.
            let paid_now = world
                .progress()
                .is_some_and(|p| {
                    p > self.progress_seen
                });
            if let Some(p) = world.progress() {
                self.progress_seen =
                    self.progress_seen.max(p);
            }
            // [БЕСПЛОДНОСТЬ = ОТСУТСТВИЕ НОВИЗНЫ]
            // возврат в корень — не бесплодность
            // сам по себе: в ЦИКЛИЧЕСКОМ мире это
            // ПЕРИОД (ровно то, что покупает язык
            // орбиты — ℤ₆ с периодом 3); он
            // становится бесплодным лишь когда
            // прожит LAW раз и новизны в нём нет.
            // Мир, буквально не сдвинувшийся, —
            // бесплоден всегда; гибель хоронит
            // сразу.
            let stale_loop = rootish && {
                let ck = self.coined_key(
                    raw_state,
                    self.since_root,
                );
                self.map
                    .outcomes(ck, action)
                    .is_some_and(|m| {
                        m.values().sum::<u32>()
                            >= u32::from(
                                crate::law::LAW_OF_REPETITION,
                            )
                    })
            };
            let law32 = u32::from(
                crate::law::LAW_OF_REPETITION,
            );
            let e = self
                .barren
                .entry((state, action))
                .or_default();
            if died {
                e.died(law32);
            } else {
                // новизна = мир сдвинулся и не в
                // прожитую петлю (закон ценза),
                // ЛИБО мир заплатил прогрессом
                let novel = paid_now
                    || (after != raw_state
                        && !stale_loop);
                e.live(novel, 0.0);
            }
        }
        // [THE DOOR OF RULES] the tick lived is a show of the door; the model is bought again where the world
        // contradicted it, and the lived change witnesses its question of dynamics (the belief market's live seam)
        if terminal.is_none()
            && let Some((pre, act, level_pre)) = rule_pre
            && let Some(post) = world.rule_frame()
        {
            let died = matches!(act_res, Err(Cut::Death));
            let took = crate::optimality::level_of(world.key()) > level_pre;
            self.live_rules(pre, post, act, died, took);
        }
        let applied_time = match self.source_time.commit(time_receipt) {
            Ok(applied) => applied,
            Err((reason, _receipt)) => {
                let failure = ActionFailure::new(action, ActionStage::Receive, format!("source time commit: {reason:?}"));
                self.action_failure = Some(failure.clone()); return Err(failure);
            }
        };
        if let Some(ex) = &self.exhaust {
            for floor in &ex.floors { floor.observer.source_physical_commit(&applied_time); }
        }
        if let Err(cut) = act_res {
            // [M-1654] a clock's cut ends the life as a death
            // does, but it is no voice of the gesture: the
            // guilt ledgers below (the events court's window,
            // the graves, the deadly witness, the buried goal)
            // hear only Death and Refusal
            let guilty = matches!(cut, Cut::Death | Cut::Refusal);
            if let Some(ex) = &mut self.exhaust
                && guilty
            {
                match cut {
                    Cut::Death => ex.life_deaths += 1,
                    Cut::Refusal => {
                        ex.life_refusals += 1;
                    }
                    Cut::Time | Cut::Completed | Cut::Ended => {}
                }
                // both no-step voices turn the window
                // suspect — a wall and a door are equally
                // worth the events-only court's ear
                ex.window_deaths.insert(state);
            }
            let vb = self.visits_of(state);
            if let Some(bans) = &mut self.bans
                && guilty
            {
                // both voices dig the grave (Z-6): a
                // refused gesture and a deadly one alike
                // are «this gesture leads nowhere here»
                *bans.entry((state, action)).or_insert(0) +=
                    1;
                *self
                    .deadly_bans
                    .entry((state, action))
                    .or_insert(0) += 1;
                self.ban_at
                    .insert((state, action), vb);
                let d = bans[&(state, action)];
                self.glass(|| format!(
                    "{{\"ev\":\"ban\",\"rod\":\"self\",\"k\":{state},\"bans\":{d}}}"
                ));
            }
            if matches!(cut, Cut::Death | Cut::Time | Cut::Completed | Cut::Ended) {
                self.pending_goal_fire = None;
                self.transfer_pending = None;
                self.swap_pending = None;
                // The observed episode boundary invalidates pending execution,
                // regardless of a historical plan's proposed reset. Only an
                // actual death contributes to the death-specific plan counters.
                if !self.plan.is_empty() {
                    if self.plan_is_task && cut == Cut::Death {
                        self.task_plan_death[3] += 1;
                        self.tear_kinds[1] += 1;
                        self.note_hold_torn();
                    }
                    self.plan_is_task = false;
                    self.watch_plan_kill(15520);
                    self.plan.clear();
                    self.plan_expect = None;
                    self.plan_goal = None;
                }
                let tick_pre = self.since_root;
                self.since_root = 0;
                let coined_pre = self.coined_key(
                    raw_state, tick_pre,
                );
                self.unmint
                    .insert(coined_pre, raw_state);
                // The legacy map consumes a binary mortality classification.
                // An undifferentiated end is retained above, but supplies no
                // positive or negative mortality vote to that narrower carrier.
                if cut != Cut::Ended {
                self.map.note(
                    coined_pre,
                    acted,
                    crate::worldmap::Outcome::End(match cut {
                        Cut::Death => 1u8, Cut::Time => 2, Cut::Completed => 3,
                        Cut::Ended => 4, Cut::Refusal => unreachable!("terminal branch"),
                    }),
                );
                // Г1-2: маргинал смертного исхода
                self.map.mark_tick(
                    self.coined_key(
                        raw_state, tick_pre,
                    ),
                    acted,
                    &crate::worldmap::Outcome::End(match cut {
                        Cut::Death => 1u8, Cut::Time => 2, Cut::Completed => 3,
                        Cut::Ended => 4, Cut::Refusal => unreachable!("terminal branch"),
                    }),
                    u64::from(tick_pre),
                );
                self.coin_tacts += 1;
                self.live_tape.push_back((
                    raw_state,
                    acted,
                    crate::worldmap::Outcome::End(match cut {
                        Cut::Death => 1u8, Cut::Time => 2, Cut::Completed => 3,
                        Cut::Ended => 4, Cut::Refusal => unreachable!("terminal branch"),
                    }),
                    tick_pre,
                ));
                if self.live_tape.len() > 4096 {
                    self.live_tape.pop_front();
                }
                }
                if guilty {
                    self.glue_witness(
                        state,
                        action,
                        GlueOutcome::Death,
                    );
                }
                // СК: the second lived cadence — the
                // life boundary is the moment of
                // reflection (boredom never comes in a
                // 60-tick world; death always does)
                if self.glue_on {
                    // граница смерти: уроки смертельных
                    // фаз свежайшие — сидка рынка
                    // координат здесь же, где рынок
                    // склейки (вторая прожитая граница)
                    self.coin_coords_market();
                    self.glue_market();
                }
                if cut != Cut::Ended { self.steer_judge(guilty); }
                if let Some(g) = self.plan_goal.take()
                    && guilty
                {
                    let vg = self.visits_of(g);
                    let b = self.goal_graves.bury(
                        self.source_time.life_age(),
                        g,
                        vg,
                        crate::holdings::Cause(
                            "plan_death",
                        ),
                    );
                    self.glass(|| format!(
                        "{{\"ev\":\"burial\",\"rod\":\"passive\",\"goal\":{g},\"cause\":\"plan_death\",\"burials\":{b}}}"
                    ));
                }
            }
        } else {
            let moved_now =
                world.key() != raw_state;
            if moved_now {
                self.moved_since_reset = true;
            }
            if Some(action) == world.reset_action()
            {
                // цикл закрыт — новый обязан
                // заработать свой ресет походом
                self.moved_since_reset = moved_now;
                self.novel_since_reset = false;
                // [ПРЕРЕГ-6 УТОЧНЁН СУДОМ РУКАВОВ]
                // ТЕЛЕПОРТ РВЁТ ПЛАН, НО ТОЛЬКО
                // ЧУЖОЙ: свой ЗАПЛАНИРОВАННЫЙ
                // прыжок (ресет — шаг самого плана,
                // plan_edge такт-в-такт) — законное
                // ребро дороги: Дейкстра клала его
                // зная post, хвост строился ОТ
                // корня. Опровержимость цела: burn-
                // суд следующего такта (exp vs
                // state) казнит враньё таблицы.
                // Шрам «1307 прогулок» — о ЧУЖОМ
                // ресете (хвост от старого места
                // слеп) — рвач для него стоит.
                // e-числа ft09: 16901 из 16901
                // рвачей были шагом плана — ложный
                // палач съедал всю доставку.
                // G1_PLAN_SURVIVES_TP=1 —
                // архив-двойник (диагностика).
                let planned_jump = self.plan_edge
                    == Some((
                        raw_state,
                        self.since_root,
                        action,
                    ));
                if planned_jump
                    && !self.plan.is_empty()
                {
                    // прыжок пережит планом
                    self.tear_kinds[3] += 1;
                }
                if std::env::var(
                    "G1_PLAN_SURVIVES_TP",
                )
                .is_err()
                    && !self.plan.is_empty()
                    && !planned_jump
                {
                    if self.plan_is_task {
                        self.task_plan_death
                            [3] += 1;
                        self.tear_kinds[2] += 1;
                        self.plan_is_task = false;
                        // [ПРЕРЕГ-18] рвач — не
                        // попытка; [ЦЕЛЬ-ПАМЯТЬ]
                        // намерение живёт, но кап
                        // LAW² рвачей отпускает
                        // (вечный ресет-мир не
                        // держит цель навсегда)
                        self.note_hold_torn();
                    }
                    self.watch_plan_kill(15658);
                    self.plan.clear();
                    self.plan_expect = None;
                    self.plan_goal = None;
                }
            }
            self.glue_witness(
                state,
                action,
                if world.key() == raw_state {
                    GlueOutcome::Stayed
                } else {
                    GlueOutcome::Moved
                },
            );
            // КАРТА: СЫРЫЕ ключи мира + активные
            // координаты Т-КЛЮЧ (канон: чеканка — рынок
            // НАД картой; свежие чеканенные рёбра копят
            // чистую массу инкрементально)
            let tick_pre = self.since_root;
            let next_raw = world.key();
            let tick_next = if self
                .root_raw
                .is_some_and(|rr| {
                    self.try_eyed(next_raw).ok().zip(self.try_eyed(rr).ok()).is_some_and(|(a, b)| a == b)
                }) {
                0
            } else {
                tick_pre + 1
            };
            self.since_root = tick_next;
            let out = crate::worldmap::Outcome::Next(
                self.coined_key(
                    next_raw, tick_next,
                ),
            );
            {
                let coined_pre = self.coined_key(
                    raw_state, tick_pre,
                );
                self.unmint.insert(
                    coined_pre, raw_state,
                );
            }
            self.map.note(
                self.coined_key(
                    raw_state, tick_pre,
                ),
                acted,
                out.clone(),
            );
            // Г1-2: тик-маргинал живого времени
            self.map.mark_tick(
                self.coined_key(
                    raw_state, tick_pre,
                ),
                acted,
                &out,
                u64::from(tick_pre),
            );
            self.coin_tacts += 1;
            self.live_tape.push_back((
                raw_state,
                acted,
                crate::worldmap::Outcome::Next(
                    next_raw,
                ),
                tick_pre,
            ));
            if self.live_tape.len() > 4096 {
                self.live_tape.pop_front();
            }
            if let Some(ex) = &mut self.exhaust
                && world.key() != raw_state
            {
                ex.window_moves.insert(state);
            }
            // [ПРЕРЕГ-7б v3] ОПРОВЕРЖЕНИЕ МАССОЙ
            // ЖИВЫХ: лёгкий бан (< LAW) снимается
            // одним проживанием (Cor. 18.9);
            // ТЯЖЁЛЫЙ (>= LAW) — только LAW живых
            // ПОДРЯД: одно выживание — случайность
            // (вахта P: 13 из 581 размораживали
            // убийцу), серия — смена мира
            // (ForcedGate-канон жив).
            let ban_mass = self
                .deadly_bans
                .get(&(state, action))
                .copied()
                .unwrap_or(0);
            // [7б-v4 МАЖОРИТАРНОЕ ОПРОВЕРЖЕНИЕ,
            // S-род]: тяжёлый бан снимается, когда
            // ЖИВЫЕ проживания ребра сравняются со
            // смертной массой (большинство сменилось)
            // — убийца 13/568 заперт навсегда;
            // стенды после смены мира зеленеют
            // (живые быстро превышают старую массу;
            // Cor.18.9 жив в мажоритарной форме).
            let heavy_refuted = if self
                .retest_simple
                || std::env::var(
                    "G1_RETEST_SIMPLE",
                )
                .is_ok()
            {
                true
            } else if ban_mass
                >= crate::law::LAW_OF_REPETITION
            {
                let st = self
                    .retest_streak
                    .entry((state, action))
                    .or_insert(0);
                *st += 1;
                *st >= ban_mass
            } else {
                true
            };
            if watch_glass("RETEST")
                && self
                    .bans
                    .as_ref()
                    .is_some_and(|b| {
                        b.contains_key(&(
                            state, action,
                        ))
                    })
            {
                eprintln!(
                    "RETEST\ts={state:x} a?=... mass={ban_mass} streak={:?} heavy_ok={heavy_refuted}",
                    self.retest_streak
                        .get(&(state, action))
                );
            }
            if let Some(bans) = &mut self.bans
                && heavy_refuted
                && bans.remove(&(state, action)).is_some()
            {
                self.retest_streak
                    .remove(&(state, action));
                self.deadly_bans
                    .remove(&(state, action));
                self.glass(|| format!(
                    "{{\"ev\":\"retest\",\"rod\":\"self\",\"k\":{state}}}"
                ));
                // REFUTATION: a lived passage through a
                // banned transition lifts the verdict —
                // frozen-until-contradiction, never
                // re-judged per reading (Cor. 18.9)
            }
        }
        if let Some((kind, resumption)) = terminal {
            let revision = self.note_observed_action(state, acted, ObservedWorldOutcome::End(kind));
            self.witness_the_world(representation_witness, ObservedWorldOutcome::End(kind));
            self.finish_observed_revision(state, acted, revision);
            self.source_time.close_terminal().expect("the physical terminal receipt owns episode closure");
            self.close_episode();
            if let Some(failure) = terminal_failure {
                self.action_failure = Some(failure.clone());
                return Err(failure);
            }
            // A resumed episode has an adapter-owned current observation.
            // Chronicle it without making it this terminal action's successor.
            // Stopped/failed resumptions provide no such observation.
            if resumption == Resumption::Resumed {
                let resumed_raw = self.sample_captured_observation(physical_after.expect("captured resumed observation"));
                self.heartbeat(resumed_raw);
            }
            if resumption == Resumption::Stopped {
                self.action_stop = Some((action, kind));
                return Ok(StepOutcome::Stopped { action, terminal: kind });
            }
            // This pulse reports the completed boundary, not a motion edge.
            // No post-reset state has been used as evidence for this action.
            return Ok(StepOutcome::Pulse(Pulse {
                action, novel: false, climate: 0.0, takeover,
            }));
        }
        let successor_raw = self.sample_captured_observation(physical_after.expect("captured continuing observation"));
        self.heartbeat(successor_raw);
        let mut post_work = ObserverWork { remaining: self.exhaust.as_ref().map_or(0, |ex| ex.observer_work) };
        let mut successor = Successor { state, raw: successor_raw, acted, observed, takeover,
            witness: representation_witness.take(), progress: world.progress(),
            menu: world.actions(), features: world.observe() };
        let mut reading = observer_chain::Reading::new(self, successor_raw,
            self.source_time.life_age(), self.source_time.episode(), self.cur_pose).with_sensory(self.cur_sensory.clone());
        let result = reading.advance(self, &mut crate::program::observer::Budget::new(
            &mut post_work, crate::program::ExecutionLimit::Unlimited))
            .and_then(|value| value.ok_or_else(observer_chain::unavailable));
        let nxt = match result {
            Ok(key) => key,
            Err(observer_domain::ExecutionFailure::Native(fault)) => {
                let outcome = match observed { ObservedAction::Step => ObservedWorldOutcome::Next(successor_raw),
                    ObservedAction::Refused => ObservedWorldOutcome::Refused(successor_raw),
                    ObservedAction::Terminal { .. } => unreachable!("terminal returned above") };
                let actual = successor.witness.as_ref().map(|w| (std::sync::Arc::new(w.cut.clone()), outcome));
                self.record_world_outcome(successor.witness.take(), outcome, false);
                return self.finish_domain_boundary(world, acted, takeover, fault, actual, &mut post_work);
            }
            Err(reason) if matches!(&reason, observer_domain::ExecutionFailure::Unavailable(r) if r.resource()) => {
                return self.begin_after_act_read(successor, reading, reason, &mut post_work);
            }
            Err(reason) => {
                let outcome = match observed { ObservedAction::Step => ObservedWorldOutcome::Next(successor_raw),
                    ObservedAction::Refused => ObservedWorldOutcome::Refused(successor_raw),
                    ObservedAction::Terminal { .. } => unreachable!("terminal returned above") };
                self.witness_the_world(successor.witness.take(), outcome);
                let failure = ActionFailure::new(acted, ActionStage::Decode, reason.to_string());
                self.action_failure = Some(failure.clone()); return Err(failure);
            }
        };
        self.finish_successor(successor, nxt)
    }

    fn finish_successor(&mut self, successor: Successor<A>, nxt: u64)
        -> Result<StepOutcome<A>, ActionFailure<A>>
    {
        let Successor { state, raw: successor_raw, acted, observed, takeover,
            witness: representation_witness, progress, menu, features } = successor;
        // РЫНОК ЦЕЛЕЙ: строгий рост прогресс-сенсора
        // рождает цель-класс прибытия (стекло:
        // goal_birth); первый тик лишь калибрует.
        let pr =
            progress.unwrap_or(-1.0);
        let grew = pr >= 0.0
            && self.prev_progress >= 0.0
            && pr > self.prev_progress + 1e-9;
        // СУД ОБЕЩАНИЯ: выстрел = хвост-акт пары
        // сыгран ИЗ класса-источника последним шагом
        // плана В ЭТОТ тик (plan_edge). Прошлая форма
        // «план пуст» отставала от хита: exam-рука
        // успевала построить фронтир-план, prev
        // догонял сенсор — ложный приговор (стекло:
        // buy t=85, суд t=96, pr==prev). Не дошёл /
        // план замещён — не судим (обещание
        // перезапишет следующая покупка).
        // суд переноса (ступень-2): акт сыгран из
        // чужого класса — сенсор выносит вердикт
        if let Some((tcur, tpair)) =
            self.transfer_pending.take()
        {
            if grew {
                // перенос ОКУПИЛСЯ: новая пара
                // текущего источника рождается тем же
                // законом (вес-скорость шага = Δp)
                let dp = pr - self.prev_progress;
                self.progress_goals.born_or(
                    self.source_time.life_age(),
                    (tcur, tpair.1),
                    dp,
                    |old, new| {
                        if *old < new {
                            *old = new;
                        }
                    },
                );
                self.glass(|| format!(
                    "{{\"ev\":\"transfer_paid\",\"rod\":\"self\",\"at\":{tcur}}}"
                ));
            } else {
                self.tried_transfers
                    .insert((tcur, tpair));
                self.glass(|| format!(
                    "{{\"ev\":\"transfer_refuted\",\"rod\":\"self\",\"at\":{tcur}}}"
                ));
            }
        }
        if let Some(pair) = self.pending_goal_fire {
            let fired = self.plan.is_empty()
                && self.plan_edge.is_some_and(
                    |(er, _et, ea)| {
                        ea == pair.1
                            && self.try_eyed(er).is_ok_and(|key| key == pair.0)
                    },
                );
            if fired {
                self.pending_goal_fire = None;
                let (pv, age) = (
                    self.prev_progress,
                    self.source_time.life_age(),
                );
                self.glass(|| format!(
                    "{{\"ev\":\"goal_court\",\"rod\":\"self\",\"k\":{},\"grew\":{grew},\"at\":{nxt},\"pr\":{pr:.4},\"prev\":{pv:.4},\"t\":{age}}}",
                    pair.0
                ));
                // [ЖИВОЙ ПОТРЕБИТЕЛЬ] сенсор-суд
                // пары = прямое свидетельство
                // вопроса прогресса пары; пара —
                // держание, стоящее на своём
                // вопросе (биты = подтверждения)
                {
                    let qp = {
                        let mut h = 0xcbf2_9ce4_8422_2325u64;
                        for v in [pair.0, {
                            let mut bs = Vec::new();
                            pair.1.w(&mut bs);
                            let mut hh = 0xcbf2_9ce4_8422_2325u64;
                            for b in bs {
                                hh ^= u64::from(b);
                                hh = hh.wrapping_mul(0x0000_0100_0000_01b3);
                            }
                            hh
                        }] {
                            for byte in v.to_le_bytes() {
                                h ^= u64::from(byte);
                                h = h.wrapping_mul(0x0000_0100_0000_01b3);
                            }
                        }
                        h
                    };
                    self.belief_market.witness(
                        qp,
                        u64::from(grew),
                    );
                    if let Some(hld) = self
                        .progress_goals
                        .get(&pair)
                    {
                        self.belief_market
                            .depends(
                                qp ^ 1,
                                qp,
                                f64::from(
                                    hld.confirmations,
                                ),
                            );
                    }
                }
                if grew {
                    // [КУРС-ЛЕДЖЕР] закрыть прошлую
                    // строку обмена (что открыло
                    // прошлое взятие) и открыть новую
                    if let Some((
                        dv,
                        s0,
                        t0,
                    )) = self.goal_rate_open.take()
                    {
                        self.goal_rate.push((
                            dv,
                            (self.seen.len()
                                - s0.min(
                                    self.seen
                                        .len(),
                                ))
                                as u64,
                            (self.table.len()
                                - t0.min(
                                    self.table
                                        .len(),
                                ))
                                as u64,
                        ));
                    }
                    self.goal_rate_open = Some((
                        pr - self.prev_progress,
                        self.seen.len(),
                        self.table.len(),
                    ));
                    self.progress_goals.confirm(
                        self.source_time.life_age(),
                        pair,
                    );
                    // ВЕС = СКОРОСТЬ (регрет-этаж как
                    // валюта рынка): Δp/шаги похода —
                    // merge-max отдаёт цель быстрейшей
                    // дороге (2x2-урок: вес-скачок
                    // гвоздил ПЕРВУЮ дорогу, best 24
                    // при прожитых 18/13)
                    if let Some((wg, st)) =
                        self.cur_walk
                        && wg == pair.0
                    {
                        let steps = self.source_time.life_age()
                            .saturating_sub(st)
                            .max(1);
                        let dp = pr
                            - self.prev_progress;
                        let speed =
                            dp / steps as f64;
                        self.progress_goals
                            .born_or(
                            self.source_time.life_age(),
                            pair,
                            speed,
                            |old, new| {
                                if *old < new {
                                    *old = new;
                                }
                            },
                        );
                    }
                } else if self
                    .progress_goals
                    .die(
                        self.source_time.life_age(),
                        pair,
                        crate::holdings::Cause(
                            "sensor_silent",
                        ),
                    )
                    .is_some()
                {
                    self.glass(|| format!(
                        "{{\"ev\":\"goal_refuted\",\"rod\":\"self\",\"k\":{}}}",
                        pair.0
                    ));
                }
            }
        }
        if grew {
            let w = pr - self.prev_progress;
            let before =
                self.progress_goals.len();
            self.progress_goals.born_or(
                self.source_time.life_age(),
                (state, acted),
                w,
                |old, new| {
                    if *old < new {
                        *old = new;
                    }
                },
            );
            if self.progress_goals.len() > before {
                self.glass(|| format!(
                    "{{\"ev\":\"goal_birth\",\"rod\":\"self\",\"k\":{state},\"w\":{w:.3}}}"
                ));
            }
        }
        self.prev_progress = pr;
        let novel = !self.seen.contains_key(&nxt);
        if novel {
            self.novel_since_reset = true;
        }
        // [НОВИЗНА-2] класс жеста прожил такт; открыл
        // ли он НОВОЕ место — леджер открытий
        {
            let sg = self.glue_sig_of(state);
            let e = self
                .sig_novel
                .entry((sg, acted))
                .or_insert((0, 0));
            e.1 += 1;
            if novel {
                e.0 += 1;
            }
        }
        *self.arrivals.entry(nxt).or_insert(0) += 1;
        self.seen.entry(nxt).or_insert(menu);
        let named_outcome = match observed {
            ObservedAction::Step => ObservedWorldOutcome::Next(nxt),
            ObservedAction::Refused => ObservedWorldOutcome::Refused(nxt),
            ObservedAction::Terminal { .. } => unreachable!("terminal branch completed"),
        };
        let revision = self.note_observed_action(state, acted, named_outcome);
        // регрет-этаж: старт/смена похода — одна
        // точка наблюдения (любая рука, любой орган)
        match (self.plan_goal, self.cur_walk) {
            (Some(g), Some((wg, _))) if wg == g => {
                self.walk_acts.push(acted);
            }
            (Some(g), _) => {
                self.cur_walk =
                    Some((g, self.source_time.life_age()));
                self.walk_acts.clear();
                self.walk_acts.push(acted);
            }
            (None, _) => {
                self.walk_acts.clear();
            }
        }
        if self.plan_goal == Some(nxt) {
            // регрет-этаж: прибытие свидетельствует
            // шаги похода против собственного best
            if let Some((wg, start)) =
                self.cur_walk.take()
                && wg == nxt
            {
                let steps = self.source_time.life_age()
                    .saturating_sub(start)
                    .max(1);
                let e = self
                    .goal_regret
                    .entry(nxt)
                    .or_insert((steps, 0, 0));
                if steps < e.0 {
                    e.0 = steps;
                }
                e.1 += steps - e.0;
                e.2 += 1;
                let (best0, n2) = (e.0, e.2);
                self.glass(|| format!(
                    "{{\"ev\":\"walk\",\"rod\":\"self\",\"goal\":{nxt},\"steps\":{steps},\"best\":{best0},\"n\":{n2}}}"
                ));
                if let Some((sg, skey)) =
                    self.swap_pending
                    && sg == nxt
                {
                    self.skills.confirm(
                        self.source_time.life_age(),
                        skey,
                    );
                    self.swap_pending = None;
                }
                // СТУПЕНЬ-3: тело успешного похода —
                // кандидат навыка (LAW=2 чеканит,
                // точный MDL-суд покупает)
                let body =
                    std::mem::take(&mut self.walk_acts);
                if body.len() >= 2 {
                    self.walk_steps_total +=
                        body.len() as u64;
                    let fnv = {
                        let mut h: u64 =
                            0xcbf2_9ce4_8422_2325;
                        for a in &body {
                            let mut bs = Vec::new();
                            a.w(&mut bs);
                            for b in bs {
                                h ^= u64::from(b);
                                h = h.wrapping_mul(
                                    0x0000_0100_0000_01b3,
                                );
                            }
                        }
                        h
                    };
                    let key = (nxt, fnv);
                    let c = self
                        .skill_counts
                        .entry(key)
                        .or_insert(0);
                    *c += 1;
                    let count = *c;
                    match self
                        .skill_bodies
                        .entry(key)
                    {
                        std::collections::hash_map::Entry::Occupied(mut e) => {
                            if body.len()
                                < e.get().len()
                            {
                                e.insert(body);
                            }
                        }
                        std::collections::hash_map::Entry::Vacant(e) => {
                            e.insert(body);
                        }
                    }
                    if count
                        >= u32::from(
                            crate::law::LAW_OF_REPETITION,
                        )
                        && self.skills
                            .get(&key)
                            .is_none()
                    {
                        // ТОЧНЫЙ MDL ПО ПРОЖИТОМУ:
                        // алфавит |A| из меню цели,
                        // до = total·log2A; после =
                        // (total − uses·(len−1))·
                        // log2(A+1) + len·log2(A+1)
                        let blen = self.skill_bodies
                            [&key]
                            .len()
                            as f64;
                        let uses = f64::from(count);
                        let alen = self
                            .seen
                            .get(&nxt)
                            .map_or(2.0, |m| {
                                m.len().max(2) as f64
                            });
                        let total = self
                            .walk_steps_total
                            as f64;
                        let before =
                            total * alen.log2();
                        let after = (total
                            - uses * (blen - 1.0))
                            .max(0.0)
                            * (alen + 1.0).log2()
                            + blen
                                * (alen + 1.0)
                                    .log2();
                        if after < before {
                            let b = self
                                .skill_bodies[&key]
                                .clone();
                            self.skills.born_or(
                                self.source_time.life_age(),
                                key,
                                b,
                                |_o, _n| {},
                            );
                            self.glass(|| format!(
                                "{{\"ev\":\"skill_buy\",\"rod\":\"self\",\"goal\":{nxt},\"len\":{},\"uses\":{count},\"gain\":{:.1}}}",
                                blen as u64,
                                before - after
                            ));
                        }
                    }
                }
            }
            // ПРИБЫТИЕ СУДИТ ДОЛГ — ПОСЛЕ леджеров шага
            // (гонка: суд до witness видел живой долг,
            // который тот же шаг съедал складкой): долг
            // жив — могила опровергнута; долга нет —
            // цель-лгунья хоронится и спит могильным
            // законом (вечный план к ней падает)
            let debt_alive = std::env::var(
                "G1_NO_ARRIVAL_JUDGE",
            )
            .is_ok()
                || (!self
                    .untried(nxt)
                    .is_empty()
                    && self.debt_collectable(nxt))
                || self.underpaid(nxt);
            self.glass(|| format!(
                "{{\"ev\":\"arrival\",\"rod\":\"stream\",\"goal\":{nxt},\"debt_alive\":{debt_alive}}}"
            ));
            self.steer_judge(false);
            if debt_alive {
                // прощение свидетельством: долг жив
                if self.goal_graves.forgive(
                    self.source_time.life_age(),
                    nxt,
                    crate::holdings::Cause(
                        "debt_alive",
                    ),
                ) {
                    self.glass(|| format!(
                        "{{\"ev\":\"grave_forgive\",\"rod\":\"stream\",\"goal\":{nxt},\"cause\":\"debt_alive\"}}"
                    ));
                }
                self.just_arrived = Some(nxt);
            } else {
                // ШРАМ БЕЗМОЛВНОГО МОГИЛЬЩИКА: эти
                // похороны душили рынок целей 1914
                // тиков невидимо — теперь причина и
                // стекло обязательны
                let vg = self.visits_of(nxt);
                let b = self.goal_graves.bury(
                    self.source_time.life_age(),
                    nxt,
                    vg,
                    crate::holdings::Cause(
                        "debt_dead",
                    ),
                );
                self.glass(|| format!(
                    "{{\"ev\":\"burial\",\"rod\":\"stream\",\"goal\":{nxt},\"cause\":\"debt_dead\",\"burials\":{b}}}"
                ));
            }
            self.plan_goal = None;
        }
        // witnessed AFTER the geography writes: a purchase
        // climbs the eye and sheds every old-language entry,
        // this tick's included — zero pollution by order
        let outcome=match observed {
            ObservedAction::Step=>ObservedWorldOutcome::Next(successor_raw),
            ObservedAction::Refused=>ObservedWorldOutcome::Refused(successor_raw),
            ObservedAction::Terminal{..}=>unreachable!("terminal outcome was witnessed before episode close"),
        };
        self.witness_the_world(representation_witness, outcome);
        self.finish_observed_revision(state, acted, revision);

        Ok(StepOutcome::Pulse(self.feed_observed_features(&features, acted, novel, takeover)))
    }

    fn feed_observed_pulse<H: Habitat<Action = A>>(&mut self, world: &H, acted: A,
        novel: bool, takeover: Option<Takeover>) -> Pulse<A>
    {
        self.feed_observed_features(&world.observe(), acted, novel, takeover)
    }

    fn feed_observed_features(&mut self, features: &[f64; 7], acted: A,
        novel: bool, takeover: Option<Takeover>) -> Pulse<A>
    {
        let food = food_from_features(features, &self.anchor);
        let before = *self.tower.level(0);
        for _ in 0..self.feed_ticks {
            self.tower.tick_fed(&food, None, self.gamma, self.dt);
        }
        if self.injection > 0.0 {
            self.tower.inject_base(&food, self.injection);
        }
        if self.attention > 0.0 {
            self.tower.attention_lift(self.attention_kind, self.attention);
        }
        if let Some(o) = self.organs.as_mut() {
            o.on_food(&food);
            if self.organ_feedback > 0.0 {
                let children: Vec<Gamma> = o
                    .spawned_lines
                    .iter()
                    .filter_map(|&l| o.body.child(l))
                    .map(|c| *c.gamma())
                    .collect();
                for child in children {
                    self.tower
                        .inject_base(&child, self.organ_feedback);
                }
            }
        }
        let mut dg = 0.0;
        for i in 0..N {
            for j in 0..N {
                let d = self.tower.level(0).herm().get(i, j)
                    - before.herm().get(i, j);
                dg += d.norm_sqr();
            }
        }
        let climate = dg.sqrt();
        self.pending = self.wheel.observe(climate, novel);

        Pulse { action: acted, novel, climate, takeover }
    }

    /// Account for an observed action without asserting an ordinary successor.
    /// The timestamp belongs to this representation, so language changes clear
    /// it alongside the transition table. A terminal is tried, never a road.
    fn note_observed_action(
        &mut self,
        state: u64,
        acted: A,
        outcome: ObservedWorldOutcome,
    ) -> Option<u64> {
        let receipt = self.verified_at.get(&(state, acted));
        let fresh = receipt.is_none() && !self.table.contains_key(&(state, acted));
        let previous = receipt.and_then(|receipt| receipt.latest).map(|(_, outcome)| outcome);
        let mut revise = false;
        if let Some(previous) = previous {
            self.predictions_total += 1;
            let surprised = previous != outcome;
            if surprised {
                self.record_surprise(state, acted, previous, outcome);
            }
            if self.last_branch == 4 {
                let futile = self.patrol_futile.entry((state, acted)).or_insert(0);
                *futile = if surprised { 0 } else { futile.saturating_add(1) };
            }
            if let Some((window, threshold)) = self.molt_rule {
                self.surprise_window.push_back(surprised);
                if self.surprise_window.len() > window {
                    self.surprise_window.pop_front();
                }
                revise = self.surprise_window.iter().filter(|&&hit| hit).count() >= threshold;
            }
        }
        *self.lived_pairs.entry((state, acted)).or_insert(0) += 1;
        if fresh {
            self.mk_new_life += 1;
            self.bore_glass[2] += 1;
        }
        match self.last_branch {
            0 | 1 | 2 => {
                self.mk_cur_acts += 1;
                if fresh { self.mk_cur_new += 1; }
            }
            3 | 11 if self.plan_is_task => { self.mk_serve_acts += 1; }
            _ => {}
        }
        self.steps += 1;
        let receipt = self.verified_at.entry((state, acted))
            .or_insert_with(|| ObservationReceipt::new(self.steps, outcome));
        receipt.observe(self.steps, outcome);
        if let Some(next) = receipt.next() {
            if self.table.insert((state, acted), next).is_none() {
                let acts = self.table_acts.entry(state).or_default();
                if !acts.contains(&acted) { acts.push(acted); }
            }
        } else {
            self.table.remove(&(state, acted));
            if let Some(acts) = self.table_acts.get_mut(&state) {
                acts.retain(|&a| a != acted);
            }
        }
        match outcome {
            ObservedWorldOutcome::Next(next) => {
                let destination = self.act_dest.entry(acted).or_insert((Some(next), 0, true));
                destination.1 += 1;
                if destination.0 != Some(next) { destination.2 = false; }
            }
            ObservedWorldOutcome::Refused(_) | ObservedWorldOutcome::End(_) => {
                let destination = self.act_dest.entry(acted).or_insert((None, 0, false));
                destination.1 += 1;
                destination.2 = false;
            }
        }
        revise.then_some(self.steps)
    }

    /// Finish the same observation before replacing its representation. An
    /// independent language purchase may already have invalidated this owner.
    fn finish_observed_revision(&mut self, state: u64, acted: A, revision: Option<u64>) {
        let Some(at) = revision else { return; };
        if !self.verified_at.get(&(state, acted)).is_some_and(|receipt| receipt.latest.is_some_and(|(stamp, _)| stamp == at)) {
            return;
        }
        self.table.clear();
        self.table_acts.clear();
        self.watch_plan_kill(16083);
        self.plan.clear();
        self.surprise_window.clear();
        self.verified_at.clear();
        self.molts += 1;
        // SLEEP: the map lied — the past is
        // repacked over the organ that lived
        // it, and the sleep has a body (the
        // derived-depth anchor regeneration)
        self.dream();
    }

    /// Discard episode-local promises without judging them against another
    /// world's initial observation. Acquired laws and lived history remain.
    fn close_episode(&mut self) {
        if let Some(ex)=self.exhaust.as_mut() { ex.pend=None; }
        self.plan.clear();
        self.plan_refs.clear();
        self.plan_expect = None;
        self.plan_goal = None;
        self.plan_edge = None;
        self.plan_is_task = false;
        self.plan_from_map = false;
        self.plan_notes = false;
        self.plan_step_lv = None;
        self.plan_step_pre = None;
        self.plan_step_ref = None;
        self.plan_step_court = None;
        self.plan_step_reset = false;
        self.plan_phase_retry = 0;
        self.pilgrim_hold = 0;
        self.pilgrim_goal = None;
        self.pilgrim_started = false;
        self.combo_queue.clear();
        self.pending_refusals.clear();
        self.pending_goal_fire = None;
        self.transfer_pending = None;
        self.steer_pending = None;
        self.swap_pending = None;
        self.goal_rate_open = None;
        self.rule_goal_armed = None;
        self.vte_plan = false;
        self.vte_failed_at = None;
        self.docket_case = None;
        self.pending = None;
        self.since_root = 0;
        self.prev_progress = -1.0;
        self.progress_seen = 0.0;
        self.moved_since_reset = false;
        self.novel_since_reset = false;
        self.last_step_act = None;
    }

    /// Read-only preflight for callers that will restart an external world.
    /// Check this before the external effect, then call begin_run after success.
    pub fn check_observer_lifecycle(&self) -> Result<(), ObserverLifecycleRefusal> {
        if let Some(ex) = &self.exhaust {
            if ex.before_act_continuation.is_some() || ex.after_act_continuation.is_some()
                || ex.pending_domain_retirement.is_some() { return Err(ObserverLifecycleRefusal::PendingBoundary); }
            if ex.observer_history.current_history().is_err() { return Err(ObserverLifecycleRefusal::UnknownDelivery); }
        }
        // The physical clock also exists without an observer journal. A
        // published journal is insufficient while its time receipt is pending.
        self.source_time.check_restart()?;
        Ok(())
    }

    /// Begin an explicitly new run after a verified caller-owned restart.
    /// An owned suspension or unknown native delivery refuses before mutation.
    /// A new episode is not evidence that a failed physical action succeeded.
    /// This declares a new source-time origin; it issues no observed reset edge.
    pub fn begin_run(&mut self) -> Result<(), ObserverLifecycleRefusal> {
        self.check_observer_lifecycle()?;
        self.source_time.declared_restart()?;
        if let Some(ex) = &self.exhaust {
            for floor in &ex.floors { floor.observer.invalidate_source(); }
        }
        self.close_episode();
        self.action_failure = None;
        self.action_stop = None;
        self.root = None;
        self.root_raw = None;
        Ok(())
    }

    /// Last observed terminal, distinct from a failed attempt and its reset.
    pub fn last_terminal(&self) -> Option<(A, TerminalKind, Resumption)> {
        self.terminal_receipts.last().map(|receipt| (receipt.action, receipt.kind, receipt.resumption))
    }

    /// Complete observed terminal history; unknown kinds remain explicitly unknown.
    pub fn terminal_receipts(&self) -> &[TerminalReceipt<A>] { &self.terminal_receipts }

    fn check_action_status(&self) -> Result<(), ActionFailure<A>> {
        match &self.action_failure {
            Some(failure) => Err(failure.clone()),
            None => Ok(()),
        }
    }

    /// Last execution failure is sticky. An owned observer continuation may be
    /// resumed explicitly; an unrelated failure still requires a new run.
    pub fn action_failure(&self) -> Option<&ActionFailure<A>> { self.action_failure.as_ref() }

    /// Live up to `budget` steps, retaining the prefix on any stop or failure.
    pub fn live<H: Habitat<Action = A>>(&mut self, world: &mut H, budget: usize) -> LifeRun<A> {
        self.live_observed(world, budget, |_, _, _| {})
    }

    /// The same run lifecycle with read-only inspection after each completed
    /// pulse. A stop, no admitted action, or execution failure creates no pulse.
    /// The callback receives no mutable organism or world capability; diagnostic
    /// consumers must not implement a separate stepping or termination loop.
    pub fn live_observed<H, F>(&mut self, world: &mut H, budget: usize, mut observe: F) -> LifeRun<A>
    where
        H: Habitat<Action = A>,
        F: FnMut(usize, &Self, &Pulse<A>),
    {
        let before = self.action_attempts;
        if let Err(failure) = self.check_action_status() {
            return LifeRun { report: self.report(), end: RunEnd::Failed(failure), attempted_actions: 0 };
        }
        if let Some((action, terminal)) = self.action_stop {
            return LifeRun { report: self.report(), end: RunEnd::Stopped { action, terminal }, attempted_actions: 0 };
        }
        let mut end = RunEnd::BudgetCompleted;
        for step in 0..budget {
            match self.step(world) {
                Ok(StepOutcome::Pulse(pulse)) => observe(step, self, &pulse),
                Ok(StepOutcome::NoAction) => { end = RunEnd::NoAction; break; }
                Ok(StepOutcome::Stopped { action, terminal }) => {
                    end = RunEnd::Stopped { action, terminal }; break;
                }
                Err(failure) => { end = RunEnd::Failed(failure); break; }
            }
        }
        LifeRun { report: self.report(), end, attempted_actions: self.action_attempts - before }
    }

    /// The colony's social API, inbound: another's breath
    /// — injecting a foreign base into one's own (the same
    /// machinery as food; W-ORG-5, the chronicle colony's
    /// machinery).
    pub fn social_inject(&mut self, rho: &Gamma, lambda: f64) {
        self.tower.inject_base(rho, lambda);
    }

    /// The social API, outbound: a copy of one's own base
    /// — breath one can give a neighbour.
    #[must_use]
    pub fn base_state(&self) -> Gamma {
        *self.tower.level(0)
    }

    /// THE KINSHIP GATE — recognition as the input of a
    /// decision (the qualia address read by policy). A
    /// MEETING is a consented influence: before letting
    /// another mind into one's base, the organism READS the
    /// other's quality — the ink-weighted affinity of the
    /// seven line holonomies against its own — and scales
    /// the proposed weight by it. Every number is the
    /// recognition organ's own: kin (affinity → 1) pass
    /// near-whole; a stranger is let in exactly by their
    /// kinship; opposed letters (affinity ≤ 0) are refused;
    /// absent common observations do not authorize influence. This gate
    /// is a model policy and supplies no phenomenal-consciousness evidence.
    ///
    /// Returns the weight actually accepted. The raw
    /// channel [`Self::social_inject`] stays ungated: the
    /// world can still wound you — a wound is not a
    /// meeting.
    pub fn meet(&mut self, other: &Gamma, weight: f64) -> f64 {
        let mine = synarc_math::holonomy::holonomy(
            self.tower.level(0),
        );
        let theirs = synarc_math::holonomy::holonomy(other);
        let Some(gate)=Self::kinship_gate(&mine,&theirs) else {
            // No common phase observation: refuse the proposed influence.
            // This zero is an accepted action weight, not measured affinity.
            return 0.0;
        };
        let accepted = weight*gate;
        if accepted > 0.0 {
            self.tower.inject_base(other, accepted);
        }
        accepted
    }

    /// The gate itself: non-negative kinship — the
    /// ink-weighted circular agreement of the seven line
    /// holonomies, clamped at refusal (opposed letters let
    /// nothing in). Missing comparison is separate from measured opposition.
    fn kinship_gate(
        mine: &[synarc_math::holonomy::Hol; 7],
        theirs: &[synarc_math::holonomy::Hol; 7],
    ) -> Option<f64> {
        synarc_math::holonomy::affinity(mine, theirs).map(|a|a.max(0.0))
    }

    /// THE GATHERING — the colony's simultaneous breath
    /// over a graph. The pairwise law lifted to topology:
    /// if edges were exchanged one after another, a node
    /// with two neighbours would hand its second meeting an
    /// already-mixed mind — an order the world does not
    /// have. So the gathering snapshots EVERY base first,
    /// reads every gate from the snapshots, and then gives
    /// each node ONE convex mix of all its gated
    /// neighbours: `(1−Σλ)·self + Σ λ_k·other_k`. When a
    /// crowd asks more than everything (`Σλ > 1`), the
    /// shares scale proportionally — nobody's kinship buys
    /// another's share. Returns the weight each node let
    /// in.
    ///
    /// # Panics
    /// An edge naming a mind outside the gathering is no
    /// edge — indices must be in range and distinct.
    pub fn gathering(
        minds: &mut [Self],
        edges: &[(usize, usize)],
        weight: f64,
    ) -> Vec<f64> {
        let snaps: Vec<Gamma> =
            minds.iter().map(Self::base_state).collect();
        let hols: Vec<[synarc_math::holonomy::Hol; 7]> =
            snaps
                .iter()
                .map(synarc_math::holonomy::holonomy)
                .collect();
        let mut shares: Vec<Vec<(usize, f64)>> =
            vec![Vec::new(); minds.len()];
        for &(i, j) in edges {
            assert!(
                i != j && i < minds.len() && j < minds.len(),
                "an edge names two distinct minds present"
            );
            let Some(gate)=Self::kinship_gate(&hols[i],&hols[j]) else {
                continue; // Missing comparative evidence cannot license influence.
            };
            let lambda = weight * gate;
            if lambda > 0.0 {
                shares[i].push((j, lambda));
                shares[j].push((i, lambda));
            }
        }
        let mut let_in = vec![0.0; minds.len()];
        for (n, mine) in shares.iter().enumerate() {
            let total: f64 =
                mine.iter().map(|&(_, l)| l).sum();
            if total <= 0.0 {
                continue;
            }
            let scale =
                if total > 1.0 { 1.0 / total } else { 1.0 };
            let guests: Vec<(Gamma, f64)> = mine
                .iter()
                .map(|&(k, lambda)| {
                    (snaps[k], lambda * scale)
                })
                .collect();
            minds[n].tower.gather_base(&guests);
            let_in[n] = total.min(1.0);
        }
        let_in
    }

    /// THE SIMULTANEOUS BREATH — the colony's two-sided
    /// meeting. Both breaths are read BEFORE either is
    /// accepted: an exchange that let one side absorb first
    /// would invent an order the world does not have, and
    /// the second reader would meet an already-mixed mind.
    /// With the snapshots taken together and the affinity
    /// symmetric in its arguments, the two accepted weights
    /// are EQUAL by construction — kinship is mutual or it
    /// is not kinship. Returns the weight each side let in.
    pub fn exchange(
        a: &mut Self,
        b: &mut Self,
        weight: f64,
    ) -> (f64, f64) {
        let (breath_a, breath_b) =
            (a.base_state(), b.base_state());
        let let_in_a = a.meet(&breath_b, weight);
        let let_in_b = b.meet(&breath_a, weight);
        (let_in_a, let_in_b)
    }

    /// The summary so far.
    #[must_use]
    pub fn report(&self) -> LifeReport {
        let (body, mind) = self.wheel.seizures();
        LifeReport {
            uniq: self.seen.len(),
            body_seizures: body,
            mind_seizures: mind,
            tower: self.tower.frame(),
            organ_nodes: self
                .organs
                .as_ref()
                .map_or(1, |o| o.body.node_count()),
            organs_spawned: self.organs.as_ref().map_or(0, |o| o.spawned),
        }
    }
}

impl<
    A: Copy
        + Eq
        + std::hash::Hash
        + Ord
        + crate::worldmap::Wire,
> Default for Organism<A>
{
    fn default() -> Self {
        Self::new()
    }
}


#[cfg(test)]
mod tests;

#[cfg(test)]
mod hunger_identity_courts;

#[cfg(test)]
mod observation_receipt_courts;

/// Explicit execution of a caller-selected, context-bound experiment.
pub mod experiment;

#[cfg(test)]
mod experiment_courts;

#[cfg(test)]
mod action_courts;

#[cfg(test)]
mod terminal_outcome_courts;

#[cfg(test)]
mod outcome_acquisition_courts;

#[cfg(test)]
mod decision_boundary_courts;

#[cfg(test)]
mod decision_dispatch_courts;


#[cfg(test)]
mod refinement_intake_courts;

#[cfg(test)]
impl Organism<u8> {
    fn record_test_event(&mut self, raw: u64, action: u8, age: u64) -> Option<RepresentationWitness<u8>> {
        let state = self.try_eyed(raw).ok()?;
        self.seen.insert(state, vec![0, 1]);
        self.advance_representation(state, raw, action, age)
    }
}

#[cfg(test)]
mod causal_retention_courts;

#[cfg(test)]
mod causal_merge_courts;


#[cfg(test)]
mod typed_context_courts;
