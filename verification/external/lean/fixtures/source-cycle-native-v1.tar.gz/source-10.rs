use super::super::acquisition_budget::AcquisitionWorkReceipt;
use super::super::observer_acquired as input;
use super::*;
use crate::construction::family::{Grammar, OperationSpec, syntax::Syntax};
use crate::program::code_mass::Mass;
use crate::program::observer::acquisition::{self as native, joint};
use crate::program::observer::{Budget, InputBinding, InputSource};
use crate::program::{Operand, Operation, Program, Step};
use std::collections::{BTreeMap, BTreeSet};
struct Alternating {
    calls: usize,
}
impl Habitat for Alternating {
    type Action = u8;
    fn observe(&self) -> [f64; 7] {
        [1.0 / 7.0; 7]
    }
    fn key(&self) -> u64 {
        1
    }
    fn actions(&self) -> Vec<u8> {
        vec![0]
    }
    fn reset_action(&self) -> Option<u8> {
        None
    }
    fn act(&mut self, _: u8) -> Result<ObservedAction, ActionFailure<u8>> {
        let outcome = if self.calls % 2 == 0 {
            ObservedAction::Step
        } else {
            ObservedAction::Refused
        };
        self.calls += 1;
        Ok(outcome)
    }
}
fn toggler() -> Program<input::Value<u8>, input::Op> {
    Program {
        steps: vec![
            Step {
                operation: Operation::Primitive(input::Op::Unit),
                arguments: vec![],
            },
            Step {
                operation: Operation::Primitive(input::Op::Equal),
                arguments: vec![Operand::Input(0), Operand::Register(0)],
            },
            Step {
                operation: Operation::Primitive(input::Op::Equal),
                arguments: vec![Operand::Input(0), Operand::Register(1)],
            },
        ],
        output: Some(2),
        library: vec![],
    }
}
fn published() -> (
    Organism<u8>,
    Alternating,
    observer_acceptance::Admission<u8>,
) {
    let mut org = Organism::<u8>::new().with_exhaustion_climb(4096).unwrap();
    org.exhaust.as_mut().unwrap().program_agenda = None;
    let h = &org.exhaust.as_ref().unwrap().observer_history;
    let source = input::Source {
        sensory: false,
        epoch: h.epoch(),
        raw_space: h.raw_space(),
        owner: Some(h.lineage()),
        shape: input::Shape::Event,
    };
    let grammar = |inputs, operations| Grammar {
        inputs,
        operations,
        literals: vec![],
        max_steps: 1,
    };
    let mut series = input::JointSeries::freeze(
        Syntax::freeze(grammar(
            0,
            vec![OperationSpec {
                id: input::Op::Unit,
                arity: 0,
            }],
        ))
        .unwrap(),
        Syntax::with_library(grammar(1, vec![]), vec![(1, toggler())]).unwrap(),
        Syntax::with_library(grammar(1, vec![]), vec![(1, toggler())]).unwrap(),
        InputBinding::new(source.clone(), 1, vec![InputSource::State]).unwrap(),
        InputBinding::new(
            input::Source {
                shape: input::Shape::Query,
                ..source.clone()
            },
            1,
            vec![InputSource::State],
        )
        .unwrap(),
        Arc::new(input::Meaning::for_sensory_court(4096)),
    )
    .unwrap()
    .declare_admission(native::AdmissionProfile::ExactPredictiveV1 {
        risk: Mass::uniform(20u8.into()).unwrap(),
    })
    .unwrap_or_else(|_| panic!("profile fixed before outcomes"));
    assert_eq!(series.family_count(), Some(1));
    let alphabet = BTreeMap::from([(
        (source.epoch, 1, 0u8),
        BTreeSet::from([
            input::Value::Outcome(ObservedWorldOutcome::Next(1)),
            input::Value::Outcome(ObservedWorldOutcome::Refused(1)),
        ]),
    )]);
    let mut intake = series.open_trial(alphabet.clone()).unwrap();
    let mut world = Alternating { calls: 0 };
    let mut work = ObserverWork {
        remaining: 4_000_000,
    };
    for _ in 0..64 {
        org.step_forced(&mut world, 0).unwrap();
    }
    let batch = org.program_rows(&source, 0, &alphabet, &mut work).unwrap();
    let end = batch.end;
    assert_eq!(batch.rows.len(), 64);
    for row in batch.rows {
        intake
            .observe(
                Arc::clone(&batch.history),
                row.cut,
                row.context,
                row.query,
                row.outcome,
            )
            .unwrap();
    }
    let mut search = intake.finish::<()>().unwrap();
    let (candidate, accepted) = loop {
        match search.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)) {
            joint::Progress::Advanced => {}
            joint::Progress::Assessed {
                candidate,
                assessment,
            } => {
                break (
                    candidate,
                    assessment
                        .accepted()
                        .unwrap()
                        .expect("actual exact purchase"),
                );
            }
            _ => panic!("single well-defined native family must assess"),
        }
    };
    let mut fresh = accepted.open_validation();
    for _ in 0..64 {
        org.step_forced(&mut world, 0).unwrap();
    }
    let batch = org
        .program_rows(&source, end, &alphabet, &mut work)
        .unwrap();
    assert_eq!(batch.rows.len(), 64);
    for row in batch.rows {
        fresh
            .observe(
                Arc::clone(&batch.history),
                row.cut,
                row.context,
                row.query,
                row.outcome,
            )
            .unwrap();
    }
    let validated = fresh
        .finish()
        .unwrap()
        .evaluate(&mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("actual fresh VM execution"))
        .validated()
        .unwrap()
        .expect("actual independent suffix confirms original program");
    let admission =
        observer_acceptance::Admission::from_native(input::Producer::from(candidate), validated)
            .unwrap();
    org.install_program_observer(&admission, 128, &mut work)
        .unwrap_or_else(|_| panic!("actual publication gate"));
    assert_eq!(org.exhaust.as_ref().unwrap().floors.len(), 1);
    (org, world, admission)
}
fn limits() -> ObserverFiniteLimits {
    ObserverFiniteLimits {
        states: 16,
        workspace: 256,
        execution: ExecutionLimit::Unlimited,
    }
}
fn finish(org: &mut Organism<u8>, floor: FloorIdentity) -> ObserverFiniteReceipt {
    for _ in 0..20000 {
        let receipt = org
            .advance_observer_finite_analysis(floor, limits(), 1)
            .unwrap();
        assert_eq!(
            receipt.allowed_units,
            receipt.spent_units + receipt.returned_units
        );
        if matches!(
            receipt.analysis.status,
            ObserverFiniteStatus::ExecutableCycle {
                binding: ObserverFiniteBinding::Current { .. },
                ..
            }
        ) {
            return receipt.analysis;
        }
        assert!(!matches!(
            receipt.analysis.status,
            ObserverFiniteStatus::Unknown(_)
        ));
    }
    panic!("bounded native finite published fixture")
}
fn assert_ledger_unchanged(before: &AcquisitionWorkReceipt, after: &AcquisitionWorkReceipt) {
    assert!(before.same_ledger(after));
    assert_eq!(before.requests(), after.requests());
    assert_eq!(before.quoted_units(), after.quoted_units());
    assert_eq!(before.entitled_units(), after.entitled_units());
    assert_eq!(before.available_units(), after.available_units());
    assert_eq!(before.reserved_units(), after.reserved_units());
    assert_eq!(before.spent_units(), after.spent_units());
}
#[test]
fn published_semantic_service_uses_actual_ledger_and_read_only_glass_does_no_work() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let before = org.acquisition_work_receipt().unwrap();
    let original_code = org.observer_receipts().unwrap()[0].code.clone();
    let original_climbs = org.climbs();
    for _ in 0..3 {
        assert_eq!(
            org.observer_receipts().unwrap()[0]
                .finite
                .as_ref()
                .unwrap()
                .status,
            ObserverFiniteStatus::NotRequested
        );
    }
    let after = org.acquisition_work_receipt().unwrap();
    assert_eq!(before.spent_units(), after.spent_units());
    assert_eq!(before.requests(), after.requests());
    let zero = org
        .advance_observer_finite_analysis(floor, limits(), 0)
        .unwrap();
    assert_eq!(zero.analysis.status, ObserverFiniteStatus::NotRequested);
    assert_eq!(zero.spent_units, 0);
    let certified = finish(&mut org, floor);
    assert!(matches!(
        certified.status,
        ObserverFiniteStatus::ExecutableCycle {
            reachable_states: 3,
            primitive_observable_period: 2,
            binding: ObserverFiniteBinding::Current { .. },
            ..
        }
    ));
    let end = org.acquisition_work_receipt().unwrap();
    assert_eq!(org.observer_receipts().unwrap()[0].code, original_code);
    assert_eq!(org.climbs(), original_climbs);
    assert_eq!(
        end.spent_units() - after.spent_units(),
        certified.spent_units
    );
    let before = org.acquisition_work_receipt().unwrap();
    for quote in [37, 0, 37] {
        assert_eq!(
            org.advance_observer_finite_analysis(floor, limits(), quote),
            Err(ObserverFiniteRefusal::NoWork)
        );
        assert_eq!(
            org.observer_receipts().unwrap()[0].finite.as_ref().unwrap(),
            &certified
        );
        assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
    }
    let altered = ObserverFiniteLimits {
        states: 32,
        ..limits()
    };
    assert_eq!(
        org.advance_observer_finite_analysis(floor, altered, 99),
        Err(ObserverFiniteRefusal::DifferentLimits)
    );
    assert_eq!(
        before.requests(),
        org.acquisition_work_receipt().unwrap().requests(),
        "invalid resume earns no new entitlement"
    );
}
#[test]
fn actual_commit_requires_explicit_rebinding_and_preserves_original_certificate_work() {
    let (mut org, mut world, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let before = finish(&mut org, floor);
    org.step_forced(&mut world, 0).unwrap();
    assert!(matches!(
        org.observer_receipts().unwrap()[0]
            .finite
            .as_ref()
            .unwrap()
            .status,
        ObserverFiniteStatus::ExecutableCycle {
            binding: ObserverFiniteBinding::Stale,
            ..
        }
    ));
    let stale = org.observer_receipts().unwrap()[0].finite.clone().unwrap();
    assert_eq!(stale.spent_units, before.spent_units);
    let ledger = org.acquisition_work_receipt().unwrap();
    for quote in [64, 0, 64] {
        assert_eq!(
            org.advance_observer_finite_analysis(floor, limits(), quote),
            Err(ObserverFiniteRefusal::NoWork)
        );
        assert_eq!(
            org.observer_receipts().unwrap()[0].finite.as_ref().unwrap(),
            &stale
        );
        assert_ledger_unchanged(&ledger, &org.acquisition_work_receipt().unwrap());
    }
    let zero = org.rebind_observer_finite_analysis(floor, 0).unwrap();
    assert_eq!(zero.analysis.rebindings, 0u8.into());
    org.rebind_observer_finite_analysis(floor, 1).unwrap();
    let rebound = finish(&mut org, floor);
    assert_eq!(rebound.rebindings, 1u8.into());
    assert!(rebound.spent_units > before.spent_units);
    assert_eq!(
        org.rebind_observer_finite_analysis(floor, 1),
        Err(ObserverFiniteRefusal::NotStale)
    );
}
#[test]
fn publication_replacement_refuses_old_floor_before_issuing_work() {
    let (mut org, _, admission) = published();
    let old = org.top_floor_identity().unwrap();
    let _ = finish(&mut org, old);
    org.raze_top(RazeReason::Declared("finite published owner lifecycle"));
    let before = org.acquisition_work_receipt().unwrap();
    assert_eq!(
        org.advance_observer_finite_analysis(old, limits(), 64),
        Err(ObserverFiniteRefusal::NotPublished)
    );
    assert_eq!(
        before.requests(),
        org.acquisition_work_receipt().unwrap().requests()
    );
    org.install_program_observer(
        &admission,
        128,
        &mut ObserverWork {
            remaining: 2_000_000,
        },
    )
    .unwrap_or_else(|_| panic!("same actual admission republishes into fresh native language"));
    let fresh = org.top_floor_identity().unwrap();
    assert_ne!(fresh, old);
    assert_eq!(
        org.advance_observer_finite_analysis(old, limits(), 64),
        Err(ObserverFiniteRefusal::NotPublished)
    );
    assert_eq!(
        org.observer_receipts().unwrap()[0]
            .finite
            .as_ref()
            .unwrap()
            .status,
        ObserverFiniteStatus::NotRequested
    );
}
#[test]
fn fractional_entitlement_and_zero_allowed_grant_do_not_start_an_analysis() {
    let (org, _, _) = published();
    let mut org = org.with_sitting_budget(0.5);
    let floor = org.top_floor_identity().unwrap();
    // Publication fixture does not issue acquisition ledger requests; any rights
    // already present are inspected, never silently assumed empty.
    let before = org.acquisition_work_receipt().unwrap();
    assert_eq!(
        before.available_units(),
        &num_rational::Ratio::from_integer(BigUint::from(0u8))
    );
    let first = org
        .advance_observer_finite_analysis(floor, limits(), 1)
        .unwrap();
    assert_eq!(first.allowed_units, 0);
    assert_eq!(first.analysis.status, ObserverFiniteStatus::NotRequested);
    let second = org
        .advance_observer_finite_analysis(floor, limits(), 1)
        .unwrap();
    assert_eq!(second.allowed_units, 1);
    assert_eq!(second.spent_units, 1);
    assert!(matches!(
        second.analysis.status,
        ObserverFiniteStatus::Pending { .. }
    ));
    let after = org.acquisition_work_receipt().unwrap();
    assert_eq!(
        after.spent_units() - before.spent_units(),
        BigUint::from(1u8)
    );
}

#[test]
fn actual_open_carrier_refusal_cannot_issue_new_entitlement() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let original = org.observer_receipts().unwrap()[0].code.clone();
    let bounded = ObserverFiniteLimits {
        states: 1,
        ..limits()
    };
    // The same genuinely admitted native toggler has more than one state. Its
    // original one-state limit produces an actual retained unknown, not a
    // fabricated terminal status or a new allowance on every retry.
    let unknown = (0..20000)
        .find_map(|_| {
            let receipt = org
                .advance_observer_finite_analysis(floor, bounded, 1)
                .unwrap();
            assert_eq!(
                receipt.allowed_units,
                receipt.spent_units + receipt.returned_units
            );
            match &receipt.analysis.status {
                ObserverFiniteStatus::Unknown(ObserverFiniteUnknown::OpenCarrier) => {
                    Some(receipt.analysis)
                }
                ObserverFiniteStatus::Pending { .. } => None,
                other => panic!("expected retained one-state refusal, got {other:?}"),
            }
        })
        .expect("bounded native analysis reaches its original carrier limit");
    assert!(unknown.spent_units > BigUint::from(0u8));
    let before = org.acquisition_work_receipt().unwrap();
    for quote in [64, 0, 64] {
        assert_eq!(
            org.advance_observer_finite_analysis(floor, bounded, quote),
            Err(ObserverFiniteRefusal::NoWork)
        );
        assert_eq!(
            org.observer_receipts().unwrap()[0].finite.as_ref().unwrap(),
            &unknown
        );
        assert_eq!(org.observer_receipts().unwrap()[0].code, original);
        assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
    }
    assert_eq!(
        org.advance_observer_finite_analysis(floor, limits(), 64),
        Err(ObserverFiniteRefusal::DifferentLimits)
    );
    assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
}

fn finish_source(org: &mut Organism<u8>, floor: FloorIdentity, grant: usize) -> ObserverSourceCycleReceipt {
    for _ in 0..20000 {
        let serviced = org.advance_observer_source_cycle(floor, limits(), grant).unwrap();
        assert_eq!(serviced.allowed_units, serviced.spent_units + serviced.returned_units);
        if let Some(bound) = serviced.source_cycle { return bound; }
        assert!(!matches!(serviced.analysis.status, ObserverFiniteStatus::Unknown(_)));
    }
    panic!("paid native certificate, membership and anchor must finish")
}

#[test]
fn source_cycle_paid_service_and_actual_step_refusal_keep_one_current_binding() {
    let (mut org, mut world, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let before = org.acquisition_work_receipt().unwrap();
    for _ in 0..3 { assert_eq!(org.observer_source_cycle(floor).unwrap(), None); }
    assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
    let zero = org.advance_observer_source_cycle(floor, limits(), 0).unwrap();
    assert_eq!(zero.spent_units, 0);
    assert_eq!(zero.analysis.status, ObserverFiniteStatus::NotRequested);
    let mut current = finish_source(&mut org, floor, 1);
    assert_eq!(current.primitive_observable_period, 2);
    assert_eq!(org.key_rung(), 1, "source capability does not fabricate compatibility metadata");
    org.exhaust.as_ref().unwrap().floors[0].observer.general().enable_audit();
    let original_calls = world.calls;
    for _ in 0..4 {
        // The actual fixture alternates Step and Refused; both dispatch once.
        org.step_forced(&mut world, 0).unwrap();
        let next = org.observer_source_cycle(floor).unwrap().expect("both owned halves completed");
        assert_eq!(next.phase, (current.phase + 1) % current.primitive_observable_period);
        assert_eq!(next.life_age, current.life_age + 1);
        assert_eq!(next.anchor_age, current.anchor_age);
        assert_eq!(next.episode, current.episode);
        current = next;
    }
    assert_eq!(world.calls - original_calls, 4);
    let events = org.exhaust.as_ref().unwrap().floors[0].observer.general().take_audit();
    assert_eq!(events.iter().filter(|e| matches!(e, observer_runtime::AuditEvent::Commit { .. })).count(), 4);
    let before = org.acquisition_work_receipt().unwrap();
    assert_eq!(org.advance_observer_source_cycle(floor, limits(), 100), Err(ObserverFiniteRefusal::NoWork));
    assert_eq!(org.observer_source_cycle(floor).unwrap(), Some(current));
    assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
}

#[test]
fn source_cycle_terminal_restart_fork_and_replacement_cannot_retain_physical_authority() {
    struct End;
    impl Habitat for End {
        type Action = u8;
        fn observe(&self) -> [f64; 7] { [1.0 / 7.0; 7] }
        fn key(&self) -> u64 { 1 }
        fn actions(&self) -> Vec<u8> { vec![0] }
        fn reset_action(&self) -> Option<u8> { None }
        fn act(&mut self, _: u8) -> Result<ObservedAction, ActionFailure<u8>> {
            Ok(ObservedAction::Terminal { kind: TerminalKind::Ended, resumption: Resumption::Stopped })
        }
    }
    let (mut org, _, admission) = published();
    let floor = org.top_floor_identity().unwrap();
    let before = finish_source(&mut org, floor, 3);
    let fork = org.exhaust.as_ref().unwrap().floors[0].observer.fork();
    assert!(fork.general().finite_analysis.lock().unwrap().is_none());
    let terminal_before = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    org.exhaust.as_ref().unwrap().floors[0].observer.general().enable_audit();
    org.step_forced(&mut End, 0).unwrap();
    let terminal_after = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    let events = org.exhaust.as_ref().unwrap().floors[0].observer.general().take_audit();
    let receipts: Vec<_> = events.iter().filter_map(|e| match e {
        observer_runtime::AuditEvent::Commit { receipt, .. } => Some(receipt), _ => None,
    }).collect();
    assert_eq!(receipts.len(), 1, "terminal retains exactly one actual native U");
    assert!(receipts[0].before().same_revision(&terminal_before));
    assert!(receipts[0].after().same_revision(&terminal_after));
    assert!(!terminal_before.same_revision(&terminal_after));
    assert_ne!(terminal_before.state(), terminal_after.state(), "actual fixture U changes native state");
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    let after = finish_source(&mut org, floor, 1);
    assert_eq!(after.episode, before.episode + 1);
    assert_eq!(after.anchor_age, 0);
    assert_eq!(after.life_age, 0);
    assert_eq!(after.phase, (before.phase + 1) % before.primitive_observable_period);
    assert_eq!(after.anchor_phase, after.phase, "new zero-age anchor keeps the actual phase");
    assert!(terminal_after.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    org.begin_run().unwrap();
    assert_eq!(terminal_after.state(), org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut().state());
    assert!(terminal_after.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()),
        "declared restart changes no native state revision");
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    let restarted = finish_source(&mut org, floor, 1);
    assert_eq!(restarted.episode, after.episode + 1);
    assert_eq!(restarted.anchor_age, 0);
    assert_eq!(restarted.phase, after.phase);
    assert_eq!(restarted.anchor_phase, after.phase);
    assert!(terminal_after.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    org.raze_top(RazeReason::Declared("source cycle owner lifecycle"));
    assert_eq!(org.observer_source_cycle(floor), Err(ObserverFiniteRefusal::NotPublished));
    let mut work = ObserverWork { remaining: 4_000_000 };
    // The existing production publication API returns a fresh native owner.
    org.install_program_observer(&admission, 128, &mut work)
        .unwrap_or_else(|_| panic!("actual publication gate"));
    let fresh = org.top_floor_identity().unwrap();
    assert_ne!(fresh, floor);
    assert_eq!(org.observer_source_cycle(fresh).unwrap(), None);
    assert_eq!(org.observer_source_cycle(floor), Err(ObserverFiniteRefusal::NotPublished));
}

#[test]
fn native_half_clock_half_and_repeated_completion_never_mint_an_extra_tick() {
    use super::super::causal_coordinates::{CapturedDispatch, physical_time};
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let before = finish_source(&mut org, floor, 1);
    let point = org.source_time.point().unwrap();
    let time = point.metadata();
    let mut work = ObserverWork { remaining: 10000 };
    let view = observer_runtime::View { sensory: None, raw: 1, input: 1,
        episode: time.episode, life_age: time.life_age, pose: 255 };
    let prepared = org.exhaust.as_ref().unwrap().floors[0].observer
        .prepare(view, 0, &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("actual native update"));
    let pending = org.exhaust.as_mut().unwrap().observer_history
        .prepare_in_layers(point, 1, &[(floor.input_epoch(), 1), (floor.output_epoch(), 1)], 0, 10000).unwrap().dispatch();
    let dispatch = CapturedDispatch::invoke_physical(pending, &mut org.source_time,
        |a| ActionCapture::unavailable(a, Ok(ObservedAction::Step)))
        .unwrap_or_else(|_| panic!("owned physical dispatch"));
    let (cut, _, receipt) = dispatch.observed_physical().unwrap_or_else(|_| panic!("owned capture"));
    let cut = cut.unwrap();
    let retained_cut = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    let old_episode = org.source_time.episode();
    let old_age = org.source_time.life_age();
    assert!(org.begin_run().is_err(), "pending physical receipt refuses restart before mutation");
    assert_eq!(org.source_time.episode(), old_episode);
    assert_eq!(org.source_time.life_age(), old_age);
    assert!(retained_cut.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    let observer = &mut org.exhaust.as_mut().unwrap().floors[0].observer;
    let committed = observer.commit(prepared).unwrap_or_else(|_| panic!("actual native commit"));
    assert!(committed.before().same_revision(&retained_cut));
    observer.source_native_commit(&committed, &cut);
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    let ledger = org.acquisition_work_receipt().unwrap();
    assert_eq!(org.advance_observer_source_cycle(floor, limits(), 1), Err(ObserverFiniteRefusal::SourceBoundary));
    assert_ledger_unchanged(&ledger, &org.acquisition_work_receipt().unwrap());
    let applied: physical_time::Applied = org.source_time.commit(receipt).unwrap();
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None, "native and clock receipts must be joined");
    org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
    let next = org.observer_source_cycle(floor).unwrap().unwrap();
    assert_eq!(next.life_age, before.life_age + 1);
    assert_eq!(next.phase, (before.phase + 1) % before.primitive_observable_period);
    org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None, "reinspection cannot advance a second time");
}

#[test]
fn source_request_uses_original_carrier_bound_and_unit_coarse_work_is_identical() {
    let run = |grant| {
        let (mut org, _, _) = published();
        let floor = org.top_floor_identity().unwrap();
        let before = org.acquisition_work_receipt().unwrap();
        let receipt = finish_source(&mut org, floor, grant);
        (receipt.phase, receipt.primitive_observable_period,
            org.acquisition_work_receipt().unwrap().spent_units() - before.spent_units())
    };
    assert_eq!(run(1), run(1000));
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let bounded = ObserverFiniteLimits { states: 1, ..limits() };
    let mut refused = false;
    for _ in 0..20000 {
        let service = org.advance_observer_source_cycle(floor, bounded, 1).unwrap();
        assert!(service.source_cycle.is_none());
        if matches!(service.analysis.status, ObserverFiniteStatus::Unknown(ObserverFiniteUnknown::OpenCarrier)) { refused = true; break; }
    }
    assert!(refused, "original finite bound must produce its retained refusal");
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    let before = org.acquisition_work_receipt().unwrap();
    assert_eq!(org.advance_observer_source_cycle(floor, bounded, 100), Err(ObserverFiniteRefusal::NoWork));
    assert_eq!(org.advance_observer_source_cycle(floor, limits(), 100), Err(ObserverFiniteRefusal::DifferentLimits));
    assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
}

#[test]
fn foreign_native_instance_cannot_advance_the_published_source_cycle() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    finish_source(&mut org, floor, 1);
    let point = org.source_time.point().unwrap().metadata();
    let mut fork = org.exhaust.as_ref().unwrap().floors[0].observer.fork();
    let mut work = ObserverWork { remaining: 10000 };
    let pending = fork.prepare(observer_runtime::View { sensory: None, raw: 1, input: 1,
        episode: point.episode, life_age: point.life_age, pose: 255 }, 0,
        &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("same code executes in its separate native instance"));
    let foreign = fork.commit(pending).unwrap_or_else(|_| panic!("actual fork receipt"));
    let point = org.source_time.point().unwrap();
    let pending = org.exhaust.as_mut().unwrap().observer_history.prepare_in_layers(point, 1,
        &[(floor.input_epoch(), 1), (floor.output_epoch(), 1)], 0, 10000).unwrap().dispatch();
    let dispatch = causal_coordinates::CapturedDispatch::invoke_physical(pending, &mut org.source_time,
        |a| ActionCapture::unavailable(a, Ok(ObservedAction::Step))).unwrap_or_else(|_| panic!("actual dispatch"));
    let (cut, _, time) = dispatch.observed_physical().unwrap_or_else(|_| panic!("actual capture"));
    org.exhaust.as_ref().unwrap().floors[0].observer.source_native_commit(&foreign, &cut.unwrap());
    let applied = org.source_time.commit(time).unwrap();
    org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
}


#[test]
fn same_instance_wrong_actual_update_input_cannot_pair_with_a_physical_dispatch() {
    for prepared_action in [0, 1] {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    finish_source(&mut org, floor, 1);
    let point = org.source_time.point().unwrap();
    let time = point.metadata();
    let mut work = ObserverWork { remaining: 10000 };
    // Autonomy makes both actions produce the same successor. That semantic
    // coincidence cannot replace correspondence to the dispatched input.
    let prepared = org.exhaust.as_ref().unwrap().floors[0].observer.prepare(
        observer_runtime::View { sensory: None, raw: 1, input: 1,
            episode: time.episode, life_age: time.life_age, pose: 255 }, prepared_action,
        &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("actual autonomous U on a different action"));
    let pending = org.exhaust.as_mut().unwrap().observer_history.prepare_in_layers(point, 1,
        &[(floor.input_epoch(), 1), (floor.output_epoch(), 1)], 0, 10000).unwrap().dispatch();
    let dispatch = causal_coordinates::CapturedDispatch::invoke_physical(pending, &mut org.source_time,
        |a| ActionCapture::unavailable(a, Ok(ObservedAction::Step)))
        .unwrap_or_else(|_| panic!("actual physical action"));
    let (cut, _, time) = dispatch.observed_physical().unwrap_or_else(|_| panic!("actual capture"));
    let observer = &mut org.exhaust.as_mut().unwrap().floors[0].observer;
    let committed = observer.commit(prepared).unwrap_or_else(|_| panic!("same-instance actual commit"));
    assert!(committed.after().same_revision(&observer.general().installed().cut()));
    observer.source_native_commit(&committed, &cut.unwrap());
    let applied = org.source_time.commit(time).unwrap();
    org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
    assert_eq!(org.observer_source_cycle(floor).unwrap().is_some(), prepared_action == 0,
        "same actual input permits the pair; equal autonomous successor with wrong input does not");
    }
}


#[test]
fn delayed_source_binding_survives_a_real_step_between_every_unit_grant() {
    let (mut stationary, _, _) = published();
    let stationary_floor = stationary.top_floor_identity().unwrap();
    let static_receipt = finish_source(&mut stationary, stationary_floor, 1000);
    let (mut moving, mut world, _) = published();
    let floor = moving.top_floor_identity().unwrap();
    moving.exhaust.as_ref().unwrap().floors[0].observer.general().enable_audit();
    let mut original_comparison = None;
    let mut steps = 0;
    let mut completed = false;
    for _ in 0..20000 {
        let service = moving.advance_observer_source_cycle(floor, limits(), 1).unwrap();
        assert!(service.spent_units <= 1);
        let general = moving.exhaust.as_ref().unwrap().floors[0].observer.general();
        {
            let slot = general.finite_analysis.lock().unwrap();
            if let Some(binding) = slot.as_ref().and_then(|a| a.source_binding.as_ref()) {
                let captured = binding.captured_cut();
                if let Some(original) = &original_comparison {
                    assert!(captured.same_revision(original), "moving U never restarts the paid exact comparison");
                } else { original_comparison = Some(captured.clone()); }
            }
        }
        if let Some(receipt) = service.source_cycle {
            assert!(original_comparison.is_some());
            assert_eq!(receipt.phase, (static_receipt.phase + steps % static_receipt.primitive_observable_period)
                % static_receipt.primitive_observable_period);
            let slot = general.finite_analysis.lock().unwrap();
            let certificate = slot.as_ref().unwrap().certificate.as_ref().unwrap();
            assert!(certificate.concrete_cycle_start() > 0, "native fixture has a real transient");
            let actual = general.installed().cut();
            let index = certificate.carrier().iter().position(|cut| cut.state() == actual.state()).unwrap();
            assert_eq!(receipt.phase, certificate.projection().codes()[index]);
            assert_eq!(receipt.anchor_age, moving.source_time.life_age());
            assert_eq!(receipt.anchor_phase, receipt.phase);
            completed = true;
            break;
        }
        moving.step_forced(&mut world, 0).unwrap();
        steps += 1;
    }
    assert!(completed, "one new actual U per unit grant cannot starve finite membership");
    let audit = moving.exhaust.as_ref().unwrap().floors[0].observer.general().take_audit();
    assert_eq!(audit.iter().filter(|event| matches!(event, observer_runtime::AuditEvent::Commit { .. })).count(), steps);
}

fn actual_unpaired_commit(org: &mut Organism<u8>, action: u8) -> observer_runtime::Commit<u8> {
    let point = org.source_time.point().unwrap().metadata();
    let observer = &mut org.exhaust.as_mut().unwrap().floors[0].observer;
    let mut work = ObserverWork { remaining: 10000 };
    let prepared = observer.prepare(observer_runtime::View { sensory: None, raw: 1, input: 1,
        episode: point.episode, life_age: point.life_age, pose: 255 }, action,
        &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("actual autonomous native preparation"));
    observer.commit(prepared).unwrap_or_else(|_| panic!("actual successful native commit"))
}

#[test]
fn source_transport_gaps_refuse_and_ordinary_finite_binding_stays_strict() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    finish(&mut org, floor);
    let certificate = org.exhaust.as_ref().unwrap().floors[0].observer.general()
        .finite_analysis.lock().unwrap().as_ref().unwrap().certificate.as_ref().unwrap().clone();
    let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
    let mut strict = certificate.begin_binding(general.installed()).unwrap();
    let mut following = certificate.begin_following_binding(general.installed()).unwrap();
    let receipt = actual_unpaired_commit(&mut org, 0);
    let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
    following.committed(&receipt, general.installed());
    assert!(following.current(general.installed()));
    assert!((0..10000).any(|_| strict.advance(&mut ObserverWork { remaining: 1 })
        .unwrap_or_else(|_| panic!("strict finite comparison progresses"))));
    assert!(matches!(strict.take(general.installed()), Err(finite::BindingRefusal::StaleInstallation)));
    assert!((0..10000).any(|_| following.advance(&mut ObserverWork { remaining: 1 })
        .unwrap_or_else(|_| panic!("following finite comparison progresses"))));
    let bound = following.take(general.installed()).unwrap();
    assert!(bound.applies_to(general.installed()));
    assert_eq!(certificate.carrier()[bound.state_index()].state(), general.installed().cut().state());

    for gap in ["duplicate", "missing", "foreign"] {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        let mut pending = certificate.begin_following_binding(general.installed()).unwrap();
        if gap == "foreign" {
            let mut foreign = org.exhaust.as_ref().unwrap().floors[0].observer.fork();
            let mut work = ObserverWork { remaining: 10000 };
            let prepared = foreign.prepare(observer_runtime::View { sensory: None, raw: 1, input: 1,
                episode: org.source_time.episode().unwrap(), life_age: org.source_time.life_age(), pose: 255 }, 0,
                &mut Budget::new(&mut work, ExecutionLimit::Unlimited)).unwrap_or_else(|_| panic!("actual fork U"));
            let receipt = foreign.commit(prepared).unwrap_or_else(|_| panic!("actual fork commit"));
            pending.committed(&receipt, org.exhaust.as_ref().unwrap().floors[0].observer.general().installed());
        } else {
            let first = actual_unpaired_commit(&mut org, 0);
            let current = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed();
            if gap == "duplicate" {
                pending.committed(&first, current);
                pending.committed(&first, current);
            } else {
                assert!(!pending.current(current), "even one omitted final commit is detected");
                let second = actual_unpaired_commit(&mut org, 0);
                pending.committed(&second, org.exhaust.as_ref().unwrap().floors[0].observer.general().installed());
            }
        }
        let current = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed();
        assert!(!pending.current(current), "{gap} cannot reconstruct a native chain from equal values");
        assert!(matches!(pending.take(current), Err(finite::BindingRefusal::StaleInstallation)));
    }
}

#[test]
fn pending_membership_keeps_terminal_u_across_admitted_restart() {
    struct End;
    impl Habitat for End {
        type Action = u8;
        fn observe(&self) -> [f64; 7] { [1.0 / 7.0; 7] }
        fn key(&self) -> u64 { 1 }
        fn actions(&self) -> Vec<u8> { vec![0] }
        fn reset_action(&self) -> Option<u8> { None }
        fn act(&mut self, _: u8) -> Result<ObservedAction, ActionFailure<u8>> {
            Ok(ObservedAction::Terminal { kind: TerminalKind::Ended, resumption: Resumption::Stopped })
        }
    }
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    let strict = finish(&mut org, floor);
    let ObserverFiniteStatus::ExecutableCycle { primitive_observable_period, binding: ObserverFiniteBinding::Current { native_state }, .. } = strict.status else { panic!("actual strict certificate"); };
    let before_phase = {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        let slot = general.finite_analysis.lock().unwrap();
        slot.as_ref().unwrap().certificate.as_ref().unwrap().projection().codes()[native_state]
    };
    let first = org.advance_observer_source_cycle(floor, limits(), 1).unwrap();
    assert!(first.source_cycle.is_none());
    let original = org.exhaust.as_ref().unwrap().floors[0].observer.general().finite_analysis.lock().unwrap()
        .as_ref().unwrap().source_binding.as_ref().unwrap().captured_cut().clone();
    org.exhaust.as_ref().unwrap().floors[0].observer.general().enable_audit();
    org.step_forced(&mut End, 0).unwrap();
    let after_u = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    assert!(!original.same_revision(&after_u));
    assert_ne!(original.state(), after_u.state());
    org.begin_run().unwrap();
    assert!(after_u.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        let slot = general.finite_analysis.lock().unwrap();
        let pending = slot.as_ref().unwrap().source_binding.as_ref().unwrap();
        assert!(pending.captured_cut().same_revision(&original));
        assert!(pending.current(general.installed()));
    }
    let anchored = finish_source(&mut org, floor, 1);
    assert_eq!(anchored.phase, (before_phase + 1) % primitive_observable_period);
    assert_eq!(anchored.life_age, 0);
    assert_eq!(anchored.anchor_phase, anchored.phase);
    assert!(after_u.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    let events = org.exhaust.as_ref().unwrap().floors[0].observer.general().take_audit();
    let commits: Vec<_> = events.iter().filter_map(|event| match event {
        observer_runtime::AuditEvent::Commit { receipt, .. } => Some(receipt), _ => None,
    }).collect();
    assert_eq!(commits.len(), 1);
    assert!(commits[0].before().same_revision(&original));
    assert!(commits[0].after().same_revision(&after_u));
}


#[test]
fn pending_membership_refused_restart_keeps_the_captured_comparison_and_commit_chain() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    finish(&mut org, floor);
    let before_phase = {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        let slot = general.finite_analysis.lock().unwrap();
        let bound = slot.as_ref().unwrap().bound.as_ref().unwrap();
        bound.certificate().projection().codes()[bound.state_index()]
    };
    assert!(org.advance_observer_source_cycle(floor, limits(), 1).unwrap().source_cycle.is_none());
    let original = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    let point = org.source_time.point().unwrap();
    let time = point.metadata();
    let mut work = ObserverWork { remaining: 10000 };
    let prepared = org.exhaust.as_ref().unwrap().floors[0].observer.prepare(
        observer_runtime::View { sensory: None, raw: 1, input: 1,
            episode: time.episode, life_age: time.life_age, pose: 255 }, 0,
        &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .unwrap_or_else(|_| panic!("actual prepared U"));
    let pending = org.exhaust.as_mut().unwrap().observer_history.prepare_in_layers(point, 1,
        &[(floor.input_epoch(), 1), (floor.output_epoch(), 1)], 0, 10000).unwrap().dispatch();
    let dispatch = causal_coordinates::CapturedDispatch::invoke_physical(pending, &mut org.source_time,
        |a| ActionCapture::unavailable(a, Ok(ObservedAction::Step)))
        .unwrap_or_else(|_| panic!("actual captured action"));
    let (cut, _, time_receipt) = dispatch.observed_physical().unwrap_or_else(|_| panic!("actual dispatch tuple"));
    assert!(org.begin_run().is_err());
    assert_eq!(org.source_time.episode(), Some(time.episode));
    assert_eq!(org.source_time.life_age(), time.life_age);
    {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        assert!(general.installed().cut().same_revision(&original));
        let slot = general.finite_analysis.lock().unwrap();
        let pending = slot.as_ref().unwrap().source_binding.as_ref().unwrap();
        assert!(pending.captured_cut().same_revision(&original));
        assert!(pending.current(general.installed()));
    }
    let observer = &mut org.exhaust.as_mut().unwrap().floors[0].observer;
    let committed = observer.commit(prepared).unwrap_or_else(|_| panic!("actual native commit"));
    assert!(committed.before().same_revision(&original));
    observer.source_native_commit(&committed, &cut.unwrap());
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    let applied = org.source_time.commit(time_receipt).unwrap();
    org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
    let actual = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    let anchored = finish_source(&mut org, floor, 1);
    assert_eq!(anchored.phase, (before_phase + 1) % anchored.primitive_observable_period);
    assert_eq!(anchored.life_age, time.life_age + 1);
    assert!(actual.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
}


#[test]
fn duplicate_actual_commit_hook_refuses_source_service_before_new_entitlement() {
    let (mut org, _, _) = published();
    let floor = org.top_floor_identity().unwrap();
    finish(&mut org, floor);
    assert!(org.advance_observer_source_cycle(floor, limits(), 1).unwrap().source_cycle.is_none());
    let receipt = actual_unpaired_commit(&mut org, 0);
    {
        let general = org.exhaust.as_ref().unwrap().floors[0].observer.general();
        let mut slot = general.finite_analysis.lock().unwrap();
        // Deliberate fault injection reuses an actual private native receipt;
        // no fabricated state/value/phase can stand in for a missing owner.
        slot.as_mut().unwrap().source_native_succeeded(general.installed(), &receipt);
    }
    let before = org.acquisition_work_receipt().unwrap();
    let actual = org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    assert_eq!(org.advance_observer_source_cycle(floor, limits(), 100), Err(ObserverFiniteRefusal::SourceGap));
    assert_eq!(org.observer_source_cycle(floor).unwrap(), None);
    assert_ledger_unchanged(&before, &org.acquisition_work_receipt().unwrap());
    assert!(actual.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
}


#[test]
fn one_coarse_source_quote_finishes_the_same_paid_binding_as_unit_service() {
    let (mut unit, _, _) = published();
    let unit_floor = unit.top_floor_identity().unwrap();
    finish(&mut unit, unit_floor);
    let mut exact_cost = 0;
    let mut unit_result = None;
    for _ in 0..20000 {
        let service = unit.advance_observer_source_cycle(unit_floor, limits(), 1).unwrap();
        assert_eq!(service.allowed_units, service.spent_units + service.returned_units);
        exact_cost += service.spent_units;
        if service.source_cycle.is_some() { unit_result = service.source_cycle; break; }
    }
    let unit_result = unit_result.expect("unchanged native fixture completes under unit grants");
    assert!(exact_cost > 1, "the court exercises retained comparison plus its separate anchor toll");
    let (mut coarse, _, _) = published();
    let coarse_floor = coarse.top_floor_identity().unwrap();
    finish(&mut coarse, coarse_floor);
    let before = coarse.acquisition_work_receipt().unwrap();
    // Independent unit service measures the exact existing obligations, rather
    // than choosing a larger budget that might hide unnecessary new quotes.
    let service = coarse.advance_observer_source_cycle(coarse_floor, limits(), exact_cost).unwrap();
    let current = service.source_cycle.expect("one coarse quote must drain ready binding work and seal");
    assert_eq!(service.spent_units, exact_cost);
    assert_eq!(service.allowed_units, service.spent_units + service.returned_units);
    assert_eq!(service.returned_units, 0);
    assert_eq!(current.phase, unit_result.phase);
    assert_eq!(current.primitive_observable_period, unit_result.primitive_observable_period);
    let after = coarse.acquisition_work_receipt().unwrap();
    assert_eq!(after.requests(), before.requests() + 1);
    assert_eq!(after.spent_units() - before.spent_units(), BigUint::from(exact_cost));
}

#[cfg(feature = "serde")]
mod source_cycle_export;
