//! Native reservation/capture observations, never a second publication path.
use super::*;
use crate::organism::causal_coordinates::lifecycle_export::{cut, sensory};
use crate::organism::causal_coordinates::CapturedEvent;
use crate::organism::{ActionCapture, ActionFailure, ActionStage,
    ObservedAction, Resumption, Sensory, TerminalKind, TerminalScope, ActionOperation, ActionContext};
use serde_json::{json, Value as Json};

#[derive(Default)]
struct Owners { slots: Vec<Arc<OnceLock<CapturedEvent>>> }
impl Owners {
    fn slot(&mut self, value: &Arc<OnceLock<CapturedEvent>>) -> usize {
        if let Some(index) = self.slots.iter().position(|old| Arc::ptr_eq(old, value)) { return index; }
        self.slots.push(Arc::clone(value)); self.slots.len() - 1
    }
    fn reservation(&mut self, value: &Reservation<u16>) -> Json {
        json!({"before":cut(&value.before),"next_ordinal":value.next_ordinal,
            "highest_epoch":value.highest_epoch.to_string(),"pending_epoch":value.pending_epoch.map(|v|v.to_string()),
            "slot":self.slot(&value.captured),"slot_filled":value.captured.get().is_some(),
            "unpublished_history":history(&value.next_history)})
    }
    fn pending(&mut self, value: &Reserving<u16>) -> Json {
        json!({"before":cut(&value.before),"next_ordinal":value.next_ordinal,
            "highest_epoch":value.highest_epoch.to_string(),"pending_epoch":value.pending_epoch.map(|v|v.to_string()),
            "slot":self.slot(&value.captured),"slot_filled":value.captured.get().is_some(),
            "poisoned":value.poisoned,"stage":match value.stage {
                Stage::History=>json!("History"),Stage::Raw=>json!("Raw"),
                Stage::Layer{index,action}=>json!({"Layer":{"index":index,"action":action}}),Stage::Complete=>json!("Complete")},
            "history_update_pending":value.history.is_some(),"history_ready":value.next_history.is_some(),
            "raw_ready":value.next_raw.is_some(),"bump":value.bump.as_ref().map(|b|json!({
                "lookup_pending":b.lookup.is_some(),"update_pending":b.update.is_some(),"ordinal":b.ordinal}))})
    }
    fn dispatch(&mut self, value: &CapturedDispatch<'_,u16>) -> Json {
        json!({"requested":value.requested,"capture":capture_json(value.capture()),
            "pending":value.pending.as_ref().map(|p|json!({
                "reservation":self.reservation(&p.transaction.reservation),
                "owner":timeline(p.transaction.owner)}))})
    }
}
fn result_target(value: Result<Arc<[u8]>, crate::organism::TargetError>) -> Json {
    match value { Ok(bytes)=>json!({"Ok":bytes.as_ref()}),Err(e)=>json!({"Err":format!("{e:?}")}) }
}
fn observed(v: ObservedAction) -> Json { match v {
    ObservedAction::Step=>json!("Step"),ObservedAction::Refused=>json!("Refused"),
    ObservedAction::Terminal{kind,resumption}=>json!({"Terminal":{"kind":format!("{kind:?}"),"resumption":format!("{resumption:?}")}}),
} }
fn terminal(v: TerminalKind) -> &'static str { match v {
    TerminalKind::Death=>"Death",TerminalKind::Time=>"Time",TerminalKind::Completed=>"Completed",TerminalKind::Ended=>"Ended",
} }
fn failure(v: &ActionFailure<u16>) -> Json {
    json!({"operation":match v.operation {
        ActionOperation::Act(action)=>json!({"Act":action}),ActionOperation::Begin=>json!("Begin"),
        ActionOperation::Checkpoint=>json!("Checkpoint"),ActionOperation::Restore=>json!("Restore")},
        "action":v.action(),"terminal":v.terminal.map(terminal),
        "terminal_scope":match v.terminal_scope {TerminalScope::Action=>"Action",TerminalScope::Episode=>"Episode"},
        "stage":match v.stage {ActionStage::Budget=>"Budget",ActionStage::Dispatch=>"Dispatch",ActionStage::Receive=>"Receive",
            ActionStage::Decode=>"Decode",ActionStage::Restart=>"Restart",ActionStage::Replay=>"Replay"},
        "context":match v.context {ActionContext::Live=>"Live",ActionContext::Imagined=>"Imagined"},"cause":v.cause})
}
fn owner_guard(before:&Cut<u16>,highest_epoch:u128,pending_epoch:Option<u128>,owner:&Timeline<u16>)->Json {
    let comparisons=json!({"complete":owner.complete,"lineage":before.id.lineage==owner.lineage,
        "ordinal":before.id.ordinal==owner.ordinal,"epoch":before.epoch==owner.epoch,"raw_space":before.raw_space==owner.raw_space,
        "highest_epoch":highest_epoch==owner.highest_epoch,"pending_epoch":pending_epoch==owner.pending_epoch,
        "layers_pointer":Arc::ptr_eq(&before.layers,&owner.layers),"raw_native_root":before.raw_before.same_native_root(&owner.raw_current),
        "history_end":before.history_before.end==owner.history.end,"history_native_root":before.history_before.root.same_native_root(&owner.history.root)});
    let result=same_owner(before,highest_epoch,pending_epoch,owner);
    assert_eq!(result,comparisons.as_object().unwrap().values().all(|v|v.as_bool()==Some(true)));
    json!({"before":cut(before),"highest_epoch":highest_epoch.to_string(),"pending_epoch":pending_epoch.map(|v|v.to_string()),
        "owner":timeline(owner),"comparisons":comparisons,"native_result":result})
}
fn bind_observed<'a>(reservation:Reservation<u16>,owner:&'a mut Timeline<u16>,records:&mut Vec<Json>)
    ->Result<Prepared<'a,u16>,Reservation<u16>> {
    let guard=owner_guard(&reservation.before,reservation.highest_epoch,reservation.pending_epoch,owner);
    let result=reservation.bind(owner);
    assert_eq!(guard["native_result"],json!(result.is_ok()));
    records.push(json!({"guard":guard,"accepted":result.is_ok()}));
    result
}
fn capture_json(v: &ActionCapture<u16>) -> Json {
    json!({"action":v.action(),"result":match v.result() {
        Ok(o)=>json!({"Ok":observed(*o)}),Err(e)=>json!({"Err":failure(e)})},
        "observation":v.observation().map(sensory),"resumed":v.resumed().map(sensory),"target":result_target(v.target())})
}
fn event(v: &HistoryEvent<u16>) -> Json {
    json!({"lineage":lifecycle_lineage(&v.id.lineage),"ordinal":v.id.ordinal,
        "time":{"episode":v.time.episode,"life_age":v.time.life_age},
        "raw":v.event.raw_state,"state":v.event.situation,"action":v.event.action,
        "epoch":v.epoch.to_string(),"raw_space":v.raw_space.to_string(),"pose":v.pose,
        "inputs":v.inputs.iter().map(|(e,s)|json!([e.to_string(),s])).collect::<Vec<_>>(),
        "sensory":v.sensory.as_ref().map(sensory),"captured":v.captured().map(|c|json!({
            "observed":observed(c.observed()),"observation":c.observation().map(sensory),"target":result_target(c.target())}))})
}
fn history(v: &HistoryPrefix<u16>) -> Json {
    json!({"lineage":lifecycle_lineage(&v.lineage),"end":v.end,
        "events":(0..v.end).map(|at|event(&v.root.get(&at).expect("complete tree"))).collect::<Vec<_>>()})
}
fn timeline(v: &Timeline<u16>) -> Json {
    json!({"lineage":lifecycle_lineage(&v.lineage),"ordinal":v.ordinal,"complete":v.complete,
        "epoch":v.epoch.to_string(),"raw_space":v.raw_space.to_string(),"highest_epoch":v.highest_epoch.to_string(),
        "pending_epoch":v.pending_epoch.map(|v|v.to_string()),"history":history(&v.history)})
}
fn fresh() -> Timeline<u16> {
    let mut authority=HistoryAuthority::new().unwrap();
    Timeline::new(authority.birth().unwrap(),1,1,100_000)
}
fn reserve(v: &Timeline<u16>) -> Reserving<u16> {
    v.reserving_in_layers_with_sensory(PreActionTime{episode:0,life_age:v.ordinal},31,&[(1,41)],257,Some(6),
        Some(Sensory::new(Arc::from([2]),Arc::from([3,5])))).unwrap()
}
fn sample(action:u16, byte:u8) -> ActionCapture<u16> {
    ActionCapture::new(action,Ok(ObservedAction::Step),Some(Sensory::new(Arc::from([7]),Arc::from([byte]))),None).unwrap()
}

#[test]
fn physical_causal_lifecycle_snapshot() {
    let mut owners=Owners::default(); let mut cases=Vec::new(); let mut bindings=Vec::new();
    let mut life=fresh(); let original=life.current_history().unwrap();
    let original_json=history(&original);
    let direct=reserve(&life).run_to_completion(&mut 10_000).unwrap();
    let direct_json=owners.reservation(&direct);
    let mut pending=reserve(&life);let original_slot=Arc::clone(&pending.captured);
    let mut visits=Vec::new();let mut ready=false;
    for turn in 0..512 {
        let grant=if turn%2==0 {0} else {1};let mut work=grant;
        let before=owners.pending(&pending);
        let guard=owner_guard(&pending.before,pending.highest_epoch,pending.pending_epoch,&life);
        let result=pending.advance(&life,&mut work);
        visits.push(json!({"grant":grant,"paid":grant-work,"before":before,"guard":guard,
            "result":format!("{result:?}"),"after":owners.pending(&pending),
            "same_slot":Arc::ptr_eq(&original_slot,&pending.captured),
            "same_published_root":life.history.root.same_native_root(&original.root),"owner":timeline(&life)}));
        assert!(Arc::ptr_eq(&original_slot,&pending.captured));
        assert!(life.history.root.same_native_root(&original.root));assert_eq!(life.ordinal,0);
        match result { Ok(true)=>{ready=true;break},Ok(false)=>{},
            Err(ReservationRefusal::History(Refusal::Store(StoreRefusal::Work)))=>{},Err(e)=>panic!("{e:?}") }
    }
    assert!(ready);
    let reservation=pending.finish().unwrap_or_else(|_|panic!("completed reservation"));
    assert_eq!(reservation.before.id,direct.before.id);assert_eq!(reservation.before.event,direct.before.event);
    let reservation_json=owners.reservation(&reservation);drop(direct);
    let body:Arc<[u8]>=Arc::from((0..=255u8).collect::<Vec<_>>());
    let sensor=Sensory::new(Arc::from([7,8]),Arc::clone(&body));
    let restart=Sensory::new(Arc::from([9]),Arc::from([11,12]));
    let mut calls=Vec::new();
    let dispatch=CapturedDispatch::invoke(bind_observed(reservation,&mut life,&mut bindings).unwrap().dispatch(),|action|{
        calls.push(action);ActionCapture::new(action,Ok(ObservedAction::Terminal{
            kind:TerminalKind::Completed,resumption:Resumption::Resumed}),Some(sensor.clone()),Some(restart.clone())).unwrap()
    });
    let invocation=owners.dispatch(&dispatch);let expected=dispatch.capture().target().unwrap();
    let (before,returned)=dispatch.observed().unwrap_or_else(|_|panic!("same invocation"));
    let before=before.unwrap();let now=life.current_history().unwrap();
    let retained_event=now.root.get(&0).unwrap();
    let retained=retained_event.captured().unwrap();
    let same_body=Arc::ptr_eq(retained.observation().unwrap().body(),&body);
    assert!(same_body);assert_eq!(retained.target().unwrap(),expected);assert_eq!(calls,vec![257]);
    assert_eq!(history(&original),original_json);assert!(original.root.get(&0).is_none());
    cases.push(json!({"kind":"zero_unit_then_terminal","original":original_json,"direct":direct_json,
        "visits":visits,"ready":reservation_json,"invocation":invocation,"callback_actions":calls,
        "returned_cut":cut(&before),"returned_capture":capture_json(&returned),"after":timeline(&life),
        "same_observation_body":same_body,"old_history_after":history(&original),
        "published_slot":owners.slot(&now.root.get(&0).unwrap().captured)}));

    for kind in ["foreign_action","unobserved","missing_body","owned_terminal_failure","episode_terminal_failure","foreign_terminal_failure","control_failure"] {
        let mut life=fresh();let before=life.current_history().unwrap();
        let reservation=reserve(&life).run_to_completion(&mut 10_000).unwrap();
        let slot=Arc::clone(&reservation.captured);let prepared=owners.reservation(&reservation);
        let mut calls=Vec::new();
        let dispatch=CapturedDispatch::invoke(bind_observed(reservation,&mut life,&mut bindings).unwrap().dispatch(),|action|{
            calls.push(action);match kind {
                "foreign_action"=>sample(9,31),
                "unobserved"=>ActionCapture::unavailable(action,Err(ActionFailure::new(action,ActionStage::Receive,"unknown delivery"))),
                "owned_terminal_failure"=>ActionCapture::new(action,Err(ActionFailure::after_action_terminal(action,ActionStage::Restart,"restart unavailable",TerminalKind::Ended)),
                    Some(Sensory::new(Arc::from([7]),Arc::from([19]))),None).unwrap(),
                "episode_terminal_failure"=>ActionCapture::unavailable(action,Err(ActionFailure::new(action,ActionStage::Restart,"previous episode terminal").after_terminal(TerminalKind::Ended))),
                "foreign_terminal_failure"=>ActionCapture::unavailable(action,Err(ActionFailure::after_action_terminal(9,ActionStage::Restart,"foreign action terminal",TerminalKind::Ended))),
                "control_failure"=>ActionCapture::unavailable(action,Err(ActionFailure::restore(ActionStage::Replay,"restore failed"))),
                _=>ActionCapture::unavailable(action,Ok(ObservedAction::Step)),
            }
        });
        let invocation=owners.dispatch(&dispatch);
        let returned=match dispatch.observed() {
            Ok((cut,capture))=>json!({"Ok":{"cut":cut.as_ref().map(self::cut),"capture":capture_json(&capture)}}),
            Err(owner)=>json!({"Err":owners.dispatch(&owner)}),
        };
        let same_root=life.history.root.same_native_root(&before.root);
        assert_eq!(calls,vec![257]);
        if kind=="missing_body" { assert_eq!(life.ordinal,1);assert!(life.complete);assert!(slot.get().is_some());
            assert_eq!(slot.get().unwrap().outcome.target(),Err(crate::organism::TargetError::Missing)); }
        else if kind=="owned_terminal_failure" { assert_eq!(life.ordinal,1);assert!(life.complete);assert!(slot.get().is_some());
            assert!(slot.get().unwrap().outcome.target().is_ok()); }
        else { assert_eq!(life.ordinal,0);assert!(!life.complete);assert!(same_root);assert!(slot.get().is_none()); }
        cases.push(json!({"kind":kind,"before":history(&before),"reservation":prepared,"invocation":invocation,
            "callback_actions":calls,"result":returned,"after":timeline(&life),"same_root":same_root,"slot_filled":slot.get().is_some()}));
    }

    let mut life=fresh();let stale=reserve(&life).run_to_completion(&mut 10_000).unwrap();
    let slot=Arc::clone(&stale.captured);let stale_json=owners.reservation(&stale);
    let concurrent=reserve(&life).run_to_completion(&mut 10_000).unwrap();
    let mut calls=0;
    let dispatch=CapturedDispatch::invoke(bind_observed(concurrent,&mut life,&mut bindings).unwrap().dispatch(),|action|{calls+=1;sample(action,91)});
    let invocation=owners.dispatch(&dispatch);
    dispatch.observed().unwrap_or_else(|_|panic!("current reservation"));
    let before_bind=timeline(&life);
    let returned=match bind_observed(stale,&mut life,&mut bindings) { Err(owner)=>owner,Ok(_)=>panic!("stale bind admitted") };
    assert!(Arc::ptr_eq(&returned.captured,&slot));assert!(slot.get().is_none());
    assert_eq!(timeline(&life),before_bind);assert_eq!(calls,1);
    cases.push(json!({"kind":"stale_reservation","reservation":stale_json,"concurrent_invocation":invocation,
        "before_bind":before_bind,"returned":owners.reservation(&returned),"after_bind":timeline(&life),
        "same_slot":Arc::ptr_eq(&returned.captured,&slot),"callback_count":calls}));

    let (mut first,mut second)=(fresh(),fresh());
    let a=reserve(&first).run_to_completion(&mut 10_000).unwrap();
    let b=reserve(&second).run_to_completion(&mut 10_000).unwrap();
    let mut calls=Vec::new();
    let a=CapturedDispatch::invoke(bind_observed(a,&mut first,&mut bindings).unwrap().dispatch(),|action|{calls.push(action);sample(action,11)});
    let b=CapturedDispatch::invoke(bind_observed(b,&mut second,&mut bindings).unwrap().dispatch(),|action|{calls.push(action);sample(action,22)});
    let invocations=json!([owners.dispatch(&a),owners.dispatch(&b)]);
    let (target_a,target_b)=(a.capture().target().unwrap(),b.capture().target().unwrap());
    let (cut_b,_)=b.observed().unwrap_or_else(|_|panic!("second invocation"));
    let (cut_a,_)=a.observed().unwrap_or_else(|_|panic!("first invocation"));
    assert_eq!(first.history.root.get(&0).unwrap().captured().unwrap().target().unwrap(),target_a);
    assert_eq!(second.history.root.get(&0).unwrap().captured().unwrap().target().unwrap(),target_b);
    assert_ne!(target_a,target_b);assert_ne!(first.lineage,second.lineage);assert_eq!(calls,vec![257,257]);
    cases.push(json!({"kind":"independent_reverse_completion","invocations":invocations,"callback_actions":calls,
        "completion_order":[cut_b.as_ref().map(cut),cut_a.as_ref().map(cut)],"after":[timeline(&first),timeline(&second)]}));

    let mut life=fresh();let reservation=reserve(&life).run_to_completion(&mut 10_000).unwrap();
    let prepared=owners.reservation(&reservation);
    let before=bind_observed(reservation,&mut life,&mut bindings).unwrap().dispatch().observed();
    assert!(life.history.root.get(&0).unwrap().captured().is_none());
    cases.push(json!({"kind":"legacy_confirmation","reservation":prepared,"returned_cut":cut(&before),"after":timeline(&life)}));
    let packet=json!({"format":"synarc-physical-causal-lifecycle-v2","cases":cases,"bindings":bindings,
        "scope":{"observed":"actual reservation/dispatch/capture/refusal/root transitions; structured failure fields; full same_owner comparisons at advance/bind; full published histories; nominal slots retain Arc owners",
            "premises":["physical adapter reports the world truthfully","exported outer reservation frontier does not expose internal AVL cursor positions","native pointer comparisons are observations, not a portable memory-model proof"]}});
    if let Ok(path)=std::env::var("SYNARC_PHYSICAL_CAUSAL_EXPORT") {
        use std::io::Write;
        let mut out=std::fs::OpenOptions::new().create(true).append(true).open(path).unwrap();
        serde_json::to_writer(&mut out,&packet).unwrap();writeln!(out).unwrap();
    }
}
