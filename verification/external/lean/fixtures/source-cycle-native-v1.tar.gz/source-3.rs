//! Source time owned by physical dispatch, distinct from imported time metadata.
//! No periodicity or relation to a world's internal clock is asserted here.
use super::{PreActionTime, SampleId};
use super::super::{ObservedAction, TerminalKind};
use std::sync::Arc;

#[derive(Debug)]
struct Origin;

/// Read-only point in one local source-time origin. Cloning grants no tick.
#[derive(Clone, Debug)]
pub(in crate::organism) struct Point {
    origin: Arc<Origin>,
    time: PreActionTime,
}
impl PartialEq for Point {
    fn eq(&self, other: &Self) -> bool {
        self.same_origin(other) && self.time == other.time
    }
}
impl Eq for Point {}
impl Point {
    pub(in crate::organism) fn metadata(&self) -> PreActionTime { self.time }
    pub(in crate::organism) fn same_origin(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.origin, &other.origin)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum Transition { Tick, TerminalReset(TerminalKind) }

/// Immutable inspection evidence for one actually captured physical operation.
/// A successor is actionable only after the owner consumes its linear receipt
/// and, for a terminal, closes the pending episode. None means exhausted episode
/// identity, never an invented wraparound. This is not a finite-factor proof.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::organism) struct Edge {
    point: Point,
    sample: Option<SampleId>,
    transition: Transition,
    successor: Option<PreActionTime>,
}
impl Edge {
    pub(in crate::organism) fn point(&self) -> &Point { &self.point }
    pub(in crate::organism) fn sample(&self) -> Option<SampleId> { self.sample }
    pub(in crate::organism) fn transition(&self) -> Transition { self.transition }
    pub(in crate::organism) fn successor(&self) -> Option<PreActionTime> { self.successor }
    // Only the enclosing physical dispatch owner constructs edges. An inspected
    // ActionCapture or a caller-supplied PreActionTime is insufficient.
    pub(super) fn observed(point: Point, sample: Option<SampleId>, outcome: ObservedAction) -> Self {
        let (transition, successor) = match outcome {
            ObservedAction::Step | ObservedAction::Refused => (Transition::Tick, Some(PreActionTime {
                episode: point.time.episode,
                life_age: point.time.life_age.checked_add(1).expect("physical dispatch preflights age addressability"),
            })),
            ObservedAction::Terminal { kind, .. } => (Transition::TerminalReset(kind),
                point.time.episode.checked_add(1).map(|episode| PreActionTime { episode, life_age: 0 })),
        };
        Self { point, sample, transition, successor }
    }
}

/// Created only after the matching clock has consumed its linear receipt.
/// Inspection cannot consume another tick or certify a native observer update.
#[derive(Debug)]
pub(in crate::organism) struct Applied { edge: Edge }
impl Applied {
    pub(in crate::organism) fn edge(&self) -> &Edge { &self.edge }
    pub(in crate::organism) fn tick_successor(&self) -> Option<Point> {
        if self.edge.transition != Transition::Tick { return None; }
        Some(Point { origin: Arc::clone(&self.edge.point.origin), time: self.edge.successor? })
    }
}

/// Consumed once by the clock that authorized the invocation. Not Clone/Copy.
#[derive(Debug)]
pub(in crate::organism) struct Receipt { edge: Edge }
impl Receipt {
    pub(super) fn observed(edge: Edge) -> Self { Self { edge } }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum Refusal {
    MissingEpisode, AgeOverflow, PendingOutcome, PendingTerminal,
    UndeclaredTime, ForeignPoint,
}
/// Restart needs completed time ownership, independently of journal retention.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum RestartRefusal { PendingOutcome, PendingTerminal }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase { Ready, InFlight, TerminalPending }

/// The sole production owner of episode and life age. A declared new run starts
/// a fresh origin; it does not certify that an external world physically reset.
#[derive(Debug)]
pub(in crate::organism) struct Clock {
    origin: Arc<Origin>, episode: Option<u64>, life_age: u64, phase: Phase,
}
impl Clock {
    pub(in crate::organism) fn new() -> Self {
        Self { origin: Arc::new(Origin), episode: Some(0), life_age: 0, phase: Phase::Ready }
    }
    pub(in crate::organism) fn episode(&self) -> Option<u64> { self.episode }
    pub(in crate::organism) fn life_age(&self) -> u64 { self.life_age }
    pub(in crate::organism) fn point(&self) -> Result<Point, Refusal> {
        match self.phase {
            Phase::InFlight => return Err(Refusal::PendingOutcome),
            Phase::TerminalPending => return Err(Refusal::PendingTerminal),
            Phase::Ready => {},
        }
        let episode = self.episode.ok_or(Refusal::MissingEpisode)?;
        self.life_age.checked_add(1).ok_or(Refusal::AgeOverflow)?;
        Ok(Point { origin: Arc::clone(&self.origin), time: PreActionTime { episode, life_age: self.life_age } })
    }
    pub(super) fn start(&mut self, point: &Point) -> Result<(), Refusal> {
        if self.point()?.ne(point) { return Err(Refusal::ForeignPoint); }
        self.phase = Phase::InFlight;
        Ok(())
    }
    pub(in crate::organism) fn commit(&mut self, receipt: Receipt) -> Result<Applied, (Refusal, Receipt)> {
        if self.phase != Phase::InFlight || !Arc::ptr_eq(&self.origin, &receipt.edge.point.origin)
            || self.episode != Some(receipt.edge.point.time.episode)
            || self.life_age != receipt.edge.point.time.life_age {
            return Err((Refusal::ForeignPoint, receipt));
        }
        match receipt.edge.transition {
            Transition::Tick => {
                self.life_age = receipt.edge.successor.expect("a preflighted tick owns its successor").life_age;
                self.phase = Phase::Ready;
            },
            Transition::TerminalReset(_) => {
                // Preserve native ordering: age resets before terminal witness
                // service; the episode closes only after that service finishes.
                self.life_age = 0;
                self.phase = Phase::TerminalPending;
            },
        }
        Ok(Applied { edge: receipt.edge })
    }
    pub(in crate::organism) fn close_terminal(&mut self) -> Result<(), Refusal> {
        if self.phase != Phase::TerminalPending { return Err(Refusal::PendingTerminal); }
        self.episode = self.episode.and_then(|episode| episode.checked_add(1));
        self.phase = Phase::Ready;
        Ok(())
    }
    /// Inspect only ownership phase: ready clocks at an arithmetic boundary may
    /// still declare a new run. This grants no physical reset evidence.
    pub(in crate::organism) fn check_restart(&self) -> Result<(), RestartRefusal> {
        match self.phase {
            Phase::Ready => Ok(()),
            Phase::InFlight => Err(RestartRefusal::PendingOutcome),
            Phase::TerminalPending => Err(RestartRefusal::PendingTerminal),
        }
    }
    /// Compare origin identity without granting an actionable point or a tick.
    pub(in crate::organism) fn has_origin(&self, point: &Point) -> bool {
        Arc::ptr_eq(&self.origin, &point.origin)
    }
    pub(in crate::organism) fn declared_restart(&mut self) -> Result<(), RestartRefusal> {
        self.check_restart()?;
        self.origin = Arc::new(Origin);
        self.episode = self.episode.and_then(|episode| episode.checked_add(1));
        self.life_age = 0;
        self.phase = Phase::Ready;
        Ok(())
    }
    #[cfg(test)]
    pub(in crate::organism) fn at_episode_limit() -> Self {
        Self { episode: Some(u64::MAX), ..Self::new() }
    }
}

/// Explicit protocols share the same reservation executor. Plain metadata is
/// retained faithfully but cannot become physical source-time authority.
pub(in crate::organism) enum Input { Declared(PreActionTime), Physical(Point) }
impl From<PreActionTime> for Input { fn from(time: PreActionTime) -> Self { Self::Declared(time) } }
impl From<Point> for Input { fn from(point: Point) -> Self { Self::Physical(point) } }
impl Input {
    pub(super) fn parts(self) -> (PreActionTime, Option<Point>) {
        match self { Self::Declared(time) => (time, None), Self::Physical(point) => (point.metadata(), Some(point)) }
    }
}

#[cfg(test)]
mod courts;

#[cfg(test)]
pub(in crate::organism) mod export;

// Native contracts run by the source-bound Verum/Kani adapter.
#[cfg(kani)]
mod verification;
