//! Opt-in actual native boundary witnesses. No restore or certificate constructor.
//! The initial acquired fixture has an explicitly omitted physical prefix.
use super::*;
use crate::organism::causal_coordinates::{self as history, physical_time, CapturedDispatch};
use crate::organism::observer_acquired::lifecycle_export as encode;
use crate::organism::observer_acquired_courts::lifecycle_export::report;
use crate::program::observer::lifecycle_export::{identity, Identities};
use serde_json::{json, Value as Json};

type Ids = Identities<input::Value<u8>, input::Op, input::Source, input::Meaning>;
struct Recorder {
    ids: Ids,
    namespaces: observer_runtime::lifecycle_export::Namespaces,
    clock: physical_time::export::Recorder,
    histories: Vec<Arc<input::NativeHistory<u8>>>,
    certificates: Vec<Arc<finite::CertifiedCycle<u8>>>,
    rows: Vec<Json>,
    anchor_event: Option<usize>,
}
fn limits_json(limits: ObserverFiniteLimits) -> Json {
    json!({"states":limits.states,"workspace":limits.workspace,"execution":match limits.execution {
        ExecutionLimit::Unlimited=>json!({"Unlimited":null}),ExecutionLimit::Dispatches(n)=>json!({"Dispatches":n})}})
}
fn public_result(result: Result<Option<ObserverSourceCycleReceipt>, ObserverFiniteRefusal>) -> Json {
    match result {
        Ok(None)=>json!({"Ok":null}), Err(reason)=>json!({"Err":format!("{reason:?}")}),
        Ok(Some(r))=>json!({"Ok":{"floor":{"lineage":history::lifecycle_lineage(&r.floor.lineage),
            "input_epoch":r.floor.input_epoch.to_string(),"output_epoch":r.floor.output_epoch.to_string()},
            "primitive_observable_period":r.primitive_observable_period,"phase":r.phase,
            "anchor_episode":r.anchor_episode,"anchor_age":r.anchor_age,"anchor_phase":r.anchor_phase,
            "episode":r.episode,"life_age":r.life_age}}),
    }
}
impl Recorder {
    fn new() -> Self { Self { ids:Ids::new(),namespaces:observer_runtime::lifecycle_export::Namespaces::new(),clock:physical_time::export::Recorder::new(),
        histories:Vec::new(),certificates:Vec::new(),rows:Vec::new(),anchor_event:None } }
    fn snapshot(&mut self, org: &Organism<u8>, floor: FloorIdentity) -> Json {
        // Public inspection is observed independently, before taking the same
        // analysis mutex for private diagnostics. It does no proof/VM work.
        let inspection = public_result(org.observer_source_cycle(floor));
        let ex = org.exhaust.as_ref().unwrap();
        let general = ex.floors[0].observer.general();
        let installed = general.installed();
        let native = self.ids.cut(&installed.cut(), encode::value);
        let history_id = identity(&mut self.histories, installed.history());
        let slot = general.finite_analysis.lock().unwrap();
        let certificate = slot.as_ref().and_then(|a| a.certificate.as_ref())
            .map(|c| identity(&mut self.certificates,c));
        let binding = slot.as_ref().and_then(|a| a.source_cycle.as_ref()).map(|owner| {
            let view = owner.export_view();
            json!({"certificate":identity(&mut self.certificates,view.bound.certificate()),
                "anchor_event":self.anchor_event,"anchor_point":self.clock.point(view.anchor),
                "anchor_phase":view.anchor_phase,"point":self.clock.point(view.point),
                "bound_cut":self.ids.cut(view.bound.export_cut(),encode::value),
                "state_index":view.bound.state_index(),"pending_sample":view.pending_sample.map(|s|json!({
                    "lineage":history::lifecycle_lineage(&s.lineage),"ordinal":s.ordinal}))})
        });
        let following = slot.as_ref().and_then(|a| a.source_binding.as_ref()).map(|owner| {
            let view = owner.export_view();
            json!({"certificate":identity(&mut self.certificates,view.certificate),
                "original_cut":self.ids.cut(view.original,encode::value),"latest_cut":self.ids.cut(view.latest,encode::value),
                "history":identity(&mut self.histories,view.history),"origin_cut":view.origin_cut,
                "comparison_cursor":view.comparison_cursor,"comparison_pending":view.comparing,"found_index":view.found,
                "shift":{"states":view.states,"start":view.start,"capped":view.capped,"residue":view.residue},
                "broken":view.broken,"taken":view.taken,"poisoned":view.poisoned})
        });
        json!({"floor":{"lineage":history::lifecycle_lineage(&floor.lineage),
            "input_epoch":floor.input_epoch.to_string(),"output_epoch":floor.output_epoch.to_string()},
            "clock":self.clock.clock(&org.source_time),"journal":{
                "pending_boundary":ex.before_act_continuation.is_some() || ex.after_act_continuation.is_some()
                    || ex.pending_domain_retirement.is_some(),
                "history_known":ex.observer_history.current_history().is_ok(),"ordinal":ex.observer_history.ordinal()},
            "installed":{"cut":native,"history":history_id,"origin_cut":installed.origin_cut()},
            "namespace":self.namespaces.snapshot(general),
            "certificate":certificate,"binding":binding,"following_binding":following,"inspection":inspection})
    }
    fn push(&mut self, operation: &str, input: Json, result: Json, before: Json, after: Json) -> usize {
        let seq = self.rows.len();
        self.rows.push(json!({"seq":seq,"operation":operation,"input":input,"result":result,"before":before,"after":after}));
        seq
    }
    fn service(&mut self, org: &mut Organism<u8>, floor: FloorIdentity, quote: usize) -> bool {
        let before = self.snapshot(org,floor);
        let result = org.advance_observer_source_cycle(floor,limits(),quote);
        if let Ok(r)=&result { assert_eq!(r.allowed_units,r.spent_units+r.returned_units); }
        let ready = result.as_ref().is_ok_and(|r|r.source_cycle.is_some());
        if ready { self.anchor_event=Some(self.rows.len()); }
        let encoded = match result {
            Ok(r)=>json!({"Ok":{"quoted":r.quoted_units,"allowed":r.allowed_units,"spent":r.spent_units,
                "returned":r.returned_units,"strict_analysis":format!("{:?}",r.analysis.status),
                "source_cycle":public_result(Ok(r.source_cycle))}}),
            Err(reason)=>json!({"Err":format!("{reason:?}")}),
        };
        let after = self.snapshot(org,floor);
        if quote==0 { assert_eq!(before,after,"zero work changes no native/source owner"); }
        self.push("anchor",json!({"limits":limits_json(limits()),"quoted_work":quote}),encoded,before,after);
        ready
    }
    fn restart(&mut self, org: &mut Organism<u8>, floor: FloorIdentity, success: bool) {
        let before=self.snapshot(org,floor);
        let result=org.begin_run();
        assert_eq!(result.is_ok(),success);
        let after=self.snapshot(org,floor);
        self.push("begin_run",Json::Null,match result {Ok(())=>json!({"Ok":null}),Err(e)=>json!({"Err":format!("{e:?}")})},before,after);
    }
    fn dispatch(&mut self, org: &mut Organism<u8>, floor: FloorIdentity,
        world: &mut Delivery, prepared_action: u8, refuse_restart: bool) {
        assert_eq!(org.exhaust.as_ref().unwrap().floors.len(),1);
        assert!(org.exhaust.as_ref().unwrap().tier.is_none());
        let raw=world.key();
        let point=org.source_time.point().unwrap();let time=point.metadata();
        let before=self.snapshot(org,floor);
        let mut work=ObserverWork{remaining:10000};
        let observer=&org.exhaust.as_ref().unwrap().floors[0].observer;
        observer.general().enable_audit();
        let view=observer_runtime::View{sensory:world.sensory(),raw,input:raw,
            episode:time.episode,life_age:time.life_age,pose:255};
        let mut budget=Budget::new(&mut work,ExecutionLimit::Unlimited);
        let read=observer.read(view.clone(),&mut budget).unwrap_or_else(|_|panic!("actual R before dispatch"));
        let prepared=observer.prepare(view,prepared_action,&mut budget).unwrap_or_else(|_|panic!("actual U preparation"));
        drop(budget);
        let read_audit=observer.general().take_audit();
        let [observer_runtime::AuditEvent::Read{query,reading,name,..}]=read_audit.as_slice() else {panic!("one actual native read");};
        assert_eq!(*name,read.key);
        let actual_read=json!({"input":encode::row(query),"cut":self.ids.cut(reading.cut(),encode::value),
            "value":encode::value(reading.value()),"execution":report(reading.execution()),"name":name});
        let prepared_json=self.ids.prepared(prepared.program(),encode::value);
        let actual_input=encode::row(prepared.input());
        let execution=report(prepared.program().execution());
        let after=self.snapshot(org,floor);
        let preparation=self.push("prepare",json!({"input":actual_input,"work_grant":10000,"execution_limit":{"Unlimited":null}}),
            json!({"read":actual_read,"prepared":prepared_json,"execution":execution,"remaining_work":work.remaining}),before,after);
        let before=self.snapshot(org,floor);let point_json=self.clock.point(&point);
        let pending=org.exhaust.as_mut().unwrap().observer_history.prepare_in_layers(point,raw,
            &[(floor.input_epoch(),raw),(floor.output_epoch(),read.key)],0,10000).unwrap().dispatch();
        let captured=CapturedDispatch::invoke_physical(pending,&mut org.source_time,|a|world.act_captured(a))
            .unwrap_or_else(|_|panic!("actual captured dispatch"));
        let (cut,capture,time_receipt)=captured.observed_physical().unwrap_or_else(|_|panic!("actual owned return tuple"));
        let cut=cut.unwrap();let receipt_json=self.clock.receipt(&time_receipt);
        let after=self.snapshot(org,floor);
        let captured_json=json!({"cut":history::lifecycle_export::cut(&cut),"receipt":receipt_json,
            "capture":{"action":capture.action(),"outcome":physical_time::export::Recorder::outcome(capture.captured_outcome().unwrap().observed())},
            "physical_point":self.clock.point(cut.physical_point().unwrap()),"world_calls":world.calls});
        let dispatch=self.push("dispatch",json!({"preparation":preparation,"point":point_json,"action":0}),captured_json,before,after);
        if refuse_restart { self.restart(org,floor,false); }
        let before=self.snapshot(org,floor);
        let observer=&mut org.exhaust.as_mut().unwrap().floors[0].observer;
        observer.general().enable_audit();
        let committed=observer.commit(prepared).unwrap_or_else(|_|panic!("actual successful U"));
        let audit=observer.general().take_audit();
        let [observer_runtime::AuditEvent::Commit{input,receipt}] = audit.as_slice() else { panic!("one actual native commit"); };
        assert!(receipt.before().same_revision(committed.before()));assert!(receipt.after().same_revision(committed.after()));
        let native=json!({"input":encode::row(input),"receipt":self.ids.committed(receipt,encode::value),"execution":report(receipt.execution())});
        let after=self.snapshot(org,floor);
        let native_event=self.push("native_commit",json!({"dispatch":dispatch,"preparation":preparation}),native,before,after);
        let before=self.snapshot(org,floor);
        org.exhaust.as_ref().unwrap().floors[0].observer.source_native_commit(&committed,&cut);
        let after=self.snapshot(org,floor);
        self.push("pair_native",json!({"dispatch":dispatch,"native_commit":native_event}),json!({"returned":"Unit"}),before,after);
        assert_eq!(org.observer_source_cycle(floor).unwrap(),None);
        let before=self.snapshot(org,floor);
        let applied=org.source_time.commit(time_receipt).unwrap();
        let after=self.snapshot(org,floor);
        let applied_json=self.clock.applied(&applied);
        let physical_event=self.push("physical_commit",json!({"dispatch":dispatch}),json!({"Ok":applied_json}),before,after);
        assert_eq!(org.observer_source_cycle(floor).unwrap(),None);
        let before=self.snapshot(org,floor);
        org.exhaust.as_ref().unwrap().floors[0].observer.source_physical_commit(&applied);
        let after=self.snapshot(org,floor);
        self.push("pair_physical",json!({"physical_commit":physical_event}),json!({"returned":"Unit"}),before,after);
        if matches!(world.outcome,ObservedAction::Terminal{..}) {
            let before=self.snapshot(org,floor);
            org.source_time.close_terminal().unwrap();
            let after=self.snapshot(org,floor);
            self.push("close_terminal",Json::Null,json!({"Ok":null}),before,after);
        }
    }
    fn write(mut self, case: &str) {
        let mut certificates=Vec::new();
        for (index,c) in self.certificates.clone().iter().enumerate() {
            let l=c.export_limits();
            let definition=self.ids.definition(c.definition());
            certificates.push(json!({"identity":index,"definition":definition,
                "autonomy":{"definition":definition,"applies":c.autonomy().applies_to(c.definition())},
                "limits":limits_json(ObserverFiniteLimits{states:l.states,workspace:l.workspace,execution:l.execution}),
                "inputs":c.hypothetical_inputs().iter().map(encode::row).collect::<Vec<_>>(),
                "carrier":c.carrier().iter().map(|cut|self.ids.cut(cut,encode::value)).collect::<Vec<_>>(),
                "readings":c.readings().iter().map(|r|json!({"cut":self.ids.cut(r.cut(),encode::value),
                    "value":encode::value(r.value()),"execution":report(r.execution())})).collect::<Vec<_>>(),
                "transitions":c.transitions().iter().map(|t|json!({"receipt":self.ids.committed(t,encode::value),
                    "execution":report(t.execution())})).collect::<Vec<_>>(),
                "closing_target":c.concrete_cycle_start(),"period":c.primitive_observable_period(),
                "observation_labels":c.observation_labels(),"phase_codes":c.projection().codes(),
                "scope":"autonomous observer factor; not a physical-world period"}));
        }
        let definitions=self.ids.definitions().iter().enumerate().map(|(i,d)|encode::definition(i,d)).collect::<Vec<_>>();
        let histories=self.histories.iter().enumerate().map(|(identity,h)| {
            let origin=h.origin();
            json!({"identity":identity,"origin":{"lineage":history::lifecycle_lineage(&origin.lineage()),
                "epoch":origin.epoch().to_string(),"ordinal":origin.ordinal()}})
        }).collect::<Vec<_>>();
        let data=json!({"protocol":"synarc-source-cycle-v1","case":case,"maximum":u64::MAX,
            "initialization":"actual acquired publication fixture; 128 ordinary Step/Refused prefix actions omitted; native boundary operations below are not a full Organism action-policy trace",
            "identity_scope":"one retained native/clock/history/certificate registry for the entire case",
            "definitions":definitions,"histories":histories,"certificates":certificates,"samples":self.clock.sample_catalogue(),"steps":self.rows});
        if let Some(root)=std::env::var_os("SYNARC_SOURCE_CYCLE_EXPORT") {
            let root=std::path::PathBuf::from(root);std::fs::create_dir_all(&root).unwrap();
            std::fs::write(root.join(format!("{case}.json")),serde_json::to_vec_pretty(&data).unwrap()).unwrap();
        }
    }
}
struct Delivery {outcome:ObservedAction,calls:usize}
impl Habitat for Delivery {
    type Action=u8;
    fn observe(&self)->[f64;7]{[1.0/7.0;7]}
    fn key(&self)->u64{1}
    fn actions(&self)->Vec<u8>{vec![0]}
    fn reset_action(&self)->Option<u8>{None}
    fn act(&mut self,_:u8)->Result<ObservedAction,ActionFailure<u8>>{self.calls+=1;Ok(self.outcome)}
}
#[test]
fn actual_source_cycle_lifecycle_export() {
    let (mut org,_,_)=published();let floor=org.top_floor_identity().unwrap();let mut log=Recorder::new();
    assert!(!log.service(&mut org,floor,0));
    // Certificate work is real; start moving exactly when membership starts.
    let mut pending=false;
    for _ in 0..20000 {
        assert!(!log.service(&mut org,floor,1));
        pending=org.exhaust.as_ref().unwrap().floors[0].observer.general().finite_analysis.lock().unwrap()
            .as_ref().is_some_and(|a|a.source_binding.is_some());
        if pending {break;}
    }
    assert!(pending);
    let mut world=Delivery{outcome:ObservedAction::Step,calls:0};let mut ready=false;
    for turn in 0..20000 {
        world.outcome=if turn%2==0{ObservedAction::Step}else{ObservedAction::Refused};
        log.dispatch(&mut org,floor,&mut world,0,turn==0);
        ready=log.service(&mut org,floor,1);
        if ready{break;}
    }
    assert!(ready,"moving exact membership eventually seals");
    for outcome in [ObservedAction::Step,ObservedAction::Refused,ObservedAction::Step,ObservedAction::Refused] {
        let before=org.observer_source_cycle(floor).unwrap().unwrap();world.outcome=outcome;
        log.dispatch(&mut org,floor,&mut world,0,false);
        let after=org.observer_source_cycle(floor).unwrap().unwrap();
        assert_eq!(after.phase,(before.phase+1)%before.primitive_observable_period);
    }
    let before=org.observer_source_cycle(floor).unwrap().unwrap();
    world.outcome=ObservedAction::Terminal{kind:TerminalKind::Ended,resumption:Resumption::Stopped};
    log.dispatch(&mut org,floor,&mut world,0,false);
    assert!(org.observer_source_cycle(floor).unwrap().is_none());
    assert!((0..20000).any(|_|log.service(&mut org,floor,1)));
    let reanchored=org.observer_source_cycle(floor).unwrap().unwrap();
    assert_eq!(reanchored.phase,(before.phase+1)%before.primitive_observable_period);
    let cut=org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
    log.restart(&mut org,floor,true);
    assert!((0..20000).any(|_|log.service(&mut org,floor,1)));
    assert!(cut.same_revision(&org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut()));
    assert_eq!(org.observer_source_cycle(floor).unwrap().unwrap().phase,reanchored.phase);
    log.write("moving_membership_and_physical_lifecycle");
}
#[test]
fn actual_matching_and_wrong_action_pair_exports() {
    let mut matching_successor=None;
    for prepared_action in [0,1] {
        let (mut org,_,_)=published();let floor=org.top_floor_identity().unwrap();let mut log=Recorder::new();
        assert!((0..20000).any(|_|log.service(&mut org,floor,1)));
        let mut world=Delivery{outcome:ObservedAction::Step,calls:0};
        log.dispatch(&mut org,floor,&mut world,prepared_action,false);
        assert_eq!(org.observer_source_cycle(floor).unwrap().is_some(),prepared_action==0);
        assert_eq!(world.calls,1);
        let actual=org.exhaust.as_ref().unwrap().floors[0].observer.general().installed().cut();
        if prepared_action==0 { matching_successor=Some(actual.state().clone()); }
        else { assert_eq!(matching_successor.as_ref(),Some(actual.state()),"wrong input has the same actual autonomous U successor"); }
        log.write(if prepared_action==0{"matching_actual_action"}else{"wrong_actual_action_equal_autonomous_successor"});
    }
}
