//! Actual Step/Refused observations purchase and validate a partial Rem reader.
//! No synthetic verdict, observer state, risk count or outcome is installed.
use super::*;
use crate::construction::family::{Grammar, OperationSpec, syntax::Syntax};
use crate::program::observer::{Budget, InputBinding, InputSource, acquisition::joint};
use crate::program::{ExecutionLimit, Operand as Arg, Operation, Program, Step};
use std::collections::BTreeMap;

struct ParityWorld {
    calls: u64,
    raw: u64,
    leave_support: bool,
    sensory: bool,
}
impl ParityWorld {
    fn new() -> Self {
        Self {
            calls: 0,
            raw: 2,
            leave_support: false,
            sensory: false,
        }
    }
}
impl Habitat for ParityWorld {
    type Action = u8;
    fn observe(&self) -> [f64; 7] {
        [1.0 / 7.0; 7]
    }
    fn key(&self) -> u64 {
        self.raw
    }
    fn actions(&self) -> Vec<u8> {
        vec![0]
    }
    fn reset_action(&self) -> Option<u8> {
        None
    }
    fn sensory(&self) -> Option<Sensory> {
        self.sensory.then(|| Sensory::new(
            Arc::from(b"refusal-court/u64-le".as_slice()),
            Arc::from(self.calls.to_le_bytes().as_slice()),
        ))
    }
    fn act(&mut self, action: u8) -> Result<ObservedAction, ActionFailure<u8>> {
        assert_eq!(action, 0, "rollback cannot bypass the physical action menu");
        let even = self.calls % 2 == 0;
        self.calls += 1;
        if self.leave_support {
            self.raw = 0;
            return Ok(ObservedAction::Step);
        }
        self.raw = 2;
        Ok(if even {
            ObservedAction::Step
        } else {
            ObservedAction::Refused
        })
    }
}
fn program(
    steps: Vec<(input::Op, Vec<Arg<input::Value<u8>>>)>,
) -> Program<input::Value<u8>, input::Op> {
    let output = Some(steps.len() - 1);
    Program {
        steps: steps
            .into_iter()
            .map(|(op, arguments)| Step {
                operation: Operation::Primitive(op),
                arguments,
            })
            .collect(),
        output,
        library: Vec::new(),
    }
}
fn grammar(inputs: usize, ops: &[input::Op]) -> Grammar<input::Op, input::Value<u8>> {
    Grammar {
        inputs,
        operations: ops
            .iter()
            .map(|&id| OperationSpec {
                id,
                arity: id.arity(),
            })
            .collect(),
        literals: Vec::new(),
        max_steps: 1,
    }
}
fn alphabet() -> BTreeMap<input::Context<u8>, BTreeSet<input::Value<u8>>> {
    BTreeMap::from([(
        (1, 2, 0),
        BTreeSet::from([
            input::Value::Outcome(ObservedWorldOutcome::Next(2)),
            input::Value::Outcome(ObservedWorldOutcome::Refused(2)),
        ]),
    )])
}

/// A declared finite source grammar, frozen before any measurements. A lexical
/// library makes the tiny court enumerate the actual composed Program directly;
/// original family/look names remain attached through native validation/install.
fn family(update_partial: bool) -> input::JointSeries<u8> {
    family_with_sensory(update_partial, false)
}
fn family_with_sensory(update_partial: bool, sensory: bool) -> input::JointSeries<u8> {
    let source = input::Source {
        sensory, epoch: 1,
        raw_space: 1,
        owner: None,
        shape: input::Shape::Event,
    };
    let query = input::Source {
        shape: input::Shape::Query,
        ..source.clone()
    };
    let semantics = Arc::new(input::Meaning::for_sensory_court(4096));
    let initial = Syntax::freeze(grammar(0, &[input::Op::Unit])).unwrap();
    let update = if update_partial {
        Syntax::with_library(
            grammar(1, &[]),
            vec![(
                1,
                program(vec![
                    (input::Op::EventAge, vec![Arg::Input(0)]),
                    (input::Op::EventInput, vec![Arg::Input(0)]),
                    (input::Op::Rem, vec![Arg::Register(0), Arg::Register(1)]),
                ]),
            )],
        )
        .unwrap()
    } else {
        Syntax::freeze(grammar(1, &[input::Op::Identity])).unwrap()
    };
    let read_body = if update_partial {
        program(vec![
            (input::Op::QueryAge, vec![Arg::Input(0)]),
            (
                input::Op::Rem,
                vec![Arg::Register(0), Arg::Literal(input::Value::Nat(2))],
            ),
        ])
    } else {
        program(vec![
            (input::Op::QueryAge, vec![Arg::Input(0)]),
            (input::Op::QueryInput, vec![Arg::Input(0)]),
            (input::Op::Rem, vec![Arg::Register(0), Arg::Register(1)]),
        ])
    };
    let read = Syntax::with_library(grammar(1, &[]), vec![(1, read_body)]).unwrap();
    input::JointSeries::freeze(
        initial,
        update,
        read,
        InputBinding::new(
            source,
            1,
            vec![if update_partial {
                InputSource::External(0)
            } else {
                InputSource::State
            }],
        )
        .unwrap(),
        InputBinding::new(query, 1, vec![InputSource::External(0)]).unwrap(),
        Arc::clone(&semantics),
    )
    .unwrap()
}

fn installed(
    update_partial: bool,
) -> (
    Organism<u8>,
    ParityWorld,
    Arc<input::JointCandidate<u8>>,
    observer_acceptance::Admission<u8>,
) {
    installed_with_profile(update_partial, crate::program::observer::acquisition::AdmissionProfile::ExactPredictiveV1 { risk: crate::program::code_mass::Mass::uniform(num_bigint::BigUint::from(20u8)).unwrap() })
}

fn installed_with_profile(
    update_partial: bool,
    profile: crate::program::observer::acquisition::AdmissionProfile,
) -> (
    Organism<u8>,
    ParityWorld,
    Arc<input::JointCandidate<u8>>,
    observer_acceptance::Admission<u8>,
) {
    installed_with_source(update_partial, profile, false)
}

fn installed_with_source(
    update_partial: bool,
    profile: crate::program::observer::acquisition::AdmissionProfile,
    sensory: bool,
) -> (
    Organism<u8>,
    ParityWorld,
    Arc<input::JointCandidate<u8>>,
    observer_acceptance::Admission<u8>,
) {
    let mut series = family_with_sensory(update_partial, sensory).declare_admission(profile)
        .unwrap_or_else(|_| panic!("the comparison profile must precede the first intake"));
    assert_eq!(
        series.family_count().unwrap(),
        1,
        "one conditional library name; no observed pruning"
    );
    let source = series.update_interface().clone();
    let mut intake = series.open_trial(alphabet()).unwrap();
    let mut organism = Organism::new()
        .with_exhaustion_climb(4096)
        .expect("fresh observer configuration");
    // This component court drives its explicitly frozen native Series. The
    // independent production agenda is not a second competing source grammar.
    organism.exhaust.as_mut().unwrap().program_agenda = None;
    let mut world = ParityWorld::new();
    world.sensory = sensory;
    for _ in 0..128 {
        organism.step_forced(&mut world, 0).unwrap();
    }
    let mut work = ObserverWork {
        remaining: 10_000_000,
    };
    let rows = organism
        .program_rows(&source, 0, &alphabet(), &mut work)
        .unwrap();
    assert_eq!(rows.rows.len(), 128);
    for row in rows.rows {
        intake
            .observe(
                Arc::clone(&rows.history),
                row.cut,
                row.context,
                row.query,
                row.outcome,
            )
            .unwrap();
    }
    let mut search = intake.finish::<()>().unwrap();
    let (candidate, accepted) = {
        let mut budget = Budget::new(&mut work, ExecutionLimit::Unlimited);
        loop {
            match search.advance(&mut budget) {
                joint::Progress::Assessed {
                    candidate,
                    assessment,
                } => {
                    assert!(
                        assessment.purchased().unwrap(),
                        "actual parity outcomes must pay their original declared price"
                    );
                    break (candidate, assessment.accepted().unwrap().unwrap());
                }
                joint::Progress::Advanced => {}
                _ => panic!("the one declared reader is defined on all actual training cuts"),
            }
        }
    };
    assert_eq!(
        candidate.comparison_count().unwrap(),
        2,
        "original family and first-look fee"
    );
    let mut fresh = accepted.open_validation();
    for _ in 0..128 {
        organism.step_forced(&mut world, 0).unwrap();
    }
    let rows = organism
        .program_rows(&source, 128, &alphabet(), &mut work)
        .unwrap();
    assert_eq!(rows.rows.len(), 128);
    for row in rows.rows {
        fresh
            .observe(
                Arc::clone(&rows.history),
                row.cut,
                row.context,
                row.query,
                row.outcome,
            )
            .unwrap();
    }
    let validated = {
        let mut budget = Budget::new(&mut work, ExecutionLimit::Unlimited);
        fresh
            .finish()
            .unwrap()
            .evaluate(&mut budget)
            .unwrap()
            .validated().unwrap()
            .expect("fresh physical outcomes confirm the conditional reader")
    };
    let admission = observer_acceptance::Admission::from_native(
        input::Producer::from(Arc::clone(&candidate)),
        validated,
    )
    .unwrap();
    organism
        .install_program_observer(&admission, 1024, &mut work)
        .unwrap();
    assert_eq!(world.calls, 256);
    assert_eq!(organism.exhaust.as_ref().unwrap().floors.len(), 1);
    #[cfg(all(test, feature = "serde"))]
    if retirement_export::active() { retirement_export::enable(&mut organism); }
    (organism, world, candidate, admission)
}

#[test]
fn actual_partial_read_retires_after_one_act_and_preserves_exact_lower_edge() {
    let (mut org, mut world, candidate, _) = installed(false);
    let before = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let old_epoch = org.exhaust.as_ref().unwrap().observer_history.epoch();
    let attempts = org.action_attempts;
    world.leave_support = true;
    let pulse = org.step_forced(&mut world, 0).unwrap().pulse().unwrap();
    assert!(pulse.climate.is_finite());
    assert_eq!(world.calls, 257, "the physical effect is not retried");
    assert_eq!(org.action_attempts, attempts + 1);
    let ex = org.exhaust.as_ref().unwrap();
    assert_eq!(ex.observer_history.ordinal(), before + 1);
    assert_eq!(ex.observer_history.epoch(), 1);
    assert!(ex.floors.is_empty());
    let receipt = org.last_domain_retirement().unwrap();
    assert_eq!(receipt.boundary(), DomainBoundary::AfterAct);
    assert_eq!(receipt.floor().input_epoch(), 1);
    assert_eq!(receipt.floor().output_epoch(), old_epoch);
    assert!(Arc::ptr_eq(
        receipt.fault.cut.definition(),
        candidate.definition()
    ));
    assert_eq!(
        receipt.fault.refusal.classification(),
        RefusalClass::Undefined
    );
    assert!(
        matches!(receipt.fault.input.values(), [input::Value::Query(q)] if q.input == 0 && q.life_age == 257 && q.action.is_none())
    );
    assert_eq!(
        receipt.actual_outcome(),
        Some((0, ObservedWorldOutcome::Next(0)))
    );
    assert_eq!(receipt.actual.as_ref().unwrap().0.ordinal(), before);
    assert_eq!(receipt.actual.as_ref().unwrap().0.input(1).unwrap(), 2);
    assert_eq!(receipt.history.len(), before + 1);
    assert!(
        receipt
            .corpus
            .values()
            .flatten()
            .any(|row| row.1 == ObservedWorldOutcome::Next(0) && row.3.cut.ordinal() == before)
    );
    assert_eq!(receipt.current_prefix().epoch, 1);
    assert!(receipt.current_prefix().floors.is_empty());
    assert!(receipt.current_prefix().tiers.is_empty());
    assert!(receipt.retirement_work().0 > receipt.retirement_work().1);
    assert_eq!(org.table.get(&(2, 0)), Some(&0));
    assert!(org.action_failure.is_none());
    org.step_forced(&mut world, 0).unwrap();
    assert_eq!(world.calls, 258);
}

struct CountBoundary {
    before: usize,
    after: usize,
}
impl experiment::ActBoundary<ParityWorld> for CountBoundary {
    fn before(&mut self, organism: &Organism<u8>, world: &ParityWorld, action: u8) -> bool {
        self.before += 1;
        assert!(
            organism.exhaust.as_ref().unwrap().floors.is_empty(),
            "admission sees the restored language"
        );
        assert!(world.actions().contains(&action));
        true
    }
    fn after(
        &mut self,
        _world: &ParityWorld,
        action: u8,
        outcome: &Result<ObservedAction, ActionFailure<u8>>,
    ) {
        self.after += 1;
        assert_eq!(action, 0);
        assert!(matches!(outcome, Ok(ObservedAction::Step)));
    }
}

#[test]
fn partial_update_retries_before_delivery_without_consuming_an_extra_command_or_stamp() {
    let (mut org, mut world, candidate, _) = installed(true);
    world.leave_support = true;
    org.step_forced(&mut world, 0).unwrap(); // Total read; update consumed the old input2.
    assert!(org.last_domain_retirement().is_none());
    let before = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let attempts = org.action_attempts;
    // Exercise the actual macro continuation command path, not a hand-called
    // retirement helper. Its queued action survives the representation retry.
    org.combo_queue.push_back(0);
    org.combo_queue.push_back(0);
    let mut boundary = CountBoundary {
        before: 0,
        after: 0,
    };
    org.step_inner_observed(&mut world, None, Some(&mut boundary))
        .unwrap();
    assert_eq!(
        (boundary.before, boundary.after),
        (1, 1),
        "attempt admission is charged once after retry"
    );
    assert_eq!(world.calls, 258);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(org.combo_queue.len(), 1);
    let receipt = org.last_domain_retirement().unwrap();
    assert_eq!(receipt.boundary(), DomainBoundary::BeforeAct);
    assert_eq!(receipt.confirmed_events(), before);
    assert!(receipt.actual_outcome().is_none());
    assert!(Arc::ptr_eq(
        receipt.fault.cut.definition(),
        candidate.definition()
    ));
    assert!(
        matches!(receipt.fault.input.values(), [input::Value::Event(event)] if event.input == 0 && event.action == 0)
    );
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        before + 1
    );
    assert!(org.action_failure.is_none());
}

#[test]
fn resource_during_prepare_neither_refutes_nor_retires_the_acquired_owner() {
    let (mut org, mut world, candidate, _) = installed(false);
    let epoch = org.exhaust.as_ref().unwrap().observer_history.epoch();
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let attempts = org.action_attempts;
    org.exhaust.as_mut().unwrap().observer_capture_work = 0;
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.calls, 256);
    assert_eq!(org.action_attempts, attempts);
    assert!(org.last_domain_retirement().is_none());
    let ex = org.exhaust.as_ref().unwrap();
    assert_eq!(ex.observer_history.epoch(), epoch);
    assert_eq!(ex.observer_history.ordinal(), ordinal);
    assert!(Arc::ptr_eq(
        ex.floors[0]
            .observer
            .general()
            .installed()
            .cut()
            .definition(),
        candidate.definition()
    ));
}

#[test]
fn a_counterexample_below_a_tier_retires_the_entire_dependent_suffix() {
    let (mut org, mut world, _, _) = installed(false);
    org.seen.insert(org.eyed(2), vec![0]);
    {
        let ex = org.exhaust.as_mut().unwrap();
        ex.tier_armed = true;
        ex.headroom_streak = crate::law::LAW_OF_REPETITION;
    }
    org.tier_birth_if_due();
    assert!(org.exhaust.as_ref().unwrap().tier.is_some());
    append_periodic_fixture(&mut org, 3, 2, false);
    let calls_before = world.calls;
    let issued = org
        .exhaust
        .as_ref()
        .unwrap()
        .observer_history
        .highest_epoch();
    world.leave_support = true;
    org.step_forced(&mut world, 0).unwrap();
    let ex = org.exhaust.as_ref().unwrap();
    assert!(ex.floors.is_empty());
    assert!(ex.tier.is_none());
    assert_eq!(ex.observer_history.epoch(), 1);
    assert_eq!(
        ex.observer_history.highest_epoch(),
        issued,
        "retirement never recycles an epoch"
    );
    assert_eq!(
        org.last_domain_retirement().unwrap().retired_floor_count(),
        2
    );
    assert!(org.last_domain_retirement().unwrap().retired_tier.is_some());
    assert_eq!(world.calls, calls_before + 1);
    org.step_forced(&mut world, 0).unwrap();
    assert_eq!(
        world.calls, calls_before + 2,
        "all live capture inputs belong to the restored prefix"
    );
}

fn native_fault(org: &Organism<u8>) -> NativeFault<u8> {
    let floor = &org.exhaust.as_ref().unwrap().floors[0];
    // An explicit adversarial input for the owner-binding control. This is not
    // reported as an actual physical event or added to any training corpus.
    let view = observer_runtime::View { sensory: None,
        raw: 0,
        input: 0,
        episode: org.source_time.episode().unwrap(),
        life_age: org.source_time.life_age(),
        pose: org.cur_pose,
    };
    let mut work = ObserverWork { remaining: 10_000 };
    let refusal = match floor
        .observer
        .read(view.clone(), &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
    {
        Err(reason) => reason,
        Ok(_) => panic!("Rem denominator0 is undefined"),
    };
    match ExecutionFailure::capture(0, &floor.observer, view, None, refusal) {
        ExecutionFailure::Native(fault) => fault,
        _ => panic!("semantic failure"),
    }
}

#[test]
fn retirement_rejects_a_foreign_fork_and_an_equal_value_stale_cut() {
    let (mut org, mut world, _, _) = installed(false);
    let current = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .general()
        .installed()
        .cut();
    assert!(current.same_revision(&current.clone()));
    let mut forked = native_fault(&org);
    forked.cut = current.fork().cut();
    assert!(!current.same_revision(&forked.cut));
    let epoch = org.exhaust.as_ref().unwrap().observer_history.epoch();
    assert!(
        org.retire_observer_domain(forked, DomainBoundary::BeforeAct, None, &mut 100_000)
            .is_err()
    );
    assert!(org.pending_domain_retirement().is_none());
    assert!(org.domain_retirements().is_empty());
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.epoch(),
        epoch
    );
    org.step_forced(&mut world, 0).unwrap();
    let live = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .general()
        .installed()
        .cut();
    assert_eq!(
        current.state(),
        live.state(),
        "Identity may preserve the value while changing the revision"
    );
    assert!(!current.same_revision(&live));
    let mut stale = native_fault(&org);
    stale.cut = current;
    assert!(
        org.retire_observer_domain(stale, DomainBoundary::BeforeAct, None, &mut 100_000)
            .is_err()
    );
    assert!(org.pending_domain_retirement().is_none());
    assert!(org.domain_retirements().is_empty());
    assert!(
        live.same_revision(
            &org.exhaust.as_ref().unwrap().floors[0]
                .observer
                .general()
                .installed()
                .cut()
        )
    );
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.epoch(),
        epoch
    );
}

#[test]
fn full_journal_preserves_previous_witness_and_pending_actual_without_retiring() {
    let (mut org, mut world, first, _) = installed(false);
    world.leave_support = true;
    org.step_forced(&mut world, 0).unwrap();
    assert_eq!(org.domain_retirements().len(), 1);
    let first_ordinal = org.domain_retirements()[0].confirmed_events();
    // A real action returns to the declared support. A separately purchased
    // native owner is installed through the same receiver replay boundary.
    world.leave_support = false;
    org.step_forced(&mut world, 0).unwrap();
    assert_eq!(world.key(), 2);
    let (_, _, second, admission) = installed(false);
    let mut work = ObserverWork {
        remaining: 10_000_000,
    };
    org.install_program_observer(&admission, 1024, &mut work)
        .unwrap();
    let ex = org.exhaust.as_mut().unwrap();
    ex.domain_retirement_limit = ex.domain_retirement_used; // Explicit exhausted journal allowance.
    let epoch = ex.observer_history.epoch();
    let ordinal = ex.observer_history.ordinal();
    let attempts = org.action_attempts;
    let calls = world.calls;
    world.leave_support = true;
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.calls, calls + 1);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(
        org.domain_retirements().len(),
        1,
        "full means refusal, not replacement"
    );
    assert_eq!(
        org.domain_retirements()[0].confirmed_events(),
        first_ordinal
    );
    assert!(Arc::ptr_eq(
        org.domain_retirements()[0].fault().cut().definition(),
        first.definition()
    ));
    let pending = org
        .pending_domain_retirement()
        .expect("the actual association survives Resource");
    assert_eq!(pending.boundary, DomainBoundary::AfterAct);
    assert!(Arc::ptr_eq(
        pending.fault.cut().definition(),
        second.definition()
    ));
    let (cut, outcome) = pending.actual.as_ref().unwrap();
    assert_eq!(cut.ordinal(), ordinal);
    assert_eq!(cut.event().action, 0);
    assert_eq!(*outcome, ObservedWorldOutcome::Next(0));
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.epoch(),
        epoch
    );
    assert_eq!(org.exhaust.as_ref().unwrap().floors.len(), 1);
    assert!(
        org.exhaust.as_ref().unwrap().floors[0]
            .observer
            .general()
            .installed()
            .cut()
            .same_revision(pending.fault.cut())
    );
}

/// Suspension is caused by the declared journal allowance, not a fabricated
/// interpreter refusal or state. The original world effect has already happened.
fn suspended_actual() -> (Organism<u8>, ParityWorld) {
    let (mut org, mut world, _, _) = installed(false);
    org.exhaust.as_mut().unwrap().domain_retirement_limit = 0;
    world.leave_support = true;
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.calls, 257);
    assert_eq!(
        org.observer_continuation_status().unwrap().phase,
        ObserverContinuationPhase::Retire
    );
    (org, world)
}

#[test]
fn owned_after_act_resumes_with_a_grant_without_act_update_witness_or_feed_repetition() {
    let (mut org, world) = suspended_actual();
    let calls = world.calls;
    let attempts = org.action_attempts;
    let steps = org.steps;
    let (ordinal, witnessed, epoch) = {
        let ex = org.exhaust.as_ref().unwrap();
        (
            ex.observer_history.ordinal(),
            ex.witnessed,
            ex.observer_history.epoch(),
        )
    };
    let actual = org.observer_continuation_actual().unwrap().clone();
    let first = org.observer_continuation_status().unwrap();
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant::default())
            .unwrap_err(),
        ObserverResumeRefusal::Resource {
            phase: ObserverContinuationPhase::Retire
        }
    );
    let second = org.observer_continuation_status().unwrap();
    assert_eq!(second.initial_work, first.initial_work);
    assert_eq!(second.granted_work, 0);
    assert!(
        second.remaining_work < first.remaining_work,
        "a rejected attempt does not refund its phase work"
    );
    assert!(org.domain_retirements().is_empty());
    assert_eq!(org.steps, steps);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.epoch(),
        epoch
    );
    assert!(Arc::ptr_eq(
        &actual.0,
        &org.observer_continuation_actual().unwrap().0
    ));
    assert_eq!(org.observer_continuation_actual().unwrap().1, actual.1);
    // Resume owns every successor port; dropping the Habitat makes accidental
    // re-observation/act impossible in the continuation API itself.
    drop(world);
    let pulse = org
        .resume_observer_boundary(ObserverResumeGrant {
            work: 10_000,
            retention_slots: 10_000,
        })
        .unwrap()
        .pulse()
        .unwrap();
    assert_eq!(pulse.action, 0);
    assert!(pulse.climate.is_finite());
    assert_eq!(calls, 257);
    assert_eq!(org.action_attempts, attempts);
    assert_eq!(
        org.steps,
        steps + 1,
        "the lower-language edge is recorded once"
    );
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal
    );
    assert_eq!(org.exhaust.as_ref().unwrap().witnessed, witnessed);
    assert_eq!(org.domain_retirements().len(), 1);
    let receipt = org.last_domain_retirement().unwrap();
    assert!(Arc::ptr_eq(&receipt.actual().unwrap().0, &actual.0));
    assert_eq!(receipt.actual().unwrap().1, actual.1);
    assert_eq!(org.table.get(&(2, 0)), Some(&0));
    assert!(org.action_failure.is_none());
    assert!(org.observer_continuation_status().is_none());
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: 10_000,
            retention_slots: 10_000
        })
        .unwrap_err(),
        ObserverResumeRefusal::NoAfterActContinuation
    );
    assert_eq!(org.action_attempts, attempts);
    assert_eq!(org.steps, steps + 1);
}

#[test]
fn after_act_rejects_changed_native_owner_and_arithmetic_grant_without_spending_them() {
    let (mut org, mut world) = suspended_actual();
    let initial = org.observer_continuation_status().unwrap();
    let failure = org.action_failure.clone();
    let slots = org.exhaust.as_ref().unwrap().domain_retirement_limit;
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: usize::MAX,
            retention_slots: 10
        })
        .unwrap_err(),
        ObserverResumeRefusal::GrantCapacity
    );
    assert_eq!(org.observer_continuation_status().unwrap(), initial);
    assert_eq!(org.exhaust.as_ref().unwrap().domain_retirement_limit, slots);
    assert_eq!(org.action_failure, failure);
    // Equal semantic state in a different native instance is a foreign owner.
    let floor = &mut org.exhaust.as_mut().unwrap().floors[0];
    floor.observer = floor.observer.fork();
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: 100,
            retention_slots: 100
        })
        .unwrap_err(),
        ObserverResumeRefusal::ForeignBoundary
    );
    assert_eq!(org.observer_continuation_status().unwrap(), initial);
    assert_eq!(org.exhaust.as_ref().unwrap().domain_retirement_limit, slots);
    assert_eq!(org.action_failure, failure);
    assert!(org.domain_retirements().is_empty());
    assert!(
        org.step_forced(&mut world, 0).is_err(),
        "sticky failure cannot be bypassed"
    );
    assert_eq!(world.calls, 257);
}

fn body(org: &Organism<u8>) -> Vec<C64> {
    (0..N)
        .flat_map(|i| (0..N).map(move |j| org.tower.level(0).herm().get(i, j)))
        .collect()
}

#[test]
fn each_owned_after_act_phase_is_consumed_once_under_small_explicit_grants() {
    // An uninterrupted twin supplies the actual transaction cost and expected
    // body state. Both organisms learn from the same actual 256-event schedule.
    let (mut reference, mut reference_world, _, _) = installed(false);
    reference_world.leave_support = true;
    let expected = reference
        .step_forced(&mut reference_world, 0)
        .unwrap()
        .pulse()
        .unwrap();
    let (before, after) = reference
        .last_domain_retirement()
        .unwrap()
        .retirement_work();
    let retirement_work = before - after;

    let (mut org, mut world, _, _) = installed(false);
    // Measure native reads with their real meter, then declare the minimum
    // pre-act read allowance. No state or semantic result is injected.
    let mut pre = ObserverWork { remaining: 10_000 };
    org.eyed_checked(2, &mut Budget::new(&mut pre, ExecutionLimit::Unlimited))
        .unwrap_or_else(|reason| panic!("{reason}"));
    let pre_cost = 10_000 - pre.remaining;
    let mut post = ObserverWork { remaining: 10_000 };
    assert!(matches!(
        org.eyed_checked(0, &mut Budget::new(&mut post, ExecutionLimit::Unlimited)),
        Err(ExecutionFailure::Native(_))
    ));
    let post_cost = 10_000 - post.remaining;
    org.exhaust.as_mut().unwrap().observer_work = pre_cost.max(post_cost + 1);
    world.leave_support = true;
    let steps = org.steps;
    let body_before = body(&org);
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.calls, 257);
    let held = org.observer_continuation_status().unwrap();
    assert_eq!(held.phase, ObserverContinuationPhase::Retire);
    assert!(
        held.remaining_work <= retirement_work,
        "the measured small allowance stops before retirement can commit"
    );
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: retirement_work + 1 - held.remaining_work,
            retention_slots: 0,
        })
        .unwrap_err(),
        ObserverResumeRefusal::Resource {
            phase: ObserverContinuationPhase::Project
        }
    );
    assert_eq!(org.domain_retirements().len(), 1);
    assert_eq!(org.steps, steps);
    assert_eq!(body(&org), body_before);
    assert_eq!(
        org.observer_continuation_status().unwrap().remaining_work,
        0
    );

    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: 1,
            retention_slots: 0
        })
        .unwrap_err(),
        ObserverResumeRefusal::Resource {
            phase: ObserverContinuationPhase::Record
        }
    );
    assert_eq!(org.steps, steps);
    assert!(org.table.get(&(2, 0)).is_none());
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: 1,
            retention_slots: 0
        })
        .unwrap_err(),
        ObserverResumeRefusal::Resource {
            phase: ObserverContinuationPhase::Feed
        }
    );
    assert_eq!(org.steps, steps + 1);
    assert_eq!(org.table.get(&(2, 0)), Some(&0));
    assert_eq!(body(&org), body_before, "record does not feed the body");
    let actual = org
        .resume_observer_boundary(ObserverResumeGrant {
            work: 1,
            retention_slots: 0,
        })
        .unwrap()
        .pulse()
        .unwrap();
    assert_eq!(actual.climate, expected.climate);
    assert_eq!(body(&org), body(&reference));
    assert_eq!(org.steps, steps + 1);
    assert_eq!(world.calls, 257);
    assert_eq!(org.domain_retirements().len(), 1);
    assert!(org.pending_domain_retirement().is_none());
    assert!(org.observer_continuation_status().is_none());
}

/// The wrapper adds observable menu/request/pose ports and counts reads of
/// one-time bookkeeping. Physical action0 is the original learned world.
struct DispatchWorld {
    inner: ParityWorld,
    menu: Vec<u8>,
    request: Option<u8>,
    pose: u8,
    confirmations_read: std::cell::Cell<usize>,
    delivered: Vec<u8>,
    lose_delivery: bool,
}
impl DispatchWorld {
    fn new(inner: ParityWorld) -> Self {
        Self {
            inner,
            menu: vec![0],
            request: None,
            pose: 1,
            confirmations_read: std::cell::Cell::new(0),
            delivered: Vec::new(),
            lose_delivery: false,
        }
    }
}
impl Habitat for DispatchWorld {
    type Action = u8;
    fn observe(&self) -> [f64; 7] {
        self.inner.observe()
    }
    fn key(&self) -> u64 {
        self.inner.key()
    }
    fn actions(&self) -> Vec<u8> {
        self.menu.clone()
    }
    fn pose(&self) -> Option<u8> {
        Some(self.pose)
    }
    fn mile_act(&self) -> Option<u8> {
        self.request
    }
    fn reset_action(&self) -> Option<u8> {
        None
    }
    fn task_confirms(&self) -> u64 {
        self.confirmations_read
            .set(self.confirmations_read.get() + 1);
        0 // This world has no task-payment channel.
    }
    fn act(&mut self, action: u8) -> Result<ObservedAction, ActionFailure<u8>> {
        assert!(self.menu.contains(&action));
        self.delivered.push(action);
        let result = if action == 0 {
            self.inner.act(action)
        } else {
            assert_eq!(action, 1);
            self.inner.calls += 1;
            self.inner.raw = 3;
            Ok(ObservedAction::Step)
        };
        if self.lose_delivery {
            Err(ActionFailure::new(
                action,
                ActionStage::Receive,
                "actual delivery is unobserved",
            ))
        } else {
            result
        }
    }
}

#[test]
fn before_act_keeps_one_macro_command_and_reobserves_current_ports_without_recrediting_bookkeeping()
{
    let (mut org, mut original, _, _) = installed(true);
    original.leave_support = true;
    org.step_forced(&mut original, 0).unwrap(); // Actual input2 update, actual successor0.
    let mut world = DispatchWorld::new(original);
    org.combo_queue = [0, 0].into();
    org.exhaust.as_mut().unwrap().domain_retirement_limit = 0;
    let attempts = org.action_attempts;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let takeover = org.pending;
    assert!(org.step(&mut world).is_err());
    assert_eq!(world.inner.calls, 257);
    assert!(world.delivered.is_empty());
    assert_eq!(org.combo_queue.len(), 1);
    assert_eq!(
        org.before_act_status().unwrap().phase,
        BeforeActPhase::Retire
    );
    assert_eq!(world.confirmations_read.get(), 1);
    let pending = org.pending_domain_retirement().unwrap();
    assert!(
        matches!(pending.fault.input().values(),[input::Value::Event(event)] if event.input==0 && event.action==0)
    );
    let old_cut = pending.fault.cut().clone();

    // The environment changes while the undelivered command is held. This is a
    // real external act, outside the organism's accepted-event history.
    world.inner.leave_support = false;
    world.inner.act(0).unwrap();
    assert_eq!(world.key(), 2);
    world.pose = 7;
    world.menu.clear();
    assert!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                read_work: 100_000,
                capture_work: 100_000,
                retention_slots: 10_000,
            }
        )
        .is_err()
    );
    assert_eq!(world.inner.calls, 258);
    assert!(
        world.delivered.is_empty(),
        "a held macro cannot bypass the current menu"
    );
    assert_eq!(org.combo_queue.len(), 1);
    assert_eq!(world.confirmations_read.get(), 1);
    assert_eq!(org.domain_retirements().len(), 1);
    assert!(old_cut.same_revision(org.last_domain_retirement().unwrap().fault().cut()));
    assert_eq!(org.action_attempts, attempts);
    let held = org.before_act_status().unwrap();
    let mut receiver = Organism::new()
        .with_exhaustion_climb(4096)
        .expect("fresh observer configuration");
    assert_eq!(
        receiver.anastomose(&mut org).unwrap_err(),
        ExAnastomosisRefusal::ObserverContinuation
    );
    assert_eq!(org.before_act_status().unwrap(), held);
    assert_eq!(org.combo_queue.len(), 1);
    world.menu.push(0);
    let pulse = org
        .resume_observer_before_act(&mut world, BeforeActResumeGrant::default())
        .unwrap()
        .pulse()
        .unwrap();
    assert_eq!(pulse.takeover, takeover);
    assert_eq!(world.delivered, [0]);
    assert_eq!(org.combo_queue.len(), 1);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(
        world.confirmations_read.get(),
        1,
        "task payments and docket entry are not replayed"
    );
    let ex = org.exhaust.as_ref().unwrap();
    assert_eq!(ex.observer_history.ordinal(), ordinal + 1);
    let mut cursor = ex
        .observer_history
        .current_history()
        .unwrap()
        .cursor(ordinal)
        .unwrap();
    let event = cursor.next(&mut 10_000).unwrap().unwrap();
    assert_eq!(event.event().raw_state, 2);
    assert_eq!(event.event().action, 0);
    assert_eq!(event.pose(), Some(7));
    assert!(
        org.proposal_cancellations().is_empty(),
        "a macro is retained, not replaced by autonomous choice"
    );
    assert!(org.before_act_status().is_none());
}

#[test]
fn before_act_resource_cancels_one_autonomous_proposal_without_refuting_its_program() {
    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    world.menu = vec![0, 1];
    world.request = Some(0);
    let current = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .owned_cut();
    org.exhaust.as_mut().unwrap().observer_capture_work = 0;
    org.exhaust.as_mut().unwrap().domain_retirement_limit = 0;
    assert!(org.step(&mut world).is_err());
    assert!(world.delivered.is_empty());
    assert!(org.domain_retirements().is_empty());
    assert!(org.proposal_cancellations().is_empty());
    assert_eq!(
        org.before_act_status().unwrap().phase,
        BeforeActPhase::CancelProposal
    );
    assert!(matches!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                read_work: 100_000,
                capture_work: 100_000,
                retention_slots: 0,
            }
        ),
        Err(BeforeActResumeError::Unavailable(
            BeforeActResumeRefusal::Resource
        ))
    ));
    assert!(current.matches(&org.exhaust.as_ref().unwrap().floors[0].observer));
    assert!(
        org.proposal_cancellations().is_empty(),
        "full journal never drops or fabricates a cancellation"
    );
    world.request = Some(1);
    org.resume_observer_before_act(
        &mut world,
        BeforeActResumeGrant {
            retention_slots: 1,
            ..BeforeActResumeGrant::default()
        },
    )
    .unwrap();
    assert_eq!(world.delivered, [1]);
    assert_eq!(world.confirmations_read.get(), 1);
    assert!(
        org.domain_retirements().is_empty(),
        "Resource is not a semantic counterexample"
    );
    let cancellation = &org.proposal_cancellations()[0];
    assert_eq!(cancellation.decision(), Decision::WorldRequest(0));
    assert_eq!(
        cancellation.reason(),
        ProposalCancellationReason::ReobserveAfterResource
    );
    assert_eq!(org.proposal_cancellations().len(), 1);
    assert!(org.before_act_status().is_none());
}

struct AdmissionCounter {
    calls: usize,
    after: usize,
    remaining: usize,
    allow: bool,
}
impl experiment::ActBoundary<DispatchWorld> for AdmissionCounter {
    fn before(&mut self, org: &Organism<u8>, world: &DispatchWorld, action: u8) -> bool {
        self.calls += 1;
        assert_eq!(org.exhaust.as_ref().unwrap().observer_history.ordinal(), 0);
        assert!(
            org.exhaust
                .as_ref()
                .unwrap()
                .observer_history
                .current_history()
                .is_ok()
        );
        assert!(world.actions().contains(&action));
        if self.allow {
            self.remaining -= 1;
        }
        self.allow
    }
    fn after(&mut self, _: &DispatchWorld, _: u8, _: &Result<ObservedAction, ActionFailure<u8>>) {
        self.after += 1;
    }
}
#[test]
fn owned_history_reservation_precedes_guard_budget_and_decline_never_closes_delivery() {
    for exhausted in [true, false] {
        let mut org = Organism::new()
            .with_exhaustion_climb(4096)
            .expect("fresh observer configuration");
        org.exhaust.as_mut().unwrap().program_agenda = None;
        if exhausted {
            org.exhaust.as_mut().unwrap().observer_capture_work = 0;
        }
        let mut world = DispatchWorld::new(ParityWorld::new());
        let mut guard = AdmissionCounter {
            calls: 0,
            after: 0,
            remaining: 1,
            allow: false,
        };
        let result = org.step_inner_observed(&mut world, Some(0), Some(&mut guard));
        if exhausted {
            assert!(result.is_err());
            assert_eq!(
                guard.calls, 0,
                "Resource is decided before the trial spends its guard allowance"
            );
            assert!(matches!(
                org.resume_observer_before_act(
                    &mut world,
                    BeforeActResumeGrant {
                        read_work: 100_000,
                        capture_work: 100_000,
                        retention_slots: 100,
                    }
                ),
                Err(BeforeActResumeError::Unavailable(
                    BeforeActResumeRefusal::BoundaryRequired
                ))
            ));
        } else {
            assert!(matches!(result, Ok(StepOutcome::NoAction)));
            assert_eq!(guard.calls, 1);
        }
        assert_eq!(guard.remaining, 1);
        assert_eq!(guard.after, 0);
        assert_eq!(org.action_attempts, 0);
        assert!(world.delivered.is_empty());
        let ex = org.exhaust.as_ref().unwrap();
        assert_eq!(ex.observer_history.ordinal(), 0);
        assert_eq!(ex.observer_history.current_history().unwrap().len(), 0);
        assert_eq!(
            ex.observer_history.live_nodes(),
            0,
            "cancelled reserved roots are released"
        );
    }
}

#[test]
fn before_act_resume_cannot_clear_an_unknown_delivery_or_foreign_sticky_failure() {
    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    let before = org.exhaust.as_ref().unwrap().floors[0].observer.owned_cut();
    org.exhaust.as_ref().unwrap().floors[0].observer.general().enable_audit();
    org.exhaust.as_mut().unwrap().observer_capture_work = 0;
    assert!(org.step_forced(&mut world, 0).is_err());
    let held = org.before_act_status().unwrap();
    let own_failure = org.action_failure.clone();
    org.action_failure = Some(ActionFailure::new(
        0,
        ActionStage::Receive,
        "foreign infrastructure owner",
    ));
    assert!(matches!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                capture_work: 100_000,
                ..BeforeActResumeGrant::default()
            }
        ),
        Err(BeforeActResumeError::Unavailable(
            BeforeActResumeRefusal::ForeignBoundary
        ))
    ));
    assert_eq!(org.before_act_status().unwrap(), held);
    assert!(world.delivered.is_empty());
    // Restore only the adversarial fixture's original owned error. Production
    // has no clear-failure method and the previous call changed nothing.
    org.action_failure = own_failure;
    world.lose_delivery = true;
    assert!(matches!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                read_work: 100_000,
                capture_work: 100_000,
                retention_slots: 100
            }
        ),
        Err(BeforeActResumeError::Execution(_))
    ));
    assert_eq!(world.delivered, [0]);
    assert!(org.before_act_status().is_none());
    assert!(
        org.exhaust
            .as_ref()
            .unwrap()
            .observer_history
            .current_history()
            .is_err()
    );
    assert!(matches!(
        org.resume_observer_before_act(&mut world, BeforeActResumeGrant::default()),
        Err(BeforeActResumeError::Unavailable(
            BeforeActResumeRefusal::NoContinuation
        ))
    ));
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.delivered, [0]);
    let ex = org.exhaust.as_ref().unwrap();
    assert_eq!(ex.floors.len(), 1, "unknown delivery neither retires nor replaces its owner");
    assert!(before.matches(&ex.floors[0].observer),
        "unknown delivery must not commit even an equal-valued prepared state");
    let audit = ex.floors[0].observer.general().take_audit();
    assert_eq!(audit.iter().filter(|event| matches!(event,
        observer_runtime::AuditEvent::Commit { .. })).count(), 0,
        "no native commit without an observed outcome, including refused retry paths");
}

#[test]
fn unfinished_before_act_owner_survives_restart_and_consuming_configuration_refusals() {
    let (mut org, mut world, _, _) = installed(true);
    world.leave_support = true;
    org.step_forced(&mut world, 0).unwrap();
    org.exhaust.as_mut().unwrap().domain_retirement_limit = 0;
    assert!(org.step_forced(&mut world, 0).is_err());
    let status = org.before_act_status().unwrap();
    let episode = org.source_time.episode();
    let failure = org.action_failure.clone();
    let cut = org.pending_domain_retirement().unwrap().fault.cut().clone();
    assert_eq!(
        org.check_observer_lifecycle(),
        Err(ObserverLifecycleRefusal::PendingBoundary)
    );
    assert_eq!(
        org.begin_run(),
        Err(ObserverLifecycleRefusal::PendingBoundary)
    );
    assert_eq!(org.before_act_status().unwrap(), status);
    assert_eq!(org.source_time.episode(), episode);
    assert_eq!(org.action_failure, failure);
    let rejected = org
        .with_exhaustion_resources(1, ObserverResources::default())
        .unwrap_err();
    assert_eq!(rejected.reason(), ObserverLifecycleRefusal::PendingBoundary);
    let mut org = rejected.into_organism();
    assert_eq!(org.before_act_status().unwrap(), status);
    assert_eq!(org.action_failure, failure);
    assert!(cut.same_revision(org.pending_domain_retirement().unwrap().fault.cut()));
    org.resume_observer_before_act(
        &mut world,
        BeforeActResumeGrant {
            read_work: 100_000,
            capture_work: 100_000,
            retention_slots: 10_000,
        },
    )
    .unwrap();
    assert_eq!(world.calls, 258);
    assert!(org.check_observer_lifecycle().is_ok());
}

#[test]
fn unfinished_after_act_and_unknown_delivery_cannot_be_reset_by_configuration() {
    let (mut org, world) = suspended_actual();
    let actual = org.observer_continuation_actual().unwrap().clone();
    let status = org.observer_continuation_status().unwrap();
    assert_eq!(
        org.begin_run(),
        Err(ObserverLifecycleRefusal::PendingBoundary)
    );
    let rejected = org.with_exhaustion_climb(1).unwrap_err();
    assert_eq!(rejected.reason(), ObserverLifecycleRefusal::PendingBoundary);
    let mut org = rejected.into_organism();
    assert_eq!(org.observer_continuation_status().unwrap(), status);
    assert!(Arc::ptr_eq(
        &actual.0,
        &org.observer_continuation_actual().unwrap().0
    ));
    org.resume_observer_boundary(ObserverResumeGrant {
        work: 100_000,
        retention_slots: 10_000,
    })
    .unwrap();
    assert_eq!(world.calls, 257);
    assert!(
        org.begin_run().is_ok(),
        "a completed body can begin an explicitly new run"
    );

    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    world.lose_delivery = true;
    assert!(org.step_forced(&mut world, 0).is_err());
    let failure = org.action_failure.clone();
    assert_eq!(
        org.begin_run(),
        Err(ObserverLifecycleRefusal::UnknownDelivery)
    );
    let rejected = org.with_exhaustion_climb(1).unwrap_err();
    assert_eq!(rejected.reason(), ObserverLifecycleRefusal::UnknownDelivery);
    let org = rejected.into_organism();
    assert_eq!(org.action_failure, failure);
    assert!(
        org.exhaust
            .as_ref()
            .unwrap()
            .observer_history
            .current_history()
            .is_err()
    );
    assert_eq!(world.delivered, [0]);
}

#[test]
fn completed_observer_reconfiguration_remains_an_explicit_success() {
    let mut org = Organism::new()
        .with_exhaustion_climb(4096)
        .expect("fresh observer configuration");
    let mut world = ParityWorld::new();
    org.step_forced(&mut world, 0).unwrap();
    org.begin_run().unwrap();
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        1,
        "a new episode keeps the existing complete native history"
    );
    let mut org = org
        .with_exhaustion_resources(128, ObserverResources::default())
        .unwrap_or_else(|_| panic!("a completed body is not an unfinished boundary"));
    org.step_forced(&mut world, 0).unwrap();
    assert_eq!(world.calls, 2);
}

// Reuse the actual ownership/physical courts, including their world-call
// assertions. This adds observation only; no state or verdict is synthesized.
#[cfg(all(test, feature = "serde"))]
#[test]
fn export_frozen_retirement_boundaries() {
    let Some(path) = std::env::var_os("SYNARC_RETIREMENT_EXPORT") else { return; };
    retirement_export::start();
    actual_partial_read_retires_after_one_act_and_preserves_exact_lower_edge();
    partial_update_retries_before_delivery_without_consuming_an_extra_command_or_stamp();
    a_counterexample_below_a_tier_retires_the_entire_dependent_suffix();
    full_journal_preserves_previous_witness_and_pending_actual_without_retiring();
    each_owned_after_act_phase_is_consumed_once_under_small_explicit_grants();
    upper_prefix_court::actual_upper_failure_preserves_advanced_lower();
    retirement_export::finish(std::path::Path::new(&path));
}

#[cfg(all(test, feature = "serde"))]
mod upper_prefix_court {
    use super::*;
    use std::cell::RefCell;

    struct CommitEntry {
        cuts: Vec<observer_runtime::OwnedCut<u8>>,
        epochs: Vec<u128>,
        history_ordinal: u64,
        attempts: u64,
    }
    thread_local! { static ENTRY: RefCell<Option<CommitEntry>> = const { RefCell::new(None) }; }

    fn observe(ex: &ExhaustClimb<u8>, ports: retirement_export::PhysicalPorts,
        work: usize, point: retirement_export::Point<'_>) {
        if matches!(&point, retirement_export::Point::Precommit) {
            ENTRY.with(|entry| {
                let mut entry = entry.borrow_mut();
                assert!(entry.is_none(), "one actual retirement commit");
                *entry = Some(CommitEntry {
                    cuts: ex.floors.iter().map(|f| f.observer.owned_cut()).collect(),
                    epochs: ex.floors.iter().map(|f| f.input_epoch).collect(),
                    history_ordinal: ex.observer_history.ordinal(),
                    attempts: ports.attempts,
                });
            });
        }
        if retirement_export::active() { retirement_export::observe(ex, ports, work, point); }
    }


    #[test]
    pub(super) fn actual_upper_failure_preserves_advanced_lower() {
        let mut org = Organism::new().with_exhaustion_climb(4096).unwrap();
        org.exhaust.as_mut().unwrap().program_agenda = None;
        append_periodic_fixture(&mut org, 2, 3, false);
        append_periodic_fixture(&mut org, 3, 3, true);
        let middle_definition = Arc::clone(org.exhaust.as_ref().unwrap().floors[1]
            .observer.general().installed().cut().definition());
        append_periodic_fixture(&mut org, 5, 3, false);
        let mut world = ParityWorld::new();
        world.raw = 3;
        let ex = org.exhaust.as_ref().unwrap();
        assert_eq!(ex.floors.len(), 3);
        assert!(ex.tier.is_none());
        let lower_before = ex.floors[0].observer.owned_cut();
        let observer_runtime::OwnedCut(lower_before) = lower_before;
        let input::Value::Nat(count_before) = lower_before.state() else { panic!("the native fixture owns its acquired count") };
        let count_before = *count_before;
        let attempts = org.action_attempts;
        let calls = world.calls;
        let ordinal = ex.observer_history.ordinal();
        ENTRY.with(|entry| assert!(entry.borrow().is_none()));
        org.exhaust.as_mut().unwrap().domain_retirement_audit = Some(observe);
        world.leave_support = true;
        org.step_forced(&mut world, 0).unwrap();
        assert_eq!(world.calls, calls+1, "exactly one actual physical delivery");
        assert_eq!(org.action_attempts, attempts+1);
        let entry = ENTRY.with(|entry| entry.borrow_mut().take().expect("independent live precommit cuts"));
        let ex = org.exhaust.as_ref().unwrap();
        assert_eq!(entry.cuts.len(), 3);
        assert_eq!(ex.floors.len(), 1);
        assert_eq!(entry.history_ordinal, ordinal+1);
        assert_eq!(ex.observer_history.ordinal(), entry.history_ordinal);
        assert_eq!(entry.attempts, org.action_attempts);
        assert!(entry.cuts[0].matches(&ex.floors[0].observer), "current lower instance AND state must survive");
        assert_eq!(entry.epochs[0], ex.floors[0].input_epoch);
        let observer_runtime::OwnedCut(lower_now) = ex.floors[0].observer.owned_cut();
        assert!(!lower_before.same_revision(&lower_now), "the one delivery really advanced the lower revision");
        assert_eq!(lower_now.state(), &input::Value::Nat(count_before+1));
        assert!(Arc::ptr_eq(lower_before.definition(),lower_now.definition()));
        let r = org.last_domain_retirement().unwrap();
        assert_eq!(r.boundary(), DomainBoundary::AfterAct);
        assert_eq!(r.fault().floor_index(), 1);
        assert_eq!(r.retired_floor_count(), 2);
        assert_eq!(ex.observer_history.epoch(), entry.epochs[1]);
        assert_eq!(r.floor().input_epoch(), entry.epochs[1]);
        for (i,floor) in r.retired_floors().iter().enumerate() {
            assert!(entry.cuts[i+1].matches(&floor.observer), "the exact observed dependent suffix is retained");
            assert_eq!(entry.epochs[i+1],floor.input_epoch);
        }
        let observer_runtime::OwnedCut(upper_entry) = &entry.cuts[1] else { panic!("acquired failing upper floor") };
        assert!(upper_entry.same_revision(r.fault().cut()));
        assert!(Arc::ptr_eq(r.fault().cut().definition(), &middle_definition));
        assert_eq!(r.fault().refusal().classification(), RefusalClass::Undefined);
        assert_eq!(r.actual_outcome(), Some((0,ObservedWorldOutcome::Next(0))));
        assert_eq!(r.current_prefix().floors.len(), 1);
        assert!(r.current_prefix().floors[0].cut.matches(&ex.floors[0].observer));
        assert_eq!(r.current_prefix().epoch, ex.observer_history.epoch());
    }
}
// Every fixture below is acquired and freshly validated from real Habitat
// events by installed(); no synthetic Tick or admitted state is introduced.
fn sliced_runtime_read(
    mut call: observer_runtime::Reading<u8>,
    quantum: usize,
) -> (observer_runtime::Read, u64) {
    let mut dispatches = 0;
    for _ in 0..512 {
        let mut work = ObserverWork { remaining: quantum };
        let mut budget = Budget::new(&mut work, ExecutionLimit::Unlimited);
        let result = call.advance(&mut budget);
        dispatches += budget.dispatches();
        match result {
            Ok(Some(read)) => return (read, dispatches),
            Ok(None) => {}
            Err(r) => assert!(r.resource(), "{r:?}"),
        }
    }
    panic!("a finite owned read must finish under repeated fixed service");
}
fn sliced_runtime_prepare(
    mut call: observer_runtime::Preparing<u8>,
    quantum: usize,
) -> (observer_runtime::Prepared<u8>, u64) {
    let mut dispatches = 0;
    for _ in 0..512 {
        let mut work = ObserverWork { remaining: quantum };
        let mut budget = Budget::new(&mut work, ExecutionLimit::Unlimited);
        let result = call.advance(&mut budget);
        dispatches += budget.dispatches();
        match result {
            Ok(Some(prepared)) => return (prepared, dispatches),
            Ok(None) => {}
            Err(r) => assert!(r.resource(), "{r:?}"),
        }
    }
    panic!("a finite owned update must finish under repeated fixed service");
}
#[test]
fn acquired_runtime_whole_and_fixed_slices_preserve_output_update_and_dispatch_count() {
    let (org, world, _, _) = installed(true);
    let floor = &org.exhaust.as_ref().unwrap().floors[0].observer;
    let view = observer_runtime::View { sensory: None,
        raw: world.key(),
        input: world.key(),
        episode: org.source_time.episode().unwrap(),
        life_age: org.source_time.life_age(),
        pose: org.cur_pose,
    };
    let before = floor.owned_cut();
    let (whole_read, read_dispatches) =
        sliced_runtime_read(floor.begin_read(view.clone()).unwrap(), 100_000);
    let (whole_update, update_dispatches) =
        sliced_runtime_prepare(floor.begin_prepare(view.clone(), 0).unwrap(), 100_000);
    let whole_input = whole_update.input();
    let whole_update = whole_update.program();
    for quantum in [1, 2, 3, 7] {
        let (read, dispatches) = sliced_runtime_read(floor.begin_read(view.clone()).unwrap(), quantum);
        assert_eq!(
            read.key,
            whole_read.key
        );
        assert_eq!(dispatches, read_dispatches);
        let (prepared, dispatches) =
            sliced_runtime_prepare(floor.begin_prepare(view.clone(), 0).unwrap(), quantum);
        let program = prepared.program();
        let input = prepared.input();
        assert_eq!(input, whole_input);
        assert_eq!(program.next_state(), whole_update.next_state());
        assert_eq!(program.execution(), whole_update.execution());
        assert_eq!(dispatches, update_dispatches);
        assert!(program.before().same_revision(whole_update.before()));
        assert!(
            before.matches(floor),
            "neither read nor uncommitted update mutates live state"
        );
    }
}

#[test]
fn physical_capture_fixed_grants_deliver_and_commit_only_once() {
    let (mut org, original, _, _) = installed(true);
    let mut world = DispatchWorld::new(original);
    let before = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .owned_cut();
    let (attempts, ordinal, steps) = (
        org.action_attempts,
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        org.steps,
    );
    org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .general()
        .enable_audit();
    org.exhaust.as_mut().unwrap().observer_capture_work = 1;
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.inner.calls, 256);
    assert!(world.delivered.is_empty());
    assert_eq!(org.action_attempts, attempts);
    let mut completed = false;
    for _ in 0..512 {
        assert!(before.matches(&org.exhaust.as_ref().unwrap().floors[0].observer));
        assert_eq!(
            org.exhaust.as_ref().unwrap().observer_history.ordinal(),
            ordinal
        );
        match org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                capture_work: 1,
                ..Default::default()
            },
        ) {
            Ok(result) => {
                assert_eq!(result.pulse().unwrap().action, 0);
                completed = true;
                break;
            }
            Err(BeforeActResumeError::Unavailable(BeforeActResumeRefusal::Resource)) => {}
            Err(error) => panic!("unexpected retained boundary refusal: {error:?}"),
        }
    }
    assert!(completed);
    assert_eq!(world.delivered, [0]);
    assert_eq!(world.inner.calls, 257);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(org.steps, steps + 1);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal + 1
    );
    assert_eq!(world.confirmations_read.get(), 1);
    assert!(org.before_act_status().is_none());
    assert!(org.domain_retirements().is_empty());
    let audit = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .general()
        .take_audit();
    assert_eq!(
        audit
            .iter()
            .filter(|e| matches!(e, observer_runtime::AuditEvent::Commit { .. }))
            .count(),
        1
    );
}

#[test]
fn normal_successor_resource_resumes_full_bookkeeping_and_body_without_habitat() {
    let (mut reference, mut reference_world, _, _) = installed(false);
    let expected = reference
        .step_forced(&mut reference_world, 0)
        .unwrap()
        .pulse()
        .unwrap();
    let (mut org, mut world, _, _) = installed(false);
    // Measured pre-read is the same complete native program. The actual
    // successor has a different exact value/name and requires another namespace
    // insertion. This creates a resource boundary without forging an error.
    let mut measurement = ObserverWork { remaining: 100_000 };
    org.eyed_checked(
        world.key(),
        &mut Budget::new(&mut measurement, ExecutionLimit::Unlimited),
    )
    .unwrap_or_else(|r| panic!("{r}"));
    let measured_pre = 100_000 - measurement.remaining;
    assert!(measured_pre > 0);
    org.exhaust.as_mut().unwrap().observer_work = measured_pre;
    let steps = org.steps;
    let attempts = org.action_attempts;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    assert!(org.step_forced(&mut world, 0).is_err());
    assert_eq!(world.calls, 257);
    assert_eq!(
        org.observer_continuation_status().unwrap().phase,
        ObserverContinuationPhase::Project
    );
    assert_eq!(org.steps, steps);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal + 1
    );
    let cut = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .owned_cut();
    drop(world); // The resume API has no Habitat with which to repeat act/read.
    let mut completed = None;
    // The phase-entry receipt and each actual native transition are retained;
    // a unit grant performs new work instead of paying the same header again.
    for _ in 0..128 {
        match org.resume_observer_boundary(ObserverResumeGrant {
            work: 1,
            retention_slots: 0,
        }) {
            Ok(result) => {
                completed = Some(result.pulse().unwrap());
                break;
            }
            Err(ObserverResumeRefusal::Resource { .. }) => {}
            Err(r) => panic!("{r:?}"),
        }
        assert!(cut.matches(&org.exhaust.as_ref().unwrap().floors[0].observer));
        assert_eq!(org.action_attempts, attempts + 1);
        assert_eq!(
            org.exhaust.as_ref().unwrap().observer_history.ordinal(),
            ordinal + 1
        );
    }
    let actual = completed.expect("captured normal successor resumes under fixed service");
    assert_eq!(actual.action, expected.action);
    assert_eq!(actual.novel, expected.novel);
    assert_eq!(actual.climate, expected.climate);
    assert_eq!(body(&org), body(&reference));
    assert_eq!(org.table, reference.table);
    assert_eq!(org.steps, reference.steps);
    assert_eq!(
        org.exhaust.as_ref().unwrap().witnessed,
        reference.exhaust.as_ref().unwrap().witnessed
    );
    assert_eq!(org.steps, steps + 1);
    assert_eq!(org.action_attempts, attempts + 1);
    assert!(cut.matches(&org.exhaust.as_ref().unwrap().floors[0].observer));
    assert!(org.domain_retirements().is_empty());
    assert!(org.observer_continuation_status().is_none());
    assert!(org.action_failure.is_none());
    assert_eq!(
        org.resume_observer_boundary(ObserverResumeGrant {
            work: 1,
            retention_slots: 0
        })
        .unwrap_err(),
        ObserverResumeRefusal::NoAfterActContinuation
    );
    assert_eq!(org.steps, steps + 1);
    assert_eq!(body(&org), body(&reference));
}

#[test]
fn resource_held_command_revalidates_changed_ports_and_menu_before_delivery() {
    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    org.exhaust.as_mut().unwrap().observer_capture_work = 1;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let attempts = org.action_attempts;
    assert!(org.step_forced(&mut world, 0).is_err());
    assert!(world.delivered.is_empty());
    world.menu = vec![1];
    world.pose = 7;
    world.act(1).unwrap(); // actual external effect, outside owned journal
    assert_eq!(world.key(), 3);
    assert_eq!(world.delivered, [1]);
    assert!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                read_work: 100_000,
                capture_work: 100_000,
                retention_slots: 0
            }
        )
        .is_err()
    );
    assert_eq!(world.delivered, [1]);
    assert_eq!(org.action_attempts, attempts);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal
    );
    world.menu = vec![0];
    org.resume_observer_before_act(&mut world, BeforeActResumeGrant::default())
        .unwrap();
    assert_eq!(world.delivered, [1, 0]);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal + 1
    );
    let prefix = org
        .exhaust
        .as_ref()
        .unwrap()
        .observer_history
        .current_history()
        .unwrap();
    let event = prefix
        .cursor(ordinal)
        .unwrap()
        .next(&mut 10_000)
        .unwrap()
        .unwrap();
    assert_eq!(event.event().raw_state, 3);
    assert_eq!(event.event().action, 0);
    assert_eq!(event.pose(), Some(7));
    assert_eq!(world.confirmations_read.get(), 1);
    assert!(org.domain_retirements().is_empty());
}
#[test]
fn autonomous_resource_cancellation_cannot_spend_every_fixed_grant_before_native_work() {
    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    world.menu = vec![0, 1];
    world.request = Some(0);
    org.exhaust.as_mut().unwrap().observer_capture_work = 1;
    let attempts = org.action_attempts;
    let steps = org.steps;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let before = org.exhaust.as_ref().unwrap().floors[0]
        .observer
        .owned_cut();
    assert!(org.step(&mut world).is_err());
    assert!(world.delivered.is_empty());
    assert_eq!(
        org.before_act_status().unwrap().phase,
        BeforeActPhase::CancelProposal
    );
    let mut completed = false;
    for _ in 0..512 {
        assert!(before.matches(&org.exhaust.as_ref().unwrap().floors[0].observer));
        assert_eq!(
            org.exhaust.as_ref().unwrap().observer_history.ordinal(),
            ordinal
        );
        assert_eq!(world.confirmations_read.get(), 1);
        match org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                capture_work: 1,
                read_work: 0,
                retention_slots: 0,
            },
        ) {
            Ok(result) => {
                assert_eq!(result.pulse().unwrap().action, 0);
                completed = true;
                break;
            }
            Err(BeforeActResumeError::Unavailable(BeforeActResumeRefusal::Resource)) => {}
            Err(error) => panic!("unexpected autonomous continuation refusal: {error:?}"),
        }
    }
    assert!(
        completed,
        "a paid cancellation must not repeat ahead of every new unit of native work"
    );
    assert_eq!(world.delivered, [0]);
    assert_eq!(world.inner.calls, 257);
    assert_eq!(world.confirmations_read.get(), 1);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(org.steps, steps + 1);
    assert_eq!(
        org.exhaust.as_ref().unwrap().observer_history.ordinal(),
        ordinal + 1
    );
    assert_eq!(
        org.proposal_cancellations().len(),
        1,
        "one held boundary, one cancelled original promise, one retained replacement"
    );
    assert_eq!(
        org.proposal_cancellations()[0].decision(),
        Decision::WorldRequest(0)
    );
    assert_eq!(
        org.proposal_cancellations()[0].reason(),
        ProposalCancellationReason::ReobserveAfterResource
    );
    assert!(org.domain_retirements().is_empty());
    assert!(org.before_act_status().is_none());
}
#[test]
fn retained_autonomous_generation_revalidates_changed_request_with_identical_observation_ports() {
    let (mut reference, original, _, _) = installed(false);
    let mut reference_world = DispatchWorld::new(original);
    reference_world.menu = vec![0, 1];
    reference_world.request = Some(1);
    let expected = reference
        .step(&mut reference_world)
        .unwrap()
        .pulse()
        .unwrap();
    assert_eq!(reference_world.delivered, [1]);

    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    world.menu = vec![0, 1];
    world.request = Some(0);
    org.exhaust.as_mut().unwrap().observer_capture_work = 1;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let attempts = org.action_attempts;
    assert!(org.step(&mut world).is_err());
    assert!(
        org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                capture_work: 1,
                read_work: 0,
                retention_slots: 0,
            }
        )
        .is_err()
    );
    assert_eq!(
        org.proposal_cancellations().len(),
        1,
        "the original cancellation is actually paid before the request changes"
    );
    assert_eq!(
        org.proposal_cancellations()[0].decision(),
        Decision::WorldRequest(0)
    );
    assert!(world.delivered.is_empty());
    let ports = (world.key(), world.pose(), world.actions());
    world.request = Some(1); // Only the actual external request changes.
    assert_eq!((world.key(), world.pose(), world.actions()), ports);
    let mut completed = None;
    for _ in 0..512 {
        match org.resume_observer_before_act(
            &mut world,
            BeforeActResumeGrant {
                capture_work: 1,
                read_work: 0,
                retention_slots: 0,
            },
        ) {
            Ok(result) => {
                completed = Some(result.pulse().unwrap());
                break;
            }
            Err(BeforeActResumeError::Unavailable(BeforeActResumeRefusal::Resource)) => {}
            Err(error) => panic!("unexpected request-revalidation refusal: {error:?}"),
        }
    }
    let actual = completed.expect("changed request reaches a fresh retained generation");
    assert_eq!(
        world.delivered,
        [1],
        "a surviving old VM cursor cannot authorize delivery of the cancelled request0"
    );
    assert_eq!(world.inner.calls, 257);
    assert_eq!(world.confirmations_read.get(), 1);
    assert_eq!(org.action_attempts, attempts + 1);
    assert_eq!(actual.action, expected.action);
    assert_eq!(actual.novel, expected.novel);
    assert_eq!(actual.climate, expected.climate);
    assert_eq!(body(&org), body(&reference));
    assert_eq!(org.table, reference.table);
    assert_eq!(org.steps, reference.steps);
    assert!(org.domain_retirements().is_empty());
    assert!(org.before_act_status().is_none());
    let prefix = org
        .exhaust
        .as_ref()
        .unwrap()
        .observer_history
        .current_history()
        .unwrap();
    assert_eq!(prefix.len(), ordinal + 1);
    let event = prefix
        .cursor(ordinal)
        .unwrap()
        .next(&mut 10_000)
        .unwrap()
        .unwrap();
    assert_eq!(event.event().raw_state, ports.0);
    assert_eq!(event.event().action, 1);
    assert_eq!(event.pose(), ports.1);
}

#[cfg(feature = "serde")]
#[test]
fn actual_acquired_name_cursor_preserves_prefix_across_denial_sibling_and_capacity_grant() {
    let (org, world, _, _) = installed(false);
    let ex=org.exhaust.as_ref().unwrap();
    observer_runtime::naming_export::exercise(ex.floors[0].observer.general(),
        observer_runtime::View { sensory: None, raw:world.key(),input:world.key(),episode:org.source_time.episode().unwrap(),
            life_age:org.source_time.life_age(),pose:org.cur_pose,});
}

#[test]
fn resumed_delivery_hands_a_real_successor_to_after_act_instead_of_claiming_no_action() {
    let (mut reference, mut reference_world, _, _) = installed(false);
    reference.step_forced(&mut reference_world, 0).unwrap();
    let (mut org, original, _, _) = installed(false);
    let mut world = DispatchWorld::new(original);
    let mut measure = ObserverWork { remaining: 100_000 };
    org.eyed_checked(world.key(), &mut Budget::new(&mut measure, ExecutionLimit::Unlimited))
        .unwrap_or_else(|r| panic!("{r}"));
    org.exhaust.as_mut().unwrap().observer_work = 100_000 - measure.remaining;
    org.exhaust.as_mut().unwrap().observer_capture_work = 1;
    let ordinal = org.exhaust.as_ref().unwrap().observer_history.ordinal();
    assert!(org.step_forced(&mut world, 0).is_err());
    assert!(world.delivered.is_empty());
    let mut delivered = false;
    for _ in 0..512 {
        match org.resume_observer_before_act(&mut world, BeforeActResumeGrant {
            capture_work: 1, ..Default::default()
        }) {
            Err(BeforeActResumeError::Unavailable(BeforeActResumeRefusal::Resource)) => {
                assert!(world.delivered.is_empty(), "undelivered Resource is not a post-effect error");
                assert_eq!(org.exhaust.as_ref().unwrap().observer_history.ordinal(), ordinal);
            }
            Err(BeforeActResumeError::Execution(failure)) => {
                assert_eq!(failure.stage, ActionStage::Budget);
                assert_eq!(world.delivered, [0]);
                assert!(org.before_act_status().is_none());
                assert!(org.observer_continuation_status().is_some());
                delivered = true;
                break;
            }
            other => panic!("unexpected delivery boundary: {other:?}"),
        }
    }
    assert!(delivered);
    assert_eq!(org.exhaust.as_ref().unwrap().observer_history.ordinal(), ordinal + 1);
    drop(world);
    let mut completed = false;
    for _ in 0..128 {
        match org.resume_observer_boundary(ObserverResumeGrant { work: 1, retention_slots: 0 }) {
            Ok(result) => { assert_eq!(result.pulse().unwrap().action, 0); completed = true; break; }
            Err(ObserverResumeRefusal::Resource { .. }) => {}
            Err(other) => panic!("unexpected owned successor refusal: {other:?}"),
        }
    }
    assert!(completed);
    assert_eq!(org.steps, reference.steps);
    assert_eq!(org.table, reference.table);
    assert_eq!(body(&org), body(&reference));
}

mod general_duel;

/// Already acquired current native owner, for execution-boundary requirements.
pub(in crate::organism) fn installed_organism() -> Organism<u8> { installed(false).0 }

/// The same native acquisition/validation, with sensory present from its first show.
pub(in crate::organism) fn installed_sensory_organism() -> Organism<u8> {
    installed_with_source(false,
        crate::program::observer::acquisition::AdmissionProfile::ExactPredictiveV1 { risk: crate::program::code_mass::Mass::uniform(num_bigint::BigUint::from(20u8)).unwrap() }, true).0
}

/// Current-owner fixture for stacked standing and retirement requirements.
/// Each appended observer must buy its unchanged native price on actual actions
/// and validate on later actions. It cannot install an identity/duplicate floor.
pub(in crate::organism) fn append_periodic_fixture(
    org: &mut Organism<u8>, modulus: u64, raw: u64, partial: bool,
) -> FloorIdentity {
    append_fixture(org, modulus, raw, partial, false)
}

pub(in crate::organism) fn append_pose_fixture(org: &mut Organism<u8>, raw: u64) {
    append_fixture(org, 3, raw, false, true);
}

fn append_fixture(org: &mut Organism<u8>, modulus: u64, raw: u64, partial: bool, pose: bool) -> FloorIdentity {
    struct Training { age: u64, modulus: u64, raw: u64, pose: bool }
    impl Habitat for Training {
        type Action = u8;
        fn observe(&self) -> [f64;7] { [1.0/7.0;7] }
        fn key(&self) -> u64 { self.raw }
        fn pose(&self) -> Option<u8> { self.pose.then(|| u8::try_from(self.age % self.modulus).unwrap()) }
        fn actions(&self) -> Vec<u8> { vec![0] }
        fn reset_action(&self) -> Option<u8> { None }
        fn act(&mut self, action: u8) -> Result<ObservedAction, ActionFailure<u8>> {
            assert_eq!(action, 0);
            let observed = if self.age % self.modulus == 0 { ObservedAction::Step } else { ObservedAction::Refused };
            self.age += 1;
            Ok(observed)
        }
    }
    assert!(modulus > 1);
    assert!(!partial || raw == modulus);
    let ex = org.exhaust.as_ref().unwrap();
    assert!(ex.program_agenda.is_none(), "fixture owns one explicitly declared native source");
    let source = input::Source { sensory:false, epoch:ex.observer_history.epoch(),
        raw_space:ex.observer_history.raw_space(), owner:Some(ex.observer_history.lineage()), shape:input::Shape::Event };
    let query = input::Source { shape:input::Shape::Query, ..source.clone() };
    let semantics = Arc::new(input::Meaning::for_sensory_court(4096));
    let mut read_body = vec![(if pose { input::Op::QueryPose } else { input::Op::QueryAge }, vec![Arg::Input(0)])];
    let divisor = if partial {
        read_body.push((input::Op::QueryRaw, vec![Arg::Input(0)]));
        Arg::Register(1)
    } else { Arg::Literal(input::Value::Nat(modulus)) };
    if !pose { read_body.push((input::Op::Rem, vec![Arg::Register(0), divisor])); }
    // Freeze code and its original uniform family before the calibration prefix.
    let mut series = input::JointSeries::freeze(
        Syntax::freeze(grammar(0, &[input::Op::Zero])).unwrap(),
        Syntax::freeze(grammar(1, &[input::Op::Succ])).unwrap(),
        Syntax::with_library(grammar(1, &[]), vec![(1, program(read_body))]).unwrap(),
        InputBinding::new(source.clone(),1,vec![InputSource::State]).unwrap(),
        InputBinding::new(query,1,vec![InputSource::External(0)]).unwrap(),
        Arc::clone(&semantics),
    ).unwrap().declare_admission(crate::program::observer::acquisition::AdmissionProfile::ExactPredictiveV1 { risk: crate::program::code_mass::Mass::uniform(num_bigint::BigUint::from(20u8)).unwrap() }).map_err(|(_, reason)| reason).unwrap();
    assert_eq!(series.family_count().unwrap(),1);
    let mut world = Training { age:org.source_time.life_age(), modulus, raw, pose };
    let mut alphabets = BTreeMap::new();
    for _ in 0..128 {
        org.step_forced(&mut world,0).unwrap();
        let ex=org.exhaust.as_ref().unwrap();
        let cut=&ex.last_observed_cut.as_ref().unwrap().cut;
        alphabets.insert((source.epoch,cut.input(source.epoch).unwrap(),0), BTreeSet::from([
            input::Value::Outcome(ObservedWorldOutcome::Next(raw)),
            input::Value::Outcome(ObservedWorldOutcome::Refused(raw)),
        ]));
    }
    let origin=org.exhaust.as_ref().unwrap().observer_history.ordinal();
    let mut intake=series.open_trial(alphabets.clone()).unwrap();
    for _ in 0..256 { org.step_forced(&mut world,0).unwrap(); }
    let mut work=ObserverWork { remaining:10_000_000 };
    let rows=org.program_rows(&source,origin,&alphabets,&mut work).unwrap();
    assert_eq!(rows.rows.len(),256);
    for row in rows.rows { intake.observe(Arc::clone(&rows.history),row.cut,row.context,row.query,row.outcome).unwrap(); }
    let mut search=intake.finish::<()>().unwrap();
    let (candidate,accepted) = loop {
        match search.advance(&mut Budget::new(&mut work,ExecutionLimit::Unlimited)) {
            joint::Progress::Advanced => {},
            joint::Progress::Assessed { candidate,assessment } => {
                assert!(assessment.purchased().unwrap(), "independent physical variation must pay the unchanged native price");
                break(candidate,assessment.accepted().unwrap().unwrap());
            },
            _ => panic!("declared fixture must remain defined on its actual source"),
        }
    };
    assert_eq!(candidate.comparison_count().unwrap(),2);
    let mut fresh=accepted.open_validation();
    for _ in 0..256 { org.step_forced(&mut world,0).unwrap(); }
    let rows=org.program_rows(&source,origin+256,&alphabets,&mut work).unwrap();
    assert_eq!(rows.rows.len(),256);
    for row in rows.rows { fresh.observe(Arc::clone(&rows.history),row.cut,row.context,row.query,row.outcome).unwrap(); }
    let validated=fresh.finish().unwrap().evaluate(&mut Budget::new(&mut work,ExecutionLimit::Unlimited))
        .unwrap().validated().unwrap().expect("independent fresh outcomes must validate the fixture");
    let admission=observer_acceptance::Admission::from_native(input::Producer::from(Arc::clone(&candidate)),validated).unwrap();
    org.install_program_observer(&admission,4096,&mut work).unwrap();
    org.top_floor_identity().unwrap()
}
