//! Runtime for admitted native observer definitions.
//! Every execution retains the actual instance, source and output namespace.
use super::{observer_acquired as acquired, ObserverWork};
use crate::program::observer::{self, Input};
use std::sync::Mutex;
use std::sync::Arc;

type Budget<'a> = observer::Budget<'a, ObserverWork>;

/// Every branch in one output epoch shares this exact monotone namespace.
/// Naming may happen on a failed preparation; it never changes semantic state.
struct Names<A: Ord> { birth: super::causal_coordinates::LanguageBirth, capacity: usize, values: Vec<(u64, acquired::Value<A>)> }
impl<A: Copy + Ord> Names<A> {
    /// One paid comparison or insertion. A retained caller owns `scanned`;
    /// an atomic caller drives this same transition with a local cursor.
    fn advance(&mut self, input: u64, value: &acquired::Value<A>, scanned: &mut usize,
        budget: &mut Budget<'_>) -> Result<Option<u64>, Refusal<A>> {
        budget.charge_external(1).map_err(Refusal::External)?;
        if let Some((old_input, old_value)) = self.values.get(*scanned) {
            if *old_input == input && old_value == value {
                return u64::try_from(*scanned).map(Some)
                    .map_err(|_| Refusal::NameCapacity { epoch: self.birth.epoch() });
            }
            *scanned += 1;
            return Ok(None);
        }
        debug_assert_eq!(*scanned, self.values.len(), "a retained prefix cannot skip entries");
        let name = u64::try_from(self.values.len())
            .map_err(|_| Refusal::NameCapacity { epoch: self.birth.epoch() })?;
        if self.values.len() >= self.capacity || name >= (1u64 << 56) {
            return Err(Refusal::NameCapacity { epoch: self.birth.epoch() });
        }
        self.values.try_reserve(1).map_err(|_| Refusal::NameCapacity { epoch: self.birth.epoch() })?;
        self.values.push((input, value.clone()));
        Ok(Some(name))
    }
    fn intern(&mut self, input: u64, value: &acquired::Value<A>, budget: &mut Budget<'_>) -> Result<u64, Refusal<A>> {
        let mut scanned = 0;
        loop {
            if let Some(name) = self.advance(input, value, &mut scanned, budget)? {
                return Ok(name);
            }
        }
    }
}

/// The exact attempted query and immutable native state survive a refused
/// read. None means the source-shape check refused before native evaluation.
pub(super) struct GeneralReadRefusal<A: Copy + Ord> {
    pub(super) cut: acquired::Cut<A>,
    pub(super) query: Option<acquired::InputRow<A>>,
    pub(super) reason: Refusal<A>,
}
impl<A: Copy + Ord> std::fmt::Debug for GeneralReadRefusal<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("GeneralReadRefusal").field("cut", &self.cut)
            .field("query_retained", &self.query.is_some()).field("reason", &self.reason).finish()
    }
}

pub(super) struct General<A: Copy + Ord> {
    installed: acquired::Installed<A>, producer: acquired::Producer<A>, names: Arc<Mutex<Names<A>>>,
    pub(super) finite_analysis: Mutex<Option<Box<super::observer_finite::Analysis<A>>>>,
    #[cfg(test)]
    audit: Arc<Mutex<Option<Vec<AuditEvent<A>>>>>,
}
impl<A: Copy + Ord> General<A> {
    pub(super) fn new(installed: acquired::Installed<A>, producer: impl Into<acquired::Producer<A>>, birth: super::causal_coordinates::LanguageBirth, capacity: usize) -> Result<Self, Refusal<A>> {
        let producer = producer.into();
        if installed.admission().is_predictive() { return Err(Refusal::PredictiveOnly); }
        if installed.history().origin().lineage() != birth.lineage() || !Arc::ptr_eq(installed.cut().definition(), producer.definition()) { return Err(Refusal::ForeignSource); }
        Ok(Self { installed, producer, names: Arc::new(Mutex::new(Names { birth, capacity, values: Vec::new() })),
            finite_analysis: Mutex::new(None),
            #[cfg(test)]
            audit: Arc::new(Mutex::new(None)),
        })
    }
    /// The same owned adapter row is used by execution and domain receipts.
    pub(super) fn input_row(&self, view: View, action: Option<A>) -> acquired::InputRow<A> {
        let cut = self.installed.cut();
        match action {
            Some(action) => { let source = cut.definition().update_binding().interface();
                acquired::event_row(acquired::Event { sensory: view.sensory.clone(), epoch: source.epoch, raw_space: source.raw_space, owner: source.owner,
                    raw: view.raw, input: view.input, action, episode: view.episode, life_age: view.life_age,
                    pose: (view.pose != 255).then_some(view.pose) }) }
            None => { let source = cut.definition().read_binding().interface();
                acquired::query_row(acquired::Query { sensory: view.sensory.clone(), epoch: source.epoch, raw_space: source.raw_space, owner: source.owner,
                    raw: view.raw, input: view.input, episode: view.episode, life_age: view.life_age,
                    pose: (view.pose != 255).then_some(view.pose), action: None }) }
        }
    }
    /// Common read implementation for both installed floors and publication.
    /// This envelope retains the actual row used by the same native VM; no
    /// reconstructed post-failure input stands in for the attempted query.
    pub(super) fn read_owned(&self, view: View, budget: &mut Budget<'_>) -> Result<Read, GeneralReadRefusal<A>> {
        let cut = self.installed.cut();
        if cut.definition().read_binding().interface().shape != acquired::Shape::Query {
            return Err(GeneralReadRefusal { cut, query: None, reason: Refusal::ForeignSource });
        }
        let query = self.input_row(view.clone(), None);
        let result = (|| {
            let read = cut.read(Input::new(query.interface(), query.values()), budget).map_err(Refusal::Acquired)?;
            let key = self.names.lock().map_err(|_| Refusal::NameOwnerPoisoned)?.intern(view.input, read.value(), budget)?;
            #[cfg(test)]
            if let Some(events) = &mut *self.audit.lock().expect("test audit owner") {
                events.push(AuditEvent::Read { view, query: query.clone(), reading: read, name: key });
            }
            Ok(Read { key })
        })();
        result.map_err(|reason| GeneralReadRefusal { cut, query: Some(query), reason })
    }
    /// Explicit engineering retention grant; does not replace the native
    /// namespace owner or remap any existing value/name association.
    pub(super) fn set_name_capacity(&self, capacity: usize) -> Result<(), Refusal<A>> {
        let mut names = self.names.lock().map_err(|_| Refusal::NameOwnerPoisoned)?;
        if capacity < names.values.len() { return Err(Refusal::NameCapacity { epoch: names.birth.epoch() }); }
        names.capacity = capacity; Ok(())
    }
    pub(super) fn installed(&self) -> &acquired::Installed<A> { &self.installed }
    pub(super) fn producer(&self) -> &acquired::Producer<A> { &self.producer }
    pub(super) fn output_epoch(&self) -> Option<u128> { self.names.lock().ok().map(|n| n.birth.epoch()) }
    fn fork(&self) -> Self { Self { installed: self.installed.fork(), producer: self.producer.clone(), names: Arc::clone(&self.names),
        // A fork is a different installed instance. It cannot clone a paid
        // analysis continuation or current-revision binding from its source.
        finite_analysis: Mutex::new(None),
        #[cfg(test)]
        audit: Arc::new(Mutex::new(None)),
    } }
    #[cfg(test)]
    pub(super) fn enable_audit(&self) { *self.audit.lock().expect("test audit owner") = Some(Vec::new()); }
    #[cfg(all(test, feature = "serde"))]
    pub(super) fn enable_publication_audit(&self, original: acquired::Cut<A>, mut prefix: Vec<AuditEvent<A>>) {
        // Capture the actual returned publication fork, before any subsequent
        // read or physical commit. This is evidence, never an authority input.
        prefix.push(AuditEvent::Fork { before: original, after: self.installed.cut() });
        *self.audit.lock().expect("test audit owner") = Some(prefix);
    }
    #[cfg(test)]
    pub(super) fn take_audit(&self) -> Vec<AuditEvent<A>> {
        std::mem::take(self.audit.lock().expect("test audit owner").as_mut().expect("explicitly enabled audit"))
    }
}

/// Test-only retention of actual successful native executions. Disabled by
/// default; enabling it neither replays a program nor fabricates a receipt.
#[cfg(test)]
pub(super) enum AuditEvent<A: Copy + Ord> {
    #[cfg(feature = "serde")]
    Fork { before: acquired::Cut<A>, after: acquired::Cut<A> },
    Read { view: View, query: acquired::InputRow<A>,
        reading: observer::Reading<acquired::Value<A>, acquired::Op, acquired::Source, acquired::Meaning>, name: u64 },
    Commit { input: acquired::InputRow<A>,
        receipt: Arc<observer::Committed<acquired::Value<A>, acquired::Op, acquired::Source, acquired::Meaning>> },
}

pub(super) struct FloorObserver<A: Copy + Ord>(pub(super) General<A>);
impl<A: Copy + Ord> std::fmt::Debug for FloorObserver<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { f.write_str("FloorObserver::Acquired") }
}

/// Exact immutable native state ownership, for retirement/export boundaries.
pub(super) struct OwnedCut<A: Copy + Ord>(pub(super) acquired::Cut<A>);
impl<A: Copy + Ord> std::fmt::Debug for OwnedCut<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_tuple("AcquiredCut").field(&self.0).finish()
    }
}

impl<A: Copy + Ord> OwnedCut<A> {
    pub(super) fn matches(&self, observer: &FloorObserver<A>) -> bool {
        self.0.same_revision(&observer.general().installed().cut())
    }
}

/// A provenance-only projection of the actual successful native Committed.
/// Fields are private; no caller-supplied before/after pair can mint one.
/// Cut clones share Definition/instance/State Arcs; the original input is moved.
/// This duplicates neither Value/history payloads nor the ExecutionReport.
pub(super) struct Commit<A: Copy + Ord> {
    before: acquired::Cut<A>, after: acquired::Cut<A>, input: acquired::InputRow<A>,
}
impl<A: Copy + Ord> Commit<A> {
    pub(super) fn before(&self) -> &acquired::Cut<A> { &self.before }
    pub(super) fn after(&self) -> &acquired::Cut<A> { &self.after }
    pub(super) fn input(&self) -> &acquired::InputRow<A> { &self.input }
}

/// Runtime-owned association between the actual VM result and its pinned input.
/// Only synchronous prepare and the retained Preparing cursor construct it.
pub(super) struct Prepared<A: Copy + Ord> { program: acquired::Prepared<A>, input: acquired::InputRow<A> }
impl<A: Copy + Ord> Prepared<A> {
    #[cfg(test)]
    pub(super) fn program(&self) -> &acquired::Prepared<A> { &self.program }
    #[cfg(test)]
    pub(super) fn input(&self) -> &acquired::InputRow<A> { &self.input }
}
pub(super) struct CommitRefusal<A: Copy + Ord> {
    pub(super) rejected: observer::Rejected<acquired::Value<A>, acquired::Op, acquired::Source, acquired::Meaning>, pub(super) input: acquired::InputRow<A>,
}
impl<A: Copy + Ord> std::fmt::Debug for CommitRefusal<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.rejected.reason().fmt(f)
    }
}

pub(super) enum Refusal<A: Copy + Ord> {
    Acquired(observer::Refusal<acquired::Value<A>, acquired::DomainRefusal, ()>),
    External(observer::ExternalRefusal<()>),
    NameCapacity { epoch: u128 }, NameOwnerPoisoned, ForeignSource, PredictiveOnly,
}
impl<A: Copy + Ord> std::fmt::Debug for Refusal<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::External(r) => r.fmt(f),
            Self::NameCapacity { epoch } => f.debug_struct("NameCapacity").field("epoch", epoch).finish(),
            Self::PredictiveOnly => f.write_str("PredictiveAdmissionDoesNotAuthorizePhysicalQuotient"),
            Self::NameOwnerPoisoned => f.write_str("NameOwnerPoisoned"),
            Self::ForeignSource => f.write_str("ForeignSource"),
            Self::Acquired(r) => match r {
                observer::Refusal::Suspended { phase, suspension } => f.debug_tuple("Suspended").field(phase).field(suspension).finish(),
                observer::Refusal::Poisoned { phase } => f.debug_tuple("Poisoned").field(phase).finish(),
                observer::Refusal::Consumed { phase, classification } => f.debug_tuple("Consumed").field(phase).field(classification).finish(),
                observer::Refusal::Binding { phase, reason } => f.debug_tuple("Binding").field(phase).field(reason).finish(),
                observer::Refusal::Work { phase, point, error, .. } => f.debug_tuple("Work").field(phase).field(point).field(error).finish(),
                observer::Refusal::Capacity { phase, point } => f.debug_tuple("Capacity").field(phase).field(point).finish(),
                observer::Refusal::MissingRootOutput { phase, execution } => f.debug_tuple("MissingRootOutput").field(phase).field(&execution.stop).finish(),
                observer::Refusal::Execution { phase, report, counter_capacity, primitive_refusal } => f.debug_struct("Execution")
                    .field("phase", phase).field("stop", &report.execution.stop).field("halt", &report.execution.halt)
                    .field("dispatches", &report.execution.dispatch_attempts).field("meter", &report.meter_error).field("counter_capacity", counter_capacity).field("primitive_refusal", primitive_refusal).finish(),
            },
        }
    }
}
impl<A: Copy + Ord> Refusal<A> {
    pub(super) fn classification(&self) -> observer::RefusalClass {
        use observer::RefusalClass as C;
        match self {
            Self::Acquired(reason) => reason.classification(),
            Self::External(observer::ExternalRefusal::Poisoned) | Self::NameOwnerPoisoned => C::Poisoned,
            Self::External(observer::ExternalRefusal::Work(_)) | Self::NameCapacity { .. } => C::Resource,
            _ => C::Undefined,
        }
    }
    pub(super) fn resource(&self) -> bool { self.classification() == observer::RefusalClass::Resource }

}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct View { pub sensory: Option<super::Sensory>, pub raw: u64, pub input: u64, pub episode: u64, pub life_age: u64, pub pose: u8 }
pub(super) struct Read { pub key: u64 }

impl<A: Copy + Ord> FloorObserver<A> {
    pub(super) fn general(&self) -> &General<A> { &self.0 }

    pub(super) fn owned_cut(&self) -> OwnedCut<A> { OwnedCut(self.0.installed().cut()) }
    pub(super) fn input_epoch(&self) -> u128 {
        match self { Self(g) => g.installed.cut().definition().read_binding().interface().epoch }
    }
    pub(super) fn fork(&self) -> Self {
        match self { Self(g) => Self(g.fork()) }
    }
    pub(super) fn origin(&self) -> origin::Origin<'_, A> { origin::Origin::of(self) }
    pub(super) fn input_of(&self, key: u64) -> Option<u64> {
        self.origin().input_of(key).ok()
    }
    pub(super) fn read(&self, view: View, budget: &mut Budget<'_>) -> Result<Read, Refusal<A>> {
        match self {

            Self(g) => g.read_owned(view, budget).map_err(|refusal| refusal.reason),
        }
    }
    pub(super) fn prepare(&self, view: View, action: A, budget: &mut Budget<'_>) -> Result<Prepared<A>, Refusal<A>> {
        match self {
            Self(g) => {
                let cut = g.installed.cut(); let source = cut.definition().update_binding().interface();
                if source.shape != acquired::Shape::Event { return Err(Refusal::ForeignSource); }
                let event = g.input_row(view.clone(), Some(action));
                let program = g.installed.prepare(Input::new(event.interface(), event.values()), budget).map_err(Refusal::Acquired)?;
                Ok(Prepared { program, input: event })
            }
        }
    }
    pub(super) fn commit(&mut self, prepared: Prepared<A>) -> Result<Commit<A>, CommitRefusal<A>> {
        match (self, prepared) {
            (Self(g), Prepared { program, input }) => {
                match g.installed.commit(program) {
                    Ok(receipt) => {
                        let before = receipt.before().clone();
                        let after = receipt.after().clone();
                        #[cfg(test)]
                        if let Some(events) = &mut *g.audit.lock().expect("test audit owner") {
                            events.push(AuditEvent::Commit { input: input.clone(), receipt: Arc::new(receipt) });
                        }
                        #[cfg(not(test))]
                        let _ = receipt;
                        let committed = Commit { before, after, input };
                        if let Ok(mut slot) = g.finite_analysis.lock() {
                            if let Some(owner) = slot.as_mut() {
                                owner.source_native_succeeded(&g.installed, &committed);
                            }
                        }
                        Ok(committed)
                    }
                    Err(rejected) => Err(CommitRefusal { rejected, input }),
                }
            },
        }
    }
}

#[cfg(all(test, feature = "serde"))]
pub(super) mod lifecycle_export;

pub(super) mod origin;

mod invocation;
pub(super) use invocation::{Reading, Preparing};

#[cfg(all(test, feature = "serde"))]
pub(super) use invocation::naming_export;
