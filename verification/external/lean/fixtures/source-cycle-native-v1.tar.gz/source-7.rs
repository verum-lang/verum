//! Exact finite capability of one native executable, not a world-period oracle.
//!
//! The initial orbit is executed by the same retained observer VM. An autonomy
//! proof excludes dependence of values AND definedness on external input ports.
//! Exact native-value comparison closes the actual reachable carrier; an observable transient,
//! open frontier, undefined call, or resource pause never becomes a certificate.
//! The observable quotient is checked by reading::refinement's shared kernel.
//! All guarantees retain native pure/stable semantics and lawful action Eq/Clone
//! premises. Logical work is not a wall-time or byte-memory bound.
use super::*;
use crate::program::observer::autonomy;
use crate::program::{ExecutionLimit, WorkMeter};
use crate::reading::refinement as finite;
#[cfg(test)]
mod courts;
mod equality;
mod source_transport;
pub(in crate::organism) use source_transport::FollowingBinding;

type Reading<A> = observer::Reading<Value<A>, Op, Source, Meaning>;
type Committed<A> = observer::Committed<Value<A>, Op, Source, Meaning>;
type ReadCall<A> = observer::ReadingCall<Value<A>, Op, Source, Meaning>;
type PrepareCall<A> = observer::Preparing<Value<A>, Op, Source, Meaning>;
type NativeRefusal<A> = observer::Refusal<Value<A>, DomainRefusal, ()>;
type Dependency<A> = autonomy::Checking<Value<A>, Op, Source, Meaning>;
type Autonomous<A> = autonomy::Autonomy<Value<A>, Op, Source, Meaning>;

/// Exact executable authority as a quotient premise, never semantic equality
/// inferred from equal bodies, prices, hashes, or independently created owners.
pub(in crate::organism) struct Owner<A: Copy + Ord>(Arc<Definition<A>>);
impl<A: Copy + Ord> PartialEq for Owner<A> {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.0, &other.0)
    }
}
impl<A: Copy + Ord> Eq for Owner<A> {}
type Projection<A> = finite::OwnedProjection<usize, usize, Owner<A>>;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) struct Limits {
    /// Maximum actually retained distinct native states, fixed for this search.
    pub states: usize,
    /// Logical dependency/comparison stack cells and external input slots.
    pub workspace: usize,
    /// Original per-invocation VM dispatch allowance, never raised on resume.
    pub execution: ExecutionLimit,
}
pub(in crate::organism) enum Unknown<A: Copy + Ord> {
    Dependency(autonomy::Unknown),
    Native(NativeRefusal<A>),
    ObservableTransient,
    Open { distinct_states: usize },
    Quotient(finite::Refusal),
    Commit(observer::Rejected<Value<A>, Op, Source, Meaning>),
}
pub(in crate::organism) enum Stop<A: Copy + Ord> {
    Work,
    Capacity,
    Allocation,
    Poisoned,
    Consumed,
    /// Complete exact current-state comparison found no carrier member.
    OutsideOrbit,
    NativePause(NativeRefusal<A>),
    Unknown(Arc<Unknown<A>>),
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    Dependency,
    Inputs,
    ReadStart,
    Read,
    PrepareStart,
    Prepare,
    Compare,
    Commit,
    Labels,
    Period,
    Tables,
    Relation,
    Scope,
    Quotient,
    Seal,
    Complete,
}

pub(in crate::organism) struct Checking<A: Copy + Ord> {
    definition: Arc<Definition<A>>,
    limits: Limits,
    phase: Phase,
    dependency: Dependency<A>,
    autonomy: Option<Autonomous<A>>,
    input_part: usize,
    input_values: Vec<Value<A>>,
    inputs: [Option<observer::OwnedInput<Source, Value<A>>>; 2],
    instance: Instance<A>,
    cuts: Vec<Cut<A>>,
    readings: Vec<Reading<A>>,
    transitions: Vec<Committed<A>>,
    read: Option<ReadCall<A>>,
    prepare: Option<PrepareCall<A>>,
    prepared: Option<Prepared<A>>,
    comparing: Option<equality::Comparing<A>>,
    compare_at: usize,
    closes: bool,
    closing_target: usize,
    representatives: Vec<usize>,
    labels: Vec<usize>,
    representative_at: usize,
    period: usize,
    period_row: usize,
    excluded: Vec<ExcludedShift>,
    observations: Vec<finite::Observed<usize>>,
    actions: Vec<finite::Transition>,
    seed: Vec<usize>,
    relation: Option<finite::IndexRelation>,
    evidence: Option<Arc<crate::reading::OwnedJointEvidence<usize>>>,
    scope: Option<finite::ScopeBuilding<usize, usize, Owner<A>>>,
    quotient: Option<finite::OwnedChecking<usize, usize, Owner<A>>>,
    projection: Option<Projection<A>>,
    complete: Option<Arc<CertifiedCycle<A>>>,
    poisoned: bool,
    unknown: Option<Arc<Unknown<A>>>,
    taken: bool,
}

impl<A: Copy + Ord> Checking<A> {
    pub(in crate::organism) fn new(definition: Arc<Definition<A>>, limits: Limits) -> Self {
        let dependency = definition.begin_autonomy();
        let instance = definition.instantiate();
        Self {
            definition,
            limits,
            phase: Phase::Dependency,
            dependency,
            autonomy: None,
            input_part: 0,
            input_values: Vec::new(),
            inputs: [None, None],
            instance,
            cuts: Vec::new(),
            readings: Vec::new(),
            transitions: Vec::new(),
            read: None,
            prepare: None,
            prepared: None,
            comparing: None,
            compare_at: 0,
            closes: false,
            closing_target: 0,
            representatives: Vec::new(),
            labels: Vec::new(),
            representative_at: 0,
            period: 1,
            period_row: 0,
            excluded: Vec::new(),
            observations: Vec::new(),
            actions: Vec::new(),
            seed: Vec::new(),
            relation: None,
            evidence: None,
            scope: None,
            quotient: None,
            projection: None,
            complete: None,
            poisoned: false,
            unknown: None,
            taken: false,
        }
    }
    pub(in crate::organism) fn definition(&self) -> &Arc<Definition<A>> {
        &self.definition
    }
    pub(in crate::organism) fn retained_states(&self) -> usize {
        self.cuts.len()
    }
    pub(in crate::organism) fn take(&mut self) -> Option<Arc<CertifiedCycle<A>>> {
        if self.poisoned {
            return None;
        }
        let result = self.complete.take();
        if result.is_some() {
            self.taken = true;
        }
        result
    }
    pub(in crate::organism) fn advance(
        &mut self,
        work: &mut ObserverWork,
    ) -> Result<bool, Stop<A>> {
        if self.poisoned {
            return Err(Stop::Poisoned);
        }
        if self.taken {
            return Err(Stop::Consumed);
        }
        if let Some(reason) = &self.unknown {
            return Err(Stop::Unknown(Arc::clone(reason)));
        }
        if self.complete.is_some() {
            return Ok(true);
        }
        if work.remaining == 0 {
            return Err(Stop::Work);
        }
        self.poisoned = true;
        let result = self.step(work);
        self.poisoned = false;
        result
    }
    fn unknown<T>(&mut self, reason: Unknown<A>) -> Result<T, Stop<A>> {
        let reason = Arc::new(reason);
        self.unknown = Some(Arc::clone(&reason));
        Err(Stop::Unknown(reason))
    }
    fn charge(work: &mut ObserverWork) -> Result<(), Stop<A>> {
        work.charge(1).map_err(|_| Stop::Work)
    }
    fn equality(error: equality::Stop<()>) -> Stop<A> {
        match error {
            equality::Stop::Work(()) => Stop::Work,
            equality::Stop::Capacity => Stop::Capacity,
            equality::Stop::Allocation => Stop::Allocation,
            equality::Stop::Poisoned => Stop::Poisoned,
        }
    }
    fn native<T>(&mut self, refusal: NativeRefusal<A>) -> Result<T, Stop<A>> {
        if refusal.can_resume() {
            Err(Stop::NativePause(refusal))
        } else {
            self.unknown(Unknown::Native(refusal))
        }
    }
    fn step(&mut self, work: &mut ObserverWork) -> Result<bool, Stop<A>> {
        match self.phase {
            Phase::Dependency => match self.dependency.advance(work, self.limits.workspace) {
                Ok(false) => {}
                Ok(true) => {
                    self.autonomy = self.dependency.take();
                    self.phase = Phase::Inputs;
                }
                Err(autonomy::Stop::Unknown(reason)) => {
                    return self.unknown(Unknown::Dependency(reason));
                }
                Err(autonomy::Stop::Work(())) => return Err(Stop::Work),
                Err(autonomy::Stop::Capacity) => return Err(Stop::Capacity),
                Err(autonomy::Stop::Allocation) => return Err(Stop::Allocation),
                Err(autonomy::Stop::Poisoned | autonomy::Stop::Consumed) => {
                    return Err(Stop::Poisoned);
                }
            },
            Phase::Inputs => {
                Self::charge(work)?;
                if self.input_part < 2 {
                    let binding = if self.input_part == 0 {
                        self.definition.update_binding()
                    } else {
                        self.definition.read_binding()
                    };
                    if binding.width() > self.limits.workspace {
                        return Err(Stop::Capacity);
                    }
                    if self.input_values.len() < binding.width() {
                        self.input_values
                            .try_reserve(1)
                            .map_err(|_| Stop::Allocation)?;
                        // These are hypothetical unused ports, not observations.
                        // The exact autonomy proof precedes their construction.
                        self.input_values.push(Value::Unit);
                    } else {
                        self.inputs[self.input_part] = Some(observer::OwnedInput::new(
                            binding.interface().clone(),
                            std::mem::take(&mut self.input_values),
                        ));
                        self.input_part += 1;
                    }
                } else {
                    if self.limits.states == 0 {
                        return self.unknown(Unknown::Open { distinct_states: 0 });
                    }
                    self.cuts.try_reserve(1).map_err(|_| Stop::Allocation)?;
                    self.cuts.push(self.instance.cut());
                    self.phase = Phase::ReadStart;
                }
            }
            Phase::ReadStart => {
                Self::charge(work)?;
                self.read = Some(
                    self.instance
                        .cut()
                        .begin_read(self.inputs[1].as_ref().unwrap().clone()),
                );
                self.phase = Phase::Read;
            }
            Phase::Read => {
                self.readings.try_reserve(1).map_err(|_| Stop::Allocation)?;
                let result = self
                    .read
                    .as_mut()
                    .unwrap()
                    .advance(&mut observer::Budget::new(work, self.limits.execution));
                match result {
                    Ok(Some(reading)) => {
                        self.readings.push(reading);
                        self.read = None;
                        self.phase = Phase::PrepareStart;
                    }
                    Ok(None) => {}
                    Err(refusal) => return self.native(refusal),
                }
            }
            Phase::PrepareStart => {
                Self::charge(work)?;
                self.prepare = Some(
                    self.instance
                        .cut()
                        .begin_prepare(self.inputs[0].as_ref().unwrap().clone()),
                );
                self.phase = Phase::Prepare;
            }
            Phase::Prepare => {
                let result = self
                    .prepare
                    .as_mut()
                    .unwrap()
                    .advance(&mut observer::Budget::new(work, self.limits.execution));
                match result {
                    Ok(Some(prepared)) => {
                        self.prepared = Some(prepared);
                        self.prepare = None;
                        self.compare_at = 0;
                        self.phase = Phase::Compare;
                    }
                    Ok(None) => {}
                    Err(refusal) => return self.native(refusal),
                }
            }
            Phase::Compare => {
                if let Some(comparing) = &mut self.comparing {
                    if let Some(equal) = comparing
                        .advance(work, self.limits.workspace)
                        .map_err(Self::equality)?
                    {
                        self.comparing = None;
                        if equal {
                            self.closing_target = self.compare_at;
                            self.closes = true;
                            self.phase = Phase::Commit;
                        } else {
                            self.compare_at += 1;
                        }
                    }
                } else {
                    Self::charge(work)?;
                    if self.compare_at == self.cuts.len() {
                        if self.cuts.len() == self.limits.states {
                            return self.unknown(Unknown::Open {
                                distinct_states: self.cuts.len(),
                            });
                        }
                        self.phase = Phase::Commit;
                    } else {
                        self.comparing = Some(
                            equality::Comparing::new(
                                self.prepared.as_ref().unwrap().next_state(),
                                self.cuts[self.compare_at].state(),
                            )
                            .map_err(Self::equality)?,
                        );
                    }
                }
            }
            Phase::Commit => {
                Self::charge(work)?;
                self.transitions
                    .try_reserve(1)
                    .map_err(|_| Stop::Allocation)?;
                if !self.closes {
                    self.cuts.try_reserve(1).map_err(|_| Stop::Allocation)?;
                }
                match self.instance.commit(self.prepared.take().unwrap()) {
                    Ok(committed) => self.transitions.push(committed),
                    Err(refusal) => return self.unknown(Unknown::Commit(refusal)),
                }
                if self.closes {
                    self.phase = Phase::Labels;
                } else {
                    self.cuts.push(self.instance.cut());
                    self.phase = Phase::ReadStart;
                }
            }
            Phase::Labels => {
                let row = self.labels.len();
                if let Some(comparing) = &mut self.comparing {
                    if let Some(equal) = comparing
                        .advance(work, self.limits.workspace)
                        .map_err(Self::equality)?
                    {
                        // Reserve before losing the completed exact comparison.
                        if equal {
                            self.labels.try_reserve(1).map_err(|_| Stop::Allocation)?;
                            self.labels.push(self.representative_at);
                            self.representative_at = 0;
                        } else {
                            self.representative_at += 1;
                        }
                        self.comparing = None;
                    }
                } else {
                    Self::charge(work)?;
                    if row == self.readings.len() {
                        self.phase = Phase::Period;
                    } else if self.representative_at == self.representatives.len() {
                        self.labels.try_reserve(1).map_err(|_| Stop::Allocation)?;
                        self.representatives
                            .try_reserve(1)
                            .map_err(|_| Stop::Allocation)?;
                        self.labels.push(self.representatives.len());
                        self.representatives.push(row);
                        self.representative_at = 0;
                    } else {
                        let representative = self.representatives[self.representative_at];
                        self.comparing = Some(
                            equality::Comparing::new(
                                self.readings[row].value(),
                                self.readings[representative].value(),
                            )
                            .map_err(Self::equality)?,
                        );
                    }
                }
            }
            Phase::Period => {
                Self::charge(work)?;
                let cycle = self.labels.len() - self.closing_target;
                if self.period > cycle {
                    return self.unknown(Unknown::ObservableTransient);
                }
                if cycle % self.period != 0 {
                    self.excluded.try_reserve(1).map_err(|_| Stop::Allocation)?;
                    self.excluded.push(ExcludedShift::Closure {
                        period: self.period,
                        cycle_length: cycle,
                    });
                    self.period += 1;
                    self.period_row = 0;
                } else if self.period_row == self.labels.len() {
                    self.phase = Phase::Tables;
                } else {
                    let representative = self.period_row % self.period;
                    if self.labels[self.period_row] == self.labels[representative] {
                        self.period_row += 1;
                    } else {
                        self.excluded.try_reserve(1).map_err(|_| Stop::Allocation)?;
                        self.excluded.push(ExcludedShift::Observation {
                            period: self.period,
                            row: self.period_row,
                            representative,
                        });
                        self.period += 1;
                        self.period_row = 0;
                    }
                }
            }
            Phase::Tables => {
                Self::charge(work)?;
                let row = self.seed.len();
                let n = self.cuts.len();
                if row == n {
                    self.relation = Some(finite::IndexRelation::new(n));
                    self.phase = Phase::Relation;
                } else {
                    self.observations
                        .try_reserve(1)
                        .map_err(|_| Stop::Allocation)?;
                    self.actions.try_reserve(1).map_err(|_| Stop::Allocation)?;
                    self.seed.try_reserve(1).map_err(|_| Stop::Allocation)?;
                    self.observations
                        .push(finite::Observed::Value(self.labels[row]));
                    self.actions.push(finite::Transition::To(if row + 1 == n {
                        self.closing_target
                    } else {
                        row + 1
                    }));
                    self.seed.push(row % self.period);
                }
            }
            Phase::Relation => {
                Self::charge(work)?;
                match self
                    .relation
                    .as_mut()
                    .unwrap()
                    .advance(&mut finite::Work::new(1))
                {
                    Ok(true) => {
                        self.evidence = self.relation.as_mut().unwrap().take();
                        self.phase = Phase::Scope;
                    }
                    Ok(false) => {}
                    Err(finite::Refusal::Allocation) => return Err(Stop::Allocation),
                    Err(reason) => return self.unknown(Unknown::Quotient(reason)),
                }
            }
            Phase::Scope => {
                Self::charge(work)?;
                if let Some(scope) = &mut self.scope {
                    match scope.advance(&mut finite::Work::new(1)) {
                        Ok(true) => {
                            let owner = Arc::new(scope.take().unwrap());
                            self.quotient = Some(
                                owner
                                    .begin_check(std::mem::take(&mut self.seed))
                                    .expect("exact same table length"),
                            );
                            self.phase = Phase::Quotient;
                        }
                        Ok(false) => {}
                        Err(finite::Refusal::Budget { .. }) => {}
                        Err(finite::Refusal::Allocation) => return Err(Stop::Allocation),
                        Err(reason) => return self.unknown(Unknown::Quotient(reason)),
                    }
                } else {
                    self.scope = Some(
                        finite::OwnedFiniteScope::begin(
                            Arc::clone(self.evidence.as_ref().unwrap()),
                            Owner(Arc::clone(&self.definition)),
                            vec![finite::Observation {
                                id: 0,
                                values: std::mem::take(&mut self.observations),
                            }],
                            vec![finite::PartialAction {
                                id: 0,
                                steps: std::mem::take(&mut self.actions),
                            }],
                        )
                        .expect("closed actual orbit relation"),
                    );
                }
            }
            Phase::Quotient => {
                Self::charge(work)?;
                match self
                    .quotient
                    .as_mut()
                    .unwrap()
                    .advance(&mut finite::Work::new(1))
                {
                    Ok(true) => {
                        self.projection = self.quotient.as_mut().unwrap().take();
                        self.phase = Phase::Seal;
                    }
                    Ok(false) => {}
                    Err(finite::Refusal::Budget { .. }) => {}
                    Err(finite::Refusal::Allocation) => return Err(Stop::Allocation),
                    Err(reason) => return self.unknown(Unknown::Quotient(reason)),
                }
            }
            Phase::Seal => {
                Self::charge(work)?;
                self.complete = Some(Arc::new(CertifiedCycle {
                    definition: Arc::clone(&self.definition),
                    autonomy: self.autonomy.take().unwrap(),
                    inputs: [
                        self.inputs[0].take().unwrap(),
                        self.inputs[1].take().unwrap(),
                    ],
                    cuts: std::mem::take(&mut self.cuts),
                    readings: std::mem::take(&mut self.readings),
                    transitions: std::mem::take(&mut self.transitions),
                    labels: std::mem::take(&mut self.labels),
                    excluded: std::mem::take(&mut self.excluded),
                    period: self.period,
                    closing_target: self.closing_target,
                    projection: self.projection.take().unwrap(),
                    limits: self.limits,
                }));
                self.phase = Phase::Complete;
            }
            Phase::Complete => return Err(Stop::Consumed),
        }
        Ok(self.complete.is_some())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum ExcludedShift {
    Closure {
        period: usize,
        cycle_length: usize,
    },
    Observation {
        period: usize,
        row: usize,
        representative: usize,
    },
}
/// Native executable certificate. The quotient's one action is the autonomous
/// update, NOT any habitat action. No observed world period follows from this.
pub(in crate::organism) struct CertifiedCycle<A: Copy + Ord> {
    definition: Arc<Definition<A>>,
    autonomy: Autonomous<A>,
    inputs: [observer::OwnedInput<Source, Value<A>>; 2],
    cuts: Vec<Cut<A>>,
    readings: Vec<Reading<A>>,
    transitions: Vec<Committed<A>>,
    labels: Vec<usize>,
    excluded: Vec<ExcludedShift>,
    period: usize,
    closing_target: usize,
    projection: Projection<A>,
    limits: Limits,
}
impl<A: Copy + Ord> CertifiedCycle<A> {
    pub(in crate::organism) fn definition(&self) -> &Arc<Definition<A>> {
        &self.definition
    }
    pub(in crate::organism) fn primitive_observable_period(&self) -> usize {
        self.period
    }
    pub(in crate::organism) fn autonomy(&self) -> &Autonomous<A> {
        &self.autonomy
    }
    pub(in crate::organism) fn hypothetical_inputs(
        &self,
    ) -> &[observer::OwnedInput<Source, Value<A>>; 2] {
        &self.inputs
    }
    pub(in crate::organism) fn carrier(&self) -> &[Cut<A>] {
        &self.cuts
    }
    pub(in crate::organism) fn readings(&self) -> &[Reading<A>] {
        &self.readings
    }
    pub(in crate::organism) fn transitions(&self) -> &[Committed<A>] {
        &self.transitions
    }
    pub(in crate::organism) fn observation_labels(&self) -> &[usize] {
        &self.labels
    }
    pub(in crate::organism) fn reachable_states(&self) -> usize {
        self.cuts.len()
    }
    pub(in crate::organism) fn concrete_cycle_length(&self) -> usize {
        self.cuts.len() - self.closing_target
    }
    pub(in crate::organism) fn concrete_cycle_start(&self) -> usize {
        self.closing_target
    }
    pub(in crate::organism) fn projection(&self) -> &Projection<A> {
        &self.projection
    }
    pub(in crate::organism) fn excluded_shorter_shifts(&self) -> &[ExcludedShift] {
        &self.excluded
    }
    pub(in crate::organism) fn begin_binding(
        self: &Arc<Self>,
        installed: &Installed<A>,
    ) -> Result<Binding<A>, BindingRefusal> {
        let cut = installed.cut();
        if !Arc::ptr_eq(&self.definition, cut.definition())
            || !Arc::ptr_eq(&self.definition, installed.admission().definition())
        {
            return Err(BindingRefusal::ForeignDefinition);
        }
        Ok(Binding {
            certificate: Arc::clone(self),
            cut,
            history: Arc::clone(installed.history()),
            origin_cut: installed.origin_cut(),
            at: 0,
            comparing: None,
            found: None,
            poisoned: false,
            taken: false,
        })
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum BindingRefusal {
    ForeignDefinition,
    Incomplete,
    OutsideOrbit,
    StaleInstallation,
    Consumed,
}
pub(in crate::organism) struct Binding<A: Copy + Ord> {
    certificate: Arc<CertifiedCycle<A>>,
    cut: Cut<A>,
    history: Arc<NativeHistory<A>>,
    origin_cut: usize,
    at: usize,
    comparing: Option<equality::Comparing<A>>,
    found: Option<usize>,
    poisoned: bool,
    taken: bool,
}
impl<A: Copy + Ord> Binding<A> {
    pub(in crate::organism) fn captured_revision_matches(&self, installed: &Installed<A>) -> bool {
        self.cut.same_revision(&installed.cut())
            && Arc::ptr_eq(&self.history, installed.history())
            && self.origin_cut == installed.origin_cut()
    }
    pub(in crate::organism) fn exhausted_without_member(&self) -> bool {
        !self.poisoned && self.found.is_none() && self.at == self.certificate.cuts.len()
    }
    pub(in crate::organism) fn advance(
        &mut self,
        work: &mut ObserverWork,
    ) -> Result<bool, Stop<A>> {
        if self.poisoned {
            return Err(Stop::Poisoned);
        }
        if self.taken {
            return Err(Stop::Consumed);
        }
        if self.found.is_some() {
            return Ok(true);
        }
        if self.at == self.certificate.cuts.len() {
            return Err(Stop::OutsideOrbit);
        }
        if work.remaining == 0 {
            return Err(Stop::Work);
        }
        self.poisoned = true;
        let result = (|| {
            if let Some(comparing) = &mut self.comparing {
                if let Some(equal) = comparing
                    .advance(work, self.certificate.limits.workspace)
                    .map_err(Checking::<A>::equality)?
                {
                    if equal {
                        self.found = Some(self.at);
                    } else {
                        self.at += 1;
                    }
                    self.comparing = None;
                }
            } else {
                Checking::<A>::charge(work)?;
                self.comparing = Some(
                    equality::Comparing::new(
                        self.cut.state(),
                        self.certificate.cuts[self.at].state(),
                    )
                    .map_err(Checking::<A>::equality)?,
                );
            }
            if self.found.is_none() && self.at == self.certificate.cuts.len() {
                Err(Stop::OutsideOrbit)
            } else {
                Ok(self.found.is_some())
            }
        })();
        self.poisoned = false;
        result
    }
    pub(in crate::organism) fn take(
        &mut self,
        installed: &Installed<A>,
    ) -> Result<BoundCycle<A>, BindingRefusal> {
        if self.taken {
            return Err(BindingRefusal::Consumed);
        }
        if self.poisoned {
            return Err(BindingRefusal::StaleInstallation);
        }
        if !self.cut.same_revision(&installed.cut())
            || !Arc::ptr_eq(&self.history, installed.history())
            || self.origin_cut != installed.origin_cut()
        {
            return Err(BindingRefusal::StaleInstallation);
        }
        let state = self.found.ok_or(if self.at < self.certificate.cuts.len() {
            BindingRefusal::Incomplete
        } else {
            BindingRefusal::OutsideOrbit
        })?;
        self.taken = true;
        Ok(BoundCycle {
            certificate: Arc::clone(&self.certificate),
            cut: self.cut.clone(),
            history: Arc::clone(&self.history),
            origin_cut: self.origin_cut,
            state,
        })
    }
}
/// Ties the executable certificate to the precise current installed native
/// revision and immutable replay history. Only an actual successful autonomous
/// U receipt may transport this membership. An unrelated revision needs a new
/// paid exact comparison against the certified carrier.
pub(in crate::organism) struct BoundCycle<A: Copy + Ord> {
    certificate: Arc<CertifiedCycle<A>>,
    cut: Cut<A>,
    history: Arc<NativeHistory<A>>,
    origin_cut: usize,
    state: usize,
}
impl<A: Copy + Ord> BoundCycle<A> {
    pub(in crate::organism) fn applies_to(&self, installed: &Installed<A>) -> bool {
        self.cut.same_revision(&installed.cut())
            && Arc::ptr_eq(&self.history, installed.history())
            && self.origin_cut == installed.origin_cut()
    }
    pub(in crate::organism) fn certificate(&self) -> &Arc<CertifiedCycle<A>> {
        &self.certificate
    }
    pub(in crate::organism) fn state_index(&self) -> usize {
        self.state
    }

    /// Transport a checked carrier membership across the actual successful U.
    /// Autonomy owns the same Definition and excludes external dependence of
    /// values AND definedness. Under the existing pure/stable semantics premise,
    /// equal before-states therefore have the certified successor. This is not
    /// equality inferred from a finite data sample, and it grants no clock edge.
    pub(in crate::organism) fn after_commit(
        &self, receipt: &crate::organism::observer_runtime::Commit<A>, installed: &Installed<A>,
    ) -> Option<Self> {
        if !self.cut.same_revision(receipt.before())
            || !receipt.after().same_revision(&installed.cut())
            || !Arc::ptr_eq(&self.history, installed.history())
            || self.origin_cut != installed.origin_cut()
            || !self.certificate.autonomy.applies_to(receipt.after().definition())
        { return None; }
        let state = if self.state + 1 == self.certificate.cuts.len() {
            self.certificate.closing_target
        } else { self.state + 1 };
        Some(Self { certificate: Arc::clone(&self.certificate), cut: receipt.after().clone(),
            history: Arc::clone(&self.history), origin_cut: self.origin_cut, state })
    }
}

#[cfg(all(test, feature = "serde"))]
impl CertifiedCycle<u8> {
    pub(in crate::organism) fn export_limits(&self) -> Limits { self.limits }
}
#[cfg(all(test, feature = "serde"))]
impl BoundCycle<u8> {
    pub(in crate::organism) fn export_cut(&self) -> &Cut<u8> { &self.cut }
}
