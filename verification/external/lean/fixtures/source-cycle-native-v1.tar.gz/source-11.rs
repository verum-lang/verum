//! A paid executable cycle anchored to an actual installed physical source.
//! This is the native read component, not the lower-input naming namespace and
//! not a law of the habitat. Every actual U/read still runs with its own limits.
use super::*;
use super::super::causal_coordinates::{physical_time, SampleId};

/// Read-only projection of the current source capability. It cannot construct
/// an internal binding or supply an action receipt. Re-query after a dispatch.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ObserverSourceCycleReceipt {
    pub floor: FloorIdentity,
    pub primitive_observable_period: usize,
    pub phase: usize,
    pub anchor_episode: u64,
    pub anchor_age: u64,
    pub anchor_phase: usize,
    pub episode: u64,
    pub life_age: u64,
}

pub(super) struct SourceCycle<A: Copy + Ord> {
    bound: finite::BoundCycle<A>,
    anchor: physical_time::Point,
    anchor_phase: usize,
    point: physical_time::Point,
    pending_sample: Option<SampleId>,
}
impl<A: Copy + Ord> SourceCycle<A> {
    // This private constructor consumes an actual checked current Bound.
    // Retaining the anchor's old State payload is unnecessary: its phase is
    // frozen here and all later transports preserve this certificate/Definition.
    fn new(bound: finite::BoundCycle<A>, point: physical_time::Point) -> Self {
        let anchor_phase = bound.certificate().projection().codes()[bound.state_index()];
        Self { bound, anchor: point.clone(), anchor_phase, point, pending_sample: None }
    }
    fn current(&self, installed: &observer_acquired::Installed<A>, point: &physical_time::Point) -> bool {
        self.pending_sample.is_none() && self.bound.applies_to(installed) && &self.point == point
    }
    fn receipt(&self, floor: FloorIdentity) -> ObserverSourceCycleReceipt {
        let time = self.point.metadata();
        let anchor = self.anchor.metadata();
        let certificate = self.bound.certificate();
        ObserverSourceCycleReceipt { floor,
            primitive_observable_period: certificate.primitive_observable_period(),
            phase: certificate.projection().codes()[self.bound.state_index()],
            anchor_episode: anchor.episode, anchor_age: anchor.life_age, anchor_phase: self.anchor_phase,
            episode: time.episode, life_age: time.life_age }
    }
    fn native(mut self, installed: &observer_acquired::Installed<A>,
        receipt: &observer_runtime::Commit<A>, cut: &causal_coordinates::Cut<A>) -> Option<Self> {
        if self.pending_sample.is_some() || cut.physical_point() != Some(&self.point)
            || !matches_input(receipt, cut) { return None; }
        self.bound = self.bound.after_commit(receipt, installed)?;
        self.pending_sample = Some(cut.id());
        Some(self)
    }
    fn physical(mut self, installed: &observer_acquired::Installed<A>, applied: &physical_time::Applied) -> Option<Self> {
        let edge = applied.edge();
        // TerminalReset invalidates even though native U already committed.
        // A later explicit paid request may establish a new episode anchor.
        let next = applied.tick_successor()?;
        if self.pending_sample.is_none() || self.pending_sample != edge.sample()
            || &self.point != edge.point() || !self.bound.applies_to(installed) { return None; }
        self.point = next;
        self.pending_sample = None;
        Some(self)
    }
}
/// Validate the actual evaluator input against the original owned dispatch cut.
/// A bare equal age, sample number or successful update is insufficient.
fn matches_input<A: Copy + Ord>(receipt: &observer_runtime::Commit<A>, cut: &causal_coordinates::Cut<A>) -> bool {
    let source = receipt.before().definition().update_binding().interface();
    if source != receipt.input().interface() || source.shape != observer_acquired::Shape::Event
        || cut.raw_space() != source.raw_space
        || source.owner.is_some_and(|owner| owner != cut.id().lineage) { return false; }
    let [observer_acquired::Value::Event(event)] = receipt.input().values() else { return false; };
    event.epoch == source.epoch && event.raw_space == source.raw_space && event.owner == source.owner
        && event.raw == cut.event().raw_state && event.action == cut.event().action
        && cut.input(source.epoch).is_ok_and(|input| input == event.input)
        && event.episode == cut.time().episode && event.life_age == cut.time().life_age
        && event.pose == cut.pose() && event.sensory.as_ref() == cut.sensory()
}
impl<A: Copy + Ord> Analysis<A> {
    pub(super) fn source_current(&self, installed: &observer_acquired::Installed<A>, point: &physical_time::Point) -> bool {
        self.source_cycle.as_ref().is_some_and(|source| source.current(installed, point))
    }
    pub(super) fn source_receipt(&self, installed: &observer_acquired::Installed<A>, point: &physical_time::Point,
        floor: FloorIdentity) -> Option<ObserverSourceCycleReceipt> {
        self.source_cycle.as_ref().filter(|s| s.current(installed, point)).map(|s| s.receipt(floor))
    }
    pub(super) fn advance_source(&mut self, installed: &observer_acquired::Installed<A>, point: &physical_time::Point,
        work: &mut ObserverWork) {
        if self.source_current(installed, point) || self.refusal.is_some() { return; }
        self.advance_certificate(work);
        if self.certificate.is_none() || self.refusal.is_some() { return; }
        if self.source_binding.is_none() {
            if work.charge(1).is_err() { return; }
            self.source_binding = Some(self.certificate.as_ref().unwrap()
                .begin_following_binding(installed).expect("same published Definition"));
        }
        while work.remaining > 0 {
            let binding = self.source_binding.as_mut().unwrap();
            if !binding.current(installed) { return; }
            match binding.advance(work) {
                Ok(true) => {
                    // A completed comparison may wait for its paid seal while
                    // actual commits continue to transport the original index.
                    if work.charge(1).is_err() { return; }
                    let bound = binding.take(installed).expect("continuous actual native commit chain");
                    self.source_binding = None;
                    self.pause = None;
                    self.source_cycle = Some(SourceCycle::new(bound, point.clone()));
                    return;
                }
                Ok(false) => {}
                Err(reason) => { self.stopped(reason); return; }
            }
        }
    }
    /// Every genuine runtime commit reaches this hook, including terminal U.
    /// Restart has no native U and therefore does not call it. The separate
    /// physical pairing below is still required to advance an anchored cycle.
    pub(in crate::organism) fn source_native_succeeded(&mut self, installed: &observer_acquired::Installed<A>,
        receipt: &observer_runtime::Commit<A>) {
        if let Some(binding) = &mut self.source_binding { binding.committed(receipt, installed); }
    }
    pub(in crate::organism) fn source_native_commit(&mut self, installed: &observer_acquired::Installed<A>,
        receipt: &observer_runtime::Commit<A>, cut: &causal_coordinates::Cut<A>) {
        self.source_cycle = self.source_cycle.take().and_then(|s| s.native(installed, receipt, cut));
    }
    pub(in crate::organism) fn source_physical_commit(&mut self, installed: &observer_acquired::Installed<A>,
        applied: &physical_time::Applied) {
        self.source_cycle = self.source_cycle.take().and_then(|s| s.physical(installed, applied));
    }
    pub(in crate::organism) fn invalidate_source(&mut self) { self.source_cycle = None; }
}
impl<A: Copy + Ord> observer_runtime::FloorObserver<A> {
    pub(in crate::organism) fn source_native_commit(&self, receipt: &observer_runtime::Commit<A>, cut: &causal_coordinates::Cut<A>) {
        // Poisoned analysis never grants a capability or changes native runtime.
        if let Ok(mut slot) = self.general().finite_analysis.lock() {
            if let Some(owner) = slot.as_mut() { owner.source_native_commit(self.general().installed(), receipt, cut); }
        }
    }
    pub(in crate::organism) fn source_physical_commit(&self, applied: &physical_time::Applied) {
        if let Ok(mut slot) = self.general().finite_analysis.lock() {
            if let Some(owner) = slot.as_mut() { owner.source_physical_commit(self.general().installed(), applied); }
        }
    }
    pub(in crate::organism) fn invalidate_source(&self) {
        if let Ok(mut slot) = self.general().finite_analysis.lock() {
            if let Some(owner) = slot.as_mut() { owner.invalidate_source(); }
        }
    }
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> Organism<A> {
    /// Explicit paid certification, exact live membership and physical anchoring.
    /// Uses the same retained certificate and original limits as finite analysis;
    /// it creates no statistical look and changes no automatic service grant.
    pub fn advance_observer_source_cycle(&mut self, floor: FloorIdentity,
        limits: ObserverFiniteLimits, quoted_work: usize) -> Result<ObserverFiniteService, ObserverFiniteRefusal> {
        self.finite_service(floor, Command::Source(limits), quoted_work)
    }
    /// Inspect only. A pending physical/native half, terminal, new run, foreign
    /// floor, or retired installation cannot supply a current source capability.
    pub fn observer_source_cycle(&self, floor: FloorIdentity)
        -> Result<Option<ObserverSourceCycleReceipt>, ObserverFiniteRefusal> {
        let ex = self.exhaust.as_ref().ok_or(ObserverFiniteRefusal::Unarmed)?;
        if ex.observer_history.lineage() != floor.lineage { return Err(ObserverFiniteRefusal::NotPublished); }
        let published = ex.floors.iter().find(|f| f.input_epoch == floor.input_epoch
            && f.observer.general().output_epoch() == Some(floor.output_epoch))
            .ok_or(ObserverFiniteRefusal::NotPublished)?;
        let Ok(point) = self.source_time.point() else { return Ok(None); };
        let general = published.observer.general();
        let slot = general.finite_analysis.lock().map_err(|_| ObserverFiniteRefusal::Poisoned)?;
        Ok(slot.as_ref().and_then(|a| a.source_receipt(general.installed(), &point, floor)))
    }
}

#[cfg(all(test, feature = "serde"))]
pub(super) struct ExportView<'a> {
    pub bound: &'a finite::BoundCycle<u8>, pub anchor: &'a physical_time::Point,
    pub anchor_phase: usize, pub point: &'a physical_time::Point, pub pending_sample: Option<SampleId>,
}
#[cfg(all(test, feature = "serde"))]
impl SourceCycle<u8> {
    pub(super) fn export_view(&self) -> ExportView<'_> {
        ExportView { bound: &self.bound, anchor: &self.anchor, anchor_phase: self.anchor_phase,
            point: &self.point, pending_sample: self.pending_sample }
    }
}
