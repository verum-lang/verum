from pathlib import Path
import hashlib,json,os,re,shutil,signal,subprocess,sys,time,traceback
repo=Path('/Users/taaliman/projects/oldman/synarcai/omega')
sys.path.insert(0,str(repo/'scripts/measure'));sys.dont_write_bytecode=True
from validation_resources import ResourceContract, darwin_memory_snapshot
from build_engine_receipt import fingerprint
import native_test_inputs
out=Path('/private/tmp/synarc-recovery-runtime-v69')/sys.argv[1]
out.mkdir(parents=True,exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('SYNARC_','OMVEK_','G1_','RUST_TEST_'))}
env.update(SYNARC_ROUTING_INCUMBENT_EXPORT=str(out/'routing-incumbent-v1.json'),SYNARC_PERIODIC_ROUTING_EXPORT=str(out/'periodic-routing'),SYNARC_PRIORITY_LIFECYCLE_EXPORT=str(out/'priority-lifecycle-v3.json'),SYNARC_PREFIX_HISTORY_EDGE_EXPORT=str(out/'prefix-history-edge-v2.json'),SYNARC_PREFIX_HISTORY_EXPORT=str(out/'prefix-history.json'),SLOT_PRIO='1',PYTHONDONTWRITEBYTECODE='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_DEV_DEBUG_ASSERTIONS='true',CARGO_PROFILE_DEV_OVERFLOW_CHECKS='true',CARGO_PROFILE_COURT_INCREMENTAL='false',SYNARC_COHORT_EXPORT=str(out/'cohort-export'),SYNARC_SOURCE_PROFILE_EXPORT=str(out/'profile-export'),SYNARC_DECLARATION_EXPORT=str(out/'declaration-export'),SYNARC_MONOID_TRACE='1',SYNARC_TRANSFER_TRACE='1',SYNARC_FOREIGN_PRICE_EXPORT=str(out/'foreign-census.json'),SYNARC_NUMERAL_EXPORT=str(out/'numeral-export'),SYNARC_RUN_TO_BLOCK_EXPORT=str(out/'service-export'),SYNARC_CUMULATIVE_LIFECYCLE_EXPORT=str(out/'cumulative-lifecycle.json'),SYNARC_DYADIC_LIFECYCLE_EXPORT=str(out/'dyadic-lifecycle.json'),SYNARC_TRANSFER_TRACE_EVERY='128',SYNARC_JOINT_OBSERVER_EXPORT=str(out/'ordinary-joint-v3.json'))
env['SYNARC_SOURCE_CYCLE_EXPORT']=str(out/'source-cycle-export')
env['SYNARC_RATIO_FOLD_EXPORT']=str(out/'ratio-fold.json')
env['SYNARC_GOAL_MASS_EXPORT']=str(out/'goal-mass.json')
env['SYNARC_GOAL_NATIVE_EXPORT']=str(out/'native-goal')
inputs=native_test_inputs.provision(repo/'.diagnostics/2026-10-25/kan-main-contracts/empirical-inputs-v2.json',out/'inputs')
env.update(native_test_inputs.verify(inputs))
env['SYNARC_MEMORY_LIFECYCLE_EXPORT']=str(out/'memory-lifecycle.json')
env['SYNARC_PROMOTION_EXACT_TRACE']='1'
paths=['rust/Cargo.toml','rust/Cargo.lock','rust/crates']
def snapshot():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--',*paths],cwd=repo,text=True).splitlines()
 return {n:fingerprint(repo/n) for n in sorted(set(names)) if (repo/n).is_file()}
source=snapshot()
record={'resource_contract':fingerprint(repo/'scripts/measure/validation_resources.py'),'status':'registered','scope':'Actual paid source-cycle binding and continuous native membership transport; original Monoid, runtime/clock/automatic production controls. No modified behavior assertions or world-period claim.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source':source,'inputs':inputs,'script':fingerprint(__file__),'stages':[],'build_environment':{k:env[k] for k in ('CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_DEV_OPT_LEVEL','CARGO_PROFILE_DEV_DEBUG_ASSERTIONS','CARGO_PROFILE_DEV_OVERFLOW_CHECKS','SYNARC_SOURCE_PROFILE_EXPORT','SYNARC_DECLARATION_EXPORT')}}
subprocess.run(['git','diff','--binary','HEAD','--',*paths],cwd=repo,stdout=(out/'source.patch').open('wb'),check=True)
tracked=set(subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines())
for n in source:
 if n not in tracked:
  target=out/'untracked'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,target)
def save():
 temp=out/'receipt.tmp';temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(out/'receipt.json')
def resource(pids):
 pids=list(pids)
 raw=subprocess.check_output(['vm_stat'],text=True);page=int(re.search(r'page size of (\d+)',raw)[1]);v={m[1]:int(m[2]) for m in re.finditer(r'^([^:\n]+):\s+(\d+)\.',raw,re.M)}
 rows=[tuple(map(int,row.split())) for row in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()]
 owned=set(pids)|{os.getpid()}
 while True:
  more={p for p,parent,rss in rows if parent in owned}
  if more<=owned:break
  owned|=more
 r=dict(at=time.time(),**darwin_memory_snapshot(raw),legacy_queue_estimate_gib=max(0,(v['Pages free']+v['Pages speculative']+v['Pages inactive']/4-v['Pages occupied by compressor']/2)*page/2**30),disk_free_gib=shutil.disk_usage(out).free/2**30,pressure_dispatch_level=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True)),owned_rss_bytes=sum(rss*1024 for p,parent,rss in rows if p in owned))
 with (out/'resources.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 return r
contract=ResourceContract(25_000_000_000);initial=resource([])
def owned_group_members(pgid):
    rows = subprocess.check_output(
        ['ps', '-axo', 'pid=,ppid=,pgid=,stat=,command='],
        text=True, timeout=2,
    ).splitlines()
    members = []
    for line in rows:
        fields = line.split(None, 4)
        if len(fields) != 5:
            raise RuntimeError('invalid process observation')
        pid, ppid, group = map(int, fields[:3])
        if group == pgid:
            members.append(dict(pid=pid, ppid=ppid, pgid=group,
                                state=fields[3], command=fields[4]))
    return members


def quiesce_owned_group(process, persist, term_seconds=3, kill_seconds=5):
    """Reap the direct child and verify no live member of its owned PGID remains.

    persist receives each observation before a signal and the final result.
    Zombies are recorded but cannot perform effects or hold executable memory.
    The caller must not release its slot when complete is false. Unexpected
    children after a normally exited parent invalidate successful completion.
    """
    pgid = process.pid
    if pgid == os.getpgrp():
        raise RuntimeError('refusing controller process group')
    result = dict(pgid=pgid, started_at=time.time(), observations=[], signals=[],
                  complete=False, parent_returncode=process.poll())
    try:
        def observe():
            process.poll()  # Reap the direct child if it has exited.
            members = owned_group_members(pgid)
            result['observations'].append(dict(at=time.time(), members=members))
            result['parent_returncode'] = process.returncode
            result['survivors'] = [row for row in members if not row['state'].startswith('Z')]
            result['zombies'] = [row for row in members if row['state'].startswith('Z')]
            persist(result)
            return result['survivors']

        live = observe()
        result['unexpected_children_after_parent_exit'] = process.returncode is not None and bool(live)
        for sig, grace in [(signal.SIGTERM, term_seconds), (signal.SIGKILL, kill_seconds)]:
            if not live:
                break
            result['signals'].append(dict(signal=sig.name, at=time.time()))
            persist(result)
            try:
                os.killpg(pgid, sig)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + grace
            while True:
                live = observe()
                if not live or time.monotonic() >= deadline:
                    break
                time.sleep(min(0.1, max(0, deadline - time.monotonic())))
        # Re-observe after the last grace interval, including after an already
        # exited parent. A live child's parent may now be init; PGID still owns it.
        live = observe()
        result['complete'] = not live and process.returncode is not None
        result['finished_at'] = time.time()
    except BaseException as error:
        result.update(error=repr(error), complete=False, finished_at=time.time())
    persist(result)
    return result


def execute(name,cmd,pool,timeout,cwd,extra=None):
 admission_deadline=time.time()+600
 while True:
  r=resource([]);why=contract.failure(r,initial['swapouts'],admission=True)
  if why is not None:
   if why!='admission_reserve':raise RuntimeError(why)
   if time.time()>admission_deadline:raise TimeoutError('admission '+name)
   record.update(status='waiting_admission',latest_resource=r);save();time.sleep(5);continue
  slot=subprocess.check_output(['zsh','/tmp/heavy_slot.sh','acquire','recovery-v69-'+name,pool],env=env,text=True).strip()
  try:
   assert (snapshot()==source if name.startswith('build') else fingerprint(binary)==record['binary']),'frozen source/binary changed before '+name
   r=resource([]);why=contract.failure(r,initial['swapouts'],admission=True)
   if why is None:break
   if why!='admission_reserve':raise RuntimeError(why)
  except BaseException:
   subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True)
   raise
  subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True)
  record.update(status='waiting_admission',latest_resource=r);save()
  if time.time()>admission_deadline:raise TimeoutError('admission '+name)
  time.sleep(2)
 p=None;s={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'status':'running','started_at':time.time(),'timeout_seconds':timeout,'slot':slot};record['stages'].append(s);record['status']='running';save();print('RUN '+name,flush=True)
 try:
  with (out/(name+'.log')).open('xb') as log:
   p=subprocess.Popen(cmd,cwd=cwd,env=env|dict(extra or {}),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);s['pid']=p.pid;save()
   while p.poll() is None:
    r=resource([p.pid]);s['latest_resource']=r;s['peak_owned_rss_bytes']=max(s.get('peak_owned_rss_bytes',0),r['owned_rss_bytes']);save()
    failure=contract.failure(r,initial['swapouts'],admission=False)
    if failure:raise RuntimeError(failure)
    if time.time()-s['started_at']>timeout:raise TimeoutError(name)
    time.sleep(2)
  assert (snapshot()==source if name.startswith('build') else fingerprint(binary)==record['binary']),'frozen source/binary changed during '+name
  s.update(returncode=p.returncode,status='passed' if p.returncode==0 else 'failed')
  text=(out/(name+'.log')).read_text(errors='replace')
  native=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
  if native:
   reports=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
   s['native_reports']=[dict(zip(('passed','failed','ignored','measured','filtered'),map(int,row))) for row in reports]
   s['counts']={k:sum(r[k] for r in s['native_reports']) for k in ('passed','failed','ignored','measured','filtered')}
  return p.returncode
 finally:
  s.update(status='interrupted',error='stage did not return') if s['status']=='running' else None
  def persist_cleanup(value):
   s['process_group_cleanup']=value;save()
  cleanup = quiesce_owned_group(p,persist_cleanup) if p is not None else {'complete':True,'not_launched':True}
  s['process_group_cleanup']=cleanup
  s['seconds']=time.time()-s['started_at'];s['log']=fingerprint(out/(name+'.log')) if (out/(name+'.log')).exists() else None
  if not cleanup['complete']:
   s.update(status='cleanup_unresolved',slot_released=False,error='owned process group cleanup unconfirmed; slot retained');save()
   raise RuntimeError('owned group cleanup unresolved: '+name)
  subprocess.run(['zsh','/tmp/heavy_slot.sh','release',slot,pool],env=env,check=True,capture_output=True);s['slot_released']=True
  if cleanup.get('unexpected_children_after_parent_exit'):
   s.update(status='failed',error='live owned descendants remained after direct parent exit');save()
   raise RuntimeError('unexpected live descendants: '+name)
  save();print(json.dumps({k:s.get(k) for k in ('name','status','returncode','seconds','counts')}),flush=True)

try:
 from native_test_selection import parse_inventory, verify_selection, exact_command
 record['scope']='Actual paid source-cycle binding and continuous native membership transport; original Monoid, runtime/clock/automatic production controls. No modified behavior assertions or world-period claim.'
 target_dir=repo/'.diagnostics/2026-10-09/depth-contract/target'
 common=['--manifest-path',str(repo/'rust/Cargo.toml'),'--locked','--offline','--target-dir',str(target_dir),'--jobs','4','--profile','dev']
 assert execute('build-workspace-check',['cargo','check',*common,'--workspace','--all-targets','--message-format=json'],'build',1800,repo)==0
 assert execute('build-kan',['cargo','test',*common,'-p','synarc-kan','--lib','--no-run','--message-format=json'],'build',1200,repo)==0
 artifacts=[]
 for line in (out/'build-kan.log').read_text().splitlines():
  if line.startswith('{'):
   row=json.loads(line)
   if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='synarc_kan' and row.get('profile',{}).get('test') and row.get('executable'):artifacts.append(row['executable'])
 assert len(set(artifacts))==1,artifacts
 binary=out/'synarc_kan-courts';shutil.copy2(artifacts[0],binary)
 record['binary']=fingerprint(binary);record['frozen_binaries']={str(binary):fingerprint(binary)};save()
 listing=subprocess.check_output([str(binary),'--list','--format=terse'],text=True)
 (out/'test-list.txt').write_text(listing);inventory=parse_inventory(listing)
 record['test_inventory']=list(inventory)
 scopes=[('native-finite-service','organism::observer_finite::'),
 ('native-finite-realization','organism::observer_acquired::finite_realization::'),
 ('native-physical-clock','organism::causal_coordinates::physical_time::'),
 ('native-observer-runtime','organism::observer_runtime::'),
 ('native-observer-domain','organism::observer_domain::'),
 ('native-observer-execution','organism::observer_execution_courts::'),
 ('native-automatic','organism::observer_acceptance::automatic::'),
 ('monoid-original','monoid::courts::the_bought_rung_divides_the_worlds_clock')]
 record['declared_scopes']=scopes
 record['selected_tests']={label:[n for n in inventory if n.startswith(selector)] for label,selector in scopes}
 assert all(record['selected_tests'].values())
 flat=sum(record['selected_tests'].values(),[]);assert len(flat)==len(set(flat));save()
 for label,_ in scopes:
  selected=tuple(record['selected_tests'][label]);verify_selection(binary,selected,repo/'rust/crates/synarc-kan')
  execute(label,[*exact_command(binary,selected),'--nocapture','--test-threads=1'],'heavy',1800,repo/'rust/crates/synarc-kan')
  counts=record['stages'][-1].get('counts',{});assert counts.get('passed',0)+counts.get('failed',0)==len(selected),label+' incomplete verdict'
 assert execute('build-arena-courts',['cargo','test',*common,'-p','synarc-arena','--bin','arena','--no-run','--message-format=json'],'build',1200,repo)==0
 arena_artifacts=[]
 for line in (out/'build-arena-courts.log').read_text().splitlines():
  if line.startswith('{'):
   row=json.loads(line)
   if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='arena' and row.get('profile',{}).get('test') and row.get('executable'):arena_artifacts.append(row['executable'])
 assert len(set(arena_artifacts))==1,arena_artifacts
 binary=out/'arena-courts';shutil.copy2(arena_artifacts[0],binary);record['binary']=fingerprint(binary);record['frozen_binaries'][str(binary)]=fingerprint(binary);save()
 names=parse_inventory(subprocess.check_output([str(binary),'--list','--format=terse'],text=True));verify_selection(binary,names,repo/'rust/crates/synarc-arena');record['selected_tests']['native-arena']=names;save()
 assert execute('native-arena',[*exact_command(binary,names),'--nocapture','--test-threads=1'],'heavy',1200,repo/'rust/crates/synarc-arena')==0
 assert record['stages'][-1]['counts']['passed']==len(names) and record['stages'][-1]['counts']['ignored']==0
 assert execute('build-specification',['python3','/private/tmp/check_specs_v181.py','spec-v191'],'build',600,repo)==0
 native_test_inputs.verify(inputs)
 record['status']='passed' if all(s.get('status')=='passed' for s in record['stages']) else 'failed';save()
except BaseException as e:
 record.update(status='failed',error=repr(e));save();raise
