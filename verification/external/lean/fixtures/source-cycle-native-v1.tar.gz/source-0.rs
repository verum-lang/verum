//! Shared test-only native Cut encoding. Refactored from reservation courts;
//! these values are observations, never constructors of source authority.
use super::*;
use crate::organism::Sensory;
use serde_json::{json, Value as Json};
pub(in crate::organism) fn sensory(v: &Sensory) -> Json { json!({"schema":v.schema().as_ref(),"body":v.body().as_ref()}) }
pub(in crate::organism) fn cut<A: Copy + serde::Serialize>(v: &Cut<A>) -> Json {
    json!({"lineage":lifecycle_lineage(&v.id.lineage),"ordinal":v.id.ordinal,
        "time":{"episode":v.time.episode,"life_age":v.time.life_age},
        "raw":v.event.raw_state,"state":v.event.situation,"action":v.event.action,
        "epoch":v.epoch.to_string(),"raw_space":v.raw_space.to_string(),"pose":v.pose,
        "sensory":v.sensory.as_ref().map(sensory),"history_end":v.history_before.end,
        "inputs":v.inputs.iter().map(|(e,s)|json!([e.to_string(),s])).collect::<Vec<_>>()})
}
