//! Opt-in paid post-install semantic analysis for the existing glass receipt.
//! It creates no statistical look, changes no published program and requests no
//! background budget. The exact existing discovery ledger settles each explicit
//! quote; reading a diagnostic never performs VM or certification work.
use super::observer_acquired::finite_realization as finite;
use super::*;
use crate::program::{ExecutionLimit, WorkMeter};
use num_bigint::BigUint;
use std::sync::Arc;
#[cfg(test)]
mod courts;
mod source_cycle;
pub use source_cycle::ObserverSourceCycleReceipt;

/// Original semantic-search limits. A pending owner cannot be redeclared with
/// larger limits through a resume request.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ObserverFiniteLimits {
    /// Maximum retained concrete states in the hypothetical native carrier.
    pub states: usize,
    /// Dependency/comparison logical cells and input-port slots, not bytes.
    pub workspace: usize,
    /// Original native invocation allowance; no grant can raise it.
    pub execution: ExecutionLimit,
}
impl ObserverFiniteLimits {
    fn native(self) -> finite::Limits {
        finite::Limits {
            states: self.states,
            workspace: self.workspace,
            execution: self.execution,
        }
    }
}
/// Why a retained semantic-analysis owner currently needs another grant.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverFinitePause {
    /// Original work slice was exhausted.
    Work,
    /// The declared logical workspace bound was reached.
    Capacity,
    /// Storage allocation refused; pending owner remains retained.
    Allocation,
    /// Native VM owns a resumable resource refusal.
    NativeResource,
}
/// Exact category of a retained unknown result; none means a world law is false.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverFiniteUnknown {
    /// Value or definedness may depend on external ports.
    ExternalDependency,
    /// Structural syntax/input dependency proof was unavailable.
    StructuralDependency,
    /// Native execution was undefined in the reachable carrier.
    NativeUndefined,
    /// Original native resource bound cannot be enlarged on resume.
    NativeResource,
    /// Native execution accounting is incomplete after poison.
    NativePoisoned,
    /// A consumed native invocation cannot supply a new execution.
    NativeConsumed,
    /// Carrier did not close within its original state limit.
    OpenCarrier,
    /// No pure observable cycle removes the concrete transient.
    ObservableTransient,
    /// Exact finite quotient checker refused its proposed binding.
    Quotient,
    /// Actual native commit refused; no transition is invented.
    Commit,
    /// A generic callback unwound or owner could not be resumed lawfully.
    Poisoned,
}
/// Membership of the current installed revision in the certified carrier.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverFiniteBinding {
    /// No membership call has been started yet.
    Unstarted,
    /// Exact native-value membership comparison is retained.
    Pending,
    /// The currently published revision is the exact checked installed owner.
    Current { native_state: usize },
    /// Installation advanced after this binding started. Explicit rebind only.
    Stale,
    /// Complete comparison found no represented state.
    OutsideOrbit,
}
/// Read-only scalar projection of the actual retained semantic owner.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ObserverFiniteStatus {
    /// No paid explicit semantic request has started this owner.
    NotRequested,
    /// Certification remains incomplete.
    Pending {
        retained_states: usize,
        pause: Option<ObserverFinitePause>,
    },
    /// The exact retained owner yielded no capability.
    Unknown(ObserverFiniteUnknown),
    /// Native executable property only; not the physical world's clock.
    ExecutableCycle {
        reachable_states: usize,
        concrete_cycle_start: usize,
        concrete_cycle_length: usize,
        primitive_observable_period: usize,
        binding: ObserverFiniteBinding,
    },
}
/// Scalar glass snapshot; no copied VM reports, histories, program trees or data.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ObserverFiniteReceipt {
    /// Frozen limits, absent until the first nonzero paid request.
    pub limits: Option<ObserverFiniteLimits>,
    /// What this exact owner has checked so far.
    pub status: ObserverFiniteStatus,
    /// Actual metered units spent by this owner, including binding revisions.
    pub spent_units: BigUint,
    /// Explicit stale-binding restarts; no orbit calculation is repeated.
    pub rebindings: BigUint,
}
/// Exact settled result of one user/agent-requested semantic service call.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ObserverFiniteService {
    /// Exact currently published floor selected by the caller.
    pub floor: FloorIdentity,
    /// Original logical-unit quote before the organism's budget policy.
    pub quoted_units: usize,
    /// Actual units reserved by the existing ledger.
    pub allowed_units: usize,
    /// Actual decrement, counted once by that ledger.
    pub spent_units: usize,
    /// Unused rights returned to the same ledger.
    pub returned_units: usize,
    /// Shared executable-certificate diagnostics and the STRICT finite-binding
    /// protocol. Its binding can remain Unstarted/Stale while Source service
    /// separately compares/transports a captured native Cut; it does not report
    /// the Source cursor's progress or authority.
    pub analysis: ObserverFiniteReceipt,
    /// Current Source-protocol authority, populated only after its paid exact
    /// comparison, native-chain transport and physical anchor have completed.
    /// None grants no capability; it does not alone distinguish pending/refused.
    pub source_cycle: Option<ObserverSourceCycleReceipt>,
}
/// Refusal never selects another floor or resets the original analysis owner.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObserverFiniteRefusal {
    /// No pending semantic work exists. Read its receipt without requesting
    /// another lease; a stale binding requires the explicit rebind operation.
    NoWork,
    /// No observer work ledger is armed.
    Unarmed,
    /// No currently published floor has the requested full native identity.
    NotPublished,
    /// An existing owner has different original limits.
    DifferentLimits,
    /// Explicit rebind needs a completed executable certificate.
    NoCertificate,
    /// A fresh/current binding cannot be reset as if it were stale.
    NotStale,
    /// Analysis or native work ledger was poisoned.
    Poisoned,
    /// Budget fraction was not a valid exact entitlement.
    BudgetPolicy,
    /// The physical source has an unresolved dispatch/terminal or no actionable point.
    SourceBoundary,
    /// The retained native comparison lost its exact successful-commit chain.
    SourceGap,
    /// Work ledger refused a request or failed exact conservation.
    BudgetAccounting,
}
fn budget_error(reason: acquisition_budget::Refusal) -> ObserverFiniteRefusal {
    match reason {
        acquisition_budget::Refusal::Unarmed => ObserverFiniteRefusal::Unarmed,
        acquisition_budget::Refusal::Poisoned => ObserverFiniteRefusal::Poisoned,
        acquisition_budget::Refusal::InvalidFraction => ObserverFiniteRefusal::BudgetPolicy,
        _ => ObserverFiniteRefusal::BudgetAccounting,
    }
}
fn unknown<A: Copy + Ord>(reason: &finite::Unknown<A>) -> ObserverFiniteUnknown {
    match reason {
        finite::Unknown::Dependency(
            crate::program::observer::autonomy::Unknown::ExternalDependency,
        ) => ObserverFiniteUnknown::ExternalDependency,
        finite::Unknown::Dependency(_) => ObserverFiniteUnknown::StructuralDependency,
        finite::Unknown::Native(reason) => match reason.classification() {
            crate::program::observer::RefusalClass::Undefined => {
                ObserverFiniteUnknown::NativeUndefined
            }
            crate::program::observer::RefusalClass::Resource => {
                ObserverFiniteUnknown::NativeResource
            }
            crate::program::observer::RefusalClass::Poisoned => {
                ObserverFiniteUnknown::NativePoisoned
            }
            crate::program::observer::RefusalClass::AlreadyReturned => {
                ObserverFiniteUnknown::NativeConsumed
            }
        },
        finite::Unknown::Open { .. } => ObserverFiniteUnknown::OpenCarrier,
        finite::Unknown::ObservableTransient => ObserverFiniteUnknown::ObservableTransient,
        finite::Unknown::Quotient(_) => ObserverFiniteUnknown::Quotient,
        finite::Unknown::Commit(_) => ObserverFiniteUnknown::Commit,
    }
}
enum OldBinding<A: Copy + Ord> {
    Pending(finite::Binding<A>),
    Checked(finite::BoundCycle<A>),
}
pub(super) struct Analysis<A: Copy + Ord> {
    limits: ObserverFiniteLimits,
    checking: finite::Checking<A>,
    certificate: Option<Arc<finite::CertifiedCycle<A>>>,
    binding: Option<finite::Binding<A>>,
    bound: Option<finite::BoundCycle<A>>,
    last_stale: Option<OldBinding<A>>,
    refusal: Option<ObserverFiniteUnknown>,
    pause: Option<ObserverFinitePause>,
    spent: BigUint,
    rebindings: BigUint,
    source_cycle: Option<source_cycle::SourceCycle<A>>,
    source_binding: Option<finite::FollowingBinding<A>>,
}
impl<A: Copy + Ord> Analysis<A> {
    fn new(general: &observer_runtime::General<A>, limits: ObserverFiniteLimits) -> Self {
        Self {
            limits,
            checking: finite::Checking::new(
                Arc::clone(general.installed().cut().definition()),
                limits.native(),
            ),
            certificate: None,
            binding: None,
            bound: None,
            last_stale: None,
            refusal: None,
            pause: None,
            spent: 0u8.into(),
            rebindings: 0u8.into(),
            source_cycle: None,
            source_binding: None,
        }
    }
    fn binding_status(&self, installed: &observer_acquired::Installed<A>) -> ObserverFiniteBinding {
        if let Some(bound) = &self.bound {
            return if bound.applies_to(installed) {
                ObserverFiniteBinding::Current {
                    native_state: bound.state_index(),
                }
            } else {
                ObserverFiniteBinding::Stale
            };
        }
        if let Some(binding) = &self.binding {
            if !binding.captured_revision_matches(installed) {
                return ObserverFiniteBinding::Stale;
            }
            if binding.exhausted_without_member() {
                return ObserverFiniteBinding::OutsideOrbit;
            }
            return ObserverFiniteBinding::Pending;
        }
        ObserverFiniteBinding::Unstarted
    }
    fn receipt(&self, installed: &observer_acquired::Installed<A>) -> ObserverFiniteReceipt {
        let status = if let Some(reason) = self.refusal {
            ObserverFiniteStatus::Unknown(reason)
        } else if let Some(certificate) = &self.certificate {
            ObserverFiniteStatus::ExecutableCycle {
                reachable_states: certificate.reachable_states(),
                concrete_cycle_start: certificate.concrete_cycle_start(),
                concrete_cycle_length: certificate.concrete_cycle_length(),
                primitive_observable_period: certificate.primitive_observable_period(),
                binding: self.binding_status(installed),
            }
        } else {
            ObserverFiniteStatus::Pending {
                retained_states: self.checking.retained_states(),
                pause: self.pause,
            }
        };
        ObserverFiniteReceipt {
            limits: Some(self.limits),
            status,
            spent_units: self.spent.clone(),
            rebindings: self.rebindings.clone(),
        }
    }
    fn stopped(&mut self, reason: finite::Stop<A>) {
        self.pause = None;
        match reason {
            finite::Stop::Work => self.pause = Some(ObserverFinitePause::Work),
            finite::Stop::Capacity => self.pause = Some(ObserverFinitePause::Capacity),
            finite::Stop::Allocation => self.pause = Some(ObserverFinitePause::Allocation),
            finite::Stop::NativePause(_) => self.pause = Some(ObserverFinitePause::NativeResource),
            finite::Stop::Unknown(reason) => self.refusal = Some(unknown(&reason)),
            finite::Stop::OutsideOrbit => {}
            finite::Stop::Poisoned | finite::Stop::Consumed => {
                self.refusal = Some(ObserverFiniteUnknown::Poisoned)
            }
        }
    }
    fn advance_certificate(&mut self, work: &mut ObserverWork) {
        while self.refusal.is_none() && self.certificate.is_none() && work.remaining > 0 {
            match self.checking.advance(work) {
                Ok(true) => { self.certificate = self.checking.take(); self.pause = None; }
                Ok(false) => {}
                Err(reason) => { self.stopped(reason); return; }
            }
        }
    }
    fn advance(&mut self, installed: &observer_acquired::Installed<A>, work: &mut ObserverWork) {
        self.advance_certificate(work);
        if self.refusal.is_some() || self.certificate.is_none() { return; }
        while work.remaining > 0 {
            match self.binding_status(installed) {
                ObserverFiniteBinding::Current { .. }
                | ObserverFiniteBinding::Stale
                | ObserverFiniteBinding::OutsideOrbit => return,
                ObserverFiniteBinding::Unstarted => {
                    if work.charge(1).is_err() {
                        return;
                    }
                    self.binding = Some(
                        self.certificate
                            .as_ref()
                            .unwrap()
                            .begin_binding(installed)
                            .expect("same installed immutable definition"),
                    );
                }
                ObserverFiniteBinding::Pending => {
                    let result = self.binding.as_mut().unwrap().advance(work);
                    match result {
                        Ok(true) => {
                            self.bound = Some(
                                self.binding
                                    .as_mut()
                                    .unwrap()
                                    .take(installed)
                                    .expect("current revision held by native service borrow"),
                            );
                            self.binding = None;
                            self.pause = None;
                            return;
                        }
                        Ok(false) => {}
                        Err(reason) => {
                            self.stopped(reason);
                            return;
                        }
                    }
                }
            }
        }
    }
    fn rebind(&mut self, installed: &observer_acquired::Installed<A>, work: &mut ObserverWork) {
        if work.charge(1).is_err() {
            return;
        }
        let next = self
            .certificate
            .as_ref()
            .unwrap()
            .begin_binding(installed)
            .expect("same published native definition");
        // Keep only the last stale authority. Discarding an older diagnostic
        // never refunds its paid work or restarts the executable certificate.
        let previous = if let Some(bound) = self.bound.take() {
            Some(OldBinding::Checked(bound))
        } else {
            self.binding.take().map(OldBinding::Pending)
        };
        self.last_stale = previous;
        self.binding = Some(next);
        self.rebindings += 1u8;
        self.advance(installed, work);
    }
}
fn empty() -> ObserverFiniteReceipt {
    ObserverFiniteReceipt {
        limits: None,
        status: ObserverFiniteStatus::NotRequested,
        spent_units: 0u8.into(),
        rebindings: 0u8.into(),
    }
}
pub(super) fn snapshot<A: Copy + Ord>(
    general: &observer_runtime::General<A>,
) -> Result<ObserverFiniteReceipt, ObserverFiniteRefusal> {
    let analysis = general
        .finite_analysis
        .lock()
        .map_err(|_| ObserverFiniteRefusal::Poisoned)?;
    Ok(analysis
        .as_ref()
        .map_or_else(empty, |analysis| analysis.receipt(general.installed())))
}
#[derive(Clone, Copy)]
enum Command {
    Advance(ObserverFiniteLimits),
    Source(ObserverFiniteLimits),
    Rebind,
}
impl<A: Copy + Eq + std::hash::Hash + Ord + crate::worldmap::Wire> Organism<A> {
    /// Advance retained executable analysis for this exact published floor.
    /// A quote for pending work uses the existing work-policy/ledger. Completed,
    /// unknown and stale results return `NoWork` before issuing any entitlement.
    /// This neither installs a candidate nor changes its risk, evidence, runtime
    /// or clock; an existing result is available through `observer_receipts`.
    pub fn advance_observer_finite_analysis(
        &mut self,
        floor: FloorIdentity,
        limits: ObserverFiniteLimits,
        quoted_work: usize,
    ) -> Result<ObserverFiniteService, ObserverFiniteRefusal> {
        self.finite_service(floor, Command::Advance(limits), quoted_work)
    }
    /// Explicitly replace a stale membership binding with the current native
    /// revision. The expensive executable certificate and original limits stay.
    pub fn rebind_observer_finite_analysis(
        &mut self,
        floor: FloorIdentity,
        quoted_work: usize,
    ) -> Result<ObserverFiniteService, ObserverFiniteRefusal> {
        self.finite_service(floor, Command::Rebind, quoted_work)
    }
    fn finite_service(
        &mut self,
        floor: FloorIdentity,
        command: Command,
        quote: usize,
    ) -> Result<ObserverFiniteService, ObserverFiniteRefusal> {
        let physical_point = if matches!(command, Command::Source(_)) {
            Some(self.source_time.point().map_err(|_| ObserverFiniteRefusal::SourceBoundary)?)
        } else { None };
        let ex = self
            .exhaust
            .as_ref()
            .ok_or(ObserverFiniteRefusal::Unarmed)?;
        if ex.observer_history.lineage() != floor.lineage {
            return Err(ObserverFiniteRefusal::NotPublished);
        }
        let published = ex
            .floors
            .iter()
            .find(|f| {
                f.input_epoch == floor.input_epoch
                    && f.observer.general().output_epoch()
                        == Some(floor.output_epoch)
            })
            .ok_or(ObserverFiniteRefusal::NotPublished)?;
        let general = published
            .observer
            .general();
        let mut slot = general
            .finite_analysis
            .lock()
            .map_err(|_| ObserverFiniteRefusal::Poisoned)?;
        match (&command, slot.as_ref()) {
            (Command::Advance(limits) | Command::Source(limits), Some(old)) if *limits != old.limits => {
                return Err(ObserverFiniteRefusal::DifferentLimits);
            }
            (Command::Rebind, None) => return Err(ObserverFiniteRefusal::NoCertificate),
            (Command::Rebind, Some(old)) if old.certificate.is_none() => {
                return Err(ObserverFiniteRefusal::NoCertificate);
            }
            (Command::Rebind, Some(old))
                if old.binding_status(general.installed()) != ObserverFiniteBinding::Stale =>
            {
                return Err(ObserverFiniteRefusal::NotStale);
            }
            _ => {}
        }
        if let (Command::Advance(_), Some(owner)) = (&command, slot.as_ref()) {
            let pending = owner.refusal.is_none()
                && (owner.certificate.is_none()
                    || matches!(
                        owner.binding_status(general.installed()),
                        ObserverFiniteBinding::Unstarted | ObserverFiniteBinding::Pending
                    ));
            if !pending {
                return Err(ObserverFiniteRefusal::NoWork);
            }
        }
        if let (Command::Source(_), Some(owner)) = (&command, slot.as_ref()) {
            if owner.source_binding.as_ref().is_some_and(|binding| !binding.current(general.installed())) {
                return Err(ObserverFiniteRefusal::SourceGap);
            }
            if owner.refusal.is_some()
                || owner.source_current(general.installed(), physical_point.as_ref().unwrap())
                || owner.source_binding.as_ref().is_some_and(|binding| binding.outside())
            { return Err(ObserverFiniteRefusal::NoWork); }
        }
        let mut lease = ex
            .acquisition_budget
            .request(
                acquisition_budget::Lane::Semantic,
                quote,
                ex.glass_budget_frac,
            )
            .map_err(budget_error)?;
        lease
            .service(|work| {
                let before = work.remaining;
                if slot.is_none() && work.remaining > 0 {
                    let (Command::Advance(limits) | Command::Source(limits)) = command else {
                        unreachable!("checked existing rebind owner")
                    };
                    work.charge(1).expect("nonzero grant");
                    *slot = Some(Box::new(Analysis::new(general, limits)));
                }
                if let Some(owner) = slot.as_mut() {
                    match command {
                        Command::Advance(_) => owner.advance(general.installed(), work),
                        Command::Source(_) => owner.advance_source(general.installed(), physical_point.as_ref().unwrap(), work),
                        Command::Rebind => {
                            if work.remaining > 0 {
                                owner.rebind(general.installed(), work);
                            }
                        }
                    }
                    owner.spent += BigUint::from(before - work.remaining);
                }
            })
            .map_err(budget_error)?;
        let receipt = lease.finish().map_err(budget_error)?;
        let analysis = slot
            .as_ref()
            .map_or_else(empty, |a| a.receipt(general.installed()));
        Ok(ObserverFiniteService {
            floor,
            quoted_units: receipt.quote,
            allowed_units: receipt.allowed,
            spent_units: receipt.spent,
            returned_units: receipt.returned,
            analysis,
            source_cycle: physical_point.as_ref().and_then(|point| slot.as_ref()
                .and_then(|owner| owner.source_receipt(general.installed(), point, floor))),
        })
    }
}
