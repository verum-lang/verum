//! A causal code on ALL finite byte strings, independent of exact-state names.
//!
//! For n bytes the length mass is (count(n)+2^-(n+1))/(N+1), learned
//! from completed rows. At each of the 8n positions a
//! binary KT kernel codes the target XOR a mask fixed before this target.
//! Counts share a learned context, never the original exact situation key.
//! Every target byte is charged, including tags, shape, and unpredictable noise.
//! The reference uses the same length law and position-wise KT without a mask
//! or learned context. The ratio tests only this declared sequential reference;
//! it is NOT the old categorical parent-MLE test or a physical causal proof.
//!
//! The geometric base and binary-kernel normalization have Verum models
//! (CausalCoding/FiniteWire, a927ee5a0, 96705d21f). The posterior length
//! mixture is a new law: those earlier proofs do not alone certify it. Typed serializers may
//! occupy a strict subset of this wire domain: no normalization on that subset
//! is asserted. A port must retain its complete target, not a fitted projection.
use crate::program::{WorkMeter, code_mass::Mass};
use num_bigint::BigUint;
use num_rational::Ratio;
use std::{collections::BTreeMap, sync::Arc};

pub(crate) type Wire = Arc<[u8]>;
pub(crate) type Rational = Ratio<BigUint>;
/// Absolute wire probability law; V1 used a fixed geometric length prior.
/// The shared correction cancels in the V1 admission Bayes factor.
pub(crate) const FORECAST_LAW: &str = "shared-dirichlet-length-residual-kt-v2";
fn one() -> Rational {
    Ratio::from_integer(BigUint::from(1u8))
}
fn kt(counts: [u64; 2], bit: usize) -> Rational {
    Ratio::new(
        (BigUint::from(counts[bit]) << 1usize) + BigUint::from(1u8),
        ((BigUint::from(counts[0]) + BigUint::from(counts[1])) << 1usize) + BigUint::from(2u8),
    )
}
fn bit(bytes: &[u8], position: usize) -> usize {
    bytes
        .get(position / 8)
        .map_or(0, |byte| usize::from((byte >> (position % 8)) & 1))
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Prediction {
    context: Wire,
    mask: Wire,
}
impl Prediction {
    pub(crate) fn new(context: Wire, mask: Wire) -> Self {
        Self { context, mask }
    }
    pub(crate) fn context(&self) -> &[u8] {
        &self.context
    }
    pub(crate) fn mask(&self) -> &[u8] {
        &self.mask
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum Invalid {
    Encoding,
    MissingOutcome,
    ConflictingOutcome,
    CountOverflow,
    PendingOutcome,
    Capacity,
    Poisoned,
}
#[derive(Debug)]
pub(crate) enum Refusal<E> {
    Work(E),
    Invalid(Invalid),
}

/// Frozen causal interpretation of the native read and the complete target.
/// The prediction decoder receives only the native pre-outcome reading. Plain
/// function pointers do not enforce purity: absence of hidden/global outcome
/// access and fidelity of the complete-target encoder are explicit native port
/// premises, just like the VM semantics and physical observation boundary.
pub(crate) struct Protocol<V, Y> {
    prediction: fn(&V) -> Result<Prediction, Invalid>,
    outcome: fn(&Y) -> Result<Wire, Invalid>,
    inject: Option<fn(Wire) -> Result<V, Invalid>>,
}
impl<V, Y> Protocol<V, Y> {
    pub(crate) fn new(
        prediction: fn(&V) -> Result<Prediction, Invalid>,
        outcome: fn(&Y) -> Result<Wire, Invalid>,
    ) -> Arc<Self> {
        Arc::new(Self {
            prediction,
            outcome,
            inject: None,
        })
    }
    /// Frozen causal protocol. Injection must preserve the complete wire and be
    /// pure; this callback premise is not established by a Rust function pointer.
    pub(crate) fn causal(
        prediction: fn(&V) -> Result<Prediction, Invalid>,
        outcome: fn(&Y) -> Result<Wire, Invalid>,
        inject: fn(Wire) -> Result<V, Invalid>,
    ) -> Arc<Self> {
        Arc::new(Self { prediction, outcome, inject: Some(inject) })
    }
    pub(crate) fn requires_outcome(&self) -> bool { self.inject.is_some() }
    pub(crate) fn begin_complete<D>(&self, event: crate::program::observer::OwnedInput<D, V>, target: Option<Wire>)
        -> OutcomeCompletion<D, V> {
        OutcomeCompletion { event, target, inject: self.inject }
    }
    pub(crate) fn complete_input<D>(&self, event: &crate::program::observer::OwnedInput<D, V>, target: Option<&Wire>)
        -> Result<crate::program::observer::OwnedInput<D, V>, Invalid> where V: Clone {
        self.begin_complete(event.clone(), target.cloned()).complete()
    }
    pub(crate) fn prediction(&self, reading: &V) -> Result<Prediction, Invalid> {
        (self.prediction)(reading)
    }
    pub(crate) fn outcome(&self, target: &Y) -> Result<Wire, Invalid> {
        (self.outcome)(target)
    }
}

/// Retains completion across a work pause; the original event is never replaced.
/// Callers charge the logical completion before entering this atomic callback /
/// clone / allocation boundary. Generic value sizes remain an adapter premise.
pub(crate) struct OutcomeCompletion<D, V> {
    event: crate::program::observer::OwnedInput<D, V>,
    target: Option<Wire>,
    inject: Option<fn(Wire) -> Result<V, Invalid>>,
}
impl<D, V: Clone> OutcomeCompletion<D, V> {
    pub(crate) fn complete(&self) -> Result<crate::program::observer::OwnedInput<D, V>, Invalid> {
        let Some(inject) = self.inject else { return Ok(self.event.clone()); };
        let target = self.target.as_ref().ok_or(Invalid::MissingOutcome)?;
        self.event.try_appended(inject(Arc::clone(target))?).map_err(|_| Invalid::Capacity)
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct Model {
    // Forecasts and branches share unchanged banks. Learning copies only the
    // updated context and reference vectors, not every retained context body.
    residual: Arc<BTreeMap<Wire, Arc<Vec<[u64; 2]>>>>,
    reference: Arc<Vec<[u64; 2]>>,
    lengths: Arc<Lengths>,
}
/// A Dirichlet predictive law on all finite lengths with unit concentration and
/// geometric base. It is shared by candidate and reference, so correcting their
/// absolute probability calibration does not change their evidence ratio.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct Lengths {
    total: u64,
    counts: BTreeMap<usize, u64>,
}
impl Lengths {
    fn mass(&self, count: u64, exponent: usize) -> Rational {
        let scale = BigUint::from(1u8) << exponent;
        Ratio::new(
            BigUint::from(count) * &scale + BigUint::from(1u8),
            (BigUint::from(self.total) + BigUint::from(1u8)) * scale,
        )
    }
    fn point(&self, length: usize) -> Result<Rational, Invalid> {
        let exponent = length.checked_add(1).ok_or(Invalid::Capacity)?;
        Ok(self.mass(self.counts.get(&length).copied().unwrap_or(0), exponent))
    }
    fn observe(&mut self, length: usize) -> Result<(), Invalid> {
        let total = self.total.checked_add(1).ok_or(Invalid::CountOverflow)?;
        let count = self
            .counts
            .get(&length)
            .copied()
            .unwrap_or(0)
            .checked_add(1)
            .ok_or(Invalid::CountOverflow)?;
        self.counts.insert(length, count);
        self.total = total;
        Ok(())
    }
}

impl Model {
    /// Counts are immutable for this forecast; no target has been supplied.
    pub(crate) fn forecast(self: &Arc<Self>, prediction: Prediction) -> Forecast {
        Forecast {
            model: Arc::clone(self),
            prediction,
        }
    }
    pub(crate) fn contexts(&self) -> usize {
        self.residual.len()
    }
    fn factors(
        &self,
        prediction: &Prediction,
        position: usize,
        target: usize,
    ) -> (Rational, Rational) {
        let residual = target ^ bit(&prediction.mask, position);
        let counts = self
            .residual
            .get(&prediction.context)
            .and_then(|c| c.get(position))
            .copied()
            .unwrap_or([0, 0]);
        let base = self.reference.get(position).copied().unwrap_or([0, 0]);
        (kt(counts, residual), kt(base, target))
    }
    fn observe(
        &mut self,
        prediction: &Prediction,
        position: usize,
        target: usize,
    ) -> Result<(), Invalid> {
        let residual = target ^ bit(&prediction.mask, position);
        let counts = Arc::make_mut(&mut self.residual)
            .entry(Arc::clone(&prediction.context))
            .or_default();
        let counts = Arc::make_mut(counts);
        let reference = Arc::make_mut(&mut self.reference);
        if counts.len() <= position {
            counts
                .try_reserve(position + 1 - counts.len())
                .map_err(|_| Invalid::Capacity)?;
            counts.resize(position + 1, [0, 0]);
        }
        if reference.len() <= position {
            reference
                .try_reserve(position + 1 - reference.len())
                .map_err(|_| Invalid::Capacity)?;
            reference.resize(position + 1, [0, 0]);
        }
        let child = counts[position][residual]
            .checked_add(1)
            .ok_or(Invalid::CountOverflow)?;
        let base = reference[position][target]
            .checked_add(1)
            .ok_or(Invalid::CountOverflow)?;
        counts[position][residual] = child;
        reference[position][target] = base;
        Ok(())
    }
}

/// This owner is created from a pre-outcome native reading and a frozen learned
/// count frontier. Evaluating alternative outcomes never changes that frontier.
#[derive(Clone, Debug)]
pub(crate) struct Forecast {
    model: Arc<Model>,
    prediction: Prediction,
}
impl Forecast {
    pub(crate) fn prediction(&self) -> &Prediction {
        &self.prediction
    }
    pub(crate) fn evaluate(&self, target: Wire) -> Result<Likelihood, Invalid> {
        Likelihood::new(Arc::clone(&self.model), self.prediction.clone(), target)
    }
    /// Probability of all finite byte strings beginning with this prefix,
    /// including the prefix itself. No remembered-target normalization and no
    /// enumeration of the unbounded suffix. This is a wire cylinder, NOT the
    /// probability of a typed event unless a separate decoder proves validity.
    pub(crate) fn prefix(&self, prefix: Wire) -> Result<Likelihood, Invalid> {
        Likelihood::prefix(Arc::clone(&self.model), self.prediction.clone(), prefix)
    }
}
#[cfg(all(test, feature = "serde"))]
impl Forecast {
    pub(crate) fn native_frontier(&self) -> serde_json::Value {
        serde_json::json!({
            "forecast_law":FORECAST_LAW,
            "prediction":{"context":self.prediction.context.as_ref(),"mask":self.prediction.mask.as_ref()},
            "lengths":{"total":self.model.lengths.total,"counts":self.model.lengths.counts},
            "reference":self.model.reference.as_ref(),
            "residual":self.model.residual.iter().map(|(context,counts)|
                serde_json::json!({"context":context.as_ref(),"counts":counts.as_ref()})).collect::<Vec<_>>()
        })
    }
}
/// A point or prefix cylinder, with one factor per logical advance and a paid
/// sparse length census for cylinders. This does not create training samples.
pub(crate) struct Likelihood {
    model: Arc<Model>,
    prediction: Prediction,
    target: Wire,
    position: usize,
    bits: usize,
    candidate: Rational,
    reference: Rational,
    length_tail: Option<LengthTail>,
    poisoned: bool,
}
struct LengthTail {
    last: Option<usize>,
    count: u64,
}
impl Likelihood {
    fn new(model: Arc<Model>, prediction: Prediction, target: Wire) -> Result<Self, Invalid> {
        let bits = target.len().checked_mul(8).ok_or(Invalid::Capacity)?;
        let mass = model.lengths.point(target.len())?;
        Ok(Self {
            model,
            prediction,
            target,
            position: 0,
            bits,
            candidate: mass.clone(),
            reference: mass,
            length_tail: None,
            poisoned: false,
        })
    }
    fn prefix(model: Arc<Model>, prediction: Prediction, target: Wire) -> Result<Self, Invalid> {
        let bits = target.len().checked_mul(8).ok_or(Invalid::Capacity)?;
        Ok(Self {
            model,
            prediction,
            target,
            position: 0,
            bits,
            candidate: one(),
            reference: one(),
            length_tail: Some(LengthTail {
                last: None,
                count: 0,
            }),
            poisoned: false,
        })
    }
    pub(crate) fn advance<M: WorkMeter + ?Sized>(
        &mut self,
        work: &mut M,
    ) -> Result<bool, Refusal<M::Error>> {
        if self.poisoned {
            return Err(Refusal::Invalid(Invalid::Poisoned));
        }
        if let Some(tail) = &mut self.length_tail {
            use std::ops::Bound::{Excluded, Included, Unbounded};
            work.charge(1).map_err(Refusal::Work)?;
            self.poisoned = true;
            let lower = tail.last.map_or(Included(self.target.len()), Excluded);
            if let Some((&length, &count)) =
                self.model.lengths.counts.range((lower, Unbounded)).next()
            {
                tail.count = tail
                    .count
                    .checked_add(count)
                    .ok_or(Refusal::Invalid(Invalid::CountOverflow))?;
                tail.last = Some(length);
            } else {
                let mass = self.model.lengths.mass(tail.count, self.target.len());
                self.candidate = mass.clone();
                self.reference = mass;
                self.length_tail = None;
            }
            self.poisoned = false;
            return Ok(self.length_tail.is_none() && self.position == self.bits);
        }
        if self.position == self.bits {
            return Ok(true);
        }
        work.charge(1).map_err(Refusal::Work)?;
        self.poisoned = true;
        let (candidate, reference) = self.model.factors(
            &self.prediction,
            self.position,
            bit(&self.target, self.position),
        );
        self.candidate *= candidate;
        self.reference *= reference;
        self.position += 1;
        self.poisoned = false;
        Ok(self.position == self.bits)
    }
    pub(crate) fn result(&self) -> Option<(&Rational, &Rational)> {
        (!self.poisoned && self.length_tail.is_none() && self.position == self.bits)
            .then_some((&self.candidate, &self.reference))
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Score {
    ratio: Rational,
    samples: u64,
    bits: u64,
    model: Arc<Model>,
}
impl Score {
    pub(crate) fn ratio(&self) -> &Rational {
        &self.ratio
    }
    pub(crate) fn samples(&self) -> u64 {
        self.samples
    }
    pub(crate) fn bits(&self) -> u64 {
        self.bits
    }
    pub(crate) fn model(&self) -> &Arc<Model> {
        &self.model
    }
    pub(crate) fn order(&self, name: &Mass, risk: &Mass) -> std::cmp::Ordering {
        self.ratio
            .numer()
            .cmp(&(self.ratio.denom() * name.denominator() * risk.denominator()))
    }
}
#[cfg(all(test, feature = "serde"))]
impl Score {
    pub(crate) fn native_frontier(&self) -> serde_json::Value {
        serde_json::json!({ "forecast_law": FORECAST_LAW, "samples": self.samples, "bits": self.bits,
            "ratio": {"numerator":self.ratio.numer().to_string(), "denominator":self.ratio.denom().to_string()},
            "reference": self.model.reference.as_ref(),
            "lengths": {"total": self.model.lengths.total, "counts": self.model.lengths.counts},
            "residual": self.model.residual.iter().map(|(key, counts)|
                serde_json::json!({"context":key.as_ref(),"counts":counts.as_ref()})).collect::<Vec<_>>() })
    }
}

struct Pending {
    prediction: Prediction,
    target: Wire,
    position: usize,
    bits: usize,
}
/// Same sequential owner for training and training+fresh validation. There is
/// no post-hoc regrouping or re-fitting of outcomes into a smaller alphabet.
pub(crate) struct Accumulator {
    model: Model,
    ratio: Rational,
    samples: u64,
    bits: u64,
    pending: Option<Pending>,
    poisoned: bool,
    invalid: Option<Invalid>,
}
impl Accumulator {
    pub(crate) fn new() -> Self {
        Self {
            model: Model::default(),
            ratio: one(),
            samples: 0,
            bits: 0,
            pending: None,
            poisoned: false,
            invalid: None,
        }
    }
    pub(crate) fn continue_from(score: &Score) -> Self {
        Self {
            model: (*score.model).clone(),
            ratio: score.ratio.clone(),
            samples: score.samples,
            bits: score.bits,
            pending: None,
            poisoned: false,
            invalid: None,
        }
    }
    pub(crate) fn samples(&self) -> u64 {
        self.samples
    }
    pub(crate) fn pending(&self) -> bool {
        self.pending.is_some()
    }
    pub(crate) fn begin(&mut self, prediction: Prediction, target: Wire) -> Result<(), Invalid> {
        if self.poisoned {
            return Err(Invalid::Poisoned);
        }
        if let Some(reason) = &self.invalid {
            return Err(reason.clone());
        }
        if self.pending.is_some() {
            return Err(Invalid::PendingOutcome);
        }
        let bits = target.len().checked_mul(8).ok_or(Invalid::Capacity)?;
        self.pending = Some(Pending {
            prediction,
            target,
            position: 0,
            bits,
        });
        Ok(())
    }
    /// A resource refusal before a factor changes neither counts nor evidence.
    /// Partial rows stay private. Sealing requires every byte and the row end.
    /// Bigint/generic-key costs are size-dependent, not constant CPU units.
    pub(crate) fn advance<M: WorkMeter + ?Sized>(
        &mut self,
        work: &mut M,
    ) -> Result<(), Refusal<M::Error>> {
        if self.poisoned {
            return Err(Refusal::Invalid(Invalid::Poisoned));
        }
        if let Some(reason) = &self.invalid {
            return Err(Refusal::Invalid(reason.clone()));
        }
        if self.pending.is_none() {
            return Ok(());
        }
        work.charge(1).map_err(Refusal::Work)?;
        self.poisoned = true;
        let result = self.step();
        if let Err(reason) = &result {
            self.invalid = Some(reason.clone());
        }
        self.poisoned = false;
        result.map_err(Refusal::Invalid)
    }
    fn step(&mut self) -> Result<(), Invalid> {
        let row = self.pending.as_mut().expect("owned pending target");
        if row.position == row.bits {
            let samples = self.samples.checked_add(1).ok_or(Invalid::CountOverflow)?;
            let bits = self
                .bits
                .checked_add(u64::try_from(row.bits).map_err(|_| Invalid::Capacity)?)
                .ok_or(Invalid::CountOverflow)?;
            Arc::make_mut(&mut self.model.lengths).observe(row.target.len())?;
            self.samples = samples;
            self.bits = bits;
            self.pending = None;
            return Ok(());
        }
        let target = bit(&row.target, row.position);
        let (candidate, reference) = self.model.factors(&row.prediction, row.position, target);
        self.model.observe(&row.prediction, row.position, target)?;
        self.ratio *= candidate / reference;
        row.position += 1;
        Ok(())
    }
    pub(crate) fn finish(self) -> Result<Score, Self> {
        if self.poisoned || self.invalid.is_some() || self.pending.is_some() {
            return Err(self);
        }
        Ok(Score {
            ratio: self.ratio,
            samples: self.samples,
            bits: self.bits,
            model: Arc::new(self.model),
        })
    }
}

#[cfg(all(test, feature = "serde"))]
impl Accumulator {
    /// Actual private continuation, including unfinished row counts. This is
    /// diagnostic data and cannot be deserialized into scoring authority.
    pub(crate) fn native_frontier(&self) -> serde_json::Value {
        serde_json::json!({"forecast_law":FORECAST_LAW,
            "ratio":{"numerator":self.ratio.numer().to_string(),"denominator":self.ratio.denom().to_string()},
            "samples":self.samples,"bits":self.bits,"poisoned":self.poisoned,
            "invalid":self.invalid.as_ref().map(|v|format!("{v:?}")),
            "lengths":{"total":self.model.lengths.total,"counts":self.model.lengths.counts},
            "reference":self.model.reference.as_ref(),
            "residual":self.model.residual.iter().map(|(context,counts)|
                serde_json::json!({"context":context.as_ref(),"counts":counts.as_ref()})).collect::<Vec<_>>(),
            "pending":self.pending.as_ref().map(|row|serde_json::json!({
                "prediction":{"context":row.prediction.context.as_ref(),"mask":row.prediction.mask.as_ref()},
                "target":row.target.as_ref(),"position":row.position,"bits":row.bits}))})
    }
}

#[cfg(test)]
mod courts;
