use super::*;
use crate::program::{Code, ExecutionLimit, ExecutionStop, Semantics, Spine, execute_metered};
use std::collections::BTreeSet;
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Op { Zero, Identity, Add }
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Value { Nat(u64), Sequence(Vec<Value>) }
struct Work(usize);
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> { self.0 = self.0.checked_sub(n).ok_or(())?; Ok(()) }
}
fn grammar(inputs: usize, steps: usize) -> Grammar<Op, Value> {
    Grammar { inputs, max_steps: steps, literals: vec![], operations: vec![
        OperationSpec { id: Op::Zero, arity: 0 }, OperationSpec { id: Op::Identity, arity: 1 }, OperationSpec { id: Op::Add, arity: 2 }] }
}
fn build(inputs: usize, steps: usize, bounds: DeclarationBounds, resume: bool) -> Arc<Language<Value, Op>> {
    let mut cursor = DeclarationCursor::new(grammar(inputs, steps), bounds).unwrap();
    let mut capacity = if resume { cursor.retained_cells() } else { 100_000 };
    let owners = |c: &DeclarationCursor<Value, Op>| c.previous.iter().chain(&c.next).map(|l|Arc::as_ptr(l) as usize).collect::<Vec<_>>();
    for _ in 0..100_000 {
        let before = cursor.retained_cells(); let before_owners = owners(&cursor);
        assert!(matches!(cursor.advance(&mut Work(0), capacity), Err(DeclarationFailure::Work(()))));
        assert_eq!(cursor.retained_cells(), before);
        assert_eq!(owners(&cursor), before_owners);
        match cursor.advance(&mut Work(if resume { 1 } else { 10_000 }), capacity) {
            Ok(true) => return Arc::clone(cursor.language().unwrap()),
            Ok(false) => {},
            Err(DeclarationFailure::Structural(StructuralRefusal::Capacity)) if resume => {
                assert_eq!(cursor.retained_cells(), before);
                assert_eq!(owners(&cursor), before_owners);
                capacity += 1;
            },
            Err(e) => panic!("declaration refused: {e:?}"),
        }

    }
    panic!("declaration did not complete");
}
fn cardinality(language: &Arc<Language<Value, Op>>) -> BigUint {
    let mut count = language.cardinality().unwrap();
    for _ in 0..1_000_000 { if count.advance(&mut Work(1)).unwrap() { return count.value().unwrap().clone(); } }
    panic!("count did not complete");
}
fn programs(language: &Arc<Language<Value, Op>>) -> Vec<Program<Value, Op>> {
    let mut names = language.enumerate(); let mut result = Vec::new();
    for _ in 0..2_000_000 {
        match names.advance(&mut Work(1)).unwrap() {
            Progress::Advanced => {}, Progress::Complete => return result,
            Progress::Address(a) => {
                let mut materializer = language.materialize(a).unwrap();
                while !materializer.advance(&mut Work(1)).unwrap() {}
                result.push(materializer.finish().ok().unwrap());
            },
        }
    }
    panic!("enumeration did not complete");
}
#[test]
fn generated_envelope_counts_all_widths_and_independent_branch_choices() {
    let bounds = DeclarationBounds { nesting: 1, body_inputs: 2 };
    for inputs in 0..=2 {
        let small = build(inputs, 1, bounds, true); let coarse = build(inputs, 1, bounds, false);
        // Independent one-instruction census: primitives, two independently
        // chosen branch bodies per width, and each well-shaped fold body.
        let primitive = |k: usize| 1 + k + k * k;
        let expected = primitive(inputs) + (0..=2).map(|k| inputs.pow(k as u32 + 1) * primitive(k).pow(2)).sum::<usize>()
            + inputs.pow(2) * primitive(2);
        assert_eq!(cardinality(&small), BigUint::from(expected));
        assert_eq!(cardinality(&coarse), BigUint::from(expected));
        let a = programs(&small); let b = programs(&coarse);
        assert_eq!(a,b); assert_eq!(a.len(),expected);
        let unique: BTreeSet<_> = a.iter().map(|p| format!("{p:?}")).collect(); assert_eq!(unique.len(),expected);
        let branch = &small.controls[2];
        let ControlSpec::Branch { yes, no } = branch else { panic!("width-two branch"); };
        assert!(Arc::ptr_eq(yes,no), "DAG shares declarations, not selected bodies");
        assert!(a.iter().any(|p| matches!(p.steps[0].operation, Operation::Branch { yes, no } if p.library[yes] != p.library[no])) || inputs == 0);
    }
}
struct Meaning;
impl Semantics<Value, Op> for Meaning {
    type Error = ();
    fn apply(&self, op: &Op, args: &[Value]) -> Result<Value, ()> {
        match (op,args) {
            (Op::Zero,[]) => Ok(Value::Nat(0)), (Op::Identity,[x]) => Ok(x.clone()),
            (Op::Add,[Value::Nat(a),Value::Nat(b)]) => a.checked_add(*b).map(Value::Nat).ok_or(()), _ => Err(()),
        }
    }
    fn spine(&self, value: &Value) -> Option<Spine<Value>> {
        let Value::Sequence(xs) = value else { return None; };
        Some(match xs.split_first() { None => Spine::Empty, Some((h,t)) => Spine::Cell { head: h.clone(), tail: Value::Sequence(t.to_vec()), length: xs.len() } })
    }
}
fn run(p: &Program<Value, Op>, initial: u64, xs: &[u64]) -> Option<Value> {
    let input = [Value::Nat(initial),Value::Sequence(xs.iter().copied().map(Value::Nat).collect())];
    let r = execute_metered(p,&input,&Meaning,ExecutionLimit::Unlimited,&mut Work(100_000));
    assert!(r.meter_error.is_none());
    if r.execution.stop == ExecutionStop::Complete { p.output(&r.execution.registers) } else { None }
}
#[test]
fn generated_syntax_discovers_fold_without_a_supplied_body_and_transfers() {
    let language = build(2,1,DeclarationBounds { nesting: 1, body_inputs: 2 },false);
    let acquired = programs(&language).into_iter().find(|p| run(p,7,&[2,5]) == Some(Value::Nat(14)) && run(p,11,&[3]) == Some(Value::Nat(14))).expect("generated syntax contains sum");
    assert!(matches!(acquired.steps[0].operation,Operation::Fold { .. }));
    for (seed,xs) in [(19,vec![]),(13,vec![9,2,12,4]),(3,vec![1;64])] {
        assert_eq!(run(&acquired,seed,&xs),Some(Value::Nat(seed+xs.iter().sum::<u64>())));
    }
}
#[test]
fn nested_declarations_are_complete_acyclic_and_capacity_retains_owners() {
    let language = build(3,2,DeclarationBounds { nesting: 3, body_inputs: 4 },true);
    let mut stack = vec![(language,3)]; let mut seen = BTreeSet::new();
    while let Some((language,level)) = stack.pop() {
        if !seen.insert(Arc::as_ptr(&language) as usize) { continue; }
        assert_eq!(language.extent,Extent::Finite(2));
        assert_eq!(language.controls.len(),if level == 0 { 0 } else { 8 });
        for control in &language.controls {
            for side in 0..control.children() { let child=control.child(side); assert!(child.inputs <= 4); stack.push((Arc::clone(child),level-1)); }
        }
    }
    assert_eq!(seen.len(),16); // root plus three layers of five shared widths
}
#[test]
fn invalid_catalogues_are_refused_before_publishing_a_language() {
    for duplicate in [true,false] {
        let mut g = grammar(2,1);
        if duplicate { g.operations.push(g.operations[0].clone()); } else { g.literals=vec![Value::Nat(1),Value::Nat(1)]; }
        let mut c = DeclarationCursor::new(g,DeclarationBounds { nesting: 2,body_inputs: 3 }).unwrap();
        let mut failure = None;
        for _ in 0..100 { match c.advance(&mut Work(1),1000) { Err(DeclarationFailure::Syntax(e)) => {failure=Some(e);break;},Ok(false)=>{}, other=>panic!("{other:?}") } }
        assert_eq!(failure,Some(if duplicate {SyntaxRefusal::DuplicateOperation}else{SyntaxRefusal::DuplicateLiteral}));
        assert!(c.language().is_none()); assert!(c.previous.is_empty()); assert!(c.next.is_empty());
    }
    assert!(DeclarationCursor::new(grammar(2,1),DeclarationBounds {nesting:1,body_inputs:usize::MAX}).is_err());
}
