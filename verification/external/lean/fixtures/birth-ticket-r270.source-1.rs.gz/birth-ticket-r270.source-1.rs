//! Streaming connected expressions over immutable global arrival IDs.
//! Each constructor discovers immutable latest-arrival rectangles in a fixed
//! committed prefix. Compact birth tickets retain only bounds and an odometer;
//! one active evaluator owns actual child references and abstract outputs.
//! A paid heap selects the least positive tree-size lower bound, rotating equal
//! bounds after each finite tuple quantum. Constructor round-robin is separate.
//! This is neither global code-price ordering nor constant-memory best-first.
//! Each append finishes its paid index/wake transaction before another
//! expression can be built or its immutable owner can leave this producer.
use super::*;
#[cfg(test)]
pub(super) mod probe;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PlanPhase { Position, Lookup, Publish, Done }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Posting { arrival: usize, mask: u64, minimum_size: usize }
struct DomainGroup {
    domain: u64,
    positions: Vec<(usize, usize)>,
    // Entries at or beyond Expressions::indexed are not yet visible.
    postings: Vec<Posting>,
}
struct DomainPlan {
    groups: Vec<DomainGroup>, alternative: usize, anchor: usize,
    domain: u64, lookup: usize, phase: PlanPhase, cells: usize,
}
impl DomainPlan {
    fn new() -> Self { Self { groups: Vec::new(), alternative: 0, anchor: 0,
        domain: 0, lookup: 0, phase: PlanPhase::Position, cells: 0 } }
    fn ready(&self) -> bool { self.phase == PlanPhase::Done }
    fn step<V, P>(&mut self, language: &Language<V, P>, model: &dyn Abstract<V, P>,
        constructors: &mut Vec<Constructor>, cells: &mut usize, capacity: usize)
        -> Result<(), StructuralRefusal> {
        match self.phase {
            PlanPhase::Position => {
                if self.alternative == language.expression_alternatives()? { self.phase = PlanPhase::Done; }
                else if language.arity(self.alternative) == 0 { self.alternative += 1; }
                else {
                    self.domain = language.operations.get(self.alternative).map_or_else(
                        || model.universe(), |op| model.argument_domain(&op.id, self.anchor));
                    self.lookup = 0;
                    self.phase = PlanPhase::Lookup;
                }
            }
            PlanPhase::Lookup => {
                if let Some(group) = self.groups.get(self.lookup) {
                    if group.domain == self.domain { self.phase = PlanPhase::Publish; }
                    else { self.lookup += 1; }
                } else { self.phase = PlanPhase::Publish; }
            }
            PlanPhase::Publish => {
                let new_group = self.lookup == self.groups.len();
                let new_constructor = self.anchor == 0;
                // Immutable group/position cells and mutable constructor/axis
                // cells are distinct owners. Preflight all before publication.
                let immutable = 1 + usize::from(new_group);
                let additional = immutable + 1 + usize::from(new_constructor);
                room(*cells, additional, capacity)?;
                let mut positions = Vec::new();
                if new_group {
                    self.groups.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    positions.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                } else {
                    self.groups[self.lookup].positions.try_reserve(1)
                        .map_err(|_| StructuralRefusal::Allocation)?;
                }
                let mut axes = Vec::new();
                if new_constructor {
                    constructors.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    axes.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                } else {
                    constructors.last_mut().expect("retained constructor declaration").axes
                        .try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                }
                let position = (self.alternative, self.anchor);
                if new_group {
                    positions.push(position);
                    self.groups.push(DomainGroup { domain: self.domain, positions, postings: Vec::new() });
                } else { self.groups[self.lookup].positions.push(position); }
                let axis = Axis { domain: self.lookup, consumed: 0, before: 0, after: 0 };
                if new_constructor {
                    axes.push(axis);
                    constructors.push(Constructor::new(self.alternative, axes));
                } else { constructors.last_mut().unwrap().axes.push(axis); }
                *cells += additional;
                self.cells += immutable;
                if self.anchor + 1 == language.arity(self.alternative) {
                    self.alternative += 1; self.anchor = 0;
                } else { self.anchor += 1; }
                self.phase = PlanPhase::Position;
            }
            PlanPhase::Done => {},
        }
        Ok(())
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum IndexPhase { Cases, Publish }
struct Indexer { domain: usize, case: usize, mask: u64, phase: IndexPhase }
impl Indexer {
    fn new() -> Self { Self { domain: 0, case: 0, mask: 0, phase: IndexPhase::Cases } }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Axis { domain: usize, consumed: usize, before: usize, after: usize }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ConstructorPhase { Merge, Freeze, Anchor, Bounds, Publish, Idle }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct TicketAxis { domain: usize, end: usize, coordinate: usize }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum TicketPhase { Ready, Reset, Carry, Retire }
struct Ticket {
    newest: usize, anchor: usize, watermark: usize,
    // One root plus arity reserved logical records, including partial Bounds.
    axes: Vec<TicketAxis>, lower_bound: usize, turn: usize,
    phase: TicketPhase, scan: usize, carry: usize,
}
impl Ticket {
    fn key(&self) -> (usize, usize) { (self.lower_bound, self.turn) }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum HeapPhase { Ready, Up(usize), Choose(usize), Swap(usize, usize) }
struct Constructor {
    alternative: usize, axes: Vec<Axis>, phase: ConstructorPhase,
    scan: usize, newest: Option<usize>, anchor: usize,
    // Discovery never extends a pass because another constructor publishes.
    watermark: usize, observed: usize, building: Option<Ticket>,
    tickets: Vec<Ticket>, heap: HeapPhase, active: Option<Ticket>,
    next_turn: usize, service: bool, sleeping: bool, tuple: Option<Tuple>,
    // Counts reserved ticket roots/axis records, including the building owner.
    ticket_cells: usize,
}
enum ConstructorStep { Advanced, StartedTuple, QuantumComplete, Idle }
impl Constructor {
    fn new(alternative: usize, axes: Vec<Axis>) -> Self {
        Self { alternative, axes, phase: ConstructorPhase::Idle, scan: 0,
            newest: None, anchor: 0, watermark: 0, observed: 0, building: None,
            tickets: Vec::new(), heap: HeapPhase::Ready, active: None,
            next_turn: 0, service: false, sleeping: true, tuple: None, ticket_cells: 0 }
    }
    fn idle(&self) -> bool {
        self.sleeping
    }
    fn merge(&mut self, indexed: usize) {
        self.sleeping = false; self.watermark = indexed; self.newest = None; self.scan = 0;
        self.phase = ConstructorPhase::Merge;
    }
    fn next_birth(&mut self) {
        self.newest = None; self.scan = 0; self.phase = ConstructorPhase::Merge;
    }
    // At most one comparison or swap per paid visit. The heap can be partial
    // only while this retained repair cursor owns it; no selection occurs then.
    fn repair(&mut self) {
        match self.heap {
            HeapPhase::Ready => {},
            HeapPhase::Up(at) => {
                if at == 0 { self.heap = HeapPhase::Ready; }
                else {
                    let parent = (at - 1) / 2;
                    if self.tickets[at].key() < self.tickets[parent].key() {
                        self.tickets.swap(at, parent); self.heap = HeapPhase::Up(parent);
                    } else { self.heap = HeapPhase::Ready; }
                }
            }
            HeapPhase::Choose(at) => {
                // A node with no left child cannot overflow this arithmetic.
                if at >= self.tickets.len() / 2 { self.heap = HeapPhase::Ready; }
                else {
                    let left = at * 2 + 1; let right = left + 1;
                    let child = if right < self.tickets.len()
                        && self.tickets[right].key() < self.tickets[left].key() { right } else { left };
                    self.heap = HeapPhase::Swap(at, child);
                }
            }
            HeapPhase::Swap(at, child) => {
                if self.tickets[child].key() < self.tickets[at].key() {
                    self.tickets.swap(at, child); self.heap = HeapPhase::Choose(child);
                } else { self.heap = HeapPhase::Ready; }
            }
        }
    }
    fn release_building(&mut self, cells: &mut usize) {
        self.building = None;
        let released = 1 + self.axes.len();
        *cells -= released; self.ticket_cells -= released;
    }
    fn finish_tuple(&mut self, reset_from: Option<usize>) {
        let ticket = self.active.as_mut().expect("selected immutable birth ticket");
        ticket.scan = reset_from.unwrap_or(self.axes.len());
        ticket.carry = ticket.scan;
        ticket.phase = if reset_from.is_some() { TicketPhase::Reset } else { TicketPhase::Carry };
    }
    fn step(&mut self, groups: &[DomainGroup], catalogue: &[Arc<Expression>], indexed: usize, extent: Extent,
        cells: &mut usize, capacity: usize) -> Result<ConstructorStep, StructuralRefusal> {
        if self.heap != HeapPhase::Ready { self.repair(); return Ok(ConstructorStep::Advanced); }
        if let Some(ticket) = self.active.as_mut() {
            match ticket.phase {
                TicketPhase::Ready => {
                    room(*cells, 1, capacity)?;
                    self.tuple = Some(Tuple::new(self.alternative)); *cells += 1;
                    return Ok(ConstructorStep::StartedTuple);
                }
                TicketPhase::Reset => {
                    if let Some(axis) = ticket.axes.get_mut(ticket.scan) {
                        axis.coordinate = if ticket.scan == ticket.anchor { axis.end - 1 } else { 0 };
                        ticket.scan += 1;
                    } else { ticket.phase = TicketPhase::Carry; }
                }
                TicketPhase::Carry => {
                    if ticket.carry == 0 { ticket.phase = TicketPhase::Retire; }
                    else {
                        let at = ticket.carry - 1;
                        let axis = &mut ticket.axes[at];
                        if at != ticket.anchor && axis.coordinate + 1 < axis.end {
                            // A round number is reserved before advancing a tuple.
                            let next = self.next_turn.checked_add(1).ok_or(StructuralRefusal::Capacity)?;
                            axis.coordinate += 1; ticket.phase = TicketPhase::Ready;
                            ticket.turn = self.next_turn; self.next_turn = next;
                            // Pop selection left a reserved Vec slot. No discovery
                            // runs while the active owner needs its return slot.
                            let ticket = self.active.take().unwrap();
                            self.tickets.push(ticket); self.heap = HeapPhase::Up(self.tickets.len() - 1);
                            self.service = false;
                            return Ok(ConstructorStep::QuantumComplete);
                        } else {
                            if at != ticket.anchor { axis.coordinate = 0; }
                            ticket.carry -= 1;
                        }
                    }
                }
                TicketPhase::Retire => {
                    // Ticket axes are plain scalar records; releasing the fixed
                    // admission reservation does not traverse expression owners.
                    self.active = None;
                    let released = 1 + self.axes.len();
                    *cells -= released; self.ticket_cells -= released;
                    self.service = false;
                    return Ok(ConstructorStep::QuantumComplete);
                }
            }
            return Ok(ConstructorStep::Advanced);
        }
        if self.service {
            if self.tickets.is_empty() { self.service = false; }
            else {
                self.active = Some(self.tickets.swap_remove(0));
                self.heap = HeapPhase::Choose(0);
                return Ok(ConstructorStep::Advanced);
            }
        }
        match self.phase {
            ConstructorPhase::Idle => {
                if self.observed < indexed { self.merge(indexed); }
                else if self.tickets.is_empty() { self.sleeping = true; return Ok(ConstructorStep::Idle); }
                else { self.service = true; }
            }
            ConstructorPhase::Merge => {
                if let Some(axis) = self.axes.get(self.scan) {
                    if let Some(posting) = groups[axis.domain].postings.get(axis.consumed) {
                        if posting.arrival < self.watermark {
                            self.newest = Some(self.newest.map_or(posting.arrival, |n| n.min(posting.arrival)));
                        }
                    }
                    self.scan += 1;
                } else if self.newest.is_some() {
                    self.scan = 0; self.phase = ConstructorPhase::Freeze;
                } else {
                    self.observed = self.watermark; self.phase = ConstructorPhase::Idle;
                    // Service an admitted finite tuple before starting the next
                    // discovery pass, even if the committed prefix has grown.
                    self.service = true;
                }
            }
            ConstructorPhase::Freeze => {
                if let Some(axis) = self.axes.get_mut(self.scan) {
                    axis.before = axis.consumed;
                    if groups[axis.domain].postings.get(axis.consumed).is_some_and(|p|
                        p.arrival < self.watermark && Some(p.arrival) == self.newest) { axis.consumed += 1; }
                    axis.after = axis.consumed; self.scan += 1;
                } else { self.anchor = 0; self.phase = ConstructorPhase::Anchor; }
            }
            ConstructorPhase::Anchor => {
                if let Some(axis) = self.axes.get(self.anchor) {
                    if axis.after == axis.before { self.anchor += 1; }
                    else {
                        let additional = self.axes.len().checked_add(1).ok_or(StructuralRefusal::Capacity)?;
                        if let Err(refusal) = room(*cells, additional, capacity) {
                            if !self.tickets.is_empty() {
                                // This paid scheduling transition retains the exact
                                // undiscovered (birth, anchor). It cannot wait for a
                                // discovery pass whose admission needs freed cells.
                                self.service = true;
                                return Ok(ConstructorStep::QuantumComplete);
                            }
                            return Err(refusal);
                        }
                        let next = self.next_turn.checked_add(1).ok_or(StructuralRefusal::Capacity)?;
                        let mut axes = Vec::new();
                        axes.try_reserve(self.axes.len()).map_err(|_| StructuralRefusal::Allocation)?;
                        self.tickets.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                        self.building = Some(Ticket { newest: self.newest.unwrap(), anchor: self.anchor,
                            watermark: self.watermark, axes, lower_bound: 1, turn: self.next_turn,
                            phase: TicketPhase::Ready, scan: 0, carry: 0 });
                        self.next_turn = next; *cells += additional; self.ticket_cells += additional;
                        self.scan = 0; self.phase = ConstructorPhase::Bounds;
                    }
                } else { self.next_birth(); }
            }
            ConstructorPhase::Bounds => {
                if let Some(axis) = self.axes.get(self.scan) {
                    let end = if self.scan < self.anchor { axis.before } else { axis.after };
                    if end == 0 {
                        self.release_building(cells); self.anchor += 1; self.phase = ConstructorPhase::Anchor;
                    } else {
                        let posting = groups[axis.domain].postings[end - 1];
                        let cost = if self.scan == self.anchor { catalogue[posting.arrival].size }
                            else { posting.minimum_size };
                        let ticket = self.building.as_mut().unwrap();
                        let lower = match ticket.lower_bound.checked_add(cost) {
                            Some(lower) if !matches!(extent, Extent::Finite(limit) if lower > limit) => lower,
                            _ if matches!(extent, Extent::Finite(_)) => {
                                // Every tuple in this immutable rectangle exceeds
                                // the finite bound; identical to native prefix rejection.
                                self.release_building(cells); self.anchor += 1;
                                self.phase = ConstructorPhase::Anchor;
                                return Ok(ConstructorStep::Advanced);
                            }
                            _ => return Err(StructuralRefusal::Capacity),
                        };
                        ticket.axes.push(TicketAxis { domain: axis.domain, end,
                            coordinate: if self.scan == self.anchor { end - 1 } else { 0 } });
                        ticket.lower_bound = lower; self.scan += 1;
                    }
                } else { self.phase = ConstructorPhase::Publish; }
            }
            ConstructorPhase::Publish => {
                self.tickets.push(self.building.take().unwrap());
                self.heap = HeapPhase::Up(self.tickets.len() - 1);
                self.anchor += 1; self.phase = ConstructorPhase::Anchor;
            }
        }
        Ok(ConstructorStep::Advanced)
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum TuplePhase { Arguments, Values, Apply, Commit, Clear, Done }
struct Tuple {
    alternative: usize,
    children: Vec<Arc<Expression>>,
    outputs: Vec<u64>,
    values: Vec<u64>,
    phase: TuplePhase,
    at: usize,
    case: usize,
    reset_from: usize,
    size: usize,
    dependencies: u64,
    valid: u64,
    possible: u64,
    zero_value: bool,
}
impl Tuple {
    fn new(alternative: usize) -> Self {
        Self { alternative, children: Vec::new(), outputs: Vec::new(), values: Vec::new(),
            phase: TuplePhase::Arguments, at: 0, case: 0, reset_from: 0, size: 1,
            dependencies: 0, valid: u64::MAX, possible: 0, zero_value: false }
    }
    fn reject(&mut self, prefix: usize) { self.reset_from = prefix; self.phase = TuplePhase::Clear; }
    fn step<V, P>(&mut self, language: &Language<V, P>, model: &dyn Abstract<V, P>,
        cases: usize, catalogue: &[Arc<Expression>], groups: &[DomainGroup], axes: &[TicketAxis],
        cells: &mut usize, capacity: usize) -> Result<(), StructuralRefusal> {
        match self.phase {
            TuplePhase::Arguments => {
                if let Some(axis) = axes.get(self.at) {
                    let posting = groups[axis.domain].postings[axis.coordinate];
                    let child = &catalogue[posting.arrival];
                    let valid = self.valid & posting.mask;
                    if valid == 0 { self.reject(self.at + 1); return Ok(()); }
                    let size = match self.size.checked_add(child.size) {
                        Some(size) => size,
                        None if matches!(language.extent, Extent::Finite(_)) => {
                            self.reject(self.at + 1); return Ok(());
                        }
                        None => return Err(StructuralRefusal::Capacity),
                    };
                    if matches!(language.extent, Extent::Finite(limit) if size > limit) {
                        self.reject(self.at + 1); return Ok(());
                    }
                    room(*cells, 1, capacity)?;
                    self.children.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    self.children.push(Arc::clone(child));
                    *cells += 1;
                    self.valid = valid; self.size = size;
                    self.dependencies |= child.summary.dependencies;
                    self.at += 1;
                } else { self.case = 0; self.at = 0; self.phase = TuplePhase::Values; }
            }
            TuplePhase::Values => {
                if self.case == cases { self.phase = TuplePhase::Commit; }
                else if self.at < self.children.len() {
                    room(*cells, 1, capacity)?;
                    self.values.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                    let value = self.children[self.at].summary.outputs[self.case];
                    self.zero_value |= value == 0;
                    self.values.push(value); *cells += 1; self.at += 1;
                } else { self.phase = TuplePhase::Apply; }
            }
            TuplePhase::Apply => {
                room(*cells, 1, capacity)?;
                self.outputs.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                let value = if self.zero_value { 0 } else {
                    language.operations.get(self.alternative).map_or_else(
                        || model.universe(), |op| model.apply(&op.id, &self.values)) & model.universe()
                };
                self.outputs.push(value); *cells += 1;
                if value != 0 { self.possible |= 1u64 << self.case; }
                *cells -= self.values.len(); self.values.clear();
                self.zero_value = false; self.case += 1; self.at = 0; self.phase = TuplePhase::Values;
            }
            TuplePhase::Clear => {
                if self.children.pop().is_some() || self.outputs.pop().is_some() || self.values.pop().is_some() {
                    *cells -= 1;
                } else { self.phase = TuplePhase::Done; }
            }
            TuplePhase::Commit | TuplePhase::Done => {},
        }
        Ok(())
    }
}
fn room(held: usize, extra: usize, capacity: usize) -> Result<(), StructuralRefusal> {
    held.checked_add(extra).filter(|n| *n <= capacity)
        .ok_or(StructuralRefusal::Capacity).map(|_| ())
}

/// Native logical ownership counts; cells are not heap bytes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ExpressionStorage {
    pub catalogue_entries: usize,
    pub indexed_entries: usize,
    /// Fixed-root transaction name; the expression itself stays in catalogue.
    pub pending_index: Option<usize>,
    pub pending_emission: bool,
    pub append_ready: bool,
    pub next_ordinary_lane: usize,
    pub constructor_cursor: usize,
    pub wake_cursor: usize,
    pub posting_entries: usize,
    pub constructors: usize,
    pub active_constructors: usize,
    /// Actual retained tuple evaluators, including a nullary seed if present.
    pub active_tuples: usize,
    /// Reserved roots/axes of admitted, active and partially built birth tickets.
    pub ticket_cells: usize,
    pub accounted_cells: usize,
    pub catalogue_cells: usize,
    /// Immutable domain groups and original constructor positions (D + P).
    pub plan_cells: usize,
    pub plan_ready: bool,
    /// Fixed root, immutable plan and catalogue are excluded; None is underflow.
    pub pending_cells: Option<usize>,
    pub complete: bool,
    pub poisoned: bool,
}
pub struct Expressions<V, P> {
    language: Arc<Language<V, P>>,
    model: Arc<dyn Abstract<V, P>>,
    inputs: Arc<[Vec<u64>]>,
    catalogue: Vec<Arc<Expression>>,
    plan: DomainPlan,
    indexed: usize,
    indexer: Indexer,
    posting_entries: usize,
    constructors: Vec<Constructor>,
    constructor_at: usize,
    active_constructors: usize,
    active_tuples: usize,
    ticket_cells: usize,
    wake_at: usize,
    // A scalar name in the fixed root, never a second expression owner.
    // Leaves also finish this transaction, but do not emit an external node.
    pending_append: Option<(usize, bool)>,
    leaf: usize,
    leaf_outputs: Vec<u64>,
    seed_alternative: usize,
    seed_tuple: Option<Tuple>,
    seeded: bool,
    next_lane: usize,
    cells: usize,
    catalogue_cells: usize,
    max_size: usize,
    cleaning: bool,
    cleanup_domain: usize,
    complete: bool,
    poisoned: bool,
}
impl<V, P> Expressions<V, P> {
    pub(super) fn new(language: Arc<Language<V, P>>, model: Arc<dyn Abstract<V, P>>,
        inputs: Arc<[Vec<u64>]>) -> Self {
        Self { language, model, inputs, catalogue: Vec::new(), plan: DomainPlan::new(),
            indexed: 0, indexer: Indexer::new(), posting_entries: 0, constructors: Vec::new(),
            constructor_at: 0, active_constructors: 0, active_tuples: 0, ticket_cells: 0,
            wake_at: 0, pending_append: None, leaf: 0, leaf_outputs: Vec::new(),
            seed_alternative: 0, seed_tuple: None, seeded: false, next_lane: 0,
            cells: 1, catalogue_cells: 0, max_size: 0, cleaning: false,
            cleanup_domain: 0, complete: false, poisoned: false }
    }
    pub(crate) fn retained_cells(&self) -> usize { self.cells }
    pub(crate) fn storage_summary(&self) -> ExpressionStorage {
        ExpressionStorage { catalogue_entries: self.catalogue.len(), indexed_entries: self.indexed,
            pending_index: self.pending_append.map(|p| p.0),
            pending_emission: self.pending_append.is_some_and(|p| p.1),
            append_ready: self.append_ready(), next_ordinary_lane: self.next_lane,
            constructor_cursor: self.constructor_at,
            wake_cursor: self.wake_at,
            posting_entries: self.posting_entries, constructors: self.constructors.len(),
            active_constructors: self.active_constructors, active_tuples: self.active_tuples,
            ticket_cells: self.ticket_cells,
            accounted_cells: self.cells, catalogue_cells: self.catalogue_cells,
            plan_cells: self.plan.cells, plan_ready: self.plan.ready(),
            pending_cells: self.cells.checked_sub(1).and_then(|n| n.checked_sub(self.catalogue_cells))
                .and_then(|n| n.checked_sub(self.plan.cells)),
            complete: self.complete, poisoned: self.poisoned }
    }
    fn selected_lane(&self) -> Option<usize> {
        let active = [!self.seeded, self.active_constructors != 0];
        (0..2).map(|offset| (self.next_lane + offset) % 2).find(|lane| active[*lane])
    }
    fn append_ready(&self) -> bool {
        self.pending_append.is_some() && self.indexed == self.catalogue.len()
            && self.wake_at == self.constructors.len()
    }
    // Child/output arrays have already been paid and transfer into the catalogue.
    fn reserve_publish(&mut self, capacity: usize) -> Result<(), StructuralRefusal> {
        room(self.cells, 2, capacity)?;
        self.catalogue.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)
    }
    fn publish(&mut self, expression: Arc<Expression>, emit: bool) {
        let children = match &expression.body { Body::Leaf(_) => 0, Body::Node { children, .. } => children.len() };
        self.catalogue_cells += 2 + children + expression.summary.outputs.len();
        self.cells += 2; self.max_size = self.max_size.max(expression.size);
        self.pending_append = Some((self.catalogue.len(), emit));
        self.catalogue.push(expression);
    }
    pub(crate) fn advance<M: WorkMeter + ?Sized>(&mut self, meter: &mut M, capacity: usize)
        -> Result<Progress, Failure<M::Error>> {
        if self.poisoned { return Err(StructuralRefusal::Poisoned.into()); }
        self.poisoned = true;
        let result = (|| {
            meter.charge(1).map_err(Failure::Work)?;
            room(self.cells, 0, capacity)?;
            if !self.plan.ready() {
                self.plan.step(&self.language, &*self.model, &mut self.constructors, &mut self.cells, capacity)?;
                if self.plan.ready() { self.wake_at = self.constructors.len(); }
                return Ok(Progress::Advanced);
            }
            if self.complete { return Ok(Progress::Complete); }
            if self.cleaning { return Ok(self.cleanup()); }
            if let Some((arrival, emit)) = self.pending_append {
                // One append owns a finite transaction. New ordinary work is
                // blocked until all postings are committed and every retained
                // constructor has received its paid wake visit. These phases
                // never change either ordinary scheduling cursor.
                if self.indexed < self.catalogue.len() {
                    self.index(capacity)?;
                    return Ok(Progress::Advanced);
                }
                if self.wake_at < self.constructors.len() {
                    self.wake();
                    return Ok(Progress::Advanced);
                }
                self.pending_append = None;
                return Ok(if emit { Progress::Expression(Arc::clone(&self.catalogue[arrival])) }
                    else { Progress::Advanced });
            }
            let Some(lane) = self.selected_lane() else {
                // Every append has committed and completed its finite wake
                // pass; all seeds and constructor continuations are exhausted.
                self.cleaning = true;
                return Ok(Progress::Advanced);
            };
            let result = match lane {
                0 => self.seed(capacity),
                _ => self.construct(capacity),
            }.map_err(Failure::Structural)?;
            self.next_lane = (lane + 1) % 2;
            Ok(result)
        })();
        self.poisoned = false;
        result
    }
    fn seed(&mut self, capacity: usize) -> Result<Progress, StructuralRefusal> {
        if self.seed_tuple.is_some() { return self.evaluate(true, capacity); }
        if self.leaf < self.language.pool(0)? {
            if self.leaf_outputs.len() < self.inputs.len() {
                room(self.cells, 1, capacity)?;
                self.leaf_outputs.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                let case = self.leaf_outputs.len();
                let value = if self.leaf < self.language.inputs { self.inputs[case][self.leaf] }
                    else { self.model.literal(&self.language.literals[self.leaf - self.language.inputs]) };
                self.leaf_outputs.push(value & self.model.universe()); self.cells += 1;
            } else {
                self.reserve_publish(capacity)?;
                let expression = Arc::new(Expression { owner: Arc::clone(&self.language.owner),
                    body: Body::Leaf(self.leaf), summary: Summary {
                        outputs: Arc::from(std::mem::take(&mut self.leaf_outputs)),
                        dependencies: if self.leaf < self.language.inputs { 1u64 << self.leaf } else { 0 },
                    }, size: 0 });
                self.publish(expression, false); self.leaf += 1;
            }
        } else if self.seed_alternative < self.language.expression_alternatives()?
            && self.language.extent != Extent::Finite(0) {
            if self.language.arity(self.seed_alternative) == 0 {
                room(self.cells, 1, capacity)?;
                self.seed_tuple = Some(Tuple::new(self.seed_alternative));
                self.cells += 1; self.active_tuples += 1;
            } else { self.seed_alternative += 1; }
        } else { self.seeded = true; }
        Ok(Progress::Advanced)
    }
    fn commit_index(&mut self) {
        self.indexed += 1; self.indexer = Indexer::new();
        // Ordinary publication is suspended until this one finite pass ends.
        self.wake_at = 0;
    }
    fn index(&mut self, capacity: usize) -> Result<Progress, StructuralRefusal> {
        let child = &self.catalogue[self.indexed];
        if matches!(self.language.extent, Extent::Finite(limit) if child.size >= limit)
            || self.indexer.domain == self.plan.groups.len() {
            self.commit_index();
        } else if self.indexer.phase == IndexPhase::Cases {
            if child.summary.outputs[self.indexer.case] & self.plan.groups[self.indexer.domain].domain != 0 {
                self.indexer.mask |= 1u64 << self.indexer.case;
            }
            self.indexer.case += 1;
            if self.indexer.case == self.inputs.len() { self.indexer.phase = IndexPhase::Publish; }
        } else {
            if self.indexer.mask != 0 {
                room(self.cells, 1, capacity)?;
                let postings = &mut self.plan.groups[self.indexer.domain].postings;
                postings.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                let minimum_size = postings.last().map_or(child.size, |p| p.minimum_size.min(child.size));
                postings.push(Posting { arrival: self.indexed, mask: self.indexer.mask, minimum_size });
                self.cells += 1; self.posting_entries += 1;
            }
            self.indexer.domain += 1; self.indexer.case = 0; self.indexer.mask = 0;
            self.indexer.phase = IndexPhase::Cases;
        }
        Ok(Progress::Advanced)
    }
    fn wake(&mut self) {
        let cursor = &mut self.constructors[self.wake_at];
        if cursor.idle() && cursor.observed < self.indexed {
            cursor.merge(self.indexed); self.active_constructors += 1;
        }
        self.wake_at += 1;
    }
    fn rotate(&mut self) { self.constructor_at = (self.constructor_at + 1) % self.constructors.len(); }
    fn construct(&mut self, capacity: usize) -> Result<Progress, StructuralRefusal> {
        if self.constructors[self.constructor_at].idle() {
            self.rotate(); return Ok(Progress::Advanced);
        }
        if self.constructors[self.constructor_at].tuple.is_some() {
            return self.evaluate(false, capacity);
        }
        let cursor = &mut self.constructors[self.constructor_at];
        let before = cursor.ticket_cells;
        let result = cursor.step(&self.plan.groups, &self.catalogue, self.indexed,
            self.language.extent, &mut self.cells, capacity);
        // No growing scan is hidden in production storage/retention summaries.
        self.ticket_cells = self.ticket_cells - before + cursor.ticket_cells;
        match result? {
            ConstructorStep::Advanced => {},
            ConstructorStep::StartedTuple => { self.active_tuples += 1; },
            ConstructorStep::QuantumComplete => { self.rotate(); },
            ConstructorStep::Idle => { self.active_constructors -= 1; self.rotate(); },
        }
        Ok(Progress::Advanced)
    }
    fn evaluate(&mut self, seed: bool, capacity: usize) -> Result<Progress, StructuralRefusal> {
        let tuple = if seed { self.seed_tuple.as_ref().unwrap() }
            else { self.constructors[self.constructor_at].tuple.as_ref().unwrap() };
        if tuple.phase == TuplePhase::Commit && tuple.possible != 0 {
            self.reserve_publish(capacity)?;
            let mut tuple = if seed { self.seed_tuple.take().unwrap() }
                else { self.constructors[self.constructor_at].tuple.take().unwrap() };
            let expression = Arc::new(Expression { owner: Arc::clone(&self.language.owner),
                body: Body::Node { alternative: tuple.alternative, children: std::mem::take(&mut tuple.children) },
                summary: Summary { outputs: Arc::from(std::mem::take(&mut tuple.outputs)), dependencies: tuple.dependencies },
                size: tuple.size });
            self.cells -= 1; self.active_tuples -= 1;
            if seed { self.seed_alternative += 1; }
            else {
                let cursor = &mut self.constructors[self.constructor_at];
                cursor.finish_tuple(None);
                self.rotate();
            }
            self.publish(expression, true);
            return Ok(Progress::Advanced);
        }
        if tuple.phase == TuplePhase::Done {
            let tuple = if seed { self.seed_tuple.take().unwrap() }
                else { self.constructors[self.constructor_at].tuple.take().unwrap() };
            self.cells -= 1; self.active_tuples -= 1;
            if seed { self.seed_alternative += 1; }
            else {
                let cursor = &mut self.constructors[self.constructor_at];
                cursor.finish_tuple(Some(tuple.reset_from)); self.rotate();
            }
        } else if seed {
            let tuple = self.seed_tuple.as_mut().unwrap();
            if tuple.phase == TuplePhase::Commit { tuple.reject(0); }
            else { tuple.step(&self.language, &*self.model, self.inputs.len(), &self.catalogue,
                &self.plan.groups, &[], &mut self.cells, capacity)?; }
        } else {
            let cursor = &mut self.constructors[self.constructor_at];
            let tuple = cursor.tuple.as_mut().unwrap();
            if tuple.phase == TuplePhase::Commit { tuple.reject(cursor.axes.len()); }
            else { tuple.step(&self.language, &*self.model, self.inputs.len(), &self.catalogue,
                &self.plan.groups, &cursor.active.as_ref().unwrap().axes, &mut self.cells, capacity)?; }
        }
        Ok(Progress::Advanced)
    }
    fn cleanup(&mut self) -> Progress {
        if let Some(cursor) = self.constructors.last_mut() {
            debug_assert!(cursor.idle() && cursor.ticket_cells == 0 && cursor.tuple.is_none());
            if cursor.axes.pop().is_some() { self.cells -= 1; }
            else { self.constructors.pop(); self.cells -= 1; }
        } else if let Some(group) = self.plan.groups.get_mut(self.cleanup_domain) {
            if group.postings.pop().is_some() { self.cells -= 1; self.posting_entries -= 1; }
            else { self.cleanup_domain += 1; }
        } else { self.complete = true; return Progress::Complete; }
        Progress::Advanced
    }
}

#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct AxisCensus {
    pub domain_index: usize, pub domain: u64,
    pub consumed: usize, pub before: usize, pub after: usize,
}
#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct TupleCensus {
    pub alternative: usize, pub phase: &'static str, pub at: usize, pub case: usize,
    pub reset_from: usize, pub size: usize, pub dependencies: u64,
    pub valid: u64, pub possible: u64,
    pub children: Vec<usize>, pub outputs: Vec<u64>, pub values: Vec<u64>,
}
#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct ConstructorCensus {
    pub slot: usize, pub alternative: usize, pub phase: &'static str,
    pub scan: usize, pub newest: Option<usize>, pub anchor: usize,
    pub watermark: usize, pub observed: usize, pub axes: Vec<AxisCensus>,
    pub service: bool, pub sleeping: bool, pub heap: String, pub ticket_cells: usize, pub next_turn: usize,
    pub building: Option<TicketCensus>, pub active: Option<TicketCensus>, pub tickets: Vec<TicketCensus>,
    pub tuple: Option<TupleCensus>,
}
#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct TicketCensus {
    pub newest: usize, pub anchor: usize, pub watermark: usize,
    pub lower_bound: usize, pub turn: usize, pub phase: String, pub scan: usize, pub carry: usize,
    pub axes: Vec<(usize, usize, usize, Option<(usize, u64)>)>,
}
#[cfg(test)]
impl Ticket {
    fn census(&self, groups: &[DomainGroup]) -> TicketCensus {
        TicketCensus { newest: self.newest, anchor: self.anchor, watermark: self.watermark,
            lower_bound: self.lower_bound, turn: self.turn, phase: format!("{:?}", self.phase),
            scan: self.scan, carry: self.carry, axes: self.axes.iter().map(|axis| (axis.domain,
                axis.end, axis.coordinate, groups[axis.domain].postings.get(axis.coordinate)
                    .map(|p| (p.arrival, p.mask)))).collect() }
    }
}
#[cfg(test)]
impl Tuple {
    fn phase_name(&self) -> &'static str {
        match self.phase { TuplePhase::Arguments => "Arguments", TuplePhase::Values => "Values",
            TuplePhase::Apply => "Apply", TuplePhase::Commit => "Commit",
            TuplePhase::Clear => "Clear", TuplePhase::Done => "Done" }
    }
    fn census(&self) -> TupleCensus {
        TupleCensus { alternative: self.alternative, phase: self.phase_name(), at: self.at,
            case: self.case, reset_from: self.reset_from, size: self.size,
            dependencies: self.dependencies, valid: self.valid, possible: self.possible,
            children: self.children.iter().map(|c| Arc::as_ptr(c) as usize).collect(),
            outputs: self.outputs.clone(), values: self.values.clone() }
    }
}
#[cfg(test)]
impl Constructor {
    fn phase_name(&self) -> &'static str {
        match self.phase { ConstructorPhase::Merge => "Merge", ConstructorPhase::Freeze => "Freeze",
            ConstructorPhase::Anchor => "Anchor", ConstructorPhase::Bounds => "Bounds",
            ConstructorPhase::Publish => "Publish", ConstructorPhase::Idle => "Idle" }
    }
    fn service_phase_name(&self) -> &'static str {
        match self.heap {
            HeapPhase::Up(_) => "HeapUp", HeapPhase::Choose(_) => "HeapChoose",
            HeapPhase::Swap(_, _) => "HeapSwap", HeapPhase::Ready => {
                if let Some(tuple) = &self.tuple { return tuple.phase_name(); }
                if let Some(ticket) = &self.active { return match ticket.phase {
                    TicketPhase::Ready => "TicketReady", TicketPhase::Reset => "TicketReset",
                    TicketPhase::Carry => "TicketCarry", TicketPhase::Retire => "TicketRetire",
                }; }
                if self.service { "TicketSelect" } else { self.phase_name() }
            }
        }
    }

}
#[cfg(test)]
impl<V, P> Expressions<V, P> {
    pub(crate) fn progress_census(&self) -> ExpressionCensus {
        let lane = if self.pending_append.is_none() { self.selected_lane() } else { None };
        let cursor = self.constructors.get(self.constructor_at);
        let tuple = if lane == Some(0) { self.seed_tuple.as_ref() }
            else if lane == Some(1) { cursor.and_then(|c| c.tuple.as_ref()) } else { None };
        let indexing = self.pending_append.is_some() && self.indexed < self.catalogue.len();
        let phase = if !self.plan.ready() { match self.plan.phase {
            PlanPhase::Position => "PlanPosition", PlanPhase::Lookup => "PlanLookup",
            PlanPhase::Publish => "PlanPublish", PlanPhase::Done => unreachable!(),
        } } else if self.complete { "Done" } else if self.cleaning { "Cleanup" }
        else if self.pending_append.is_some() {
            if indexing { match self.indexer.phase {
                IndexPhase::Cases => "IndexCases", IndexPhase::Publish => "IndexPublish",
            } } else if self.append_ready() { "Handoff" } else { "Wake" }
        } else { match lane {
            Some(0) => tuple.map_or("Seeds", Tuple::phase_name),
            Some(1) => tuple.map_or_else(|| cursor.unwrap().service_phase_name(), Tuple::phase_name),
            _ => "Quiescent",
        } };
        ExpressionCensus { phase, max_emitted_size: self.max_size, catalogue_entries: self.catalogue.len(),
            indexed_entries: self.indexed, posting_entries: self.posting_entries,
            pending_index: self.pending_append.map(|p| p.0),
            pending_emission: self.pending_append.is_some_and(|p| p.1),
            append_ready: self.append_ready(), next_ordinary_lane: self.next_lane,
            constructor_cursor: self.constructor_at,
            wake_cursor: self.wake_at,
            pending_owner: self.pending_append.map(|(arrival, _)| Arc::as_ptr(&self.catalogue[arrival]) as usize),
            constructors: self.constructors.len(), active_constructors: self.active_constructors,
            active_tuples: self.active_tuples,
            newest: cursor.and_then(|c| c.newest), anchor: cursor.map_or(0, |c| c.anchor),
            alternative: if !self.plan.ready() { self.plan.alternative }
                else if lane == Some(1) { cursor.unwrap().alternative } else { self.seed_alternative },
            leaf: self.leaf,
            argument: tuple.map_or_else(|| if lane == Some(1) { cursor.unwrap().scan } else { 0 }, |t| t.at),
            case: tuple.map_or_else(|| if indexing { self.indexer.case } else { self.leaf_outputs.len() }, |t| t.case),
            carry: cursor.and_then(|c| c.active.as_ref()).map_or(0, |t| t.carry),
            tickets: cursor.map_or(0, |c| c.tickets.len()),
            ticket_cells: cursor.map_or(0, |c| c.ticket_cells),
            active_lower_bound: cursor.and_then(|c| c.active.as_ref()).map(|t| t.lower_bound),
            discovering: cursor.is_some_and(|c| !c.sleeping && !c.service && c.active.is_none() && c.heap == HeapPhase::Ready),
            retained_cells: self.cells,
            pending_cells: self.cells - 1 - self.catalogue_cells - self.plan.cells,
            poisoned: self.poisoned }
    }
    /// New admission scheduling is tested separately from retry-only allocation
    /// pauses: a tight admission may legally service an already owned ticket.
    pub(super) fn ticket_admission(&self) -> bool {
        self.pending_append.is_none() && self.selected_lane() == Some(1)
            && self.constructors.get(self.constructor_at).is_some_and(|c|
                !c.sleeping && !c.service && c.active.is_none() && c.heap == HeapPhase::Ready
                && c.phase == ConstructorPhase::Anchor
                && c.axes.get(c.anchor).is_some_and(|a| a.after > a.before))
    }
    pub(super) fn plan_census(&self) -> (usize, usize, usize, u64, usize, usize, Vec<(u64, Vec<(usize, usize)>)>) {
        let phase = match self.plan.phase { PlanPhase::Position => 0, PlanPhase::Lookup => 1,
            PlanPhase::Publish => 2, PlanPhase::Done => 3 };
        (phase, self.plan.alternative, self.plan.anchor, self.plan.domain, self.plan.lookup,
            self.plan.cells, self.plan.groups.iter().map(|g| (g.domain, g.positions.clone())).collect())
    }
    pub(super) fn index_census(&self) -> Option<(usize, usize, usize, usize, Option<u64>, usize, u64, usize, Arc<[u64]>)> {
        self.catalogue.get(self.indexed).map(|child| (Arc::as_ptr(&self.language.owner) as usize,
            Arc::as_ptr(child) as usize, self.indexed, self.indexer.domain,
            self.plan.groups.get(self.indexer.domain).map(|g| g.domain), self.indexer.case,
            self.indexer.mask, usize::from(self.indexer.phase == IndexPhase::Publish),
            Arc::clone(&child.summary.outputs)))
    }
    pub(super) fn posting_census(&self) -> Vec<(u64, Vec<(usize, u64)>)> {
        self.plan.groups.iter().map(|g| (g.domain,
            g.postings.iter().map(|p| (p.arrival, p.mask)).collect())).collect()
    }
    pub(super) fn constructor_census(&self) -> Vec<ConstructorCensus> {
        self.constructors.iter().enumerate().map(|(slot, c)| ConstructorCensus {
            slot, alternative: c.alternative, phase: c.phase_name(), scan: c.scan,
            newest: c.newest, anchor: c.anchor, watermark: c.watermark, observed: c.observed,
            service: c.service, sleeping: c.sleeping, heap: format!("{:?}", c.heap), ticket_cells: c.ticket_cells, next_turn: c.next_turn,
            building: c.building.as_ref().map(|t| t.census(&self.plan.groups)),
            active: c.active.as_ref().map(|t| t.census(&self.plan.groups)),
            tickets: c.tickets.iter().map(|t| t.census(&self.plan.groups)).collect(),
            axes: c.axes.iter().map(|a| AxisCensus { domain_index: a.domain,
                domain: self.plan.groups[a.domain].domain, consumed: a.consumed, before: a.before,
                after: a.after }).collect(),
            tuple: c.tuple.as_ref().map(Tuple::census),
        }).collect()
    }
    pub(super) fn seed_census(&self) -> Option<TupleCensus> { self.seed_tuple.as_ref().map(Tuple::census) }
}

#[cfg(test)]
#[path = "streaming/ticket_courts.rs"]
mod ticket_courts;
