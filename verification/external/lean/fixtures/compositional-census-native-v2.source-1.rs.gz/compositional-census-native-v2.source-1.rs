//! Test-only evidence from actual immutable languages and owned addresses.
//! Decode and materialize use independent bounded audit meters. They neither
//! replay acquisition nor spend/reset its native work allowance.
use super::*;
use crate::program::observer::lifecycle_export::identity;
use serde_json::{json, Value as Json};

const AUDIT_ALLOWANCE: usize = 1_000_000;
struct AuditWork { remaining: usize }
impl AuditWork {
    fn new() -> Self { Self { remaining: AUDIT_ALLOWANCE } }
    fn used(&self) -> usize { AUDIT_ALLOWANCE - self.remaining }
}
impl WorkMeter for AuditWork {
    type Error = &'static str;
    fn charge(&mut self, units: usize) -> Result<(), Self::Error> {
        self.remaining = self.remaining.checked_sub(units).ok_or("structural audit work exhausted")?;
        Ok(())
    }
}

pub(crate) struct Owners { owners: Vec<Arc<()>> }
impl Owners {
    pub(crate) fn new() -> Self { Self { owners: Vec::new() } }

    fn address(&mut self, address: &Address) -> Json {
        let mut value = json!({"owner":identity(&mut self.owners, &address.owner),
            "instructions":address.instructions.iter().map(|i|json!({
                "alternative":i.alternative,"operands":i.operands})).collect::<Vec<_>>(),
            "output":address.output});
        if !address.children.is_empty() {
            value["children"] = Json::Array(address.children.iter().map(|child| json!({
                "instruction":child.instruction,"side":child.side,"address":self.address(&child.address)
            })).collect());
        }
        value
    }
    fn language<V, P>(&mut self, language: &Language<V, P>, value: fn(&V) -> Json,
        primitive: fn(&P) -> Json, program: fn(&Program<V, P>) -> Json) -> Json {
        let extent = match language.extent {
            Extent::Finite(steps) => json!({"kind":"Finite","steps":steps}),
            Extent::AllFinite => json!({"kind":"AllFinite"}),
        };
        let mut declaration = json!({"owner":identity(&mut self.owners, &language.owner),
            "inputs":language.inputs,"extent":extent,
            "operations":language.operations.iter().map(|o|json!({"primitive":primitive(&o.id),"arity":o.arity})).collect::<Vec<_>>(),
            "literals":language.literals.iter().map(value).collect::<Vec<_>>(),
            "calls":language.calls.iter().map(|(arity,body)|json!({"arity":arity,"program":program(body)})).collect::<Vec<_>>()});
        if language.version == 2 {
            declaration["version"] = json!(2);
            declaration["controls"] = Json::Array(language.controls.iter().map(|control| match control {
                ControlSpec::Branch { yes, no } => json!({"kind":"Branch", "yes":self.language(yes, value, primitive, program), "no":self.language(no, value, primitive, program)}),
                ControlSpec::Fold { body } => json!({"kind":"Fold", "body":self.language(body, value, primitive, program)}),
            }).collect());
        }
        declaration
    }

    pub(crate) fn snapshot<V: Clone, P: Clone>(
        &mut self,
        language: &Arc<Language<V, P>>,
        encoded: &Encoded,
        value: fn(&V) -> Json,
        primitive: fn(&P) -> Json,
        program: fn(&Program<V, P>) -> Json,
    ) -> Json {
        // Read the exact retained catalogue and original address. In particular,
        // no alternatives or operands are reconstructed from the emitted bits.
        let declaration = self.language(language, value, primitive, program);
        let original = self.address(encoded.address());

        let mut decode_work = AuditWork::new();
        let mut decoder = language.decode(Arc::clone(&encoded.bits));
        while !decoder.advance(&mut decode_work).unwrap_or_else(|_| panic!("native structural audit decode refused")) {}
        let consumed_bits = decoder.consumed_bits();
        let decoded = decoder.finish().unwrap_or_else(|_| panic!("native structural audit decode incomplete"));
        let decoded_address = self.address(&decoded);

        let (materialized, materialize_work) = materialize(language, encoded.address().clone());
        let (decoded_materialized, decoded_materialize_work) = materialize(language, decoded);
        json!({"language":declaration,"address":original,"word":encoded.bits(),
            "decoded_address":decoded_address,"consumed_bits":consumed_bits,
            "materialized":program(&materialized),"decoded_materialized":program(&decoded_materialized),
            "audit":{"allowance":AUDIT_ALLOWANCE,"decode_work":decode_work.used(),
                "materialize_work":materialize_work,"decoded_materialize_work":decoded_materialize_work}})
    }
}

fn materialize<V: Clone, P: Clone>(language: &Arc<Language<V, P>>, address: Address) -> (Program<V, P>, usize) {
    let mut work = AuditWork::new();
    let mut builder = language.materialize(address).unwrap_or_else(|_| panic!("native structural audit has foreign address owner"));
    while !builder.advance(&mut work).unwrap_or_else(|_| panic!("native structural audit materialization refused")) {}
    let body = builder.finish().unwrap_or_else(|_| panic!("native structural audit materialization incomplete"));
    (body, work.used())
}
