//! Observed world outcomes and failed execution are different evidence domains.

use super::{Cut, LifeReport, Pulse};

/// What the environment actually reports about an episode's end.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum TerminalKind {
    /// The environment explicitly reports death.
    Death,
    /// The environment explicitly reports expiry of its episode clock.
    Time,
    /// The environment explicitly reports completion of its goal.
    Completed,
    /// The environment reports an end without identifying its cause.
    Ended,
}

/// Exact observation alphabet. The key is owned by the reading representation;
/// an end has no successor key, and refusal is not a successful stationary step.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum ObservedWorldOutcome {
    Next(u64),
    Refused(u64),
    End(TerminalKind),
}

/// Whether a valid successor observation has been obtained after the terminal.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Resumption {
    /// The adapter observed a valid resumed state.
    Resumed,
    /// The episode ended and execution must stop.
    Stopped,
}

/// A successfully received and interpreted action outcome, never a channel error.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObservedAction {
    /// A continuing world step, whose state is available through Habitat.
    Step,
    /// A semantically refused action with a valid continuing observation.
    Refused,
    /// An actual terminal, together with independently established resumption.
    Terminal {
        kind: TerminalKind,
        resumption: Resumption,
    },
}

impl ObservedAction {
    /// Preserve an explicitly known semantic cut and its adapter-owned reset fact.
    /// This function accepts no infrastructure failure.
    pub fn cut(cut: Cut, resumption: Resumption) -> Self {
        match cut {
            Cut::Refusal => Self::Refused,
            Cut::Death => Self::Terminal {
                kind: TerminalKind::Death,
                resumption,
            },
            Cut::Time => Self::Terminal {
                kind: TerminalKind::Time,
                resumption,
            },
            Cut::Completed => Self::Terminal {
                kind: TerminalKind::Completed,
                resumption,
            },
            Cut::Ended => Self::Terminal {
                kind: TerminalKind::Ended,
                resumption,
            },
        }
    }

    /// Legacy semantic bookkeeping is reached only after the fallible boundary.
    pub(super) fn semantic_cut(self) -> Option<Cut> {
        match self {
            Self::Step => None,
            Self::Refused => Some(Cut::Refusal),
            Self::Terminal { kind, .. } => Some(match kind {
                TerminalKind::Death => Cut::Death,
                TerminalKind::Time => Cut::Time,
                TerminalKind::Completed => Cut::Completed,
                TerminalKind::Ended => Cut::Ended,
            }),
        }
    }
}

/// The boundary at which the attempted action failed.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ActionStage {
    /// The adapter budget prevented dispatch; this is no observed refusal.
    Budget,
    Dispatch,
    Receive,
    Decode,
    Restart,
    Replay,
}

/// Whether execution occurred in the live world or inside a restored dream scope.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ActionContext {
    Live,
    Imagined,
}

/// Whether terminal metadata belongs to the episode or to this exact action.
/// A failed reset may retain the old episode boundary without observing a new
/// action outcome. Stages and action numbers do not establish this distinction.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TerminalScope {
    Episode,
    Action,
}

/// Exact operation at the failed boundary; control operations invent no action.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ActionOperation<A> {
    Act(A),
    Begin,
    Checkpoint,
    Restore,
}

/// A failed attempt. Absence of a valid successor is not a negative world law.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ActionFailure<A> {
    /// Exact operation; a control failure never invents an attempted gesture.
    pub operation: ActionOperation<A>,
    /// Failed boundary.
    pub stage: ActionStage,
    /// Original adapter/replay error, retained without semantic reinterpretation.
    pub cause: String,
    /// Retained terminal metadata; its origin is explicit in terminal_scope.
    pub terminal: Option<TerminalKind>,
    pub terminal_scope: TerminalScope,
    /// Dream failures remain distinguishable from physical execution failures.
    pub context: ActionContext,
}

impl<A> ActionFailure<A> {
    /// Construct an execution failure without claiming a world observation.
    pub fn new(action: A, stage: ActionStage, cause: impl Into<String>) -> Self {
        Self {
            operation: ActionOperation::Act(action),
            stage,
            cause: cause.into(),
            terminal: None,
            terminal_scope: TerminalScope::Episode,
            context: ActionContext::Live,
        }
    }
    /// Initialization failed before there was any admissible action.
    pub fn begin(stage: ActionStage, cause: impl Into<String>) -> Self {
        Self {
            operation: ActionOperation::Begin,
            stage,
            cause: cause.into(),
            terminal: None,
            terminal_scope: TerminalScope::Episode,
            context: ActionContext::Live,
        }
    }
    /// A checkpoint failure is not a physical action.
    pub fn checkpoint(stage: ActionStage, cause: impl Into<String>) -> Self {
        Self {
            operation: ActionOperation::Checkpoint,
            stage,
            cause: cause.into(),
            terminal: None,
            terminal_scope: TerminalScope::Episode,
            context: ActionContext::Imagined,
        }
    }
    /// A failed restore leaves the world unknown.
    pub fn restore(stage: ActionStage, cause: impl Into<String>) -> Self {
        Self {
            operation: ActionOperation::Restore,
            stage,
            cause: cause.into(),
            terminal: None,
            terminal_scope: TerminalScope::Episode,
            context: ActionContext::Imagined,
        }
    }
    /// The original action, when execution actually attempted one.
    pub fn action(&self) -> Option<&A> {
        match &self.operation {
            ActionOperation::Act(action) => Some(action),
            _ => None,
        }
    }
    pub(super) fn with_restore_failure(mut self, restore: &Self) -> Self {
        self.cause.push_str(&format!(
            "; checkpoint restore also failed ({:?}): {}",
            restore.stage, restore.cause
        ));
        self
    }
    /// Preserve the episode boundary without claiming this action observed it.
    pub fn after_terminal(mut self, terminal: TerminalKind) -> Self {
        self.terminal = Some(terminal);
        self.terminal_scope = TerminalScope::Episode;
        self
    }
    /// The adapter received this action's terminal outcome, then a later
    /// operation failed. The exact Act owner is retained; no successor is known.
    pub fn after_action_terminal(action: A, stage: ActionStage, cause: impl Into<String>, kind: TerminalKind) -> Self {
        let mut failure = Self::new(action, stage, cause);
        failure.terminal = Some(kind);
        failure.terminal_scope = TerminalScope::Action;
        failure
    }
    /// Current-operation evidence only; historical boundaries and foreign
    /// operation owners cannot supply an observation to this attempted action.
    pub(super) fn observed_terminal(&self, action: &A) -> Option<ObservedAction>
    where A: PartialEq {
        if self.terminal_scope != TerminalScope::Action || self.action() != Some(action) {
            return None;
        }
        self.terminal.map(|kind| ObservedAction::Terminal {
            kind,
            resumption: Resumption::Stopped,
        })
    }
    pub(super) fn imagined(mut self) -> Self {
        self.context = ActionContext::Imagined;
        self
    }
}
impl<A> std::fmt::Display for ActionFailure<A> {
    fn fmt(&self, out: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(out, "{:?} {:?}: {}", self.context, self.stage, self.cause)
    }
}
impl<A: std::fmt::Debug> std::error::Error for ActionFailure<A> {}

/// One lifecycle call. A terminal stop supplies no invented pulse or reset state.
#[derive(Clone, Copy, Debug)]
pub enum StepOutcome<A> {
    /// No action was admitted or available.
    NoAction,
    /// An observed continuing/resumed outcome completed the ordinary lifecycle.
    Pulse(Pulse<A>),
    /// A genuine terminal stops this run before post-state learning.
    Stopped { action: A, terminal: TerminalKind },
}

impl<A> StepOutcome<A> {
    /// Inspect a completed pulse after the caller has handled execution failure.
    /// A stopped terminal and absence of an action both have no lifecycle pulse;
    /// callers that need their distinction must inspect this enum directly.
    pub fn pulse(self) -> Option<Pulse<A>> {
        match self {
            Self::Pulse(pulse) => Some(pulse),
            Self::NoAction | Self::Stopped { .. } => None,
        }
    }
}

/// An observed terminal in the caller's current world identity scope.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TerminalReceipt<A> {
    pub state: u64,
    pub age: u64,
    pub action: A,
    pub kind: TerminalKind,
    pub resumption: Resumption,
}

/// The exact reason a requested run ended.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RunEnd<A> {
    /// All requested lifecycle steps were completed.
    BudgetCompleted,
    /// The organism had no admitted/available action.
    NoAction,
    /// The world reported a terminal without resumption.
    Stopped { action: A, terminal: TerminalKind },
    /// Execution failed. This is not a successful run or an observed death.
    Failed(ActionFailure<A>),
}

/// A retained prefix report together with its explicit termination status.
#[derive(Clone, Debug)]
pub struct LifeRun<A> {
    pub report: LifeReport,
    pub end: RunEnd<A>,
    /// Actual live Habitat::act calls during this run, including failures.
    pub attempted_actions: u64,
}
