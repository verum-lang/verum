//! Full action evidence is distinct from the next usable situation. In
//! particular an automatic restart can expose a new situation while the
//! action's own observation is a terminal. Missing bytes remain missing.
use super::{ActionFailure, Habitat, ObservedAction, Resumption, Sensory, TerminalKind, TerminalScope};
use std::sync::Arc;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CaptureError {
    /// No received observation belongs to this operation.
    UnownedObservation,
    /// A reset body cannot belong to an ordinary step, failure or stopped end.
    UnexpectedResumption,
    /// Two available captures disagree about the same continuing situation.
    ContradictorySuccessor,
}

/// Lossless target materialization can fail independently of observing an end.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TargetError { Unobserved, Missing, Capacity }

/// Immutable evidence from one adapter invocation. Clone permits inspection and
/// replay, not a second execution/learning authority. The dispatch owner still
/// binds this evidence to its pre-action cut. Adapter fidelity is a premise.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ActionCapture<A> {
    action: A,
    result: Result<ObservedAction, ActionFailure<A>>,
    observation: Option<Sensory>,
    resumed: Option<Sensory>,
}
impl<A: PartialEq> ActionCapture<A> {
    pub fn new(action: A, result: Result<ObservedAction, ActionFailure<A>>,
        observation: Option<Sensory>, resumed: Option<Sensory>) -> Result<Self, CaptureError> {
        if observation.is_some() && !match &result {
            Ok(_) => true,
            Err(failure) => failure.terminal_scope == TerminalScope::Action
                && failure.action() == Some(&action) && failure.terminal.is_some(),
        } { return Err(CaptureError::UnownedObservation); }
        if resumed.is_some() && !matches!(result,
            Ok(ObservedAction::Terminal { resumption: Resumption::Resumed, .. })) {
            return Err(CaptureError::UnexpectedResumption);
        }
        Ok(Self { action, result, observation, resumed })
    }

    /// Retain the actual outcome with shared sensor bytes. This performs no
    /// allocation and never includes the separately captured restart body.
    pub fn captured_outcome(&self) -> Result<CapturedOutcome, TargetError> {
        let observed = match &self.result {
            Ok(outcome) => *outcome,
            Err(failure) => failure.observed_terminal(&self.action).ok_or(TargetError::Unobserved)?,
        };
        Ok(CapturedOutcome { observed, observation: self.observation.clone() })
    }

    pub fn target(&self) -> Result<Arc<[u8]>, TargetError> {
        self.captured_outcome()?.target()
    }
}
/// Completed action evidence retained by the causal journal independently of
/// sample selection. Missing sensor bytes remain explicit; resumption bytes
/// cannot replace them. Construction is confined to checked ActionCapture.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CapturedOutcome {
    observed: ObservedAction,
    observation: Option<Sensory>,
}
impl CapturedOutcome {
    pub fn observed(&self) -> ObservedAction { self.observed }
    pub fn observation(&self) -> Option<&Sensory> { self.observation.as_ref() }

    /// Injective, versioned action target, not its restart. Materialization is
    /// deferred until a reader requests it; publication only shares Arc bytes.
    /// This covers a typed subset of finite wires, not a normalized subset law.
    pub fn target(&self) -> Result<Arc<[u8]>, TargetError> {
        let observed = self.observed;
        let tag = match observed {
            ObservedAction::Step => 0,
            ObservedAction::Refused => 1,
            ObservedAction::Terminal { kind, .. } => match kind {
                TerminalKind::Death => 2, TerminalKind::Time => 3,
                TerminalKind::Completed => 4, TerminalKind::Ended => 5,
            },
        };
        let sensory = self.observation.as_ref().ok_or(TargetError::Missing)?;
        let capacity = 18usize.checked_add(sensory.schema().len())
            .and_then(|n| n.checked_add(sensory.body().len())).ok_or(TargetError::Capacity)?;
        let schema_len = u64::try_from(sensory.schema().len()).map_err(|_| TargetError::Capacity)?;
        let body_len = u64::try_from(sensory.body().len()).map_err(|_| TargetError::Capacity)?;
        let mut bytes = Vec::new(); bytes.try_reserve_exact(capacity).map_err(|_| TargetError::Capacity)?;
        bytes.extend([1, tag]); // Carrier version and observed outcome, not reset status.
        bytes.extend_from_slice(&schema_len.to_le_bytes()); bytes.extend_from_slice(sensory.schema());
        bytes.extend_from_slice(&body_len.to_le_bytes()); bytes.extend_from_slice(sensory.body());
        Ok(Arc::from(bytes))
    }
}

impl<A> ActionCapture<A> {
    /// Old adapters and imported histories retain their typed result without
    /// claiming sensor bytes they never captured.
    pub fn unavailable(action: A, result: Result<ObservedAction, ActionFailure<A>>) -> Self {
        Self { action, result, observation: None, resumed: None }
    }
    pub fn action(&self) -> &A { &self.action }
    pub fn result(&self) -> &Result<ObservedAction, ActionFailure<A>> { &self.result }
    pub fn observation(&self) -> Option<&Sensory> { self.observation.as_ref() }
    pub fn resumed(&self) -> Option<&Sensory> { self.resumed.as_ref() }
    /// The continuing situation is the action observation, or a separately
    /// captured resumed observation. Stopped/failed actions supply neither.
    pub fn successor(&self) -> Option<&Sensory> {
        match &self.result {
            Ok(ObservedAction::Step | ObservedAction::Refused) => self.observation(),
            Ok(ObservedAction::Terminal { resumption: Resumption::Resumed, .. }) => self.resumed(),
            _ => None,
        }
    }
    /// Missing data remain unknown. Two present values must name one exact
    /// situation, including its schema, even when scalar addresses coincide.
    pub fn check_successor(&self, actual: Option<&Sensory>) -> Result<(), CaptureError> {
        if self.successor().zip(actual).is_some_and(|(captured, actual)| captured != actual) {
            Err(CaptureError::ContradictorySuccessor)
        } else { Ok(()) }
    }
    pub fn into_result(self) -> Result<ObservedAction, ActionFailure<A>> { self.result }
}

/// Compatibility boundary for a legacy adapter. Only a continuing state is
/// specified as the action result by Habitat::act. A terminal body cannot be
/// inferred even when resumption is Stopped: an adapter may retain an old frame.
pub(super) fn legacy<H: Habitat + ?Sized>(world: &mut H, action: H::Action) -> ActionCapture<H::Action> {
    let result = world.act(action);
    let observation = matches!(result, Ok(ObservedAction::Step | ObservedAction::Refused))
        .then(|| world.sensory()).flatten();
    let resumed = matches!(result, Ok(ObservedAction::Terminal { resumption: Resumption::Resumed, .. }))
        .then(|| world.sensory()).flatten();
    ActionCapture::new(action, result, observation, resumed)
        .expect("legacy capture never attributes a current frame to a terminal")
}

#[cfg(test)]
mod courts {
    use super::*;
    use crate::organism::{ActionStage, TerminalKind};
    use std::sync::Arc;
    fn body(n: u8) -> Sensory { Sensory::new(Arc::from([0]), Arc::from([n])) }
    #[test]
    fn targets_require_the_exact_operation_and_terminal_scope() {
        let failures = [
            ActionFailure::new(7, ActionStage::Receive, "unknown delivery"),
            ActionFailure::new(7, ActionStage::Restart, "old end").after_terminal(TerminalKind::Ended),
            ActionFailure::after_action_terminal(8, ActionStage::Restart, "other act", TerminalKind::Ended),
        ];
        for failure in failures {
            assert_eq!(ActionCapture::new(7, Err(failure), Some(body(1)), None), Err(CaptureError::UnownedObservation));
        }
        let error = ActionFailure::after_action_terminal(7, ActionStage::Restart, "reset lost", TerminalKind::Ended);
        let captured = ActionCapture::new(7, Err(error.clone()), Some(body(2)), None).unwrap();
        assert_eq!(captured.result(), &Err(error));
        assert_eq!(captured.observation(), Some(&body(2)));
        assert_eq!(captured.resumed(), None);
    }
    #[test]
    fn a_reset_is_never_an_ordinary_target_or_a_failed_successor() {
        for result in [Ok(ObservedAction::Step), Ok(ObservedAction::Refused),
            Ok(ObservedAction::Terminal { kind: TerminalKind::Ended, resumption: Resumption::Stopped }),
            Err(ActionFailure::after_action_terminal(7, ActionStage::Restart, "reset lost", TerminalKind::Ended))] {
            assert_eq!(ActionCapture::new(7, result, Some(body(1)), Some(body(2))), Err(CaptureError::UnexpectedResumption));
        }
        let captured = ActionCapture::new(7, Ok(ObservedAction::Terminal {
            kind: TerminalKind::Ended, resumption: Resumption::Resumed }), Some(body(1)), Some(body(2))).unwrap();
        assert_ne!(captured.observation(), captured.resumed());
    }
}
