//! Finite mathematical tree oracle and paid streaming-continuation courts.
use super::*;
use std::collections::BTreeMap;

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Op {
    Seed,
    Unary,
    Wide,
}
struct Model;
impl Abstract<u16, Op> for Model {
    fn universe(&self) -> u64 {
        3
    }
    fn literal(&self, _: &u16) -> u64 {
        1
    }
    fn apply(&self, op: &Op, args: &[u64]) -> u64 {
        match op {
            Op::Seed => 1,
            Op::Unary => args[0],
            Op::Wide => args.iter().fold(0, |a, b| a | b),
        }
    }
}
struct Work {
    left: usize,
    spent: usize,
}
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.left = self.left.checked_sub(n).ok_or(())?;
        self.spent += n;
        Ok(())
    }
}
fn work(n: usize) -> Work {
    Work { left: n, spent: 0 }
}
fn finite() -> Arc<Language<u16, Op>> {
    Language::finite(
        Grammar {
            inputs: 1,
            operations: vec![
                OperationSpec {
                    id: Op::Seed,
                    arity: 0,
                },
                OperationSpec {
                    id: Op::Unary,
                    arity: 1,
                },
                OperationSpec {
                    id: Op::Wide,
                    arity: 2,
                },
            ],
            literals: vec![0],
            max_steps: 3,
        },
        vec![],
    )
    .unwrap()
}
fn inputs() -> Arc<[Vec<u64>]> {
    vec![vec![1], vec![2]].into()
}
type Word = (BigUint, Vec<u8>, Vec<u64>, u64);
fn word(language: &Arc<Language<u16, Op>>, expression: Arc<Expression>) -> Word {
    let (word, length) = word_and_length(language, expression);
    assert!(length <= 3);
    word
}
fn word_and_length(language: &Arc<Language<u16, Op>>, expression: Arc<Expression>) -> (Word, usize) {
    let mut meter = work(usize::MAX);
    let mut flatten = language.flatten(Arc::clone(&expression)).unwrap();
    while !flatten.advance(&mut meter, usize::MAX).unwrap() {}
    let address = flatten.address().unwrap().clone();
    let length = address.len();
    let mut rank = language.rank(address.clone()).unwrap().unwrap();
    while !rank.advance(&mut meter).unwrap() {}
    let mut encoder = language.encode(address).unwrap();
    while !encoder.advance(&mut meter).unwrap() {}
    let encoded = encoder
        .finish()
        .unwrap_or_else(|_| panic!("completed original word"));
    ((
        rank.value().unwrap().clone(),
        encoded.bits().to_vec(),
        expression.summary.outputs.to_vec(),
        expression.summary.dependencies,
    ), length)
}
fn streaming(grant: usize, pauses: bool) -> (Vec<Word>, usize) {
    let language = finite();
    let mut producer = language.expressions(Arc::new(Model), inputs()).unwrap();
    let mut result = Vec::new();
    let mut spent = 0;
    for turn in 0..250_000 {
        if pauses && turn % 17 == 0 {
            let before = producer.progress_census();
            assert!(matches!(
                producer.advance(&mut work(0), usize::MAX),
                Err(Failure::Work(()))
            ));
            assert_eq!(producer.progress_census(), before);
            // Existing retained cells exceed this temporary engineering grant.
            assert!(matches!(
                producer.advance(&mut work(1), 0),
                Err(Failure::Structural(StructuralRefusal::Capacity))
            ));
            assert_eq!(producer.progress_census(), before);
        }
        let mut meter = work(grant);
        while meter.left > 0 {
            match producer.advance(&mut meter, usize::MAX).unwrap() {
                Progress::Advanced => {}
                Progress::Expression(expression) => result.push(word(&language, expression)),
                Progress::Complete => {
                    spent += meter.spent;
                    let census = producer.progress_census();
                    assert_eq!(census.indexed_entries, census.catalogue_entries);
                    assert_eq!(census.active_tuples, 0);
                    assert_eq!(
                        census.pending_cells, 0,
                        "all temporary slab ownership really released"
                    );
                    return (result, spent);
                }
            }
        }
        spent += meter.spent;
    }
    panic!("finite streaming expression language completes");
}
// Independent finite mathematical syntax set. No runtime phase, scheduling,
// work meter, or copy of the former producer occurs in this oracle.
#[derive(Clone)]
enum Tree {
    Leaf(usize),
    Node(usize, Vec<Tree>),
}
fn mathematical_trees() -> Vec<Tree> {
    let mut levels = vec![vec![Tree::Leaf(0), Tree::Leaf(1)]];
    let mut all = Vec::new();
    for size in 1..=3 {
        let mut level = Vec::new();
        if size == 1 {
            level.push(Tree::Node(0, vec![]));
        }
        for child in &levels[size - 1] {
            level.push(Tree::Node(1, vec![child.clone()]));
        }
        for left_size in 0..size {
            for left in &levels[left_size] {
                for right in &levels[size - 1 - left_size] {
                    level.push(Tree::Node(2, vec![left.clone(), right.clone()]));
                }
            }
        }
        all.extend(level.iter().cloned());
        levels.push(level);
    }
    all
}
fn oracle_expression(language: &Arc<Language<u16, Op>>, tree: &Tree) -> Arc<Expression> {
    let (body, outputs, dependencies, size) = match tree {
        Tree::Leaf(at) => (
            Body::Leaf(*at),
            if *at == 0 { vec![1, 2] } else { vec![1, 1] },
            usize::from(*at == 0) as u64,
            0,
        ),
        Tree::Node(alternative, children) => {
            let children: Vec<_> = children
                .iter()
                .map(|tree| oracle_expression(language, tree))
                .collect();
            let outputs = (0..2)
                .map(|case| match *alternative {
                    0 => 1,
                    1 => children[0].summary.outputs[case],
                    2 => children[0].summary.outputs[case] | children[1].summary.outputs[case],
                    _ => unreachable!("finite oracle alphabet"),
                })
                .collect();
            let dependencies = children
                .iter()
                .fold(0, |mask, child| mask | child.summary.dependencies);
            let size = 1 + children.iter().map(|child| child.size).sum::<usize>();
            (
                Body::Node {
                    alternative: *alternative,
                    children,
                },
                outputs,
                dependencies,
                size,
            )
        }
    };
    Arc::new(Expression {
        owner: Arc::clone(&language.owner),
        body,
        summary: Summary {
            outputs: Arc::from(outputs),
            dependencies,
        },
        size,
    })
}
#[test]
fn streaming_complete_original_words_and_summaries_equal_the_finite_tree_oracle_without_duplicates()
{
    let language = finite();
    let mut expected = BTreeMap::new();
    for tree in mathematical_trees() {
        let (rank, bits, summary, deps) = word(&language, oracle_expression(&language, &tree));
        assert!(expected.insert(rank, (bits, summary, deps)).is_none());
    }
    let (streamed, _) = streaming(1, false);
    let mut actual = BTreeMap::new();
    for (rank, bits, summary, deps) in streamed {
        assert!(
            actual.insert(rank, (bits, summary, deps)).is_none(),
            "arrival slabs cannot duplicate a tuple"
        );
    }
    assert_eq!(
        actual, expected,
        "service order changes no connected word, original name or sound summary"
    );
}
#[test]
fn zero_split_and_capacity_pauses_keep_exact_streaming_order_and_successful_work() {
    let one = streaming(1, false);
    assert_eq!(streaming(13, false), one);
    assert_eq!(streaming(7, true), one);
}
#[test]
fn a_deep_generic_unary_expression_arrives_before_a_wide_lower_layer_is_complete() {
    let literals = 16usize;
    let language = Language::finite(
        Grammar {
            inputs: 0,
            operations: vec![
                OperationSpec {
                    id: Op::Wide,
                    arity: 3,
                },
                OperationSpec {
                    id: Op::Seed,
                    arity: 0,
                },
                OperationSpec {
                    id: Op::Unary,
                    arity: 1,
                },
            ],
            literals: (0..literals as u16).collect(),
            max_steps: 3,
        },
        vec![],
    )
    .unwrap();
    let mut producer = language
        .expressions(Arc::new(Model), vec![vec![]; 2].into())
        .unwrap();
    let mut shallow_wide = 0;
    let mut found = false;
    for _ in 0..2_000_000 {
        match producer.advance(&mut work(1), usize::MAX).unwrap() {
            Progress::Expression(expression) => {
                if matches!(&expression.body, Body::Node { alternative: 0, .. })
                    && expression.size == 1
                {
                    shallow_wide += 1;
                }
                if expression.size == 3 {
                    // Three unary nodes are a generic deeper construction; no
                    // primitive value, target period or world law enters here.
                    let mut at = &expression;
                    let mut unary = 0;
                    while let Body::Node {
                        alternative: 2,
                        children,
                    } = &at.body
                    {
                        unary += 1;
                        at = &children[0];
                    }
                    if unary == 3 {
                        assert!(
                            shallow_wide < literals.pow(3),
                            "strict lower-size exhaustion would prevent this emission"
                        );
                        found = true;
                        break;
                    }
                }
            }
            Progress::Advanced => {}
            Progress::Complete => panic!("must observe the actual deep expression"),
        }
    }
    assert!(
        found,
        "streaming construction must make actual depth progress"
    );
}
#[test]
fn a_pending_tuple_survives_local_allocation_refusal_without_a_duplicate_or_skip() {
    let language = finite();
    let mut baseline = language.expressions(Arc::new(Model), inputs()).unwrap();
    let mut paused = language.expressions(Arc::new(Model), inputs()).unwrap();
    let mut refusals = 0;
    let mut expected = Vec::new();
    let mut actual = Vec::new();
    for _ in 0..250_000 {
        // Refuse the precise next growth where possible, not just an empty
        // initial grant. A paid refusal keeps every tuple/owner/cursor intact.
        let before = paused.progress_census();
        let next = paused.advance(&mut work(1), paused.retained_cells());
        let paused_next = match next {
            Err(Failure::Structural(StructuralRefusal::Capacity)) => {
                refusals += 1;
                assert_eq!(paused.progress_census(), before);
                paused.advance(&mut work(1), usize::MAX).unwrap()
            }
            Ok(next) => next,
            _ => panic!("only structural capacity is constrained"),
        };
        let base_next = baseline.advance(&mut work(1), usize::MAX).unwrap();
        match (base_next, paused_next) {
            (Progress::Advanced, Progress::Advanced) => {}
            (Progress::Complete, Progress::Complete) => {
                assert!(
                    refusals > 10,
                    "exercise allocations in seeds, expansion, tuple and publication"
                );
                assert_eq!(actual, expected);
                return;
            }
            (Progress::Expression(a), Progress::Expression(b)) => {
                expected.push(word(&language, a));
                actual.push(word(&language, b));
                assert_eq!(actual.last(), expected.last());
            }
            _ => panic!("refused work may not change the next owned derivation"),
        }
    }
    panic!("same finite continuation must finish");
}

#[test]
fn all_finite_streaming_covers_a_finite_tree_prefix_and_continues_beyond_it() {
    let finite = finite();
    let language = Language::all_finite(finite.inputs, finite.operations.clone(),
        finite.literals.clone(), Vec::new()).unwrap();
    assert!(language.cardinality().is_none(), "the producer has no full-family count");
    let mut expected = BTreeMap::new();
    for tree in mathematical_trees() {
        let expression = oracle_expression(&finite, &tree);
        if expression.size <= 2 {
            let (rank, bits, outputs, dependencies) = word(&finite, expression);
            assert!(expected.insert(rank, (bits, outputs, dependencies)).is_none());
        }
    }
    assert!(expected.len() > 20, "independent nonempty mixed-arity prefix");
    let mut producer = language.expressions(Arc::new(Model), inputs())
        .expect("AllFinite has the actual typed producer");
    let mut seen = BTreeMap::new();
    let mut matched = 0;
    let mut deeper = false;
    for _ in 0..2_000_000 {
        match producer.advance(&mut work(1), 1_000_000).unwrap() {
            Progress::Expression(expression) => {
                let size = expression.size;
                let ((rank, bits, outputs, dependencies), length) = word_and_length(&language, expression);
                assert_eq!(length, size, "the emitted complete word owns every constructed node");
                let actual = (bits, outputs, dependencies);
                if let Some(reference) = expected.get(&rank) {
                    assert_eq!(&actual, reference, "same word, original flat ordinal and summary");
                    matched += 1;
                }
                assert!(seen.insert(rank, actual).is_none(), "one immutable stream cannot repeat a word");
                deeper |= length > 3;
                if matched == expected.len() && deeper {
                    assert!(!producer.storage_summary().complete);
                    return;
                }
            }
            Progress::Advanced => {},
            Progress::Complete => panic!("the constructive source still has longer unary words"),
        }
    }
    panic!("each finite prefix and a deeper word must receive service");
}

fn unbounded_unary_prefix(grant: usize, pauses: bool) -> (Vec<(Word, usize)>, usize) {
    let language = Language::all_finite(0, vec![
        OperationSpec { id: Op::Seed, arity: 0 },
        OperationSpec { id: Op::Unary, arity: 1 },
    ], Vec::new(), Vec::new()).unwrap();
    let mut producer = language.expressions(Arc::new(Model), vec![vec![]; 2].into()).unwrap();
    let mut result = Vec::new();
    let mut successful_work = 0;
    let mut charged_work = 0;
    let mut refusals = 0;
    for _ in 0..100_000 {
        let mut meter = work(grant);
        while meter.left > 0 {
            if pauses {
                let before = producer.progress_census();
                assert!(matches!(producer.advance(&mut work(0), 100_000), Err(Failure::Work(()))));
                assert_eq!(producer.progress_census(), before);
            }
            let before = producer.progress_census();
            let capacity = if pauses { producer.retained_cells() } else { 100_000 };
            let before_work = meter.spent;
            let next = match producer.advance(&mut meter, capacity) {
                Err(Failure::Structural(StructuralRefusal::Capacity)) if pauses => {
                    refusals += 1;
                    assert_eq!(producer.progress_census(), before);
                    // The refused paid operation is retried on the SAME owner.
                    // Its cost is additional; successful transitions stay equal.
                    let mut retry = work(1);
                    let next = producer.advance(&mut retry, 100_000).unwrap();
                    charged_work += retry.spent;
                    next
                }
                Ok(next) => next,
                _ => panic!("only the deliberately constrained retention may refuse"),
            };
            charged_work += meter.spent - before_work;
            successful_work += 1;
            match next {
                Progress::Expression(expression) => {
                    let word = word_and_length(&language, expression);
                    assert_eq!(word.1, result.len() + 1, "every unary depth arrives exactly once");
                    result.push(word);
                    if result.len() == 12 {
                        assert_eq!(charged_work, successful_work + refusals, "refused paid work is never refunded");
                        if pauses { assert!(refusals > 12, "exercise real pending allocation boundaries"); }
                        return (result, successful_work);
                    }
                }
                Progress::Advanced => {},
                Progress::Complete => panic!("an unbounded unary source does not complete at a finite depth"),
            }
        }
    }
    panic!("the same retained source must produce the finite requested prefix");
}

#[test]
fn unbounded_streaming_preserves_words_and_work_through_unit_and_retention_pauses() {
    let whole = unbounded_unary_prefix(19, false);
    assert_eq!(unbounded_unary_prefix(1, false), whole);
    assert_eq!(unbounded_unary_prefix(7, true), whole);
}

// Deliberately heterogeneous domains: neither a common output sort nor one
// common abstract case can stand in for the actual anchor compatibility mask.
struct Heterogeneous;
impl Abstract<u16, Op> for Heterogeneous {
    fn universe(&self) -> u64 { 3 }
    fn literal(&self, _: &u16) -> u64 { 2 }
    fn argument_domain(&self, op: &Op, at: usize) -> u64 {
        match op { Op::Seed => 3, Op::Unary => 2, Op::Wide if at == 0 => 1, Op::Wide => 2 }
    }
    fn apply(&self, op: &Op, args: &[u64]) -> u64 {
        match op {
            Op::Seed => 1,
            Op::Unary => if args[0] & 2 != 0 { 1 } else { 0 },
            Op::Wide => if args[0] & 1 != 0 && args[1] & 2 != 0 { 2 } else { 0 },
        }
    }
}
fn heterogeneous_oracle(language: &Arc<Language<u16, Op>>, tree: &Tree) -> Arc<Expression> {
    let (body, outputs, dependencies, size) = match tree {
        Tree::Leaf(at) => (Body::Leaf(*at), if *at == 0 { vec![1, 2] } else { vec![2, 2] },
            u64::from(*at == 0), 0),
        Tree::Node(alternative, children) => {
            let children: Vec<_> = children.iter().map(|t| heterogeneous_oracle(language, t)).collect();
            let outputs = (0..2).map(|case| match *alternative {
                0 => 1,
                1 => u64::from(children[0].summary.outputs[case] & 2 != 0),
                2 => 2 * u64::from(children[0].summary.outputs[case] & 1 != 0
                    && children[1].summary.outputs[case] & 2 != 0),
                _ => unreachable!("independent three-operation tree alphabet"),
            }).collect();
            let dependencies = children.iter().fold(0, |m, c| m | c.summary.dependencies);
            let size = 1 + children.iter().map(|c| c.size).sum::<usize>();
            (Body::Node { alternative: *alternative, children }, outputs, dependencies, size)
        }
    };
    Arc::new(Expression { owner: Arc::clone(&language.owner), body,
        summary: Summary { outputs: Arc::from(outputs), dependencies }, size })
}

// Inspect actual shared indexes and frozen tuple coordinates, independently of
// the indexer's control flow. Every indexed child's original outputs are retained
// by the test before its publication; no synthetic child is inserted.
fn audit_causal<V, P>(producer: &Expressions<V, P>, children: &mut BTreeMap<usize, Arc<[u64]>>) -> bool {
    if let Some((_, _, arrival, _, domain, case, mask, _, outputs)) = producer.index_census() {
        children.insert(arrival, Arc::clone(&outputs));
        if let Some(domain) = domain {
            let expected = outputs.iter().take(case).enumerate().fold(0, |bits, (at, output)|
                bits | (u64::from(output & domain != 0) << at));
            assert_eq!(mask, expected, "the paid partial index is bound to actual child outputs");
        }
    }
    let mut partial = false;
    for (domain, postings) in producer.posting_census() {
        let mut previous = None;
        for (arrival, mask) in postings {
            assert!(previous.is_none_or(|last| last < arrival));
            previous = Some(arrival);
            let outputs = &children[&arrival];
            let expected = outputs.iter().enumerate().fold(0, |bits, (case, output)|
                bits | (u64::from(output & domain != 0) << case));
            assert_ne!(expected, 0, "empty supports cannot occupy an argument index");
            assert_eq!(mask, expected);
            partial |= mask.count_ones() < outputs.len() as u32;
        }
    }
    let storage = producer.storage_summary();
    for cursor in producer.constructor_census() {
        assert!(cursor.watermark <= storage.indexed_entries);
        if cursor.tuple.is_some() {
            let newest = cursor.newest.expect("a nonnullary tuple belongs to an actual arrival event");
            assert!(newest < cursor.watermark);
            for (at, axis) in cursor.axes.iter().enumerate() {
                let (arrival, mask) = axis.posting.expect("every frozen tuple coordinate exists");
                assert_ne!(mask, 0);
                assert!(arrival <= newest);
                if at < cursor.anchor { assert!(arrival < newest); }
                if at == cursor.anchor { assert_eq!(arrival, newest); }
                let end = if at < cursor.anchor { axis.before } else { axis.after };
                assert!(axis.coordinate < end);
                assert!(axis.before <= axis.after && axis.after <= axis.consumed);
            }
        }
    }
    partial
}

#[test]
fn paid_anchor_masks_preserve_the_complete_heterogeneous_tree_oracle() {
    let language = finite();
    let mut expected = BTreeMap::new();
    let mut impossible = 0;
    for tree in mathematical_trees() {
        let expression = heterogeneous_oracle(&language, &tree);
        if expression.summary.outputs.iter().all(|m| *m == 0) { impossible += 1; continue; }
        let (rank, bits, outputs, dependencies) = word(&language, expression);
        assert!(expected.insert(rank, (bits, outputs, dependencies)).is_none());
    }
    assert!(impossible > expected.len());
    assert!(expected.len() > 10);
    let mut reference = None;
    for (grant, pauses) in [(1, false), (13, false), (7, true)] {
        let mut producer = language.expressions(Arc::new(Heterogeneous), inputs()).unwrap();
        let mut actual = BTreeMap::new();
        let mut children = BTreeMap::new();
        let mut words = Vec::new();
        let mut successful = 0;
        let mut refusals = 0;
        let mut partial = false;
        let mut zero_support = false;
        let mut complete = false;
        let snapshot = |p: &Expressions<u16, Op>| (p.plan_census(), p.index_census(),
            p.posting_census(), p.constructor_census(), p.seed_census());
        for _ in 0..250_000 {
            let mut meter = work(grant);
            while meter.left > 0 {
                let before = producer.progress_census();
                let owners = snapshot(&producer);
                partial |= audit_causal(&producer, &mut children);
                if let Some((_, _, _, _, Some(domain), _, mask, 1, outputs)) = producer.index_census() {
                    zero_support |= mask == 0 && outputs.iter().all(|output| output & domain == 0);
                }
                assert!(matches!(producer.advance(&mut work(0), usize::MAX), Err(Failure::Work(()))));
                assert_eq!(producer.progress_census(), before);
                assert_eq!(snapshot(&producer), owners);
                let next = match producer.advance(&mut meter, if pauses { producer.retained_cells() } else { usize::MAX }) {
                    Err(Failure::Structural(StructuralRefusal::Capacity)) if pauses => {
                        refusals += 1;
                        assert_eq!(producer.progress_census(), before);
                        assert_eq!(snapshot(&producer), owners);
                        producer.advance(&mut work(1), usize::MAX).unwrap()
                    },
                    Ok(next) => next,
                    _ => panic!("only the intentionally constrained retention may refuse"),
                };
                successful += 1;
                if producer.storage_summary().plan_ready {
                    assert_eq!(producer.plan_census().6, vec![(2, vec![(1, 0), (2, 1)]), (1, vec![(2, 0)])]);
                    assert_eq!(producer.storage_summary().plan_cells, 5);
                }
                match next {
                    Progress::Expression(expression) => {
                        let encoded = word(&language, expression);
                        let (rank, bits, outputs, dependencies) = encoded.clone();
                        assert!(actual.insert(rank, (bits, outputs, dependencies)).is_none());
                        words.push(encoded);
                    },
                    Progress::Complete => { complete = true; break; },
                    Progress::Advanced => {},
                }
            }
            if complete { break; }
        }
        assert!(complete && partial && zero_support);
        assert!(producer.index_census().is_none());
        assert!(producer.constructor_census().is_empty());
        assert!(producer.posting_census().iter().all(|(_, rows)| rows.is_empty()));
        assert_eq!(producer.progress_census().pending_cells, 0);
        assert_eq!(actual, expected);
        if pauses { assert!(refusals > 10); }
        let result = (words, successful);
        if let Some(reference) = &reference { assert_eq!(&result, reference); } else { reference = Some(result); }
    }
}

#[test]
fn an_impossible_unary_domain_never_creates_a_tuple() {
    let language = Language::all_finite(0, vec![OperationSpec { id: Op::Seed, arity: 0 },
        OperationSpec { id: Op::Unary, arity: 1 }], Vec::new(), Vec::new()).unwrap();
    let mut producer = language.expressions(Arc::new(Heterogeneous), vec![vec![]; 2].into()).unwrap();
    let mut emitted = 0;
    let mut inspected = false;
    for _ in 0..1000 {
        let before = producer.progress_census();
        inspected |= before.phase == "IndexCases" && before.case > 0;
        assert!(matches!(producer.advance(&mut work(0), usize::MAX), Err(Failure::Work(()))));
        assert_eq!(producer.progress_census(), before);
        let next = producer.advance(&mut work(1), usize::MAX).unwrap();
        assert!(producer.constructor_census().iter().all(|cursor| cursor.tuple.is_none()));
        assert!(producer.posting_census().iter().all(|(_, entries)| entries.is_empty()));
        match next {
            Progress::Expression(expression) => { emitted += 1; assert_eq!(expression.size, 1); },
            Progress::Complete => { assert!(inspected); assert_eq!(emitted, 1); return; },
            Progress::Advanced => {},
        }
    }
    panic!("the typed subset must exhaust even though the ordinary source is AllFinite");
}

#[test]
fn every_appended_child_commits_for_reuse_before_handoff_or_further_construction() {
    let language = Language::all_finite(1,
        vec![OperationSpec { id: Op::Seed, arity: 0 },
            OperationSpec { id: Op::Unary, arity: 1 }, OperationSpec { id: Op::Wide, arity: 2 }],
        vec![0], vec![]).unwrap();
    let mut producer = language.expressions(Arc::new(Model), inputs()).unwrap();
    let mut children = BTreeMap::new();
    let mut phases = std::collections::BTreeSet::new();
    let mut emitted = 0;
    for _ in 0..100_000 {
        let before = producer.progress_census();
        audit_causal(&producer, &mut children);
        assert!(matches!(producer.advance(&mut work(0), usize::MAX), Err(Failure::Work(()))));
        assert_eq!(producer.progress_census(), before);
        let next = producer.advance(&mut work(1), usize::MAX).unwrap();
        let after = producer.progress_census();
        assert!(after.indexed_entries >= before.indexed_entries);
        assert!(after.indexed_entries <= after.catalogue_entries);
        assert!(after.catalogue_entries - after.indexed_entries <= 1,
            "unindexed children cannot accumulate behind outward materialization");
        assert!(after.constructors <= 2, "one root per positive-arity constructor");
        assert!(after.active_tuples <= 3, "one tuple per constructor plus the nullary seed");
        if let Some(arrival) = before.pending_index {
            phases.insert(before.phase);
            assert_eq!(after.catalogue_entries, before.catalogue_entries);
            assert_eq!(after.next_ordinary_lane, before.next_ordinary_lane);
            assert_eq!(after.constructor_cursor, before.constructor_cursor);
            if after.pending_index.is_some() {
                assert_eq!(after.pending_index, Some(arrival));
                assert_eq!(after.pending_emission, before.pending_emission);
            } else {
                assert!(before.append_ready);
                assert_eq!(after.indexed_entries, after.catalogue_entries);
                assert_eq!(matches!(next, Progress::Expression(_)), before.pending_emission);
            }
        }
        if let Progress::Expression(expression) = next {
            emitted += 1;
            assert!(before.pending_emission && before.append_ready);
            assert_eq!(before.pending_index, Some(after.catalogue_entries - 1));
            assert!(after.pending_index.is_none());
            assert_eq!(after.indexed_entries, after.catalogue_entries);
            assert!(expression.size > 0);
        }
        if after.indexed_entries >= 20 && emitted >= 4 {
            for phase in ["IndexCases", "IndexPublish", "Wake", "Handoff"] {
                assert!(phases.contains(phase), "the finite append transaction must exercise {phase}");
            }
            return;
        }
    }
    panic!("committed reuse must coexist with continuing finite-quantum construction");
}

#[test]
fn shared_incidence_plan_costs_less_than_independent_repeated_domain_scans() {
    use std::sync::atomic::{AtomicUsize, Ordering};
    const CASES: usize = 8;
    struct Repeated(Arc<AtomicUsize>);
    impl Abstract<u16, u8> for Repeated {
        fn universe(&self) -> u64 { 255 }
        fn literal(&self, _: &u16) -> u64 { 1 }
        fn argument_domain(&self, _: &u8, _: usize) -> u64 { self.0.fetch_add(1, Ordering::Relaxed); 1 }
        fn apply(&self, op: &u8, args: &[u64]) -> u64 { if *op < 2 || args[0] & 1 != 0 { 1 } else { 0 } }
    }
    let mut uncached = work(usize::MAX);
    for outputs in [[1u64; CASES]; 2] {
        for domain in [1u64; 8] {
            let mut mask = 0;
            for (case, output) in outputs.iter().enumerate() {
                uncached.charge(1).unwrap();
                if output & domain != 0 { mask |= 1u64 << case; }
            }
            assert_eq!(mask, 255);
        }
    }
    let mut reference = None;
    for (grant, pauses) in [(1, false), (17, false), (5, true)] {
        let language = Language::finite(Grammar { inputs: 0, max_steps: 2,
            operations: (0..10u8).map(|id| OperationSpec { id, arity: usize::from(id >= 2) }).collect(),
            literals: Vec::<u16>::new() }, Vec::new()).unwrap();
        let domain_calls = Arc::new(AtomicUsize::new(0));
        let mut producer = language.expressions(Arc::new(Repeated(Arc::clone(&domain_calls))), vec![vec![]; CASES].into()).unwrap();
        let mut words = BTreeMap::new();
        let mut support_work = 0;
        let mut successful_work = 0;
        let mut refused_work = 0;
        let mut complete = false;
        let snapshot = |p: &Expressions<u16, u8>| (p.plan_census(), p.index_census(),
            p.posting_census(), p.constructor_census(), p.seed_census());
        for _ in 0..100_000 {
            let mut meter = work(grant);
            while meter.left > 0 {
                let before = producer.progress_census();
                let owners = snapshot(&producer);
                assert!(matches!(producer.advance(&mut work(0), usize::MAX), Err(Failure::Work(()))));
                assert_eq!(snapshot(&producer), owners);
                let next = match producer.advance(&mut meter, if pauses { producer.retained_cells() } else { usize::MAX }) {
                    Err(Failure::Structural(StructuralRefusal::Capacity)) if pauses => {
                        refused_work += 1;
                        assert_eq!(producer.progress_census(), before);
                        assert_eq!(snapshot(&producer), owners);
                        producer.advance(&mut work(1), usize::MAX).unwrap()
                    },
                    Ok(next) => next,
                    _ => panic!("only deliberately constrained retention may refuse"),
                };
                successful_work += 1;
                support_work += usize::from(before.phase.starts_with("Plan") || before.phase.starts_with("Index"));
                match next {
                    Progress::Expression(expression) => {
                        assert!(producer.storage_summary().plan_ready);
                        assert_eq!(expression.summary.outputs.as_ref(), &[1u64; CASES]);
                        assert_eq!(expression.summary.dependencies, 0);
                        let mut flatten = language.flatten(expression).unwrap();
                        while !flatten.advance(&mut work(1), usize::MAX).unwrap() {}
                        let address = flatten.address().unwrap().clone();
                        let mut build = language.materialize(address.clone()).unwrap();
                        while !build.advance(&mut work(1)).unwrap() {}
                        let program = build.finish().ok().unwrap();
                        let Operation::Primitive(seed) = &program.steps[0].operation else { panic!("original primitive") };
                        assert!(*seed < 2);
                        let root = if program.steps.len() == 1 { None } else {
                            assert_eq!(program.steps.len(), 2);
                            assert_eq!(program.steps[1].arguments, vec![Operand::Register(0)]);
                            let Operation::Primitive(id) = &program.steps[1].operation else { panic!("original primitive") };
                            assert!((2..10).contains(id)); Some(*id)
                        };
                        assert_eq!(program.output, Some(program.steps.len() - 1));
                        let mut encoder = language.encode(address).unwrap();
                        while !encoder.advance(&mut work(1)).unwrap() {}
                        let code = encoder.finish().unwrap_or_else(|_| panic!("same original word"));
                        assert!(words.insert((*seed, root), code.bits().to_vec()).is_none());
                    },
                    Progress::Complete => { complete = true; break; },
                    Progress::Advanced => {},
                }
            }
            if complete { break; }
        }
        assert!(complete);
        let expected: std::collections::BTreeSet<_> = (0..2).flat_map(|seed|
            std::iter::once((seed, None)).chain((2..10).map(move |op| (seed, Some(op))))).collect();
        assert_eq!(words.keys().copied().collect::<std::collections::BTreeSet<_>>(), expected);
        assert!(support_work < uncached.spent, "shared setup and all index visits beat independent case scans");
        assert_eq!(domain_calls.load(Ordering::Relaxed), 8);
        assert_eq!(producer.plan_census().6, vec![(1, (2..10).map(|op| (op, 0)).collect())]);
        assert_eq!(producer.storage_summary().plan_cells, 9);
        assert_eq!(producer.progress_census().pending_cells, 0);
        if pauses { assert!(refused_work > 0); }
        let result = (words, successful_work, support_work);
        if let Some(reference) = &reference { assert_eq!(&result, reference); } else { reference = Some(result); }
    }
}

#[cfg(feature = "serde")]
#[test]
fn bounded_native_causal_join_export_preserves_owners_and_resumptions() {
    use serde_json::{Value as Json, json};
    struct Model;
    impl Abstract<u16, u8> for Model {
        fn universe(&self) -> u64 { 15 }
        fn literal(&self, _: &u16) -> u64 { 1 }
        fn argument_domain(&self, op: &u8, at: usize) -> u64 { match op { 0 => 1, 1 => [1,2][at], 3 => [2,1][at], _ => 15 } }
        fn apply(&self, op: &u8, args: &[u64]) -> u64 { if *op == 2 { 2 } else { u64::from(args.iter().enumerate().all(|(at,v)| v & self.argument_domain(op,at) != 0)) } }
    }
    fn tuple(t: &streaming::TupleCensus) -> Json {
        json!({"alternative":t.alternative,"phase":t.phase,"at":t.at,"case":t.case,"reset_from":t.reset_from,
            "size":t.size,"dependencies":t.dependencies,"valid":t.valid,"possible":t.possible,
            "children":t.children.iter().map(|id|format!("{id:x}")).collect::<Vec<_>>(),"outputs":t.outputs,"values":t.values})
    }
    fn snapshot(p: &Expressions<u16, u8>) -> Json {
        let plan=p.plan_census(); let c=p.progress_census();
        let indexer=p.index_census().map(|e|json!({"language_owner":format!("{:x}",e.0),"child_owner":format!("{:x}",e.1),
            "arrival":e.2,"domain_index":e.3,"domain":e.4,"case":e.5,"mask":e.6,"phase":e.7,"outputs":e.8.as_ref()}));
        let constructors=p.constructor_census().iter().map(|f|json!({"slot":f.slot,"alternative":f.alternative,"phase":f.phase,
            "scan":f.scan,"newest":f.newest,"anchor":f.anchor,"carry":f.carry,"watermark":f.watermark,"observed":f.observed,
            "axes":f.axes.iter().map(|a|json!({"domain_index":a.domain_index,"domain":a.domain,"consumed":a.consumed,
                "before":a.before,"after":a.after,"coordinate":a.coordinate,"posting":a.posting})).collect::<Vec<_>>(),
            "tuple":f.tuple.as_ref().map(tuple)})).collect::<Vec<_>>();
        json!({"phase":c.phase,"plan":{"phase":plan.0,"alternative":plan.1,"anchor":plan.2,"requested_domain":plan.3,
            "lookup":plan.4,"cells":plan.5,"groups":plan.6},"indexer":indexer,"postings":p.posting_census(),
            "constructors":constructors,"seed":p.seed_census().as_ref().map(tuple),"catalogue_entries":c.catalogue_entries,
            "indexed_entries":c.indexed_entries,"pending_index":c.pending_index,"pending_emission":c.pending_emission,
            "append_ready":c.append_ready,"next_ordinary_lane":c.next_ordinary_lane,"constructor_cursor":c.constructor_cursor,
            "wake_cursor":c.wake_cursor,"pending_owner":c.pending_owner.map(|id|format!("{id:x}")),
            "posting_entries":c.posting_entries,"active_constructors":c.active_constructors,
            "active_tuples":c.active_tuples,"cells":c.retained_cells,"pending_cells":c.pending_cells,"complete":p.storage_summary().complete})
    }
    fn intern(state: Json, states: &mut Vec<Json>, ids: &mut BTreeMap<String,usize>) -> usize {
        let key=state.to_string(); if let Some(id)=ids.get(&key) { return *id; }
        let id=states.len(); states.push(state); ids.insert(key,id); id
    }
    let language=||Language::finite(Grammar { inputs:2,max_steps:1,operations:(0..4u8).map(|id|
        OperationSpec { id,arity:[1,2,0,2][id as usize] }).collect(),literals:Vec::<u16>::new() },Vec::new()).unwrap();
    let owners=[language(),language()]; let mut streams=Vec::new();
    for owner in 0..2 {
        let rows=if owner==0 { vec![vec![1,1],vec![1,2],vec![1,1],vec![1,2]] } else { vec![vec![2,2],vec![2,1],vec![2,2],vec![2,1]] };
        let mut producer=owners[owner].expressions(Arc::new(Model),rows.clone().into()).unwrap();
        let mut states=Vec::new(); let mut ids=BTreeMap::new(); let mut events=Vec::new();
        let mut emitted=Vec::new(); let mut children=BTreeMap::new(); let mut first=None;
        let mut complete=false; let mut refused=0; let mut partial=false; let mut nonzero_anchor=false; let mut empty=false;
        for _ in 0..10_000 {
            audit_causal(&producer,&mut children);
            let before_value=snapshot(&producer); let before=intern(before_value.clone(),&mut states,&mut ids);
            let cells=producer.retained_cells();
            partial|=producer.posting_census().iter().any(|(_,p)|p.iter().any(|(a,_)|*a>=producer.storage_summary().indexed_entries));
            nonzero_anchor|=producer.constructor_census().iter().any(|f|f.anchor>0 && f.tuple.is_some());
            empty|=producer.index_census().is_some_and(|e|e.7==1 && e.6==0);
            let mut zero=work(0); assert!(matches!(producer.advance(&mut zero,4096),Err(Failure::Work(()))));
            assert_eq!(snapshot(&producer),before_value); assert_eq!(zero.spent,0);
            events.push(json!({"before":before,"after":before,"result":"work_refusal","grant":0,"charged":0,"capacity":4096}));
            let mut meter=work(1);
            let (next,resumed)=match producer.advance(&mut meter,cells) {
                Err(Failure::Structural(StructuralRefusal::Capacity))=>{
                    refused+=1; assert_eq!(snapshot(&producer),before_value);
                    events.push(json!({"before":before,"after":before,"result":"capacity_refusal","grant":1,"charged":1,"capacity":cells}));
                    let mut retry=work(1); let next=producer.advance(&mut retry,4096).unwrap(); assert_eq!(retry.spent,1); (next,true)
                }, Ok(next)=>(next,false), _=>panic!("only intentionally constrained resources may refuse"),
            };
            assert_eq!(meter.spent,1);
            let after=intern(snapshot(&producer),&mut states,&mut ids); let mut publication=None;
            let result=match next {
                Progress::Expression(expression)=>{
                    let body=match &expression.body { Body::Leaf(id)=>json!({"leaf":id}),
                        Body::Node { alternative,children }=>json!({"alternative":alternative,"children":children.iter()
                            .map(|c|format!("{:x}",Arc::as_ptr(c) as usize)).collect::<Vec<_>>()}) };
                    publication=Some(emitted.len()); emitted.push(json!({"arrival":producer.storage_summary().catalogue_entries-1,
                        "owner":format!("{:x}",Arc::as_ptr(&expression) as usize),"body":body,"outputs":expression.summary.outputs.as_ref(),
                        "dependencies":expression.summary.dependencies,"size":expression.size})); first.get_or_insert(expression); "expression"
                }, Progress::Complete=>{complete=true;"complete"}, Progress::Advanced=>"advanced",
            };
            events.push(json!({"before":before,"after":after,"result":result,"publication":publication,"grant":1,"charged":1,
                "capacity":if resumed {4096} else {cells},"resumed":resumed}));
            assert!(events.len()<=8192); if complete { break; }
        }
        assert!(complete && refused>0 && partial && nonzero_anchor && empty);
        assert_eq!(producer.progress_census().pending_cells,0);
        let expression=first.unwrap(); let before=snapshot(&producer);
        assert!(matches!(owners[1-owner].flatten(Arc::clone(&expression)),Err(StructuralRefusal::ForeignOwner)));
        assert_eq!(snapshot(&producer),before);
        assert!(emitted.iter().any(|e|e["body"]["alternative"]==2),"nullary construction is present");
        streams.push(json!({"owner":owner,"language_owner":format!("{:x}",Arc::as_ptr(&owners[owner].owner) as usize),
            "rows":rows,"argument_domains":[[1],[1,2],[],[2,1]],"max_steps":1,"states":states,"events":events,"emitted":emitted,
            "foreign_owner_control":{"source":format!("{:x}",Arc::as_ptr(&owners[owner].owner) as usize),
                "attempted":format!("{:x}",Arc::as_ptr(&owners[1-owner].owner) as usize),"result":"ForeignOwner"}}));
    }
    if let Some(path)=std::env::var_os("SYNARC_DOMAIN_SUPPORT_EXPORT") {
        use std::io::Write;
        let wire=serde_json::to_vec(&json!({"schema":"synarc-causal-constructor-native-v5",
            "scope":"bounded actual plan/index/merge/tuple/cleanup transitions; no universal refinement claim",
            "states":"deduplicated exact snapshots; event IDs reference this stream only","streams":streams})).unwrap();
        assert!(wire.len()<=8*1024*1024);
        let mut file=std::fs::OpenOptions::new().write(true).create_new(true).open(path).unwrap(); file.write_all(&wire).unwrap();
    }
}
