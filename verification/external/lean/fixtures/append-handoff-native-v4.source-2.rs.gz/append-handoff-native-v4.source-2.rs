//! Paid retrospective lookup in existing constructor owners. No expression is
//! constructed, inserted, flattened or advanced by this diagnostic.
use super::*;

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum ProbeRefusal { Work, Capacity, Allocation, ForeignOwner, UnsupportedControl, UnsupportedLayout }
#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct ProbeVisits {
    pub catalogue: usize, pub children: usize, pub constructors: usize,
    pub domains: usize, pub postings: usize,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct PostingLocation {
    pub index: usize, pub arrival: usize, pub mask: u64,
    pub committed: bool, pub within_constructor_watermark: bool,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct AxisLocation {
    pub domain_index: usize, pub domain: u64, pub posting_entries: usize,
    // These are native cursor fields, including partial Freeze/Bounds state.
    pub consumed: usize, pub before: usize, pub after: usize, pub coordinate: usize,
    pub target_posting: Option<PostingLocation>, pub coordinate_posting: Option<PostingLocation>,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct TupleLocation {
    pub phase: &'static str, pub child_arrivals: Vec<Option<usize>>,
    pub argument: usize, pub case: usize, pub valid: u64, pub possible: u64,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct ConstructorLocation {
    pub slot: usize, pub phase: &'static str, pub scan: usize,
    pub newest: Option<usize>, pub anchor: usize, pub carry: usize,
    pub watermark: usize, pub observed: usize, pub axes: Vec<AxisLocation>,
    pub tuple: Option<TupleLocation>,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct IndexLocation {
    pub arrival: usize, pub domain: usize, pub case: usize, pub mask: u64, pub phase: &'static str,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct MissingExpression {
    pub step: usize, pub alternative: usize, pub child_arrivals: Vec<Option<usize>>,
    /// Derived target tuple coordinates; these do not claim a live arrival owner.
    pub newest: Option<usize>, pub anchor: Option<usize>,
    pub constructor: Option<ConstructorLocation>, pub seed_tuple: Option<TupleLocation>,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct ExpressionLocation {
    pub catalogue_entries: usize, pub indexed_entries: usize, pub constructor_cursor: usize,
    pub indexer: Option<IndexLocation>, pub resolved_steps: usize, pub target_arrival: Option<usize>,
    pub first_unresolved: Option<MissingExpression>, pub visits: ProbeVisits,
    /// Logical owned result cells; temporary step slots also obey the supplied cap.
    pub retained_cells: usize,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct PendingLocation {
    pub expression_arrival: Option<usize>, pub target_expression: bool,
    pub target_address: Option<bool>, pub address_length: Option<usize>,
    pub flatten_cells: usize, pub ranking_present: bool, pub rank_ready: bool,
}
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct ComponentLocation {
    pub expressions: ExpressionLocation, pub pending: Option<PendingLocation>,
    pub committed_catalogue_index: Option<usize>, pub committed_visits: usize,
}
fn pay<M: WorkMeter<Error = ()>>(work: &mut M) -> Result<(), ProbeRefusal> {
    work.charge(1).map_err(|_| ProbeRefusal::Work)
}
fn reserve<T>(values: &mut Vec<T>, additional: usize, held: &mut usize, capacity: usize)
    -> Result<(), ProbeRefusal> {
    let next = held.checked_add(additional).filter(|n| *n <= capacity).ok_or(ProbeRefusal::Capacity)?;
    values.try_reserve(additional).map_err(|_| ProbeRefusal::Allocation)?;
    *held = next;
    Ok(())
}
// A tree's native flattening emits each instruction exactly once in operand
// postorder. Reject dead/repeated/reordered SSA steps instead of calling an
// equivalent expression an exact source word. This visits only the supplied
// finite address; it neither constructs nor flattens any expression.
fn connected_layout<M: WorkMeter<Error = ()>>(address: &Address, inputs: usize,
    work: &mut M, capacity: usize) -> Result<(), ProbeRefusal> {
    if address.len().checked_sub(1) != Some(address.output()) {
        return Err(ProbeRefusal::UnsupportedLayout);
    }
    let mut stack = Vec::new();
    let mut held = 1usize;
    reserve(&mut stack, 1, &mut held, capacity)?;
    stack.push((address.output(), 0usize));
    let mut next = 0usize;
    while let Some(&(step, child)) = stack.last() {
        pay(work)?;
        let instruction = &address.instructions[step];
        if let Some(&operand) = instruction.operands.get(child) {
            stack.last_mut().unwrap().1 += 1;
            let end = inputs.checked_add(step).ok_or(ProbeRefusal::Capacity)?;
            if operand >= inputs && operand < end {
                reserve(&mut stack, 1, &mut held, capacity)?;
                stack.push((operand - inputs, 0));
            }
        } else {
            if step != next { return Err(ProbeRefusal::UnsupportedLayout); }
            next += 1;
            stack.pop();
            held -= 1;
        }
    }
    if next != address.len() { return Err(ProbeRefusal::UnsupportedLayout); }
    Ok(())
}
impl<V, P> Expressions<V, P> {
    pub(crate) fn probe_arrival<M: WorkMeter<Error = ()>>(&self, expression: &Arc<Expression>, work: &mut M)
        -> Result<Option<usize>, ProbeRefusal> {
        for (at, existing) in self.catalogue.iter().enumerate() {
            pay(work)?;
            if Arc::ptr_eq(existing, expression) { return Ok(Some(at)); }
        }
        Ok(None)
    }
    fn probe_tuple<M: WorkMeter<Error = ()>>(&self, tuple: &Tuple, visits: &mut ProbeVisits,
        work: &mut M, held: &mut usize, capacity: usize) -> Result<TupleLocation, ProbeRefusal> {
        pay(work)?;
        let mut child_arrivals = Vec::new();
        for child in &tuple.children {
            pay(work)?; visits.children += 1;
            let mut arrival = None;
            for (at, existing) in self.catalogue.iter().enumerate() {
                pay(work)?; visits.catalogue += 1;
                if Arc::ptr_eq(existing, child) { arrival = Some(at); break; }
            }
            reserve(&mut child_arrivals, 1, held, capacity)?;
            child_arrivals.push(arrival);
        }
        Ok(TupleLocation { phase: match tuple.phase {
            TuplePhase::Arguments => "Arguments", TuplePhase::Values => "Values",
            TuplePhase::Apply => "Apply", TuplePhase::Commit => "Commit",
            TuplePhase::Clear => "Clear", TuplePhase::Done => "Done",
        }, child_arrivals, argument: tuple.at, case: tuple.case, valid: tuple.valid, possible: tuple.possible })
    }
    /// The target is an address already validated/materialized by the SAME
    /// source owner. Its instruction alternatives cover Primitive and Call;
    /// children are matched by retained arrival identity, not by output values.
    pub(crate) fn probe_address<M: WorkMeter<Error = ()>>(&self, address: &Address,
        work: &mut M, capacity: usize) -> Result<ExpressionLocation, ProbeRefusal> {
        pay(work)?;
        if !Arc::ptr_eq(&self.language.owner, &address.owner) { return Err(ProbeRefusal::ForeignOwner); }
        if !address.children.is_empty() { return Err(ProbeRefusal::UnsupportedControl); }
        connected_layout(address, self.language.inputs, work, capacity)?;
        let mut result = ExpressionLocation { catalogue_entries: self.catalogue.len(),
            indexed_entries: self.indexed, constructor_cursor: self.constructor_at,
            indexer: (self.indexed < self.catalogue.len()).then(|| IndexLocation {
                arrival: self.indexed, domain: self.indexer.domain, case: self.indexer.case,
                mask: self.indexer.mask, phase: match self.indexer.phase {
                    IndexPhase::Cases => "Cases", IndexPhase::Publish => "Publish",
                },
            }), resolved_steps: 0, target_arrival: None, first_unresolved: None,
            visits: ProbeVisits::default(), retained_cells: 1 };
        if capacity == 0 { return Err(ProbeRefusal::Capacity); }
        let mut held = 1usize;
        let mut steps = Vec::new();
        for (step, instruction) in address.instructions.iter().enumerate() {
            pay(work)?;
            if instruction.alternative >= self.language.expression_alternatives()
                .map_err(|_| ProbeRefusal::Capacity)? { return Err(ProbeRefusal::UnsupportedControl); }
            let mut children = Vec::new();
            for &operand in &instruction.operands {
                pay(work)?;
                result.visits.children += 1;
                let register_end = self.language.inputs.checked_add(step).ok_or(ProbeRefusal::Capacity)?;
                let arrival = if operand >= self.language.inputs && operand < register_end {
                    steps.get(operand - self.language.inputs).copied()
                } else {
                    let leaf = if operand < self.language.inputs { operand }
                        else { operand.checked_sub(step).ok_or(ProbeRefusal::Capacity)? };
                    let mut found = None;
                    for (at, entry) in self.catalogue.iter().enumerate() {
                        pay(work)?; result.visits.catalogue += 1;
                        if matches!(&entry.body, Body::Leaf(id) if *id == leaf) { found = Some(at); break; }
                    }
                    found
                };
                reserve(&mut children, 1, &mut held, capacity)?;
                children.push(arrival);
            }
            let mut found = None;
            for (at, entry) in self.catalogue.iter().enumerate() {
                pay(work)?; result.visits.catalogue += 1;
                let Body::Node { alternative, children: actual } = &entry.body else { continue; };
                if *alternative != instruction.alternative || actual.len() != children.len() { continue; }
                let mut equal = true;
                for (actual, expected) in actual.iter().zip(&children) {
                    pay(work)?; result.visits.children += 1;
                    if !expected.is_some_and(|id| Arc::ptr_eq(actual, &self.catalogue[id])) { equal = false; break; }
                }
                if equal { found = Some(at); break; }
            }
            if let Some(at) = found {
                held -= children.len();
                reserve(&mut steps, 1, &mut held, capacity)?;
                steps.push(at);
                result.resolved_steps += 1;
                continue;
            }
            let mut newest = None;
            let mut anchor = None;
            let mut complete = true;
            for (at, child) in children.iter().enumerate() {
                pay(work)?; result.visits.children += 1;
                match child {
                    Some(child) if newest.is_none_or(|old| *child > old) => {
                        newest = Some(*child); anchor = Some(at);
                    }
                    Some(_) => {}
                    None => complete = false,
                }
            }
            if !complete { newest = None; anchor = None; }
            let mut constructor = None;
            for (slot, current) in self.constructors.iter().enumerate() {
                pay(work)?; result.visits.constructors += 1;
                if current.alternative != instruction.alternative { continue; }
                let mut axes = Vec::new();
                for (argument, axis) in current.axes.iter().enumerate() {
                    pay(work)?; result.visits.domains += 1;
                    let group = &self.plan.groups[axis.domain];
                    let location = |index, posting: &Posting| PostingLocation {
                        index, arrival: posting.arrival, mask: posting.mask,
                        committed: posting.arrival < self.indexed,
                        within_constructor_watermark: posting.arrival < current.watermark,
                    };
                    let mut target_posting = None;
                    if let Some(Some(arrival)) = children.get(argument) {
                        for (index, posting) in group.postings.iter().enumerate() {
                            pay(work)?; result.visits.postings += 1;
                            if posting.arrival == *arrival {
                                target_posting = Some(location(index, posting)); break;
                            }
                        }
                    }
                    pay(work)?; result.visits.postings += 1;
                    let coordinate_posting = group.postings.get(axis.coordinate)
                        .map(|posting| location(axis.coordinate, posting));
                    reserve(&mut axes, 1, &mut held, capacity)?;
                    axes.push(AxisLocation { domain_index: axis.domain, domain: group.domain,
                        posting_entries: group.postings.len(), consumed: axis.consumed,
                        before: axis.before, after: axis.after, coordinate: axis.coordinate,
                        target_posting, coordinate_posting });
                }
                let tuple = current.tuple.as_ref().map(|tuple|
                    self.probe_tuple(tuple, &mut result.visits, work, &mut held, capacity)).transpose()?;
                constructor = Some(ConstructorLocation { slot, phase: match current.phase {
                    ConstructorPhase::Merge => "Merge", ConstructorPhase::Freeze => "Freeze",
                    ConstructorPhase::Anchor => "Anchor", ConstructorPhase::Bounds => "Bounds",
                    ConstructorPhase::Tuple => "Tuple", ConstructorPhase::Reset => "Reset",
                    ConstructorPhase::Carry => "Carry", ConstructorPhase::Idle => "Idle",
                }, scan: current.scan, newest: current.newest, anchor: current.anchor,
                    carry: current.carry, watermark: current.watermark, observed: current.observed,
                    axes, tuple });
                break;
            }
            let seed_tuple = match &self.seed_tuple {
                Some(tuple) if tuple.alternative == instruction.alternative =>
                    Some(self.probe_tuple(tuple, &mut result.visits, work, &mut held, capacity)?),
                _ => None,
            };
            result.retained_cells = held - steps.len();
            result.first_unresolved = Some(MissingExpression { step, alternative: instruction.alternative,
                child_arrivals: children, newest, anchor, constructor, seed_tuple });
            return Ok(result);
        }
        result.target_arrival = steps.get(address.output()).copied();
        Ok(result)
    }
}
/// Exact flat word equality, charged per instruction and operand. The caller
/// keeps both source-owned addresses borrowed for the whole inspection.
pub(crate) fn same_address<M: WorkMeter<Error = ()>>(a: &Address, b: &Address, work: &mut M)
    -> Result<bool, ProbeRefusal> {
    pay(work)?;
    if !a.same_language(b) || a.len() != b.len() || a.output() != b.output() { return Ok(false); }
    for at in 0..a.len() {
        pay(work)?;
        let (left, la) = a.instruction(at).unwrap(); let (right, ra) = b.instruction(at).unwrap();
        if left != right || la.len() != ra.len() { return Ok(false); }
        for (left, right) in la.iter().zip(ra) { pay(work)?; if left != right { return Ok(false); } }
    }
    Ok(true)
}

#[cfg(test)]
mod courts {
    use super::*;
    use crate::construction::family::syntax::structural as native;
    struct Model;
    impl Abstract<u8, u8> for Model {
        fn universe(&self) -> u64 { 1 }
        fn literal(&self, _: &u8) -> u64 { 1 }
        fn apply(&self, _: &u8, arguments: &[u64]) -> u64 { arguments[0] }
    }
    struct Work { left: usize, spent: usize }
    impl WorkMeter for Work {
        type Error = ();
        fn charge(&mut self, n: usize) -> Result<(), ()> {
            self.left = self.left.checked_sub(n).ok_or(())?;
            self.spent += n; Ok(())
        }
    }
    fn work(left: usize) -> Work { Work { left, spent: 0 } }
    fn fixture() -> Arc<Language<u8, u8>> {
        let body = Program { steps: vec![Step { operation: Operation::Primitive(0),
            arguments: vec![Operand::Input(0)] }], output: Some(0), library: vec![] };
        Language::finite(Grammar { inputs: 1,
            operations: vec![OperationSpec { id: 0, arity: 1 }], literals: vec![], max_steps: 2 },
            vec![(1, body)]).unwrap()
    }
    fn address(language: &Arc<Language<u8, u8>>, output: usize) -> Address {
        let mut cursor = language.enumerate();
        for _ in 0..10_000 {
            match cursor.advance(&mut work(1)).unwrap() {
                native::Progress::Address(address) if address.len() == 2 && address.output() == output
                    && address.instruction(0) == Some((0, &[0][..]))
                    && address.instruction(1) == Some((1, &[1][..])) => return address,
                native::Progress::Complete => break,
                _ => {}
            }
        }
        panic!("actual finite source contains the Primitive/Call target")
    }
    #[test]
    fn locator_observes_native_primitive_call_construction_without_advancing_it() {
        let language = fixture();
        let target = address(&language, 1);
        let dead = address(&language, 0);
        let mut producer = language.expressions(Arc::new(Model), vec![vec![1]].into()).unwrap();
        let before = producer.progress_census();
        assert_eq!(producer.probe_address(&target, &mut work(0), 64), Err(ProbeRefusal::Work));
        assert_eq!(producer.probe_address(&target, &mut work(100), 0), Err(ProbeRefusal::Capacity));
        assert_eq!(producer.probe_address(&dead, &mut work(100), 64), Err(ProbeRefusal::UnsupportedLayout));
        let foreign = address(&fixture(), 1);
        assert_eq!(producer.probe_address(&foreign, &mut work(100), 64), Err(ProbeRefusal::ForeignOwner));
        assert_eq!(producer.progress_census(), before);
        let mut saw_missing_child = false;
        let mut saw_native_continuation = false;
        for _ in 0..10_000 {
            let before = producer.progress_census();
            let storage = producer.storage_summary();
            let mut first = work(10_000);
            let mut second = work(10_000);
            let located = producer.probe_address(&target, &mut first, 64).unwrap();
            assert_eq!(producer.probe_address(&target, &mut second, 64).unwrap(), located);
            assert_eq!(first.spent, second.spent);
            assert!(first.spent > 0);
            assert_eq!(producer.progress_census(), before);
            assert_eq!(producer.storage_summary(), storage);
            assert_eq!(located.indexed_entries, producer.indexed);
            assert_eq!(located.constructor_cursor, producer.constructor_at);
            if let Some(missing) = &located.first_unresolved {
                saw_missing_child |= missing.child_arrivals.iter().any(Option::is_none);
                if missing.step == 1 {
                    assert_eq!(missing.alternative, 1, "actual captured-call alternative");
                    assert_eq!(missing.child_arrivals.len(), 1);
                    assert_eq!(missing.newest, missing.child_arrivals[0]);
                    assert_eq!(missing.anchor, Some(0));
                    if let Some(constructor) = &missing.constructor {
                        let actual = &producer.constructors[constructor.slot];
                        assert_eq!(actual.alternative, missing.alternative);
                        assert_eq!(constructor.watermark, actual.watermark);
                        assert_eq!(constructor.observed, actual.observed);
                        assert_eq!(constructor.newest, actual.newest);
                        assert_eq!(constructor.anchor, actual.anchor);
                        assert_eq!(constructor.scan, actual.scan);
                        assert_eq!(constructor.carry, actual.carry);
                        assert_eq!(constructor.axes.len(), actual.axes.len());
                        saw_native_continuation |= constructor.tuple.is_some();
                        assert_eq!(constructor.tuple.is_some(), actual.tuple.is_some());
                        assert_eq!(constructor.phase, format!("{:?}", actual.phase));
                        if let Some(tuple) = &constructor.tuple {
                            let original = actual.tuple.as_ref().unwrap();
                            assert_eq!(tuple.phase, format!("{:?}", original.phase));
                            assert_eq!((tuple.argument, tuple.case, tuple.valid, tuple.possible),
                                (original.at, original.case, original.valid, original.possible));
                            assert_eq!(tuple.child_arrivals.len(), original.children.len());
                            for (arrival, child) in tuple.child_arrivals.iter().zip(&original.children) {
                                assert!(Arc::ptr_eq(&producer.catalogue[arrival.unwrap()], child));
                            }
                        }
                        for (argument, (axis, original)) in constructor.axes.iter().zip(&actual.axes).enumerate() {
                            let group = &producer.plan.groups[original.domain];
                            assert_eq!(axis.domain_index, original.domain);
                            assert_eq!(axis.domain, group.domain);
                            assert_eq!(axis.posting_entries, group.postings.len());
                            assert_eq!((axis.consumed, axis.before, axis.after, axis.coordinate),
                                (original.consumed, original.before, original.after, original.coordinate));
                            if let Some(posting) = &axis.target_posting {
                                assert_eq!(Some(posting.arrival), missing.child_arrivals[argument]);
                                assert_eq!(posting.arrival, group.postings[posting.index].arrival);
                                assert_eq!(posting.mask, group.postings[posting.index].mask);
                                assert_eq!(posting.committed, posting.arrival < producer.indexed);
                                assert_eq!(posting.within_constructor_watermark, posting.arrival < actual.watermark);
                            }
                        }
                        assert!(located.visits.constructors > 0 && located.visits.domains > 0);
                    }
                }
            }
            if let Some(arrival) = located.target_arrival {
                assert_eq!(located.resolved_steps, 2);
                assert!(located.first_unresolved.is_none());
                let expression = Arc::clone(&producer.catalogue[arrival]);
                assert_eq!(producer.probe_arrival(&expression, &mut work(10_000)).unwrap(), Some(arrival));
                let mut flatten = language.flatten(expression).unwrap();
                while !flatten.advance(&mut work(1), 128).unwrap() {}
                assert!(same_address(flatten.address().unwrap(), &target, &mut work(100)).unwrap());
                assert!(saw_missing_child && saw_native_continuation);
                return;
            }
            producer.advance(&mut work(1), 4096).unwrap();
        }
        panic!("bounded native fixture must construct its Primitive/Call expression")
    }
}
