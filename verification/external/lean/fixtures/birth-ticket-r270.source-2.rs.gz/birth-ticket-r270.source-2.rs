//! Adversarial retained-prefix fixtures for the sole native constructor path.
//! Original whole-language word/rank/summary oracles remain in streaming_courts.
use super::*;
struct Work { left: usize, spent: usize }
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.left = self.left.checked_sub(n).ok_or(())?; self.spent += n; Ok(())
    }
}
fn work(left: usize) -> Work { Work { left, spent: 0 } }
struct Union;
impl Abstract<u8, u8> for Union {
    fn universe(&self) -> u64 { 1 }
    fn literal(&self, _: &u8) -> u64 { 1 }
    fn apply(&self, _: &u8, values: &[u64]) -> u64 { values.iter().fold(1, |a, b| a | b) }
}
fn node(owner: &Arc<()>, children: Vec<Arc<Expression>>, size: usize) -> Arc<Expression> {
    Arc::new(Expression { owner: Arc::clone(owner), body: Body::Node { alternative: 0, children },
        summary: Summary { outputs: vec![1].into(), dependencies: 1 }, size })
}
fn leaf(owner: &Arc<()>, id: usize, outputs: Vec<u64>) -> Arc<Expression> {
    Arc::new(Expression { owner: Arc::clone(owner), body: Body::Leaf(id),
        summary: Summary { outputs: outputs.into(), dependencies: 1u64 << id }, size: 0 })
}
fn ticket(newest: usize, anchor: usize, watermark: usize, lower_bound: usize,
    turn: usize, axes: Vec<TicketAxis>) -> Ticket {
    Ticket { newest, anchor, watermark, lower_bound, turn, axes,
        phase: TicketPhase::Ready, scan: 0, carry: 0 }
}
fn fixture(language: Arc<Language<u8, u8>>, model: Arc<dyn Abstract<u8,u8>>,
    inputs: Arc<[Vec<u64>]>, catalogue: Vec<Arc<Expression>>, groups: Vec<DomainGroup>,
    constructor: Constructor) -> Expressions<u8,u8> {
    let plan_cells = groups.len() + groups.iter().map(|g|g.positions.len()).sum::<usize>();
    let posting_entries = groups.iter().map(|g|g.postings.len()).sum::<usize>();
    let catalogue_cells = catalogue.iter().map(|e| 2 + e.summary.outputs.len() + match &e.body {
        Body::Leaf(_) => 0, Body::Node { children, .. } => children.len(),
    }).sum::<usize>();
    let ticket_cells = constructor.ticket_cells;
    let cells = 1 + plan_cells + posting_entries + catalogue_cells + 1 + constructor.axes.len() + ticket_cells;
    let indexed = catalogue.len();
    let max_size = catalogue.iter().map(|e| e.size).max().unwrap_or(0);
    let alternatives = language.expression_alternatives().unwrap();
    let mut p = Expressions::new(language, model, inputs);
    p.catalogue = catalogue; p.catalogue_cells = catalogue_cells; p.indexed = indexed;
    p.plan = DomainPlan { groups, alternative: alternatives, anchor: 0, domain: 0, lookup: 0,
        phase: PlanPhase::Done, cells: plan_cells };
    p.posting_entries = posting_entries; p.constructors = vec![constructor];
    p.active_constructors = 1; p.ticket_cells = ticket_cells; p.wake_at = 1;
    p.seeded = true; p.next_lane = 1; p.cells = cells; p.max_size = max_size;
    p
}
#[test]
fn a_late_cheaper_tree_is_emitted_while_an_older_rectangle_is_unfinished() {
    let language = Language::all_finite(1, vec![OperationSpec { id: 0, arity: 2 },
        OperationSpec { id: 1, arity: 0 }], Vec::<u8>::new(), vec![]).unwrap();
    // Adversarial retained-owner fixture with valid native trees of sizes
    // 0..12 and one unfinished 13-tuple region. This is not asserted to be a
    // complete reachable producer prefix; whole-source courts prove coverage.
    let first = leaf(&language.owner, 0, vec![1]);
    let mut catalogue = vec![Arc::clone(&first)];
    for size in 1..=12 {
        catalogue.push(node(&language.owner, vec![Arc::clone(catalogue.last().unwrap()), Arc::clone(&first)], size));
    }
    let mut c = Constructor::new(0, vec![Axis { domain: 0, consumed: 13, before: 12, after: 13 }; 2]);
    c.observed = 13; c.watermark = 13; c.newest = Some(12); c.sleeping = false; c.service = true;
    c.next_turn = 1; c.ticket_cells = 3;
    c.tickets.push(ticket(12,0,13,13,0,vec![TicketAxis { domain:0,end:13,coordinate:12 },
        TicketAxis { domain:0,end:13,coordinate:0 }]));
    let groups = vec![DomainGroup { domain: 1, positions: vec![(0,0),(0,1)],
        postings: (0..13).map(|arrival| Posting { arrival,mask:1,minimum_size:0 }).collect() }];
    let mut p = fixture(Arc::clone(&language), Arc::new(Union), vec![vec![1]].into(), catalogue, groups,c);
    while p.constructors[0].tuple.is_none() { p.advance(&mut work(1),usize::MAX).unwrap(); }
    assert_eq!(p.constructors[0].active.as_ref().unwrap().newest,12);
    // Append through the actual index/wake transaction while the old evaluator
    // is live. No implementation-specific target/operator ordering is installed.
    let cheap = Arc::new(Expression { owner: Arc::clone(&language.owner),
        body: Body::Node { alternative:1,children:vec![] },
        summary: Summary { outputs:vec![1].into(),dependencies:0 },size:1 });
    p.cells += 1; p.reserve_publish(usize::MAX).unwrap(); p.publish(Arc::clone(&cheap),false);
    while p.pending_append.is_some() { p.advance(&mut work(1),usize::MAX).unwrap(); }
    assert_eq!(p.constructors[0].active.as_ref().unwrap().newest,12,
        "a new cheap child cannot replace an already owned finite evaluator");
    let mut old_emitted = false;
    for _ in 0..20_000 {
        let before = p.constructor_census();
        assert!(matches!(p.advance(&mut work(0),usize::MAX),Err(Failure::Work(()))));
        assert_eq!(p.constructor_census(),before);
        if let Progress::Expression(e) = p.advance(&mut work(1),usize::MAX).unwrap() {
            let Body::Node { alternative:0,children } = &e.body else { continue; };
            if e.size == 13 { old_emitted = true; }
            if Arc::ptr_eq(&children[0],&cheap) && Arc::ptr_eq(&children[1],&first) {
                assert_eq!(e.size,2); assert_eq!(e.summary.outputs.as_ref(), &[1]);
                assert!(old_emitted, "the already active old tuple finishes first");
                let c = &p.constructors[0];
                assert!(c.tickets.iter().chain(c.active.iter()).any(|t|
                    t.newest==12 && t.axes[1].coordinate<12),
                    "actual cheap publication precedes exhaustion of the old rectangle");
                return;
            }
        }
    }
    panic!("the admitted lower-bound region must produce its actual cheap tree");
}
struct Disjoint;
impl Abstract<u8,u8> for Disjoint {
    fn universe(&self) -> u64 { 3 }
    fn literal(&self,_:&u8) -> u64 { 1 }
    fn argument_domain(&self,_:&u8,axis:usize) -> u64 { 1 << axis }
    fn apply(&self,_:&u8,values:&[u64]) -> u64 { values[0] & values[1] }
}
#[test]
fn tight_ticket_admission_services_an_owner_and_resumes_the_exact_undiscovered_birth() {
    let language = Language::finite(Grammar { inputs:2, operations:vec![OperationSpec {id:0,arity:2}],
        literals:Vec::<u8>::new(),max_steps:1 },vec![]).unwrap();
    let catalogue = vec![leaf(&language.owner,0,vec![1,2]),leaf(&language.owner,1,vec![1,0])];
    let mut c = Constructor::new(0,vec![Axis {domain:0,consumed:2,before:1,after:2},
        Axis {domain:1,consumed:1,before:1,after:1}]);
    c.phase=ConstructorPhase::Anchor; c.newest=Some(1);c.watermark=2;c.sleeping=false;
    c.next_turn=1;c.ticket_cells=3;
    c.tickets.push(ticket(0,0,1,1,0,vec![TicketAxis {domain:0,end:1,coordinate:0},
        TicketAxis {domain:1,end:1,coordinate:0}]));
    let groups=vec![DomainGroup {domain:1,positions:vec![(0,0)],postings:vec![
        Posting {arrival:0,mask:1,minimum_size:0},Posting {arrival:1,mask:1,minimum_size:0}]},
        DomainGroup {domain:2,positions:vec![(0,1)],postings:vec![Posting {arrival:0,mask:2,minimum_size:0}]}];
    let mut p=fixture(language,Arc::new(Disjoint),vec![vec![1,1],vec![2,0]].into(),catalogue,groups,c);
    let ceiling=p.cells+2; // Enough for the disjoint tuple's root/first argument, not another ticket.
    let discovery=|p:&Expressions<u8,u8>| { let c=&p.constructors[0];
        (c.phase,c.newest,c.anchor,c.watermark,c.axes.clone()) };
    let before=discovery(&p);let owners=p.constructor_census();
    assert!(matches!(p.advance(&mut work(0),ceiling),Err(Failure::Work(()))));
    assert_eq!(p.constructor_census(),owners);
    let mut paid=work(1);assert!(matches!(p.advance(&mut paid,ceiling),Ok(Progress::Advanced)));
    assert_eq!(paid.spent,1);assert_eq!(discovery(&p),before);assert!(p.constructors[0].service);
    let mut saw_tuple=false;let mut released=false;
    for _ in 0..200 {
        let c=&p.constructors[0];saw_tuple|=c.tuple.is_some();
        released|=c.ticket_cells==0;
        if c.building.as_ref().is_some_and(|t|t.newest==1) {
            assert!(saw_tuple && released,"actual native tuple cleanup must release admission room");
            assert_eq!(c.watermark,2);assert_eq!(c.newest,Some(1));assert_eq!(c.anchor,0);
            assert!(p.cells<=ceiling);return;
        }
        p.advance(&mut work(1),ceiling).unwrap();assert!(p.cells<=ceiling);
    }
    panic!("ticket admission cannot wait for the blocked discovery pass to finish");
}
#[test]
fn equal_bounds_rotate_finite_tuple_quanta_and_heap_repairs_are_resumable() {
    let mut c=Constructor::new(0,vec![Axis {domain:0,consumed:4,before:3,after:4};3]);
    c.sleeping=false;c.service=true;c.observed=4;c.watermark=4;c.next_turn=3;c.ticket_cells=12;
    for anchor in 0..3 { c.tickets.push(ticket(3,anchor,4,1,anchor,(0..3).map(|axis|
        TicketAxis {domain:0,end:if axis<anchor {3}else{4},coordinate:if axis==anchor {3}else{0}}).collect())); }
    let groups=vec![DomainGroup {domain:1,positions:vec![],postings:(0..4)
        .map(|arrival|Posting {arrival,mask:1,minimum_size:0}).collect()}];
    let mut cells=16;let mut visits=Vec::new();
    for _ in 0..300 {
        match c.step(&groups,&[],4,Extent::AllFinite,&mut cells,100).unwrap() {
            ConstructorStep::StartedTuple=>{
                visits.push(c.active.as_ref().unwrap().anchor);
                // Evaluate completion is irrelevant to this scheduler-only
                // court; no alternative expression execution engine exists.
                c.tuple.take().unwrap();cells-=1;c.finish_tuple(None);
                if visits.len()==6 { assert_eq!(visits,vec![0,1,2,0,1,2]);return; }
            },_=>{}
        }
    }
    panic!("an equal-bound ticket cannot monopolize the constructor");
}
#[test]
fn finite_lower_bound_overflow_rejects_an_impossible_region_while_open_retains_it() {
    let language=Language::finite(Grammar {inputs:1,operations:vec![OperationSpec {id:0,arity:2},OperationSpec {id:1,arity:3}],
        literals:Vec::<u8>::new(),max_steps:usize::MAX},vec![]).unwrap();
    let mut catalogue=vec![leaf(&language.owner,0,vec![1])];
    for _ in 0..usize::BITS-1 {
        let child=Arc::clone(catalogue.last().unwrap());let size=1+2*child.size;
        catalogue.push(node(&language.owner,vec![Arc::clone(&child),child],size));
    }
    let newest=catalogue.len()-1;let size=catalogue[newest].size;
    let groups=vec![DomainGroup {domain:1,positions:vec![],postings:vec![Posting {arrival:newest,mask:1,minimum_size:size}]}];
    for extent in [Extent::Finite(usize::MAX),Extent::AllFinite] {
        let mut c=Constructor::new(1,vec![Axis {domain:0,consumed:0,before:0,after:0};3]);
        c.merge(catalogue.len());let mut cells=4;let mut ended=false;
        for _ in 0..100 {
            match c.step(&groups,&catalogue,catalogue.len(),extent,&mut cells,usize::MAX) {
                Ok(ConstructorStep::Idle)=>{assert!(matches!(extent,Extent::Finite(_)));assert_eq!(cells,4);ended=true;break;}
                Err(StructuralRefusal::Capacity)=>{
                    assert_eq!(extent,Extent::AllFinite);let ticket=c.building.as_ref().unwrap();
                    assert_eq!(ticket.axes.len(),2);assert_eq!(ticket.lower_bound,usize::MAX);
                    let held=cells;let scan=c.scan;
                    assert!(matches!(c.step(&groups,&catalogue,catalogue.len(),extent,&mut cells,usize::MAX),Err(StructuralRefusal::Capacity)));
                    assert_eq!((cells,c.scan),(held,scan));ended=true;break;
                },Ok(_)=>{},other=>panic!("unexpected native step: {}",other.is_ok()),
            }
        }
        assert!(ended);
    }
}
