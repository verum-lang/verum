//! End-to-end acquisition: no selected body or target program is supplied.
use super::*;
use crate::construction::family::{Grammar as SyntaxGrammar, OperationSpec};
use crate::program::{ExecutionLimit, Operation, Spine};
use crate::program::observer::{Input, InputSource};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Value { Bit(bool), Sequence(Vec<bool>) }
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Op { Zero, Identity, Xor }
struct Meaning;
impl Semantics<Value, Op> for Meaning {
    type Error = ();
    fn apply(&self, op: &Op, args: &[Value]) -> Result<Value, ()> {
        match (op, args) {
            (Op::Zero, []) => Ok(Value::Bit(false)),
            (Op::Identity, [value]) => Ok(value.clone()),
            (Op::Xor, [Value::Bit(a), Value::Bit(b)]) => Ok(Value::Bit(a ^ b)),
            _ => Err(()),
        }
    }
    fn spine(&self, value: &Value) -> Option<Spine<Value>> {
        let Value::Sequence(items) = value else { return None; };
        Some(if let Some((&head, rest)) = items.split_first() {
            Spine::Cell { head: Value::Bit(head), tail: Value::Sequence(rest.to_vec()), length: items.len() }
        } else { Spine::Empty })
    }
}
struct Work(usize);
impl WorkMeter for Work { type Error = (); fn charge(&mut self, n: usize) -> Result<(), ()> {
    self.0 = self.0.checked_sub(n).ok_or(())?; Ok(())
} }
fn syntax(inputs: usize, ops: &[(Op, usize)]) -> SyntaxGrammar<Op, Value> {
    SyntaxGrammar { inputs, operations: ops.iter().map(|(id, arity)| OperationSpec { id: id.clone(), arity: *arity }).collect(),
        literals: Vec::new(), max_steps: 1 }
}
fn words(length: usize) -> impl Iterator<Item=Vec<bool>> {
    (0..1usize << length).map(move |word| (0..length).map(|at| word & (1 << at) != 0).collect())
}
#[test]
fn search_learns_fold_body_validates_longer_inputs_and_installs_the_same_program() {
    let initial = structural::Language::finite(syntax(0, &[(Op::Zero, 0)]), vec![]).unwrap();
    let update = structural::Language::finite(syntax(1, &[(Op::Identity, 1)]), vec![]).unwrap();
    let body = structural::Language::finite(syntax(2, &[(Op::Identity, 1), (Op::Xor, 2)]), vec![]).unwrap();
    let read = structural::Language::finite_compositional(syntax(2, &[]), vec![],
        vec![structural::ControlSpec::Fold { body }]).unwrap();
    let mut freeze = Freezing::new([initial, update, read],
        InputBinding::new(0u8, 0, vec![InputSource::State]).unwrap(),
        InputBinding::new(1, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(),
        Arc::new(Meaning), Retention { address_cells: 10_000, pending: 1_000 }).unwrap();
    while !freeze.advance(&mut Work(1)).unwrap() {}
    let mut series = freeze.finish().unwrap_or_else(|_| panic!("full finite family"));
    assert_eq!(series.family_count(), Some(24)); // 4 argument pairs * (2 identities + 4 XORs).
    let alphabet = BTreeMap::from([(0u8, BTreeSet::from([Value::Bit(false), Value::Bit(true)]))]);
    let mut builder = series.open_trial(alphabet).unwrap();
    let mut id = 0u64;
    for _ in 0..16 { for length in 1..=3 { for sequence in words(length) {
        let target = Value::Bit(sequence.iter().fold(false, |a, b| a ^ b));
        builder.observe(History::from_origin(id, vec![]), 0, 0, InputRow::new(1, vec![Value::Sequence(sequence)]), target).unwrap();
        id += 1;
    } } }
    let mut search = builder.finish::<()>().unwrap();
    let mut work = Work(10_000_000); let mut budget = Budget::new(&mut work, ExecutionLimit::Unlimited);
    let (candidate, accepted) = loop { match search.advance(&mut budget) {
        Progress::Advanced | Progress::Excluded { .. } => {},
        Progress::Assessed { candidate, assessment } => {
            if let Some(accepted) = assessment.accepted().unwrap() { break (candidate, accepted); }
        },
        _ => panic!("declared complete family must learn the parity fold"),
    } };
    assert!(matches!(candidate.definition().read().steps[0].operation, Operation::Fold { .. }));
    assert_eq!(accepted.assessment().trial().family().comparison_count(), Some(48));
    let codes = candidate.structural_codes().unwrap();
    assert!(matches!(codes[2].name().naming(), crate::program::code_mass::Naming::KraftProgramV2 { .. }));
    let mut fresh = accepted.open_validation();
    for length in 4..=7 { for sequence in words(length) {
        let target = Value::Bit(sequence.iter().fold(false, |a, b| a ^ b));
        fresh.observe(History::from_origin(id, vec![]), 0, 0, InputRow::new(1, vec![Value::Sequence(sequence)]), target).unwrap();
        id += 1;
    } }
    let check = fresh.finish().unwrap().evaluate(&mut budget).unwrap();
    assert!(check.predictive_gain_bits().unwrap() > 0.0);
    let validated = check.validated().unwrap().expect("fresh independent observations");
    let installed = validated.install(History::from_origin(id, vec![]), 0, &mut budget).unwrap_or_else(|_| panic!("shared installation"));
    for length in [0, 8, 17, 64] {
        let sequence: Vec<_> = (0..length).map(|i| i % 3 == 1).collect();
        let expected = Value::Bit(sequence.iter().fold(false, |a, b| a ^ b));
        let args = [Value::Sequence(sequence)];
        let read = installed.cut().read(Input::new(&1, &args), &mut budget).unwrap();
        assert_eq!(read.value(), &expected);
    }
    assert_eq!(series.next_look(), &BigUint::from(1u8));
    #[cfg(feature = "serde")]
    export(&candidate, series.family_count().unwrap());
}

#[cfg(feature = "serde")]
fn export(candidate: &Candidate<Value, Op, u8, Meaning>, count: usize) {
    use serde_json::{json, Value as Json};
    use crate::program::Operand;
    fn value(v: &Value) -> Json { match v { Value::Bit(b) => json!({"Bit":b}), Value::Sequence(s) => json!({"Sequence":s}) } }
    fn primitive(op: &Op) -> Json { json!(match op { Op::Zero => "Zero", Op::Identity => "Identity", Op::Xor => "Xor" }) }
    fn program(p: &Program<Value, Op>) -> Json {
        json!({"steps":p.steps.iter().map(|step| json!({"operation":match &step.operation {
            Operation::Primitive(op) => json!({"Primitive":primitive(op)}), Operation::Call(i) => json!({"Call":i}),
            Operation::Branch { yes, no } => json!({"Branch":{"yes":yes,"no":no}}), Operation::Fold { body } => json!({"Fold":body}),
        },"arguments":step.arguments.iter().map(|arg| match arg { Operand::Input(i)=>json!({"Input":i}), Operand::Register(i)=>json!({"Register":i}), Operand::Literal(v)=>json!({"Literal":value(v)}) }).collect::<Vec<_>>() })).collect::<Vec<_>>(),
            "output":p.output,"library":p.library.iter().map(program).collect::<Vec<_>>()})
    }
    let Some(path) = std::env::var_os("SYNARC_COMPOSITIONAL_EXPORT") else { return; };
    let Source::Structural(parts) = &candidate.grammar.source else { panic!("real structural source"); };
    let mut owners = structural::lifecycle_export::Owners::new();
    let codes = candidate.structural_codes().unwrap();
    let parts = (0..3).map(|i| owners.snapshot(&parts[i], &codes[i], value, primitive, program)).collect::<Vec<_>>();
    // Source witnesses are captured from the acquired candidate after the
    // behavioral checks above, never reconstructed from expected answer code.
    let packet = json!({"format":"synarc-compositional-acquisition-v2","parts":parts,
        "family_names":count,"charged_comparisons":candidate.comparison_count(),
        "look":candidate.evidence_look().to_string(),"index":candidate.index().to_string(),
        "training":{"lengths":[1,2,3],"repetitions":16,"all_binary_sequences":true},
        "validation":{"lengths":[4,5,6,7],"all_binary_sequences":true},
        "installed_probe_lengths":[0,8,17,64],
        "scope":"finite Uniform acquisition and structural source correspondence; no ARC or causal-wire admission claim"});
    std::fs::write(path, format!("{packet}\n")).expect("write acquired structural evidence");
}
