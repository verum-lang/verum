//! Retained preparation of one exact pre-action history reservation. All maps
//! use their native owned lookup/update cursors; no paid traversal restarts.
use super::*;
use synarc_store::prefix_map::{Lookup, LookupStep, Update, UpdateRefusal};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::organism) enum ReservationRefusal { History(Refusal), Poisoned }
impl From<Refusal> for ReservationRefusal {
    fn from(reason: Refusal) -> Self { Self::History(reason) }
}
impl From<UpdateRefusal> for ReservationRefusal {
    fn from(reason: UpdateRefusal) -> Self {
        match reason { UpdateRefusal::Resource(reason) => Self::History(reason.into()), UpdateRefusal::Poisoned => Self::Poisoned }
    }
}
struct Bump<A: Copy> {
    source: PrefixMap<Cause<A>, Counter>,
    cause: Cause<A>,
    ordinal: u64,
    lookup: Option<Lookup<Cause<A>, Counter>>,
    update: Option<Update<Cause<A>, Counter>>,
}
impl<A: Copy + Ord> Bump<A> {
    fn new(source: PrefixMap<Cause<A>, Counter>, cause: Cause<A>, ordinal: u64) -> Self {
        Self { lookup: Some(source.lookup(cause)), source, cause, ordinal, update: None }
    }
    fn advance(&mut self, work: &mut usize) -> Result<Option<PrefixMap<Cause<A>, Counter>>, ReservationRefusal> {
        if let Some(lookup) = &mut self.lookup {
            let old = match lookup.advance(work).map_err(Refusal::from)? {
                LookupStep::Pending => return Ok(None), LookupStep::Complete(old) => old,
            };
            let rank = old.map_or(0, |old| old.rank).checked_add(1).ok_or(Refusal::Overflow)?;
            self.update = Some(self.source.updating(self.cause, Counter { rank, last: self.ordinal }));
            self.lookup = None;
            return Ok(None);
        }
        let update = self.update.as_mut().expect("a completed lookup owns its native update");
        if !update.advance(work)? { return Ok(None); }
        let update = self.update.take().unwrap();
        Ok(Some(match update.finish() { Ok(map) => map, Err(_) => unreachable!("completed native update") }))
    }
}
#[derive(Clone, Copy)]
enum Stage { History, Raw, Layer { index: usize, action: bool }, Complete }
pub(in crate::organism) struct Reserving<A: Copy> {
    before: Cut<A>, highest_epoch: u128, pending_epoch: Option<u128>, next_ordinal: u64,
    next_layers: BTreeMap<u128, Layer<A>>,
    next_raw: Option<PrefixMap<Cause<A>, Counter>>,
    next_history: Option<HistoryPrefix<A>>,
    history: Option<Update<u64, Arc<HistoryEvent<A>>>>,
    captured: Arc<OnceLock<super::super::action_capture::CapturedOutcome>>,
    bump: Option<Bump<A>>, stage: Stage, poisoned: bool,
}
impl<A: Copy + Ord> Reserving<A> {
    pub(super) fn new(owner: &Timeline<A>, time: PreActionTime, raw_state: u64,
        inputs: &[(u128, u64)], action: A, pose: Option<u8>, sensory: Option<super::super::Sensory>) -> Result<Self, Refusal> {
        if !owner.complete { return Err(Refusal::IncompleteHistory); }
        if inputs.len() != owner.layers.len() { return Err(Refusal::MissingLayer); }
        let mut ordered = inputs.to_vec(); ordered.sort_unstable_by_key(|(epoch, _)| *epoch);
        if ordered.iter().map(|(epoch, _)| epoch).ne(owner.layers.keys()) { return Err(Refusal::MissingLayer); }
        let state = ordered.iter().find(|(epoch, _)| *epoch == owner.epoch).ok_or(Refusal::MissingLayer)?.1;
        let next_ordinal = owner.ordinal.checked_add(1).ok_or(Refusal::Overflow)?;
        let before = Cut { sensory, pose, id: SampleId { lineage: owner.lineage, ordinal: owner.ordinal }, time,
            event: Event { raw_state, situation: state, action }, epoch: owner.epoch, raw_space: owner.raw_space,
            inputs: ordered.into(), layers: Arc::clone(&owner.layers), raw_before: owner.raw_current.clone(), history_before: owner.history.clone() };
        let captured = Arc::new(OnceLock::new());
        let event = Arc::new(HistoryEvent { sensory: before.sensory.clone(), pose, id: before.id, time, event: before.event, epoch: owner.epoch,
            raw_space: owner.raw_space, inputs: Arc::clone(&before.inputs), captured: Arc::clone(&captured) });
        Ok(Self { highest_epoch: owner.highest_epoch, pending_epoch: owner.pending_epoch, next_ordinal,
            next_layers: (*owner.layers).clone(), next_raw: None, next_history: None,
            history: Some(owner.history.root.updating(owner.ordinal, event)), bump: None,
            before, captured, stage: Stage::History, poisoned: false })
    }
    /// A new grant cannot change the event, inputs or exact timeline revision.
    pub(in crate::organism) fn advance(&mut self, owner: &Timeline<A>, work: &mut usize) -> Result<bool, ReservationRefusal> {
        if self.poisoned { return Err(ReservationRefusal::Poisoned); }
        if !same_owner(&self.before, self.highest_epoch, self.pending_epoch, owner) {
            return Err(Refusal::ConflictingSample.into());
        }
        self.poisoned = true;
        let result = self.advance_inner(work);
        self.poisoned = false;
        result
    }
    fn advance_inner(&mut self, work: &mut usize) -> Result<bool, ReservationRefusal> {
        match self.stage {
            Stage::History => {
                if !self.history.as_mut().unwrap().advance(work)? { return Ok(false); }
                let root = match self.history.take().unwrap().finish() { Ok(map) => map, Err(_) => unreachable!("completed event insertion") };
                self.next_history = Some(HistoryPrefix { lineage: self.before.id.lineage, end: self.next_ordinal, root });
                self.stage = Stage::Raw;
            }
            Stage::Raw => {
                if self.bump.is_none() {
                    self.bump = Some(Bump::new(self.before.raw_before.clone(),
                        Cause::Raw { space: self.before.raw_space, state: self.before.event.raw_state }, self.before.ordinal()));
                }
                let Some(map) = self.bump.as_mut().unwrap().advance(work)? else { return Ok(false); };
                self.next_raw = Some(map); self.bump = None;
                self.stage = Stage::Layer { index: 0, action: false };
            }
            Stage::Layer { index, action } => {
                let Some(&(epoch, state)) = self.before.inputs.get(index) else {
                    self.stage = Stage::Complete; return Ok(true);
                };
                let layer = self.next_layers.get_mut(&epoch).ok_or(Refusal::MissingLayer)?;
                if self.bump.is_none() {
                    let cause = if action { Cause::Action { epoch, state, action: self.before.event.action } }
                        else { Cause::Situation { epoch, state } };
                    self.bump = Some(Bump::new(layer.root.clone(), cause, self.before.ordinal()));
                }
                let Some(map) = self.bump.as_mut().unwrap().advance(work)? else { return Ok(false); };
                layer.root = map; self.bump = None;
                self.stage = if action { Stage::Layer { index: index + 1, action: false } }
                    else { Stage::Layer { index, action: true } };
            }
            Stage::Complete => return Ok(true),
        }
        Ok(false)
    }
    pub(in crate::organism) fn finish(self) -> Result<Reservation<A>, Self> {
        if self.poisoned || !matches!(self.stage, Stage::Complete) { return Err(self); }
        Ok(self.into_reservation())
    }
    fn into_reservation(self) -> Reservation<A> {
        Reservation { before: self.before, highest_epoch: self.highest_epoch, pending_epoch: self.pending_epoch,
            next_layers: Arc::new(self.next_layers), next_raw: self.next_raw.expect("completed raw bump"),
            next_history: self.next_history.expect("completed history insertion"), captured: self.captured, next_ordinal: self.next_ordinal }
    }
    pub(super) fn run_to_completion(mut self, work: &mut usize) -> Result<Reservation<A>, Refusal> {
        loop { match self.advance_inner(work) {
            Ok(true) => return Ok(self.into_reservation()), Ok(false) => {},
            Err(ReservationRefusal::History(reason)) => return Err(reason),
            Err(ReservationRefusal::Poisoned) => unreachable!("a fresh consuming cursor cannot resume after unwind"),
        } }
    }
}
pub(super) fn same_owner<A: Copy + Ord>(before: &Cut<A>, highest_epoch: u128, pending_epoch: Option<u128>, owner: &Timeline<A>) -> bool {
    owner.complete && before.id.lineage == owner.lineage && before.id.ordinal == owner.ordinal
        && before.epoch == owner.epoch && before.raw_space == owner.raw_space
        && highest_epoch == owner.highest_epoch && pending_epoch == owner.pending_epoch
        && Arc::ptr_eq(&before.layers, &owner.layers) && before.raw_before.same_native_root(&owner.raw_current)
        && before.history_before.end == owner.history.end && before.history_before.root.same_native_root(&owner.history.root)
}

#[cfg(test)]
mod courts;
