//! Owned immutable coordinates for one confirmed-event lineage.
//!
//! This module supplies capture, projection and native evidence union. It is not
//! yet the organism's dispatch/retention/floor integration. Callers must bind each
//! epoch and raw-space identifier to an immutable interpretation, supply the exact
//! pre-action state of every live input layer, and report physical delivery
//! truthfully. Numeric epoch equality alone does not prove semantic transport.
//!
//! Every observed event advances one ordinal and all live layers. A cut owns the
//! prefix BEFORE that event. History gaps close the live timeline; a known older
//! cut remains readable. A fresh independent birth never repairs a missing event.
//! An ordered immutable event tree retains the exact admitted input alphabet,
//! including every live layer's pre-action input, alongside the counter index.
//! Its nodes share the same finite allowance; reaching capacity refuses BEFORE
//! dispatch. This in-memory prefix does not promise indefinite history or disk
//! persistence, nor outcomes/sensors not present in its declared event alphabet.
//! Work meters domain clauses and persistent-map positions, including bump reads.
//! Layer metadata, domain construction, generic comparisons, allocation and CPU
//! time have separate costs. Node limits do not cover total RAM or persistence.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::{Arc, OnceLock};
use std::sync::atomic::{AtomicU64, Ordering};
use synarc_store::prefix_map::{Lookup, LookupStep, PrefixMap, Refusal as StoreRefusal};

/// Native identity issued once. Import needs a checked external namespace map.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Lineage {
    authority: u64,
    birth: u64,
}

static NEXT_AUTHORITY: AtomicU64 = AtomicU64::new(0);

/// Issues process-local birth capabilities; IDs are not portable trust claims.
#[derive(Debug)]
pub(super) struct HistoryAuthority {
    namespace: u64,
    next_birth: u64,
}

/// Consumed by construction. Neither cloning nor deserialization can reuse it.
#[derive(Debug)]
pub(super) struct Birth {
    id: Lineage,
}

impl HistoryAuthority {
    pub(super) fn new() -> Result<Self, Refusal> {
        let namespace = NEXT_AUTHORITY
            .fetch_update(Ordering::AcqRel, Ordering::Acquire, |old| {
                old.checked_add(1)
            })
            .map_err(|_| Refusal::Overflow)?;
        Ok(Self {
            namespace,
            next_birth: 0,
        })
    }

    pub(super) fn birth(&mut self) -> Result<Birth, Refusal> {
        let birth = self.next_birth;
        self.next_birth = birth.checked_add(1).ok_or(Refusal::Overflow)?;
        Ok(Birth {
            id: Lineage {
                authority: self.namespace,
                birth,
            },
        })
    }
}

/// Caller-supplied metadata, distinct from the owned confirmed-event ordinal.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct PreActionTime {
    pub(super) episode: u64,
    pub(super) life_age: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Event<A> {
    pub(super) raw_state: u64,
    pub(super) situation: u64,
    pub(super) action: A,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct SampleId {
    pub(super) lineage: Lineage,
    pub(super) ordinal: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Cause<A> {
    Raw { space: u128, state: u64 },
    Situation { epoch: u128, state: u64 },
    Action { epoch: u128, state: u64, action: A },
}

/// One confirmed event in the declared observer-input alphabet. This is the
/// exact pre-action raw state, action, time and live layer inputs, together with
/// the captured outcome when available. It never invents an unrecorded value.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct HistoryEvent<A: Copy> {
    sensory: Option<super::Sensory>,
    pose: Option<u8>,
    id: SampleId,
    time: PreActionTime,
    event: Event<A>,
    epoch: u128,
    raw_space: u128,
    inputs: Arc<[(u128, u64)]>,
    captured: Arc<OnceLock<super::action_capture::CapturedOutcome>>,
}

impl<A: Copy> HistoryEvent<A> {
    /// The slot is filled once, before this event's history root is published.
    /// No writer survives publication; old immutable prefixes cannot change.
    pub(super) fn captured(&self) -> Option<&super::action_capture::CapturedOutcome> { self.captured.get() }
    pub(super) fn id(&self) -> SampleId {
        self.id
    }
    pub(super) fn time(&self) -> PreActionTime {
        self.time
    }
    pub(super) fn pose(&self) -> Option<u8> { self.pose }
    pub(super) fn sensory(&self) -> Option<&super::Sensory> { self.sensory.as_ref() }
    pub(super) fn event(&self) -> Event<A> {
        self.event
    }
    pub(super) fn epoch(&self) -> u128 {
        self.epoch
    }
    pub(super) fn raw_space(&self) -> u128 {
        self.raw_space
    }
    pub(super) fn layer_inputs(&self) -> &[(u128, u64)] {
        &self.inputs
    }
    pub(super) fn input(&self, epoch: u128) -> Result<u64, Refusal> {
        layer_input(&self.inputs, epoch)
    }
}

fn layer_input(inputs: &[(u128, u64)], epoch: u128) -> Result<u64, Refusal> {
    inputs
        .binary_search_by_key(&epoch, |&(id, _)| id)
        .map(|index| inputs[index].1)
        .map_err(|_| Refusal::MissingLayer)
}

/// A complete native input prefix [0,len), owning one persistent AVL root.
/// Root clones are constant-size; event payloads share immutable layer arrays.
/// The same node allowance bounds this tree and every counter/saved version.
#[derive(Clone, Debug)]
pub(super) struct HistoryPrefix<A: Copy> {
    lineage: Lineage,
    end: u64,
    root: PrefixMap<u64, Arc<HistoryEvent<A>>>,
}

impl<A: Copy> HistoryPrefix<A> {
    pub(super) fn lineage(&self) -> Lineage { self.lineage }
    pub(super) fn maximum_live_nodes(&self) -> usize { self.root.maximum_live_nodes() }
    pub(super) fn len(&self) -> u64 {
        self.end
    }

    /// Begin/resume at a known ordinal. A caller resuming an observer must also
    /// own its matching state; an arbitrary offset is not an initialization.
    pub(super) fn cursor(&self, from: u64) -> Result<HistoryCursor<A>, Refusal> {
        if from > self.end {
            return Err(Refusal::IncompleteHistory);
        }
        Ok(HistoryCursor {
            prefix: self.clone(),
            next: from,
            lookup: None,
        })
    }
}

/// Constant-size bounded replay cursor. Each lookup retains its exact AVL
/// descent across denied work, including one-unit grants; consumer work and
/// values are separate. Drop follows AVL height, never an event-count chain.
/// Exhaustion leaves the ordinal at its last complete event and never turns a
/// missing event into end-of-prefix.
pub(super) struct HistoryCursor<A: Copy> {
    prefix: HistoryPrefix<A>,
    next: u64,
    lookup: Option<Lookup<u64, Arc<HistoryEvent<A>>>>,
}
impl<A: Copy> std::fmt::Debug for HistoryCursor<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("HistoryCursor")
            .field("lineage", &self.prefix.lineage)
            .field("end", &self.prefix.end)
            .field("next", &self.next)
            .field("lookup_pending", &self.lookup.is_some())
            .finish()
    }
}

impl<A: Copy> HistoryCursor<A> {
    pub(super) fn position(&self) -> u64 {
        self.next
    }

    pub(super) fn next(
        &mut self,
        work: &mut usize,
    ) -> Result<Option<Arc<HistoryEvent<A>>>, Refusal> {
        if self.next == self.prefix.end {
            return Ok(None);
        }
        let lookup = self.lookup.get_or_insert_with(|| self.prefix.root.lookup(self.next));
        let event = loop {
            match lookup.advance(work)? {
                LookupStep::Pending => {},
                LookupStep::Complete(event) => break event.ok_or(Refusal::IncompleteHistory)?,
            }
        };
        if event.id
            != (SampleId {
                lineage: self.prefix.lineage,
                ordinal: self.next,
            })
        {
            return Err(Refusal::ConflictingSample);
        }
        self.next = self.next.checked_add(1).ok_or(Refusal::Overflow)?;
        self.lookup = None;
        Ok(Some(event))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Counter {
    rank: u64,
    last: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Refusal {
    Store(StoreRefusal),
    Overflow,
    IncompleteHistory,
    ForeignEpoch,
    MissingLayer,
    LayerCapacity,
    ConflictingSample,
    SampleCapacity,
    ForeignBudget,
    LiveInputLayers,
}

impl From<StoreRefusal> for Refusal {
    fn from(value: StoreRefusal) -> Self {
        Self::Store(value)
    }
}

/// Raw causes and situated causes cannot mix. In a situated union, a whole
/// situation absorbs its action clauses; projection also enforces this when a
/// caller constructs the variant directly. Action identity is the complete A.
#[derive(Clone, Debug)]
pub(super) enum Domain<A> {
    Raw {
        space: u128,
        states: BTreeSet<u64>,
    },
    Situated {
        epoch: u128,
        states: BTreeSet<u64>,
        actions: BTreeSet<(u64, A)>,
    },
}

impl<A: Copy + Ord> Domain<A> {
    pub(super) fn situated(
        epoch: u128,
        states: BTreeSet<u64>,
        mut actions: BTreeSet<(u64, A)>,
    ) -> Self {
        actions.retain(|(state, _)| !states.contains(state));
        Self::Situated {
            epoch,
            states,
            actions,
        }
    }
}

/// One-use output namespace reservation. It is not Clone and cannot be minted
/// from numeric epoch fields. Dropping it burns the name, never reissues it.
#[derive(Debug)]
pub(super) struct LanguageBirth { lineage: Lineage, epoch: u128 }
impl LanguageBirth {
    pub(super) fn lineage(&self) -> Lineage { self.lineage }
    pub(super) fn epoch(&self) -> u128 { self.epoch }
}

/// Exact birth of an input language in one native life. Fields stay private:
/// a caller cannot mint an origin by choosing a later convenient prefix.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct InputOrigin { lineage: Lineage, epoch: u128, ordinal: u64 }
impl InputOrigin {
    pub(super) fn lineage(self) -> Lineage { self.lineage }
    pub(super) fn epoch(self) -> u128 { self.epoch }
    pub(super) fn ordinal(self) -> u64 { self.ordinal }
}

#[derive(Clone, Debug)]
struct Layer<A: Copy> {
    origin: u64,
    root: PrefixMap<Cause<A>, Counter>,
}

/// One confirmed observation's pre-action prefix. All fields that establish
/// provenance are private; a prepared or unresolved dispatch cannot export a cut.
#[derive(Clone, Debug)]
pub(super) struct Cut<A: Copy> {
    sensory: Option<super::Sensory>,
    pose: Option<u8>,
    id: SampleId,
    time: PreActionTime,
    event: Event<A>,
    epoch: u128,
    raw_space: u128,
    inputs: Arc<[(u128, u64)]>,
    layers: Arc<BTreeMap<u128, Layer<A>>>,
    raw_before: PrefixMap<Cause<A>, Counter>,
    history_before: HistoryPrefix<A>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Coordinate {
    pub(super) rank: u64,
    pub(super) recency: u64,
    pub(super) last_carrier: Option<u64>,
}

fn charge(work: &mut usize) -> Result<(), Refusal> {
    *work = work.checked_sub(1).ok_or(StoreRefusal::Work)?;
    Ok(())
}

/// One evaluator for historical cuts, prepared reads and the live prefix.
/// Namespace/origin selection is checked by `project_owned` before entry.
fn project<A: Copy + Ord>(
    prefix: &PrefixMap<Cause<A>, Counter>,
    ordinal: u64,
    origin: u64,
    domain: &Domain<A>,
    work: &mut usize,
) -> Result<Coordinate, Refusal> {
    let mut rank = 0_u64;
    let mut last = None;
    let mut add = |cause, work: &mut usize| -> Result<(), Refusal> {
        if let Some(counter) = prefix.get_with_budget(&cause, work)? {
            rank = rank.checked_add(counter.rank).ok_or(Refusal::Overflow)?;
            last = Some(last.map_or(counter.last, |old: u64| old.max(counter.last)));
        }
        Ok(())
    };
    match domain {
        Domain::Raw { space, states } => {
            for &state in states {
                charge(work)?;
                add(
                    Cause::Raw {
                        space: *space,
                        state,
                    },
                    work,
                )?;
            }
        }
        Domain::Situated {
            epoch,
            states,
            actions,
        } => {
            for &state in states {
                charge(work)?;
                add(
                    Cause::Situation {
                        epoch: *epoch,
                        state,
                    },
                    work,
                )?;
            }
            for &(state, action) in actions {
                // Even absorbed clauses consume traversal work.
                charge(work)?;
                if !states.contains(&state) {
                    add(
                        Cause::Action {
                            epoch: *epoch,
                            state,
                            action,
                        },
                        work,
                    )?;
                }
            }
        }
    }
    let since = last
        .map(|at| at.checked_add(1).ok_or(Refusal::Overflow))
        .transpose()?
        .unwrap_or(origin);
    let recency = ordinal
        .checked_sub(since)
        .ok_or(Refusal::IncompleteHistory)?;
    Ok(Coordinate {
        rank,
        recency,
        last_carrier: last,
    })
}

fn project_owned<A: Copy + Ord>(
    raw_space: u128,
    raw_prefix: &PrefixMap<Cause<A>, Counter>,
    layers: &BTreeMap<u128, Layer<A>>,
    ordinal: u64,
    domain: &Domain<A>,
    work: &mut usize,
) -> Result<Coordinate, Refusal> {
    charge(work)?;
    let (origin, prefix) = match domain {
        Domain::Raw { space, .. } if *space == raw_space => (0, raw_prefix),
        Domain::Situated { epoch, .. } => {
            let layer = layers.get(epoch).ok_or(Refusal::ForeignEpoch)?;
            (layer.origin, &layer.root)
        }
        _ => return Err(Refusal::ForeignEpoch),
    };
    project(prefix, ordinal, origin, domain, work)
}

impl<A: Copy + Ord> Cut<A> {
    pub(super) fn id(&self) -> SampleId {
        self.id
    }
    pub(super) fn time(&self) -> PreActionTime {
        self.time
    }
    pub(super) fn pose(&self) -> Option<u8> { self.pose }
    pub(super) fn sensory(&self) -> Option<&super::Sensory> { self.sensory.as_ref() }
    pub(super) fn event(&self) -> Event<A> {
        self.event
    }
    pub(super) fn epoch(&self) -> u128 {
        self.epoch
    }
    pub(super) fn ordinal(&self) -> u64 {
        self.id.ordinal
    }
    pub(super) fn live_nodes(&self) -> usize {
        self.raw_before.live_nodes()
    }
    pub(super) fn layer_inputs(&self) -> &[(u128, u64)] {
        &self.inputs
    }
    pub(super) fn input(&self, epoch: u128) -> Result<u64, Refusal> {
        layer_input(&self.inputs, epoch)
    }
    pub(super) fn raw_space(&self) -> u128 { self.raw_space }
    pub(super) fn input_origin(&self, epoch: u128) -> Result<InputOrigin, Refusal> {
        let layer = self.layers.get(&epoch).ok_or(Refusal::ForeignEpoch)?;
        Ok(InputOrigin { lineage: self.id.lineage, epoch, ordinal: layer.origin })
    }
    pub(super) fn history(&self) -> HistoryPrefix<A> {
        self.history_before.clone()
    }

    pub(super) fn project_with_budget(
        &self,
        domain: &Domain<A>,
        work: &mut usize,
    ) -> Result<Coordinate, Refusal> {
        project_owned(
            self.raw_space,
            &self.raw_before,
            &self.layers,
            self.id.ordinal,
            domain,
            work,
        )
    }

    #[cfg(test)]
    fn project(&self, domain: &Domain<A>) -> Result<Coordinate, Refusal> {
        self.project_with_budget(domain, &mut 1000)
    }

    fn same_native_receipt(&self, other: &Self) -> bool {
        self.id == other.id
            && self.time == other.time
            && self.event == other.event
            && self.inputs == other.inputs
            && self.epoch == other.epoch
            && self.raw_space == other.raw_space
            && self.raw_before.same_native_root(&other.raw_before)
            && self.history_before.lineage == other.history_before.lineage
            && self.history_before.end == other.history_before.end
            && self
                .history_before
                .root
                .same_native_root(&other.history_before.root)
            && self.layers.len() == other.layers.len()
            && self.layers.iter().all(|(id, a)| {
                other
                    .layers
                    .get(id)
                    .is_some_and(|b| a.origin == b.origin && a.root.same_native_root(&b.root))
            })
    }
}

/// Cause selection is explicit: support-union clocks change with the candidate
/// support; a fixed cause domain does not. Neither policy remaps an epoch.
#[derive(Clone, Debug)]
pub(super) enum ProjectionPolicy<A> {
    SupportUnion { epoch: u128 },
    FixedDomain(Domain<A>),
}

/// The observer scorer borrows one immutable cut through shared ownership.
#[derive(Clone)]
pub(super) struct BoundCut<A: Copy> {
    cut: Arc<Cut<A>>,
    policy: ProjectionPolicy<A>,
}

impl<A: Copy> std::fmt::Debug for BoundCut<A> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("BoundCut")
            .field("id", &self.cut.id)
            .field("epoch", &self.cut.epoch)
            .finish_non_exhaustive()
    }
}

impl<A: Copy> BoundCut<A> {
    pub(super) fn new(cut: Arc<Cut<A>>, policy: ProjectionPolicy<A>) -> Self {
        Self { cut, policy }
    }
}

fn observer_unavailable(error: Refusal) -> crate::exhaust::ObserverUnavailable {
    use crate::exhaust::ObserverUnavailable;
    match error {
        Refusal::Overflow | Refusal::Store(StoreRefusal::Overflow) => {
            ObserverUnavailable::CoordinateOverflow
        }
        Refusal::Store(StoreRefusal::Work | StoreRefusal::LiveNodes)
        | Refusal::LayerCapacity
        | Refusal::SampleCapacity
        | Refusal::ForeignBudget => ObserverUnavailable::Resource,
        Refusal::IncompleteHistory
        | Refusal::ForeignEpoch
        | Refusal::MissingLayer
        | Refusal::ConflictingSample
        | Refusal::LiveInputLayers => ObserverUnavailable::History,
    }
}

impl<A: Copy + Ord> crate::exhaust::ObserverCut for BoundCut<A> {
    fn support_independent(&self) -> bool {
        matches!(&self.policy, ProjectionPolicy::FixedDomain(_))
    }

    fn project(
        &self,
        support: &[u64],
    ) -> Result<crate::exhaust::ObserverCoordinate, crate::exhaust::ObserverUnavailable> {
        let mut work = usize::MAX;
        self.project_with_budget(support, &mut work)
    }

    fn project_with_budget(
        &self,
        support: &[u64],
        work: &mut usize,
    ) -> Result<crate::exhaust::ObserverCoordinate, crate::exhaust::ObserverUnavailable> {
        let coordinate = match &self.policy {
            ProjectionPolicy::SupportUnion { epoch } => {
                let mut states = BTreeSet::new();
                for &state in support {
                    charge(work).map_err(observer_unavailable)?;
                    states.insert(state);
                }
                self.cut
                    .project_with_budget(&Domain::situated(*epoch, states, BTreeSet::new()), work)
            }
            ProjectionPolicy::FixedDomain(domain) => self.cut.project_with_budget(domain, work),
        }
        .map_err(observer_unavailable)?;
        Ok(crate::exhaust::ObserverCoordinate {
            events: coordinate.rank,
            recency: coordinate.recency,
        })
    }
}

/// A non-cloneable live chronology. Native IDs and epoch numbers do not certify
/// external provenance; this object records the events its trusted caller admits.
#[derive(Debug)]
pub(super) struct Timeline<A: Copy> {
    lineage: Lineage,
    ordinal: u64,
    epoch: u128,
    highest_epoch: u128,
    pending_epoch: Option<u128>,
    raw_space: u128,
    complete: bool,
    layers: Arc<BTreeMap<u128, Layer<A>>>,
    raw_current: PrefixMap<Cause<A>, Counter>,
    history: HistoryPrefix<A>,
    max_layers: usize,
}

impl<A: Copy + Ord> Timeline<A> {
    pub(super) fn new(birth: Birth, epoch: u128, raw_space: u128, max_nodes: usize) -> Self {
        let raw_current = PrefixMap::new(max_nodes);
        let layers = Arc::new(BTreeMap::from([(
            epoch,
            Layer {
                origin: 0,
                root: raw_current.empty_sibling(),
            },
        )]));
        Self {
            lineage: birth.id,
            ordinal: 0,
            epoch,
            highest_epoch: epoch,
            pending_epoch: None,
            raw_space,
            complete: true,
            layers,
            history: HistoryPrefix {
                lineage: birth.id,
                end: 0,
                root: raw_current.empty_sibling_as(),
            },
            raw_current,
            max_layers: max_nodes.max(1),
        }
    }

    pub(super) fn lineage(&self) -> Lineage { self.lineage }
    pub(super) fn raw_space(&self) -> u128 { self.raw_space }

    pub(super) fn epoch(&self) -> u128 {
        self.epoch
    }
    pub(super) fn ordinal(&self) -> u64 {
        self.ordinal
    }
    pub(super) fn live_nodes(&self) -> usize {
        self.raw_current.live_nodes()
    }

    /// Complete confirmed input history; unknown physical delivery closes even
    /// an otherwise readable prefix as the CURRENT complete state. Older owned
    /// cuts remain available independently.
    pub(super) fn input_origin(&self, epoch: u128) -> Result<InputOrigin, Refusal> {
        if !self.complete { return Err(Refusal::IncompleteHistory); }
        let layer = self.layers.get(&epoch).ok_or(Refusal::ForeignEpoch)?;
        Ok(InputOrigin { lineage: self.lineage, epoch, ordinal: layer.origin })
    }

    pub(super) fn current_history(&self) -> Result<HistoryPrefix<A>, Refusal> {
        if !self.complete {
            return Err(Refusal::IncompleteHistory);
        }
        Ok(self.history.clone())
    }

    pub(super) fn highest_epoch(&self) -> u128 {
        self.highest_epoch
    }

    /// Peek at the next never-issued name; does not reserve or install a layer.
    pub(super) fn next_epoch(&self) -> Result<u128, Refusal> {
        if !self.complete {
            return Err(Refusal::IncompleteHistory);
        }
        self.highest_epoch.checked_add(1).ok_or(Refusal::Overflow)
    }

    /// Reserve a monotonically fresh name. Only the latest unused reservation
    /// may be installed; superseded reservations are burned, never reused.
    pub(super) fn fresh_epoch(&mut self) -> Result<u128, Refusal> {
        let epoch = self.next_epoch()?;
        self.highest_epoch = epoch;
        self.pending_epoch = Some(epoch);
        Ok(epoch)
    }

    pub(super) fn reserve_language(&mut self) -> Result<LanguageBirth, Refusal> {
        let epoch = self.fresh_epoch()?;
        Ok(LanguageBirth { lineage: self.lineage, epoch })
    }

    /// Select a still-live immutable input layer without resetting its origin
    /// or counters. The issued-name high-water mark cannot decrease on a pop.
    pub(super) fn activate_layer(&mut self, epoch: u128) -> Result<(), Refusal> {
        if !self.complete {
            return Err(Refusal::IncompleteHistory);
        }
        if !self.layers.contains_key(&epoch) {
            return Err(Refusal::ForeignEpoch);
        }
        self.epoch = epoch;
        Ok(())
    }

    /// Atomically restore an explicitly retained representation prefix. Names
    /// are never recycled; confirmed events and already owned cuts are unchanged.
    /// Structural inspections are charged before publication. Map allocation,
    /// like the existing layer installation adapter, is not an RSS guarantee.
    pub(super) fn retain_input_layers(
        &mut self, epoch: u128, retained: &BTreeSet<u128>, work: &mut usize,
    ) -> Result<(), Refusal> {
        if !self.complete { return Err(Refusal::IncompleteHistory); }
        if !retained.contains(&epoch) { return Err(Refusal::ForeignEpoch); }
        for id in retained {
            charge(work)?;
            if !self.layers.contains_key(id) { return Err(Refusal::ForeignEpoch); }
        }
        for _ in self.layers.keys() { charge(work)?; }
        let layers = self.layers.iter().filter(|(id, _)| retained.contains(*id))
            .map(|(&id, layer)| (id, layer.clone())).collect();
        self.layers = Arc::new(layers);
        self.epoch = epoch;
        Ok(())
    }

    /// Read the receiver's own prospective coordinates, never imported counts.
    /// An unresolved delivery refuses even when the selected domain is empty.
    pub(super) fn current_coordinate(
        &self,
        domain: &Domain<A>,
        work: &mut usize,
    ) -> Result<Coordinate, Refusal> {
        if !self.complete {
            return Err(Refusal::IncompleteHistory);
        }
        project_owned(
            self.raw_space,
            &self.raw_current,
            &self.layers,
            self.ordinal,
            domain,
            work,
        )
    }

    pub(super) fn with_layer_limit(mut self, maximum: usize) -> Result<Self, Refusal> {
        if maximum < self.layers.len() {
            return Err(Refusal::LayerCapacity);
        }
        self.max_layers = maximum;
        Ok(self)
    }

    /// Independent known-zero birth, sharing the node allowance but no history.
    pub(super) fn independent(&self, birth: Birth, epoch: u128) -> Result<Self, Refusal> {
        let lineage = birth.id;
        if lineage == self.lineage {
            return Err(Refusal::ConflictingSample);
        }
        let raw_current = self.raw_current.empty_sibling();
        let layers = Arc::new(BTreeMap::from([(
            epoch,
            Layer {
                origin: 0,
                root: raw_current.empty_sibling(),
            },
        )]));
        Ok(Self {
            lineage,
            ordinal: 0,
            epoch,
            highest_epoch: epoch,
            pending_epoch: None,
            raw_space: self.raw_space,
            complete: true,
            layers,
            history: HistoryPrefix {
                lineage,
                end: 0,
                root: raw_current.empty_sibling_as(),
            },
            raw_current,
            max_layers: self.max_layers,
        })
    }

    /// Replace the top language only after every old input layer has retired.
    /// Its new zero origin is this installation, not a recovered historical state.
    pub(super) fn change_representation(&mut self, new_epoch: u128) -> Result<(), Refusal> {
        self.check_new_epoch(new_epoch)?;
        if self.layers.len() != 1 {
            return Err(Refusal::LiveInputLayers);
        }
        self.layers = Arc::new(BTreeMap::from([(
            new_epoch,
            Layer {
                origin: self.ordinal,
                root: self.raw_current.empty_sibling(),
            },
        )]));
        self.epoch = new_epoch;
        self.highest_epoch = self.highest_epoch.max(new_epoch);
        self.pending_epoch = None;
        Ok(())
    }

    fn check_new_epoch(&self, new_epoch: u128) -> Result<(), Refusal> {
        if !self.complete {
            return Err(Refusal::IncompleteHistory);
        }
        if new_epoch <= self.highest_epoch && self.pending_epoch != Some(new_epoch) {
            return Err(Refusal::ForeignEpoch);
        }
        Ok(())
    }

    pub(super) fn check_install_layer(&self, new_epoch: u128) -> Result<(), Refusal> {
        self.check_new_epoch(new_epoch)?;
        if self.layers.len() >= self.max_layers { return Err(Refusal::LayerCapacity); }
        Ok(())
    }

    /// New top language; old live input layers continue receiving every action.
    pub(super) fn install_layer(&mut self, new_epoch: u128) -> Result<(), Refusal> {
        self.check_install_layer(new_epoch)?;
        let mut layers = (*self.layers).clone();
        layers.insert(
            new_epoch,
            Layer {
                origin: self.ordinal,
                root: self.raw_current.empty_sibling(),
            },
        );
        self.layers = Arc::new(layers);
        self.epoch = new_epoch;
        self.highest_epoch = self.highest_epoch.max(new_epoch);
        self.pending_epoch = None;
        Ok(())
    }

    /// Replacement keeps the original input layer live and publishes a fresh
    /// output at this actual journal boundary. All checks precede mutation.
    pub(super) fn check_replace_layer(&self, old: u128, input: u128, new: u128) -> Result<(), Refusal> {
        self.check_new_epoch(new)?;
        if self.epoch != old || old == input || !self.layers.contains_key(&old) || !self.layers.contains_key(&input) {
            return Err(Refusal::ForeignEpoch);
        }
        Ok(())
    }
    pub(super) fn replace_layer(&mut self, old: u128, input: u128, new: u128) -> Result<(), Refusal> {
        self.check_replace_layer(old, input, new)?;
        let mut layers = (*self.layers).clone();
        layers.remove(&old);
        layers.insert(new, Layer { origin: self.ordinal, root: self.raw_current.empty_sibling() });
        self.layers = Arc::new(layers); self.epoch = new;
        self.highest_epoch = self.highest_epoch.max(new); self.pending_epoch = None;
        Ok(())
    }

    /// The caller must first retire the owning floor. Existing cuts pin the old
    /// input layer; retiring it cannot reopen a timeline with an unknown delivery.
    pub(super) fn retire_input_layer(&mut self, epoch: u128) -> Result<(), Refusal> {
        if epoch == self.epoch || !self.layers.contains_key(&epoch) {
            return Err(Refusal::ForeignEpoch);
        }
        let mut layers = (*self.layers).clone();
        layers.remove(&epoch);
        self.layers = Arc::new(layers);
        Ok(())
    }

    pub(super) fn prepare(
        &mut self,
        time: PreActionTime,
        raw: u64,
        state: u64,
        action: A,
        work: usize,
    ) -> Result<Prepared<'_, A>, Refusal> {
        if self.layers.len() != 1 {
            return Err(Refusal::MissingLayer);
        }
        self.prepare_in_layers(time, raw, &[(self.epoch, state)], action, work)
    }

    /// Reserve the next persistent prefix before dispatch. Input epochs must
    /// cover the live layers exactly; missing or duplicate inputs refuse.
    /// The work allowance applies to this preparation, including every counter
    /// lookup and update; layer sorting/metadata allocation are separately bounded
    /// by the declared layer limit. Refusal leaves all timeline state unchanged.
    pub(super) fn prepare_in_layers(
        &mut self,
        time: PreActionTime,
        raw_state: u64,
        inputs: &[(u128, u64)],
        action: A,
        work: usize,
    ) -> Result<Prepared<'_, A>, Refusal> {
        self.prepare_in_layers_with_pose(time, raw_state, inputs, action, None, work)
    }

    /// The optional sensor is observed before physical dispatch and owned by
    /// this exact event. Legacy callers explicitly retain an unavailable port.
    pub(super) fn prepare_in_layers_with_pose(
        &mut self,
        time: PreActionTime,
        raw_state: u64,
        inputs: &[(u128, u64)],
        action: A,
        pose: Option<u8>,
        mut work: usize,
    ) -> Result<Prepared<'_, A>, Refusal> {
        self.reserve_in_layers_with_pose(time, raw_state, inputs, action, pose, &mut work)?
            .bind(self)
            .map_err(|_| Refusal::ConflictingSample)
    }

    /// Own all fallible prefix preparation before an action guard spends its
    /// allowance. The exact native revision is checked again by `bind`; neither
    /// reserving nor dropping a reservation declares physical delivery.
    pub(super) fn reserve_in_layers_with_pose(
        &self,
        time: PreActionTime,
        raw_state: u64,
        inputs: &[(u128, u64)],
        action: A,
        pose: Option<u8>,
        work: &mut usize,
    ) -> Result<Reservation<A>, Refusal> {
        self.reserving_in_layers_with_pose(time, raw_state, inputs, action, pose)?.run_to_completion(work)
    }

    /// Capture the same event and native roots without visiting the trees yet.
    /// The owner must be retained on work refusal and bound before delivery.
    pub(super) fn reserving_in_layers_with_pose(&self, time: PreActionTime, raw_state: u64,
        inputs: &[(u128, u64)], action: A, pose: Option<u8>) -> Result<Reserving<A>, Refusal> {
        self.reserving_in_layers_with_sensory(time, raw_state, inputs, action, pose, None)
    }

    pub(super) fn reserving_in_layers_with_sensory(&self, time: PreActionTime, raw_state: u64,
        inputs: &[(u128, u64)], action: A, pose: Option<u8>, sensory: Option<super::Sensory>) -> Result<Reserving<A>, Refusal> {
        Reserving::new(self, time, raw_state, inputs, action, pose, sensory)
    }

}

/// Owned immutable allocation result. It is not cloneable and grants no
/// observed sample. Binding performs no allocation or work-budget operation.
#[derive(Debug)]
pub(super) struct Reservation<A: Copy> {
    before: Cut<A>,
    highest_epoch: u128,
    pending_epoch: Option<u128>,
    next_layers: Arc<BTreeMap<u128, Layer<A>>>,
    next_raw: PrefixMap<Cause<A>, Counter>,
    next_history: HistoryPrefix<A>,
    captured: Arc<OnceLock<super::action_capture::CapturedOutcome>>,
    next_ordinal: u64,
}
impl<A: Copy + Ord> Reservation<A> {
    pub(super) fn bind(self, owner: &mut Timeline<A>) -> Result<Prepared<'_, A>, Self> {
        let same = reservation::same_owner(&self.before, self.highest_epoch, self.pending_epoch, owner);
        if !same {
            return Err(self);
        }
        Ok(Prepared {
            owner,
            reservation: self,
        })
    }
}

/// Exclusive binding of an already-owned reservation. Dropping before dispatch
/// cancels it. Readers cannot publish its unconfirmed cut as a sample.
#[derive(Debug)]
pub(super) struct Prepared<'a, A: Copy> {
    owner: &'a mut Timeline<A>,
    reservation: Reservation<A>,
}

impl<'a, A: Copy + Ord> Prepared<'a, A> {
    pub(super) fn coordinate_before(
        &self,
        domain: &Domain<A>,
        work: &mut usize,
    ) -> Result<Coordinate, Refusal> {
        self.reservation.before.project_with_budget(domain, work)
    }
    pub(super) fn history_before(&self) -> HistoryPrefix<A> {
        self.reservation.before.history()
    }
    /// Call only after the action guard admits this exact prepared boundary.
    /// Unknown delivery stays closed even if the handle is dropped.
    pub(super) fn dispatch(self) -> InFlight<'a, A> {
        self.owner.complete = false;
        InFlight { transaction: self }
    }
}

#[derive(Debug)]
pub(super) struct InFlight<'a, A: Copy> {
    transaction: Prepared<'a, A>,
}
impl<A: Copy + Ord> InFlight<'_, A> {
    /// Completes the preallocated, unpublished journal event. A foreign action
    /// or unobserved result keeps the lineage closed and retains the handle.
    /// Sharing sensor Arcs and setting OnceLock cannot allocate after dispatch.
    fn observed_capture(self, capture: &super::ActionCapture<A>) -> Result<Cut<A>, Self> {
        if capture.action() != &self.transaction.reservation.before.event.action { return Err(self); }
        let Ok(outcome) = capture.captured_outcome() else { return Err(self); };
        self.transaction.reservation.captured.set(outcome)
            .expect("only the consuming dispatch owner can complete its unpublished slot");
        Ok(self.observed())
    }
    /// Compatibility for histories whose caller recorded only a typed event.
    /// They remain valid pre-event histories, with no invented outcome bytes.
    pub(super) fn observed(self) -> Cut<A> {
        let Prepared { owner, reservation } = self.transaction;
        owner.layers = reservation.next_layers;
        owner.raw_current = reservation.next_raw;
        owner.history = reservation.next_history;
        owner.ordinal = reservation.next_ordinal;
        owner.complete = true;
        reservation.before
    }
    pub(super) fn delivery_unknown(self) {}
    pub(super) fn not_delivered(self) {
        self.transaction.owner.complete = true;
    }
}

/// Owns the single adapter invocation at a reserved dispatch boundary. An
/// inspected/cloned ActionCapture cannot be attached to another invocation:
/// there is no completion method accepting a caller-supplied capture. The
/// physical adapter's truthful reporting remains an explicit boundary premise.
pub(super) struct CapturedDispatch<'a, A: Copy> {
    pending: Option<InFlight<'a, A>>,
    capture: super::ActionCapture<A>,
    requested: A,
}
impl<'a, A: Copy + Ord> CapturedDispatch<'a, A> {
    pub(super) fn invoke(pending: InFlight<'a, A>, invoke: impl FnOnce(A) -> super::ActionCapture<A>) -> Self {
        let action = pending.transaction.reservation.before.event.action;
        Self { pending: Some(pending), capture: invoke(action), requested: action }
    }
    /// Execution without an armed history grants no journal cut.
    pub(super) fn untracked(action: A, invoke: impl FnOnce(A) -> super::ActionCapture<A>) -> Self {
        Self { pending: None, capture: invoke(action), requested: action }
    }
    pub(super) fn capture(&self) -> &super::ActionCapture<A> { &self.capture }
    pub(super) fn observed(self) -> Result<(Option<Cut<A>>, super::ActionCapture<A>), Self> {
        if self.capture.action() != &self.requested || self.capture.captured_outcome().is_err() { return Err(self); }
        let Self { pending, capture, requested } = self;
        match pending {
            Some(pending) => match pending.observed_capture(&capture) {
                Ok(cut) => Ok((Some(cut), capture)),
                Err(pending) => Err(Self { pending: Some(pending), capture, requested }),
            },
            None => Ok((None, capture)),
        }
    }
}

/// The cut proves native prefix ownership, not the truth of this supplied label.
#[derive(Clone, Debug)]
pub(super) struct Sample<A: Copy, O> {
    pub(super) cut: Cut<A>,
    pub(super) outcome: O,
}

/// Move a checked native union into `left`, emptying `right` only on success.
/// All semantic/resource preflight errors preserve both collections. This does
/// not mutate either live timeline, transport epochs, or certify outcome labels.
/// Collection allocation and generic equality costs are outside the node budget.
pub(super) fn merge_samples<A: Copy + Ord, O: Eq>(
    left: &mut BTreeMap<SampleId, Sample<A, O>>,
    right: &mut BTreeMap<SampleId, Sample<A, O>>,
    limit: usize,
) -> Result<(), Refusal> {
    let budget = left.values().next().or_else(|| right.values().next());
    for (id, sample) in left.iter().chain(right.iter()) {
        if *id != sample.cut.id() {
            return Err(Refusal::ConflictingSample);
        }
        if budget.is_some_and(|first| !first.cut.raw_before.same_budget(&sample.cut.raw_before)) {
            return Err(Refusal::ForeignBudget);
        }
    }
    let mut additional = 0_usize;
    for (id, sample) in right.iter() {
        match left.get(id) {
            Some(old)
                if old.outcome != sample.outcome || !old.cut.same_native_receipt(&sample.cut) =>
            {
                return Err(Refusal::ConflictingSample);
            }
            Some(_) => {}
            None => additional = additional.checked_add(1).ok_or(Refusal::Overflow)?,
        }
    }
    if left
        .len()
        .checked_add(additional)
        .is_none_or(|count| count > limit)
    {
        return Err(Refusal::SampleCapacity);
    }
    left.append(right);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn birth() -> Birth {
        HistoryAuthority::new().unwrap().birth().unwrap()
    }
    fn step(life: &mut Timeline<u16>, state: u64, action: u16) -> Cut<u16> {
        let time = PreActionTime {
            episode: 0,
            life_age: life.ordinal,
        };
        life.prepare(time, state, state, action, 1000)
            .unwrap()
            .dispatch()
            .observed()
    }
    fn action(state: u64, gesture: u16) -> Domain<u16> {
        Domain::situated(1, BTreeSet::new(), [(state, gesture)].into())
    }
    #[test]
    fn live_floor_input_epochs_continue_to_count_and_missing_layers_refuse() {
        let mut life = Timeline::new(birth(), 1, 1, 10000)
            .with_layer_limit(2)
            .unwrap();
        drop(step(&mut life, 9, 257));
        life.install_layer(2).unwrap();
        assert_eq!(life.install_layer(3), Err(Refusal::LayerCapacity));
        assert_eq!(life.change_representation(3), Err(Refusal::LiveInputLayers));
        let time = PreActionTime {
            episode: 0,
            life_age: 1,
        };
        assert!(matches!(
            life.prepare(time, 9, 42, 1, 1000),
            Err(Refusal::MissingLayer)
        ));
        let cut = life
            .prepare_in_layers(time, 9, &[(2, 42), (1, 9)], 1, 1000)
            .unwrap()
            .dispatch()
            .observed();
        assert_eq!(cut.project(&action(9, 257)).unwrap().rank, 1);
        assert_eq!(
            cut.project(&Domain::situated(2, [42].into(), BTreeSet::new()))
                .unwrap()
                .rank,
            0
        );
        let next = life
            .prepare_in_layers(
                PreActionTime {
                    episode: 0,
                    life_age: 2,
                },
                7,
                &[(1, 7), (2, 43)],
                0,
                1000,
            )
            .unwrap()
            .dispatch()
            .observed();
        assert_eq!(
            next.project(&Domain::situated(1, [9].into(), BTreeSet::new()))
                .unwrap()
                .rank,
            2
        );
        assert_eq!(
            next.project(&Domain::situated(2, [42].into(), BTreeSet::new()))
                .unwrap()
                .rank,
            1
        );
        life.retire_input_layer(1).unwrap();
        let newest = step(&mut life, 7, 0);
        assert_eq!(newest.project(&action(9, 257)), Err(Refusal::ForeignEpoch));
        assert_eq!(
            cut.project(&action(9, 257)).unwrap().rank,
            1,
            "retiring live layer cannot rewrite a retained cut"
        );
    }
    #[test]
    fn every_short_stream_matches_a_complete_prefix_oracle_after_arbitrary_retention() {
        let alphabet = [(7, 0), (9, 1), (9, 257)];
        for encoded in 0..729usize {
            let mut n = encoded;
            let mut history = Vec::new();
            for _ in 0..6 {
                history.push(alphabet[n % 3]);
                n /= 3;
            }
            for subset in 0..64usize {
                let mut life = Timeline::new(birth(), 1, 1, 10000);
                let mut retained = Vec::new();
                for (i, &event) in history.iter().enumerate() {
                    let cut = step(&mut life, event.0, event.1);
                    if subset & (1 << i) != 0 {
                        retained.push((i, cut));
                    }
                }
                for (i, cut) in &retained {
                    for &cause in &alphabet {
                        let events = history[..*i]
                            .iter()
                            .enumerate()
                            .filter_map(|(j, &e)| (e == cause).then_some(j as u64))
                            .collect::<Vec<_>>();
                        let last = events.last().copied();
                        let want = Coordinate {
                            rank: events.len() as u64,
                            last_carrier: last,
                            recency: *i as u64 - last.map_or(0, |j| j + 1),
                        };
                        assert_eq!(cut.project(&action(cause.0, cause.1)).unwrap(), want);
                    }
                }
            }
        }
    }
    #[test]
    fn representation_transition_preserves_old_roots_and_raw_coordinates() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        drop(step(&mut life, 9, 1));
        let old = step(&mut life, 7, 0);
        life.change_representation(2).unwrap();
        let fresh = step(&mut life, 7, 0);
        assert_eq!(old.project(&action(9, 1)).unwrap().rank, 1);
        assert_eq!(fresh.project(&action(9, 1)), Err(Refusal::ForeignEpoch));
        let typed = Domain::situated(2, BTreeSet::new(), [(9, 1)].into());
        assert_eq!(
            fresh.project(&typed).unwrap(),
            Coordinate {
                rank: 0,
                recency: 0,
                last_carrier: None
            }
        );
        assert_eq!(
            fresh
                .project(&Domain::Raw {
                    space: 1,
                    states: [9].into()
                })
                .unwrap()
                .rank,
            1
        );
        assert_eq!(life.change_representation(1), Err(Refusal::ForeignEpoch));
    }
    #[test]
    fn evidence_union_is_idempotent_and_conflicts_do_not_partially_mutate_it() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let cut = step(&mut life, 7, 0);
        let id = cut.id;
        let mut pool = BTreeMap::from([(id, Sample { cut, outcome: 10 })]);
        let mut same = pool.clone();
        merge_samples(&mut pool, &mut same, 1).unwrap();
        assert_eq!(pool.len(), 1);
        assert!(same.is_empty());
        let mut conflicting = pool.clone();
        conflicting.get_mut(&id).unwrap().outcome = 11;
        assert_eq!(
            merge_samples(&mut pool, &mut conflicting, 2),
            Err(Refusal::ConflictingSample)
        );
        assert_eq!(pool[&id].outcome, 10);
        assert_eq!(conflicting[&id].outcome, 11, "refusal preserves the donor");
    }
    #[test]
    fn loss_of_observation_rows_does_not_change_rank_or_recency() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        let t0 = step(&mut life, 7, 0);
        let lost1 = step(&mut life, 9, 1);
        let t2 = step(&mut life, 7, 0);
        let lost3 = step(&mut life, 9, 1);
        let lost4 = step(&mut life, 9, 1);
        drop((lost1, lost3, lost4));
        assert_eq!(
            t0.project(&action(9, 1)).unwrap(),
            Coordinate {
                rank: 0,
                recency: 0,
                last_carrier: None
            }
        );
        assert_eq!(
            t2.project(&action(9, 1)).unwrap(),
            Coordinate {
                rank: 1,
                recency: 0,
                last_carrier: Some(1)
            }
        );
    }
    #[test]
    fn same_surviving_outcomes_and_latest_totals_do_not_erase_lost_source_order() {
        let mut a = Timeline::new(birth(), 1, 1, 10000);
        let mut b = a.independent(birth(), 1).unwrap();
        let mut kept_a = None;
        let mut kept_b = None;
        for (i, (ca, cb)) in [
            ((7, 0), (7, 0)),
            ((9, 0), (9, 1)),
            ((7, 0), (7, 0)),
            ((9, 1), (9, 0)),
            ((9, 0), (9, 0)),
            ((9, 1), (9, 1)),
            ((9, 0), (9, 0)),
            ((9, 1), (9, 1)),
        ]
        .into_iter()
        .enumerate()
        {
            let x = step(&mut a, ca.0, ca.1);
            let y = step(&mut b, cb.0, cb.1);
            if i == 2 {
                kept_a = Some(x);
                kept_b = Some(y)
            }
        }
        assert_eq!(kept_a.unwrap().project(&action(9, 0)).unwrap().rank, 1);
        assert_eq!(kept_b.unwrap().project(&action(9, 0)).unwrap().rank, 0);
    }
    #[test]
    fn merge_preserves_lineages_and_does_not_add_sibling_past() {
        let mut a = Timeline::new(birth(), 1, 1, 10000);
        let mut b = a.independent(birth(), 1).unwrap();
        drop(step(&mut a, 9, 1));
        let ac = step(&mut a, 7, 0);
        let bc = step(&mut b, 7, 0);
        let aid = ac.id;
        let bid = bc.id;
        let mut pool = BTreeMap::from([(
            aid,
            Sample {
                cut: ac,
                outcome: 10,
            },
        )]);
        merge_samples(
            &mut pool,
            &mut BTreeMap::from([(
                bid,
                Sample {
                    cut: bc,
                    outcome: 10,
                },
            )]),
            10,
        )
        .unwrap();
        assert_eq!(pool[&aid].cut.project(&action(9, 1)).unwrap().rank, 1);
        assert_eq!(pool[&bid].cut.project(&action(9, 1)).unwrap().rank, 0);
        assert_eq!(step(&mut b, 7, 0).project(&action(9, 1)).unwrap().rank, 0);
    }
    #[test]
    fn union_domain_deduplicates_fibres_and_keeps_full_action_identity() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        drop(step(&mut life, 9, 1));
        drop(step(&mut life, 9, 257));
        let cut = step(&mut life, 7, 0);
        assert_eq!(cut.project(&action(9, 1)).unwrap().rank, 1);
        assert_eq!(cut.project(&action(9, 257)).unwrap().rank, 1);
        let d = Domain::situated(1, [9].into(), [(9, 1), (9, 257)].into());
        assert_eq!(cut.project(&d).unwrap().rank, 2);
    }
    #[test]
    fn episode_age_reset_does_not_reset_observed_action_recency() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        drop(step(&mut life, 9, 1));
        drop(step(&mut life, 7, 0));
        let cut = life
            .prepare(
                PreActionTime {
                    episode: 1,
                    life_age: 0,
                },
                7,
                7,
                0,
                1000,
            )
            .unwrap()
            .dispatch()
            .observed();
        assert_eq!(cut.time.life_age, 0);
        assert_eq!(cut.project(&action(9, 1)).unwrap().recency, 1);
    }
    #[test]
    fn refused_resource_admission_and_unknown_delivery_never_become_zero() {
        let mut life = Timeline::new(birth(), 1, 1, 1);
        assert!(matches!(
            life.prepare(
                PreActionTime {
                    episode: 0,
                    life_age: 0
                },
                7,
                7,
                0,
                1000
            ),
            Err(Refusal::Store(StoreRefusal::LiveNodes))
        ));
        assert_eq!(life.ordinal, 0);
        assert_eq!(life.raw_current.live_nodes(), 0);
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        life.prepare(
            PreActionTime {
                episode: 0,
                life_age: 0,
            },
            7,
            7,
            0,
            1000,
        )
        .unwrap()
        .dispatch()
        .delivery_unknown();
        assert!(matches!(
            life.prepare(
                PreActionTime {
                    episode: 0,
                    life_age: 1
                },
                7,
                7,
                0,
                1000
            ),
            Err(Refusal::IncompleteHistory)
        ));
    }
    #[test]
    fn merge_cannot_smuggle_independent_memory_pools_or_false_sample_ids() {
        let mut a = Timeline::new(birth(), 1, 1, 1000);
        let mut b = Timeline::new(birth(), 1, 1, 1000);
        let ac = step(&mut a, 7, 0);
        let bc = step(&mut b, 8, 1);
        let mut pool = BTreeMap::from([(
            ac.id(),
            Sample {
                cut: ac.clone(),
                outcome: 1,
            },
        )]);
        assert_eq!(
            merge_samples(
                &mut pool,
                &mut BTreeMap::from([(
                    bc.id(),
                    Sample {
                        cut: bc,
                        outcome: 2
                    }
                )]),
                10
            ),
            Err(Refusal::ForeignBudget)
        );
        assert_eq!(pool.len(), 1);
        let mut child = a.independent(birth(), 1).unwrap();
        let cc = step(&mut child, 8, 1);
        assert_eq!(
            merge_samples(
                &mut pool,
                &mut BTreeMap::from([(
                    cc.id(),
                    Sample {
                        cut: ac,
                        outcome: 1
                    }
                )]),
                10
            ),
            Err(Refusal::ConflictingSample)
        );
        assert_eq!(pool.len(), 1);
        merge_samples(
            &mut pool,
            &mut BTreeMap::from([(
                cc.id(),
                Sample {
                    cut: cc,
                    outcome: 2,
                },
            )]),
            10,
        )
        .unwrap();
        assert_eq!(pool.len(), 2);
    }
    #[test]
    fn unresolved_delivery_cannot_reopen_lineage_via_epoch_reconfiguration() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let old = step(&mut life, 9, 257);
        life.install_layer(2).unwrap();
        life.prepare_in_layers(
            PreActionTime {
                episode: 0,
                life_age: 1,
            },
            9,
            &[(1, 9), (2, 42)],
            1,
            1000,
        )
        .unwrap()
        .dispatch()
        .delivery_unknown();
        assert_eq!(life.install_layer(3), Err(Refusal::IncompleteHistory));
        assert_eq!(
            life.change_representation(3),
            Err(Refusal::IncompleteHistory)
        );
        life.retire_input_layer(1).unwrap();
        assert_eq!(
            life.change_representation(3),
            Err(Refusal::IncompleteHistory)
        );
        assert!(matches!(
            life.prepare(
                PreActionTime {
                    episode: 1,
                    life_age: 0
                },
                7,
                7,
                0,
                1000
            ),
            Err(Refusal::IncompleteHistory)
        ));
        assert_eq!(old.project(&action(9, 257)).unwrap().rank, 0);
        let mut fresh = life.independent(birth(), 1).unwrap();
        let fresh_cut = step(&mut fresh, 7, 0);
        assert_ne!(fresh_cut.id().lineage, old.id().lineage);
        assert_eq!(fresh_cut.project(&action(9, 257)).unwrap().rank, 0);
    }
    #[test]
    fn unresolved_dispatch_drop_stays_closed_but_cancel_before_dispatch_is_safe() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let time = PreActionTime {
            episode: 0,
            life_age: 0,
        };
        drop(life.prepare(time, 7, 7, 0, 1000).unwrap());
        assert_eq!(life.ordinal, 0);
        life.prepare(time, 7, 7, 0, 1000)
            .unwrap()
            .dispatch()
            .not_delivered();
        assert_eq!(life.ordinal, 0);
        drop(life.prepare(time, 7, 7, 0, 1000).unwrap().dispatch());
        assert!(matches!(
            life.prepare(time, 7, 7, 0, 1000),
            Err(Refusal::IncompleteHistory)
        ));
    }

    #[test]
    fn current_prepared_and_retained_reads_share_values_and_exact_work_charges() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        let domains = [
            Domain::Raw {
                space: 1,
                states: [7, 9].into(),
            },
            Domain::situated(1, [7, 9].into(), BTreeSet::new()),
            action(9, 257),
            Domain::Situated {
                epoch: 1,
                states: [9].into(),
                actions: [(9, 1), (9, 257), (7, 0)].into(),
            },
        ];
        for (state, gesture) in [(7, 0), (9, 1), (9, 257), (7, 0)] {
            let before: Vec<_> = domains
                .iter()
                .map(|domain| {
                    let mut work = 1000;
                    let value = life.current_coordinate(domain, &mut work).unwrap();
                    (value, work)
                })
                .collect();
            let ordinal = life.ordinal();
            let prepared = life
                .prepare(
                    PreActionTime {
                        episode: 0,
                        life_age: ordinal,
                    },
                    state,
                    state,
                    gesture,
                    1000,
                )
                .unwrap();
            for (domain, &(want, remaining)) in domains.iter().zip(&before) {
                let mut work = 1000;
                assert_eq!(prepared.coordinate_before(domain, &mut work).unwrap(), want);
                assert_eq!(work, remaining);
            }
            let cut = prepared.dispatch().observed();
            assert_eq!(cut.epoch(), life.epoch());
            assert_eq!(cut.ordinal(), ordinal);
            assert_eq!(life.ordinal(), ordinal + 1);
            assert_eq!(cut.layer_inputs(), &[(1, state)]);
            assert_eq!(cut.live_nodes(), life.live_nodes());
            for (domain, &(want, remaining)) in domains.iter().zip(&before) {
                let mut work = 1000;
                assert_eq!(cut.project_with_budget(domain, &mut work).unwrap(), want);
                assert_eq!(work, remaining);
            }
        }
    }

    #[test]
    fn bump_reads_consume_work_and_failed_preparation_releases_all_nodes() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let mut successes = 0;
        for budget in 0..16 {
            let accepted = match life.prepare(
                PreActionTime {
                    episode: 0,
                    life_age: 0,
                },
                7,
                7,
                257,
                budget,
            ) {
                Ok(prepared) => {
                    drop(prepared);
                    true
                }
                Err(error) => {
                    assert_eq!(error, Refusal::Store(StoreRefusal::Work));
                    false
                }
            };
            if budget < 9 {
                assert!(
                    !accepted,
                    "history insertion plus three bump reads/updates need nine tree positions"
                );
            }
            successes += usize::from(accepted);
            assert_eq!(life.ordinal(), 0);
            assert_eq!(life.live_nodes(), 0);
        }
        assert!(successes > 0);
    }

    #[test]
    fn query_exhaustion_never_becomes_a_zero_coordinate() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        for state in 0..12 {
            drop(step(&mut life, state, 257));
        }
        let domain = Domain::situated(1, (0..12).collect(), BTreeSet::new());
        let mut work = 1000;
        let want = life.current_coordinate(&domain, &mut work).unwrap();
        assert_eq!(want.rank, 12);
        let required = 1000 - work;
        assert!(required > 1 + 2 * 12, "each lookup pays its full AVL path");
        for allowance in 0..required {
            let mut work = allowance;
            assert_eq!(
                life.current_coordinate(&domain, &mut work),
                Err(Refusal::Store(StoreRefusal::Work))
            );
            assert_eq!(work, 0);
        }
        let mut exact = required;
        assert_eq!(life.current_coordinate(&domain, &mut exact).unwrap(), want);
        assert_eq!(exact, 0);
        let cut = step(&mut life, 7, 1);
        let old = cut.project(&domain).unwrap();
        let time = PreActionTime {
            episode: 0,
            life_age: life.ordinal(),
        };
        life.prepare(time, 7, 7, 1, 1000)
            .unwrap()
            .dispatch()
            .delivery_unknown();
        assert_eq!(
            life.current_coordinate(&domain, &mut 1000),
            Err(Refusal::IncompleteHistory)
        );
        assert_eq!(cut.project(&domain).unwrap(), old);
        assert_eq!(
            life.current_coordinate(
                &Domain::situated(1, BTreeSet::new(), BTreeSet::new()),
                &mut 1000
            ),
            Err(Refusal::IncompleteHistory)
        );
    }

    #[test]
    fn observer_adapter_binds_union_and_fixed_causes_without_epoch_remapping() {
        use crate::exhaust::{ObserverCut, ObserverUnavailable};
        let mut life = Timeline::new(birth(), 41, 55, 10000);
        drop(step(&mut life, 7, 1));
        drop(step(&mut life, 9, 257));
        drop(step(&mut life, 7, 257));
        let cut = Arc::new(step(&mut life, 5, 0));
        let union = BoundCut::new(cut.clone(), ProjectionPolicy::SupportUnion { epoch: 41 });
        let value = union.project(&[7, 7, 9]).unwrap();
        assert_eq!((value.events, value.recency), (3, 0));
        let fixed = BoundCut::new(
            cut.clone(),
            ProjectionPolicy::FixedDomain(Domain::situated(41, BTreeSet::new(), [(9, 257)].into())),
        );
        for support in [vec![], vec![7], vec![7, 9]] {
            let value = fixed.project(&support).unwrap();
            assert_eq!((value.events, value.recency), (1, 1));
        }
        let wrong = BoundCut::new(cut, ProjectionPolicy::SupportUnion { epoch: 42 });
        assert!(matches!(
            wrong.project(&[7]),
            Err(ObserverUnavailable::History)
        ));
        assert!(matches!(
            union.project_with_budget(&[7], &mut 0),
            Err(ObserverUnavailable::Resource)
        ));
    }

    #[test]
    fn sample_capacity_refusal_preserves_both_inputs_and_live_clocks() {
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let a = step(&mut life, 7, 1);
        let b = step(&mut life, 9, 257);
        let mut left = BTreeMap::from([(a.id(), Sample { cut: a, outcome: 1 })]);
        let mut right = BTreeMap::from([(b.id(), Sample { cut: b, outcome: 2 })]);
        let before = life.current_coordinate(&action(9, 257), &mut 1000).unwrap();
        assert_eq!(
            merge_samples(&mut left, &mut right, 1),
            Err(Refusal::SampleCapacity)
        );
        assert_eq!((left.len(), right.len()), (1, 1));
        merge_samples(&mut left, &mut right, 2).unwrap();
        assert_eq!((left.len(), right.len()), (2, 0));
        assert_eq!(
            life.current_coordinate(&action(9, 257), &mut 1000).unwrap(),
            before
        );
    }

    fn actions_in(prefix: &HistoryPrefix<u16>) -> Vec<u16> {
        let mut cursor = prefix.cursor(0).unwrap();
        let mut events = Vec::new();
        while let Some(event) = cursor.next(&mut 1000).unwrap() {
            events.push(event.event().action);
        }
        events
    }

    #[test]
    fn full_history_preserves_order_that_all_rank_and_last_counters_forget() {
        let mut a = Timeline::new(birth(), 1, 1, 10000);
        let mut b = a.independent(birth(), 1).unwrap();
        let ha = [1, 257, 1, 257, 99];
        let hb = [257, 1, 1, 257, 99];
        for (&left, &right) in ha.iter().zip(&hb) {
            drop(step(&mut a, 7, left));
            drop(step(&mut b, 7, right));
        }
        for cause in [1, 257, 99] {
            let d = action(7, cause);
            assert_eq!(
                a.current_coordinate(&d, &mut 1000).unwrap(),
                b.current_coordinate(&d, &mut 1000).unwrap()
            );
        }
        let ac = step(&mut a, 7, 0);
        let bc = step(&mut b, 7, 0);
        assert_eq!(actions_in(&ac.history()), ha);
        assert_eq!(actions_in(&bc.history()), hb);
        // A finite observer remembering the first action distinguishes these
        // histories; neither retention nor counter equality may identify them.
        assert_ne!(actions_in(&ac.history())[0], actions_in(&bc.history())[0]);
        drop((a, b));
        assert_eq!(
            actions_in(&ac.history()),
            ha,
            "cut owns full previous input prefix"
        );
    }

    #[test]
    fn history_event_inputs_survive_layer_pop_retirement_and_independent_merge() {
        let mut a = Timeline::new(birth(), 10, 55, 10000)
            .with_layer_limit(3)
            .unwrap();
        drop(step(&mut a, 7, 1));
        a.install_layer(20).unwrap();
        let time = PreActionTime {
            episode: 3,
            life_age: 4,
        };
        let before = a
            .prepare_in_layers(time, 19, &[(20, 800), (10, 8)], 257, 1000)
            .unwrap()
            .dispatch()
            .observed();
        assert_eq!(before.input(10).unwrap(), 8);
        assert_eq!(before.input(20).unwrap(), 800);
        assert_eq!(before.input(30), Err(Refusal::MissingLayer));
        a.activate_layer(10).unwrap();
        a.retire_input_layer(20).unwrap();
        let retained = step(&mut a, 9, 3);
        let mut cursor = retained.history().cursor(1).unwrap();
        let event = cursor.next(&mut 1000).unwrap().unwrap();
        assert_eq!(event.id().ordinal, 1);
        assert_eq!(event.time(), time);
        assert_eq!(event.epoch(), 20);
        assert_eq!(event.raw_space(), 55);
        assert_eq!(
            event.event(),
            Event {
                raw_state: 19,
                situation: 800,
                action: 257
            }
        );
        assert_eq!(event.layer_inputs(), &[(10, 8), (20, 800)]);
        assert_eq!(event.input(10).unwrap(), 8);
        assert_eq!(event.input(20).unwrap(), 800);
        assert_eq!(event.input(30), Err(Refusal::MissingLayer));
        assert!(cursor.next(&mut 0).unwrap().is_none());
        let mut b = a.independent(birth(), 10).unwrap();
        drop(step(&mut b, 88, 99));
        let sibling = step(&mut b, 89, 98);
        let aid = retained.id();
        let bid = sibling.id();
        let mut left = BTreeMap::from([(
            aid,
            Sample {
                cut: retained,
                outcome: 0,
            },
        )]);
        let mut right = BTreeMap::from([(
            bid,
            Sample {
                cut: sibling,
                outcome: 0,
            },
        )]);
        merge_samples(&mut left, &mut right, 2).unwrap();
        assert_eq!(actions_in(&left[&aid].cut.history()), [1, 257]);
        assert_eq!(actions_in(&left[&bid].cut.history()), [99]);
        assert_eq!(actions_in(&a.current_history().unwrap()), [1, 257, 3]);
        assert_eq!(actions_in(&b.current_history().unwrap()), [99, 98]);
    }

    #[test]
    fn replay_work_is_resumable_and_missing_history_is_never_end_of_prefix() {
        let mut life = Timeline::new(birth(), 1, 1, 10000);
        for action in 0..20 {
            drop(step(&mut life, 7, action));
        }
        let prefix = life.current_history().unwrap();
        let mut cursor = prefix.cursor(0).unwrap();
        let mut all = Vec::new();
        for expected in 0..20 {
            let at = cursor.position();
            assert!(matches!(
                cursor.next(&mut 0),
                Err(Refusal::Store(StoreRefusal::Work))
            ));
            assert_eq!(cursor.position(), at);
            let event = cursor.next(&mut 1000).unwrap().unwrap();
            assert_eq!(event.id().ordinal, expected);
            all.push(event.event().action);
        }
        assert_eq!(all, (0..20).collect::<Vec<_>>());
        assert!(cursor.next(&mut 0).unwrap().is_none());
        assert!(matches!(prefix.cursor(21), Err(Refusal::IncompleteHistory)));
        let mut damaged = prefix.clone();
        damaged.root = damaged.root.empty_sibling();
        assert!(matches!(
            damaged.cursor(0).unwrap().next(&mut 1000),
            Err(Refusal::IncompleteHistory)
        ));
        let time = PreActionTime {
            episode: 0,
            life_age: 20,
        };
        let prepared = life.prepare(time, 7, 7, 50, 1000).unwrap();
        assert_eq!(prepared.history_before().len(), 20);
        prepared.dispatch().delivery_unknown();
        assert!(matches!(
            life.current_history(),
            Err(Refusal::IncompleteHistory)
        ));
        assert_eq!(actions_in(&prefix), (0..20).collect::<Vec<_>>());
    }

    // The expected complete event list is captured from actual pre-action
    // inputs, independently of the tree cursor and its conversion consumers.
    #[test]
    fn history_cursor_one_unit_grants_equal_full_list_work_and_frozen_prefix() {
        let mut life = Timeline::new(birth(), 10, 55, 100_000).with_layer_limit(3).unwrap();
        let mut expected = Vec::new();
        for ordinal in 0..31u64 {
            if ordinal == 7 { life.install_layer(20).unwrap(); }
            let time = PreActionTime { episode: ordinal / 5, life_age: ordinal % 5 };
            let inputs = if ordinal < 7 { vec![(10, ordinal + 100)] }
                else { vec![(10, ordinal + 100), (20, ordinal + 1000)] };
            let action = if ordinal % 2 == 0 { 1u16 } else { 257u16 };
            let cut = life.prepare_in_layers(time, ordinal + 2000, &inputs, action, 10_000)
                .unwrap().dispatch().observed();
            expected.push(HistoryEvent { sensory: None, pose: None, id: cut.id(), time,
                event: cut.event(), epoch: if ordinal < 7 { 10 } else { 20 },
                raw_space: 55, inputs: inputs.into(), captured: Arc::new(OnceLock::new()) });
        }
        let prefix = life.current_history().unwrap();
        let mut whole = prefix.cursor(7).unwrap();
        let mut whole_work = 10_000;
        let mut actual = Vec::new();
        while let Some(event) = whole.next(&mut whole_work).unwrap() { actual.push((*event).clone()); }
        assert_eq!(actual, expected[7..]);
        let charged = 10_000 - whole_work;
        assert!(charged > actual.len(), "fixture contains nontrivial AVL descents");

        let mut sliced = prefix.cursor(7).unwrap();
        let mut one = 1;
        assert!(matches!(sliced.next(&mut one), Err(Refusal::Store(StoreRefusal::Work))));
        assert_eq!(one, 0);
        assert_eq!(sliced.position(), 7);
        // Advance the same timeline and an independent lineage while a lookup
        // owns the old root. Neither append can alter that frozen descent.
        let mut sibling = life.independent(birth(), 10).unwrap();
        drop(step(&mut sibling, 900, 999));
        drop(life.prepare_in_layers(PreActionTime { episode: 8, life_age: 0 },
            800, &[(10, 800), (20, 1800)], 998, 10_000).unwrap().dispatch().observed());
        let mut actual = Vec::new();
        let mut spent = 1;
        for _ in 0..charged {
            let mut one = 1;
            let at = sliced.position();
            match sliced.next(&mut one) {
                Ok(Some(event)) => {
                    assert_eq!(event.id().ordinal, at);
                    actual.push((*event).clone());
                },
                Ok(None) => break,
                Err(Refusal::Store(StoreRefusal::Work)) => assert_eq!(sliced.position(), at),
                Err(reason) => panic!("unexpected history refusal: {reason:?}"),
            }
            spent += 1 - one;
        }
        assert_eq!(actual, expected[7..]);
        assert_eq!(spent, charged, "slice boundaries cannot replay paid tree positions");
        assert_eq!(sliced.position(), prefix.len());
        assert!(sliced.next(&mut 0).unwrap().is_none());
        assert_eq!(prefix.len(), 31);
        assert_eq!(life.current_history().unwrap().len(), 32);
        assert_eq!(sibling.current_history().unwrap().len(), 1);
    }

    #[test]
    fn retained_history_lookup_never_accepts_a_foreign_sample_or_missing_event() {
        let mut life = Timeline::new(birth(), 10, 55, 10_000);
        drop(step(&mut life, 7, 257));
        let prefix = life.current_history().unwrap();
        let mut foreign = life.independent(birth(), 10).unwrap();
        drop(step(&mut foreign, 7, 257));
        let mut damaged = prefix.clone();
        damaged.root = foreign.current_history().unwrap().root;
        let mut cursor = damaged.cursor(0).unwrap();
        for _ in 0..2 {
            assert_eq!(cursor.next(&mut 1), Err(Refusal::ConflictingSample));
            assert_eq!(cursor.position(), 0);
        }
        damaged.root = damaged.root.empty_sibling();
        let mut missing = damaged.cursor(0).unwrap();
        for _ in 0..2 {
            assert_eq!(missing.next(&mut 1), Err(Refusal::IncompleteHistory));
            assert_eq!(missing.position(), 0);
        }
    }

    #[test]
    fn exact_history_capacity_refuses_before_dispatch_and_releases_every_speculative_node() {
        let mut life = Timeline::new(birth(), 1, 1, 36);
        let mut confirmed = Vec::new();
        let mut refused = false;
        for action in 0..100_u16 {
            let before_nodes = life.live_nodes();
            let before_len = life.current_history().unwrap().len();
            let time = PreActionTime {
                episode: 0,
                life_age: life.ordinal(),
            };
            let accepted = match life.prepare(time, 7, 7, action, 1000) {
                Ok(prepared) => {
                    drop(prepared.dispatch().observed());
                    confirmed.push(action);
                    true
                }
                Err(error) => {
                    assert_eq!(error, Refusal::Store(StoreRefusal::LiveNodes));
                    false
                }
            };
            if !accepted {
                refused = true;
                assert_eq!(life.live_nodes(), before_nodes);
                assert_eq!(life.current_history().unwrap().len(), before_len);
                break;
            }
        }
        assert!(refused && !confirmed.is_empty());
        assert_eq!(actions_in(&life.current_history().unwrap()), confirmed);
        // Kept roots are the bound, rather than the number of Vec rows.
        let watcher: PrefixMap<u8, u8> = life.raw_current.empty_sibling_as();
        drop(life);
        assert_eq!(watcher.live_nodes(), 0);
    }

    #[test]
    fn popping_layers_cannot_reuse_an_issued_epoch_or_reset_a_live_origin() {
        let mut life = Timeline::new(birth(), 10, 1, 1000)
            .with_layer_limit(3)
            .unwrap();
        drop(step(&mut life, 7, 1));
        let future = life.fresh_epoch().unwrap();
        assert_eq!(future, 11);
        assert_eq!(life.epoch(), 10);
        life.install_layer(future).unwrap();
        life.activate_layer(10).unwrap();
        assert_eq!(life.highest_epoch(), 11);
        assert_eq!(life.next_epoch().unwrap(), 12);
        assert_eq!(
            life.current_coordinate(
                &Domain::situated(10, [7].into(), BTreeSet::new()),
                &mut 1000
            )
            .unwrap()
            .rank,
            1
        );
        assert_eq!(life.install_layer(11), Err(Refusal::ForeignEpoch));
        life.retire_input_layer(11).unwrap();
        assert_eq!(life.activate_layer(11), Err(Refusal::ForeignEpoch));
        assert_eq!(life.change_representation(11), Err(Refusal::ForeignEpoch));
        let burned = life.fresh_epoch().unwrap();
        let fresh = life.fresh_epoch().unwrap();
        assert_eq!((burned, fresh), (12, 13));
        assert_eq!(life.install_layer(burned), Err(Refusal::ForeignEpoch));
        life.install_layer(fresh).unwrap();
        assert_eq!(life.highest_epoch(), 13);
        life.activate_layer(10).unwrap();
        life.retire_input_layer(13).unwrap();
        life.install_layer(u128::MAX).unwrap();
        life.activate_layer(10).unwrap();
        assert_eq!(life.next_epoch(), Err(Refusal::Overflow));
        assert_eq!(life.fresh_epoch(), Err(Refusal::Overflow));
        assert_eq!(life.highest_epoch(), u128::MAX);
    }

    #[test]
    fn observer_adapter_needs_neither_debug_send_sync_nor_static_action() {
        use crate::exhaust::ObserverCut;
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
        struct Local<'a>(&'a u8, std::marker::PhantomData<std::rc::Rc<()>>);
        let byte = 7;
        let action = Local(&byte, std::marker::PhantomData);
        let mut life = Timeline::new(birth(), 1, 1, 1000);
        let cut = life
            .prepare(
                PreActionTime {
                    episode: 0,
                    life_age: 0,
                },
                7,
                7,
                action,
                1000,
            )
            .unwrap()
            .dispatch()
            .observed();
        let observer: Arc<dyn ObserverCut + '_> = Arc::new(BoundCut::new(
            Arc::new(cut),
            ProjectionPolicy::SupportUnion { epoch: 1 },
        ));
        assert_eq!(observer.project(&[7]).unwrap().events, 0);
        assert!(format!("{observer:?}").contains("BoundCut"));
    }
}

/// Lossless native lineage fields for test evidence, never a restore authority.
#[cfg(all(test, feature = "serde"))]
pub(super) fn lifecycle_lineage(value: &Lineage) -> serde_json::Value {
    serde_json::json!({"authority":value.authority,"birth":value.birth})
}

#[cfg(test)]
mod reservation_courts {
    use super::*;
    fn fresh()->Timeline<u16> {
        let mut authority=HistoryAuthority::new().unwrap();
        Timeline::new(authority.birth().unwrap(),1,1,1000)
    }
    fn reserve(life:&Timeline<u16>,work:&mut usize)->Result<Reservation<u16>,Refusal> {
        life.reserve_in_layers_with_pose(PreActionTime { episode:0,life_age:life.ordinal() },7,&[(1,7)],9,Some(3),work)
    }
    #[test]
    fn independent_revision_binding_and_guard_cancellation_preserve_exact_history() {
        let mut life=fresh();let mut foreign=fresh();
        let reserved=reserve(&life,&mut 1000).unwrap();
        assert_eq!(life.ordinal(),0);assert_eq!(life.current_history().unwrap().len(),0);
        let reserved=reserved.bind(&mut foreign).unwrap_err();
        assert_eq!(foreign.ordinal(),0);assert!(foreign.current_history().is_ok());
        drop(reserved); // A refusing action guard can discard without closing delivery.
        assert_eq!(life.live_nodes(),0);assert!(life.current_history().is_ok());
        let stale=reserve(&life,&mut 1000).unwrap();
        let first=reserve(&life,&mut 1000).unwrap().bind(&mut life).unwrap().dispatch().observed();
        assert_eq!(first.event().action,9);assert_eq!(life.ordinal(),1);
        assert!(stale.bind(&mut life).is_err());
        assert_eq!(life.current_history().unwrap().len(),1);
    }
    #[test]
    fn failed_owned_reservation_consumes_work_without_publishing_or_closing_a_prefix() {
        let life=fresh();let mut work=1;
        assert!(matches!(reserve(&life,&mut work),Err(Refusal::Store(StoreRefusal::Work))));
        assert_eq!(work,0);
        assert_eq!(life.ordinal(),0);assert_eq!(life.current_history().unwrap().len(),0);
        assert_eq!(life.live_nodes(),0);
    }
}

// Same exact coordinate query, with an owned cursor for finite search resumption.
mod retained_projection;

mod reservation;
pub(super) use reservation::{ReservationRefusal, Reserving};
