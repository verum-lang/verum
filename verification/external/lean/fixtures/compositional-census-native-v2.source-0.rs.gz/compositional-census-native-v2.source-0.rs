//! Finite lexical composition over the same address, price and Program path.
//! Child catalogues precede evidence. Both alternatives of a lazy branch are
//! named and charged, including the branch never executed on observed rows.
use super::*;

pub enum ControlSpec<V, P> {
    Branch { yes: Arc<Language<V, P>>, no: Arc<Language<V, P>> },
    Fold { body: Arc<Language<V, P>> },
}
impl<V, P> ControlSpec<V, P> {
    pub(super) fn arity(&self) -> usize { match self { Self::Branch { yes, .. } => yes.inputs + 1, Self::Fold { body } => body.inputs } }
    pub(super) fn children(&self) -> usize { match self { Self::Branch { .. } => 2, Self::Fold { .. } => 1 } }
    pub(super) fn child(&self, at: usize) -> &Arc<Language<V, P>> {
        match self { Self::Branch { yes, no } => if at == 0 { yes } else { no }, Self::Fold { body } => body }
    }
}
impl<V: Clone + Ord, P: Clone + Ord> Language<V, P> {
    /// A finite acyclic declaration: children are already immutable language
    /// owners, never empirical lists of successful programs. Union over finite
    /// declarations can grow; one declaration makes no unbounded-search claim.
    pub fn finite_compositional(grammar: Grammar<P, V>, calls: Vec<(usize, Program<V, P>)>, controls: Vec<ControlSpec<V, P>>)
        -> Result<Arc<Self>, SyntaxRefusal> {
        match super::super::validate(&grammar, &calls) {
            Err(SyntaxRefusal::EmptyOperations) if !controls.is_empty() => {},
            result => result?,
        }
        for control in &controls {
            match control {
                ControlSpec::Branch { yes, no } if yes.inputs != no.inputs || yes.inputs.checked_add(1).is_none() => return Err(SyntaxRefusal::ControlShape),
                ControlSpec::Fold { body } if body.inputs < 2 => return Err(SyntaxRefusal::ControlShape),
                _ => {},
            }
            for at in 0..control.children() {
                if control.child(at).extent == Extent::AllFinite { return Err(SyntaxRefusal::InfiniteChild); }
            }
        }
        Ok(Arc::new(Self { owner: Arc::new(()), inputs: grammar.inputs, operations: grammar.operations,
            literals: grammar.literals, calls, extent: Extent::Finite(grammar.max_steps), controls, version: 2 }))
    }
}
impl<V, P> Language<V, P> {
    pub(super) fn control(&self, alternative: usize) -> Option<&ControlSpec<V, P>> {
        alternative.checked_sub(self.operations.len() + self.calls.len()).and_then(|i| self.controls.get(i))
    }
    pub(super) fn child_language(&self, address: &Address, at: usize) -> &Arc<Self> {
        let child = &address.children[at];
        self.control(address.instructions[child.instruction].alternative).expect("owned control address").child(child.side)
    }
}
#[derive(Clone)]
pub(super) struct Child { pub instruction: usize, pub side: usize, pub address: Address }
pub(super) struct Slot<V, P> {
    instruction: usize, side: usize, language: Arc<Language<V, P>>,
    pub(super) cursor: Addresses<V, P>, selected: Option<Address>,
}
enum Phase { Slots { at: usize, side: usize }, Initialize(usize), Copy(usize), Carry(usize), Done }
pub(super) struct Enumeration<V, P> {
    language: Arc<Language<V, P>>, root: Address, pub(super) slots: Vec<Slot<V, P>>, copied: Vec<Child>, phase: Phase,
}
pub(super) enum Next { Advanced, Address(Address), Complete }
impl<V, P> Enumeration<V, P> {
    pub fn new(language: Arc<Language<V, P>>, root: Address) -> Self {
        Self { language, root, slots: Vec::new(), copied: Vec::new(), phase: Phase::Slots { at: 0, side: 0 } }
    }
    pub(super) fn child_index(&self) -> Option<usize> {
        match self.phase {
            Phase::Initialize(at) if at < self.slots.len() => Some(at),
            Phase::Carry(at) if at > 0 => Some(at - 1),
            _ => None,
        }
    }
    pub(super) fn accept_child(&mut self, next: Progress) {
        match self.phase {
            Phase::Initialize(at) => match next {
                Progress::Advanced => {},
                Progress::Address(a) => { self.slots[at].selected = Some(a); self.phase = Phase::Initialize(at + 1); },
                Progress::Complete => self.phase = Phase::Done,
            },
            Phase::Carry(at) if at > 0 => {
                let index = at - 1;
                match next {
                    Progress::Advanced => {},
                    Progress::Address(a) => { self.slots[index].selected = Some(a); self.phase = Phase::Initialize(at); },
                    Progress::Complete => {
                        self.slots[index].cursor = self.slots[index].language.enumerate();
                        self.slots[index].selected = None; self.phase = Phase::Carry(index);
                    },
                }
            },
            _ => unreachable!("parent is waiting for this child"),
        }
    }
    pub(super) fn step(&mut self) -> Result<Next, StructuralRefusal> {
        match self.phase {
            Phase::Slots { at, side } => {
                let Some(instruction) = self.root.instructions.get(at) else { self.phase = Phase::Initialize(0); return Ok(Next::Advanced); };
                if let Some(control) = self.language.control(instruction.alternative) {
                    if side < control.children() {
                        self.slots.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                        let language = Arc::clone(control.child(side)); let cursor = language.enumerate();
                        self.slots.push(Slot { instruction: at, side, language, cursor, selected: None });
                        self.phase = Phase::Slots { at, side: side + 1 }; return Ok(Next::Advanced);
                    }
                }
                self.phase = Phase::Slots { at: at + 1, side: 0 };
            },
            Phase::Initialize(_) => { self.copied.clear(); self.phase = Phase::Copy(0); },
            Phase::Copy(at) if at < self.slots.len() => {
                self.copied.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
                let slot = &self.slots[at];
                self.copied.push(Child { instruction: slot.instruction, side: slot.side, address: slot.selected.as_ref().expect("initialized product").clone() });
                self.phase = Phase::Copy(at + 1);
            },
            Phase::Copy(_) => {
                let mut result = self.root.clone(); result.children = Arc::from(std::mem::take(&mut self.copied));
                self.phase = Phase::Carry(self.slots.len()); return Ok(Next::Address(result));
            },
            Phase::Carry(0) => self.phase = Phase::Done,
            Phase::Carry(_) => unreachable!("delegated child carry"),
            Phase::Done => return Ok(Next::Complete),
        }
        Ok(Next::Advanced)
    }
}

pub(super) struct Counts<V, P> {
    pub factors: Vec<BigUint>, side: usize, product: BigUint, pub(super) child: Option<Box<Cardinality<V, P>>>,
}
impl<V, P> Counts<V, P> {
    pub fn new() -> Self { Self { factors: Vec::new(), side: 0, product: BigUint::from(1u8), child: None } }
    pub fn complete(&self, language: &Language<V, P>) -> bool { self.factors.len() == language.controls.len() }
    pub fn advance<M: WorkMeter + ?Sized>(&mut self, language: &Language<V, P>, meter: &mut M) -> Result<(), Failure<M::Error>> {
        meter.charge(1).map_err(Failure::Work)?;
        let control = &language.controls[self.factors.len()];
        if let Some(child) = self.child.take() {
            self.product *= child.value().expect("complete child cardinality"); self.side += 1;
        } else if self.side < control.children() {
            self.child = Some(Box::new(control.child(self.side).cardinality().expect("finite child declaration")));
        } else {
            self.factors.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
            self.factors.push(std::mem::replace(&mut self.product, BigUint::from(1u8))); self.side = 0;
        }
        Ok(())
    }
}

pub(super) struct EncodeTail<V, P> { at: usize, pub(super) child: Option<Box<Encoder<V, P>>>, ready: Option<Encoded>, copied: usize }
impl<V, P> EncodeTail<V, P> { pub fn new() -> Self { Self { at: 0, child: None, ready: None, copied: 0 } } }
pub(super) fn advance_encoder<V, P, M: WorkMeter + ?Sized>(encoder: &mut Encoder<V, P>, meter: &mut M) -> Result<bool, Failure<M::Error>> {
    if encoder.done { meter.charge(1).map_err(Failure::Work)?; return Ok(true); }
    if encoder.tail.child.is_some() {
        meter.charge(1).map_err(Failure::Work)?;
        encoder.tail.ready = Some(encoder.tail.child.take().expect("retained encoder").finish().unwrap_or_else(|_| unreachable!("complete child word")));
        return Ok(false);
    }
    meter.charge(1).map_err(Failure::Work)?;
    if let Some(word) = &encoder.tail.ready {
        if let Some(&bit) = word.bits().get(encoder.tail.copied) {
            encoder.bits.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
            encoder.bits.push(bit); encoder.tail.copied += 1;
        } else { encoder.tail.ready = None; encoder.tail.at += 1; encoder.tail.copied = 0; }
    } else if let Some(child) = encoder.address.children.get(encoder.tail.at) {
        let language = encoder.language.child_language(&encoder.address, encoder.tail.at);
        encoder.tail.child = Some(Box::new(language.encode(child.address.clone())?));
    } else { encoder.done = true; }
    Ok(encoder.done)
}

/// Iterative accounting of every retained root, instruction and operand. Shared
/// child addresses are conservatively charged per syntactic occurrence.
pub struct RetainedCells { pending: Vec<(Address, usize, usize)>, total: usize }
impl Address {
    pub fn retained_cells(&self) -> RetainedCells { RetainedCells { pending: vec![(self.clone(), 0, 0)], total: 1 } }
}
impl RetainedCells {
    pub fn total(&self) -> Option<usize> { self.pending.is_empty().then_some(self.total) }
    pub fn advance<M: WorkMeter + ?Sized>(&mut self, meter: &mut M) -> Result<bool, Failure<M::Error>> {
        meter.charge(1).map_err(Failure::Work)?;
        let Some((address, at, child)) = self.pending.last() else { return Ok(true); };
        if let Some(instruction) = address.instructions.get(*at) {
            let total = self.total.checked_add(1).and_then(|n| n.checked_add(instruction.operands.len())).ok_or(StructuralRefusal::Capacity)?;
            self.total = total; self.pending.last_mut().unwrap().1 += 1;
            let last = self.pending.last().unwrap();
            if last.1 == last.0.instructions.len() && last.0.children.is_empty() { self.pending.pop(); }
        } else if let Some(next) = address.children.get(*child) {
            let next = next.address.clone(); let total = self.total.checked_add(1).ok_or(StructuralRefusal::Capacity)?;
            self.pending.try_reserve(1).map_err(|_| StructuralRefusal::Allocation)?;
            self.pending.last_mut().unwrap().2 += 1; self.pending.push((next, 0, 0)); self.total = total;
        } else { self.pending.pop(); }
        Ok(self.pending.is_empty())
    }
}
