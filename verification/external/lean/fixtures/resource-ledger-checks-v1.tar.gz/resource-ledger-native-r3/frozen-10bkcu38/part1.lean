import FrozenObserverDeclarations

import VerumExternalReplay.ResourceLedger

open ResourceLedger

set_option warningAsError true

namespace FrozenObserverExport

theorem snapshot0 : s0.quota = some 24 ∧ total s0.slots = 0 ∧ s0.peak = 0 ∧ [classTotal 0 s0.slots, classTotal 1 s0.slots, classTotal 2 s0.slots, classTotal 3 s0.slots, classTotal 4 s0.slots] = [0, 0, 0, 0, 0] ∧ reservations s0.slots = 0 := by decide_cbv

theorem snapshot1 : s1.quota = some 24 ∧ total s1.slots = 16 ∧ s1.peak = 16 ∧ [classTotal 0 s1.slots, classTotal 1 s1.slots, classTotal 2 s1.slots, classTotal 3 s1.slots, classTotal 4 s1.slots] = [0, 16, 0, 0, 0] ∧ reservations s1.slots = 1 := by decide_cbv

theorem snapshot2 : s2.quota = some 24 ∧ total s2.slots = 16 ∧ s2.peak = 16 ∧ [classTotal 0 s2.slots, classTotal 1 s2.slots, classTotal 2 s2.slots, classTotal 3 s2.slots, classTotal 4 s2.slots] = [0, 16, 0, 0, 0] ∧ reservations s2.slots = 1 := by decide_cbv

theorem snapshot3 : s3.quota = some 48 ∧ total s3.slots = 16 ∧ s3.peak = 16 ∧ [classTotal 0 s3.slots, classTotal 1 s3.slots, classTotal 2 s3.slots, classTotal 3 s3.slots, classTotal 4 s3.slots] = [0, 16, 0, 0, 0] ∧ reservations s3.slots = 1 := by decide_cbv

theorem snapshot4 : s4.quota = some 48 ∧ total s4.slots = 32 ∧ s4.peak = 48 ∧ [classTotal 0 s4.slots, classTotal 1 s4.slots, classTotal 2 s4.slots, classTotal 3 s4.slots, classTotal 4 s4.slots] = [0, 32, 0, 0, 0] ∧ reservations s4.slots = 1 := by decide_cbv

theorem snapshot5 : s5.quota = some 48 ∧ total s5.slots = 32 ∧ s5.peak = 48 ∧ [classTotal 0 s5.slots, classTotal 1 s5.slots, classTotal 2 s5.slots, classTotal 3 s5.slots, classTotal 4 s5.slots] = [0, 32, 0, 0, 0] ∧ reservations s5.slots = 1 := by decide_cbv

theorem snapshot6 : s6.quota = some 48 ∧ total s6.slots = 32 ∧ s6.peak = 48 ∧ [classTotal 0 s6.slots, classTotal 1 s6.slots, classTotal 2 s6.slots, classTotal 3 s6.slots, classTotal 4 s6.slots] = [0, 32, 0, 0, 0] ∧ reservations s6.slots = 1 := by decide_cbv

theorem snapshot7 : s7.quota = some 48 ∧ total s7.slots = 0 ∧ s7.peak = 48 ∧ [classTotal 0 s7.slots, classTotal 1 s7.slots, classTotal 2 s7.slots, classTotal 3 s7.slots, classTotal 4 s7.slots] = [0, 0, 0, 0, 0] ∧ reservations s7.slots = 0 := by decide_cbv

#print axioms snapshot0

#print axioms snapshot1

#print axioms snapshot2

#print axioms snapshot3

#print axioms snapshot4

#print axioms snapshot5

#print axioms snapshot6

#print axioms snapshot7

end FrozenObserverExport
