import FrozenObserverDeclarations

import VerumExternalReplay.ResourceLedger

open ResourceLedger

set_option warningAsError true

namespace FrozenObserverExport

theorem step_s1 : commit s0 (reserve s0 1 16) = s1 := by
  have admitted : admissible s0 16 = true := by
    simp only [admissible, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨rfl, Nat.le_of_ble_eq_true rfl⟩, rfl⟩
  rw [(reserve_acceptance s0 1 16).mpr admitted]
  rfl

theorem step_s2 : commit s1 (reserve s1 1 32) = s2 := by
  rw [reserve_at_capacity s1 1 32 rfl (Nat.le_of_ble_eq_true rfl) rfl]
  rfl

theorem step_s3 : commit s2 (grant s2 (some 48)) = s3 := by
  decide_cbv

theorem step_grown : commit s3 (reserve s3 1 32) = grown := by
  have admitted : admissible s3 32 = true := by
    simp only [admissible, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨rfl, Nat.le_of_ble_eq_true rfl⟩, rfl⟩
  rw [(reserve_acceptance s3 1 32).mpr admitted]
  rfl

theorem step_s4 : commit grown (release grown [] ⟨1,16,1⟩ [⟨1,32,1⟩]) = s4 := by
  decide_cbv

theorem step_s5 : commit s4 (alias s4 [⟨1,16,0⟩] ⟨1,32,1⟩ []) = s5 := by
  decide_cbv

theorem step_s6 : commit s5 (release s5 [⟨1,16,0⟩] ⟨1,32,2⟩ []) = s6 := by
  decide_cbv

theorem step_s7 : commit s6 (release s6 [⟨1,16,0⟩] ⟨1,32,1⟩ []) = s7 := by
  decide_cbv

#print axioms step_s1

#print axioms step_s2

#print axioms step_s3

#print axioms step_grown

#print axioms step_s4

#print axioms step_s5

#print axioms step_s6

#print axioms step_s7

end FrozenObserverExport
