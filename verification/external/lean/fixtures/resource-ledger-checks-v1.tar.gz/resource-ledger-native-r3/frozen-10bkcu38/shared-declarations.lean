import VerumExternalReplay.ResourceLedger

open ResourceLedger

set_option warningAsError true

namespace FrozenObserverExport

def s0 : Ledger := ⟨0, 18446744073709551615, some 24, 0, false, []⟩

def s1 : Ledger := ⟨0, 18446744073709551615, some 24, 16, false, [⟨1,16,1⟩]⟩

def s2 : Ledger := ⟨0, 18446744073709551615, some 24, 16, false, [⟨1,16,1⟩]⟩

def s3 : Ledger := ⟨0, 18446744073709551615, some 48, 16, false, [⟨1,16,1⟩]⟩

def grown : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,1⟩,⟨1,32,1⟩]⟩

def s4 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,1⟩]⟩

def s5 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,2⟩]⟩

def s6 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,1⟩]⟩

def s7 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,0⟩]⟩

end FrozenObserverExport
