import VerumExternalReplay.ResourceLedger

open ResourceLedger

set_option warningAsError true

namespace FrozenObserverExport

def s0 : Ledger := ⟨0, 18446744073709551615, some 24, 0, false, []⟩

def s1 : Ledger := ⟨0, 18446744073709551615, some 24, 16, false, [⟨1,16,1⟩]⟩

theorem step_s1 : commit s0 (reserve s0 1 16) = s1 := by
  have admitted : admissible s0 16 = true := by
    simp only [admissible, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨rfl, Nat.le_of_ble_eq_true rfl⟩, rfl⟩
  rw [(reserve_acceptance s0 1 16).mpr admitted]
  rfl

def s2 : Ledger := ⟨0, 18446744073709551615, some 24, 16, false, [⟨1,16,1⟩]⟩

theorem step_s2 : commit s1 (reserve s1 1 32) = s2 := by
  rw [reserve_at_capacity s1 1 32 rfl (Nat.le_of_ble_eq_true rfl) rfl]
  rfl

def s3 : Ledger := ⟨0, 18446744073709551615, some 48, 16, false, [⟨1,16,1⟩]⟩

theorem step_s3 : commit s2 (grant s2 (some 48)) = s3 := by
  decide_cbv

def grown : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,1⟩,⟨1,32,1⟩]⟩

theorem step_grown : commit s3 (reserve s3 1 32) = grown := by
  have admitted : admissible s3 32 = true := by
    simp only [admissible, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨rfl, Nat.le_of_ble_eq_true rfl⟩, rfl⟩
  rw [(reserve_acceptance s3 1 32).mpr admitted]
  rfl

def s4 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,1⟩]⟩

theorem step_s4 : commit grown (release grown [] ⟨1,16,1⟩ [⟨1,32,1⟩]) = s4 := by
  decide_cbv

def s5 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,2⟩]⟩

theorem step_s5 : commit s4 (alias s4 [⟨1,16,0⟩] ⟨1,32,1⟩ []) = s5 := by
  decide_cbv

def s6 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,1⟩]⟩

theorem step_s6 : commit s5 (release s5 [⟨1,16,0⟩] ⟨1,32,2⟩ []) = s6 := by
  decide_cbv

def s7 : Ledger := ⟨0, 18446744073709551615, some 48, 48, false, [⟨1,16,0⟩,⟨1,32,0⟩]⟩

theorem step_s7 : commit s6 (release s6 [⟨1,16,0⟩] ⟨1,32,1⟩ []) = s7 := by
  decide_cbv

theorem snapshot0 : s0.quota = some 24 ∧ total s0.slots = 0 ∧ s0.peak = 0 ∧ [classTotal 0 s0.slots, classTotal 1 s0.slots, classTotal 2 s0.slots, classTotal 3 s0.slots, classTotal 4 s0.slots] = [0, 0, 0, 0, 0] ∧ reservations s0.slots = 0 := by decide_cbv

theorem snapshot1 : s1.quota = some 24 ∧ total s1.slots = 16 ∧ s1.peak = 16 ∧ [classTotal 0 s1.slots, classTotal 1 s1.slots, classTotal 2 s1.slots, classTotal 3 s1.slots, classTotal 4 s1.slots] = [0, 16, 0, 0, 0] ∧ reservations s1.slots = 1 := by decide_cbv

theorem snapshot2 : s2.quota = some 24 ∧ total s2.slots = 16 ∧ s2.peak = 16 ∧ [classTotal 0 s2.slots, classTotal 1 s2.slots, classTotal 2 s2.slots, classTotal 3 s2.slots, classTotal 4 s2.slots] = [0, 16, 0, 0, 0] ∧ reservations s2.slots = 1 := by decide_cbv

theorem snapshot3 : s3.quota = some 48 ∧ total s3.slots = 16 ∧ s3.peak = 16 ∧ [classTotal 0 s3.slots, classTotal 1 s3.slots, classTotal 2 s3.slots, classTotal 3 s3.slots, classTotal 4 s3.slots] = [0, 16, 0, 0, 0] ∧ reservations s3.slots = 1 := by decide_cbv

theorem snapshot4 : s4.quota = some 49 ∧ total s4.slots = 32 ∧ s4.peak = 48 ∧ [classTotal 0 s4.slots, classTotal 1 s4.slots, classTotal 2 s4.slots, classTotal 3 s4.slots, classTotal 4 s4.slots] = [0, 32, 0, 0, 0] ∧ reservations s4.slots = 1 := by decide_cbv

theorem snapshot5 : s5.quota = some 48 ∧ total s5.slots = 32 ∧ s5.peak = 48 ∧ [classTotal 0 s5.slots, classTotal 1 s5.slots, classTotal 2 s5.slots, classTotal 3 s5.slots, classTotal 4 s5.slots] = [0, 32, 0, 0, 0] ∧ reservations s5.slots = 1 := by decide_cbv

theorem snapshot6 : s6.quota = some 48 ∧ total s6.slots = 32 ∧ s6.peak = 48 ∧ [classTotal 0 s6.slots, classTotal 1 s6.slots, classTotal 2 s6.slots, classTotal 3 s6.slots, classTotal 4 s6.slots] = [0, 32, 0, 0, 0] ∧ reservations s6.slots = 1 := by decide_cbv

theorem snapshot7 : s7.quota = some 48 ∧ total s7.slots = 0 ∧ s7.peak = 48 ∧ [classTotal 0 s7.slots, classTotal 1 s7.slots, classTotal 2 s7.slots, classTotal 3 s7.slots, classTotal 4 s7.slots] = [0, 0, 0, 0, 0] ∧ reservations s7.slots = 0 := by decide_cbv

end FrozenObserverExport
