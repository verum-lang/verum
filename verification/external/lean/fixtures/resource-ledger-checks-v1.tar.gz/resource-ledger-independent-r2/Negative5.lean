import VerumExternalReplay.ResourceLedgerControls
open ResourceLedger ResourceLedgerControls
set_option warningAsError true
example : ready noQuota { pending with reason := .poisoned } = true := by decide_cbv
