import VerumExternalReplay.ResourceLedgerControls
open ResourceLedger ResourceLedgerControls
set_option warningAsError true
example : total (commit shared (release shared [] ⟨1,16,2⟩ [])).slots = 0 := by decide_cbv
