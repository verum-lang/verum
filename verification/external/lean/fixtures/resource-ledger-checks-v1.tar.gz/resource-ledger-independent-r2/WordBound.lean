import VerumExternalReplay.ResourceLedger
open ResourceLedger
set_option warningAsError true
set_option autoImplicit false

theorem literal_via_bool : (16 : Nat) ≤ 18446744073709551615 :=
  Nat.le_of_ble_eq_true rfl

theorem computed_via_bool : total ([] : List Slot) + 16 ≤ 18446744073709551615 :=
  Nat.le_of_ble_eq_true rfl

theorem literal_via_add : (16 : Nat) ≤ 18446744073709551615 :=
  Nat.le_add_right 16 18446744073709551599

def a : Ledger := ⟨0, 18446744073709551615, some 24, 0, false, []⟩
def b : Ledger := ⟨0, 18446744073709551615, some 24, 16, false, [⟨1,16,1⟩]⟩

theorem reserve_via_acceptance : commit a (reserve a 1 16) = b := by
  have accepted : admissible a 16 = true := by
    simp only [admissible, Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨⟨rfl, computed_via_bool⟩, rfl⟩
  rw [(reserve_acceptance a 1 16).mpr accepted]
  rfl

#print axioms literal_via_bool
#print axioms computed_via_bool
#print axioms literal_via_add
#print axioms reserve_via_acceptance
