import VerumExternalReplay.ResourceLedgerControls
open ResourceLedger ResourceLedgerControls
set_option warningAsError true
example : total (commit original (alias original [] ⟨1,16,1⟩ [])).slots = 32 := by decide_cbv
