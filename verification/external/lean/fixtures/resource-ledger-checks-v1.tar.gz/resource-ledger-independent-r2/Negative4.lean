import VerumExternalReplay.ResourceLedgerControls
open ResourceLedger ResourceLedgerControls
set_option warningAsError true
example : resume (commit original (grant original (some 48))) pending = some (11,13,18) := by decide_cbv
