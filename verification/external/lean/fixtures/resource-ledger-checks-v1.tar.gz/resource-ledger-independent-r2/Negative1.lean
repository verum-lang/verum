import VerumExternalReplay.ResourceLedgerControls
open ResourceLedger ResourceLedgerControls
set_option warningAsError true
example : reserve original 1 32 = .ok (admitted original 1 32) := by decide_cbv
