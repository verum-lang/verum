//! End-to-end acquired prediction on disjoint exact states and complete targets.
//! The generator is independent of the interpreter: finite arithmetic dynamics
//! with fresh nonrepeating inputs. No public benchmark data is used here.
use super::*;
use crate::program::observer::{InputBinding, InputSource};
use crate::program::{ExecutionLimit, Operand, Operation, Program, Step, code_mass::Mass};
use num_bigint::BigUint;
use num_rational::Ratio;
use std::sync::atomic::{AtomicUsize, Ordering};
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Op {
    Identity,
    Add,
}
struct Meaning {
    calls: AtomicUsize,
}
impl Semantics<u64, Op> for Meaning {
    type Error = ();
    fn apply(&self, op: &Op, a: &[u64]) -> Result<u64, ()> {
        self.calls.fetch_add(1, Ordering::Relaxed);
        match (op, a) {
            (Op::Identity, [x]) => Ok(*x),
            (Op::Add, [x, y]) => x.checked_add(*y).ok_or(()),
            _ => Err(()),
        }
    }
}
struct Work {
    left: usize,
    paid: usize,
}
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.left = self.left.checked_sub(n).ok_or(())?;
        self.paid += n;
        Ok(())
    }
}
type A = Assessment<u64, Op, u8, Meaning, u8, u64, u64>;
type T = Trial<u64, Op, u8, Meaning, u8, u64, u64>;
type R = installation::predictive::Runtime<u64, Op, u8, Meaning, u8, u64, u64>;
fn code(op: Op, args: Vec<Operand<u64>>) -> Program<u64, Op> {
    Program {
        steps: vec![Step {
            operation: Operation::Primitive(op),
            arguments: args,
        }],
        output: Some(0),
        library: vec![],
    }
}
fn profile() -> AdmissionProfile {
    AdmissionProfile::ExactResidualPredictiveV1 {
        risk: Mass::uniform(BigUint::from(20u8)).unwrap(),
    }
}
fn protocol() -> Arc<residual::Protocol<u64, u64>> {
    residual::Protocol::new(
        |x| {
            Ok(residual::Prediction::new(
                Arc::from([]),
                Arc::from(x.to_le_bytes()),
            ))
        },
        |y| Ok(Arc::from(y.to_le_bytes())),
    )
}
fn history(n: usize) -> Arc<History<u8, u8, u64>> {
    History::from_origin(
        7,
        (0..n)
            .map(|_| HistoryEvent::Observed(InputRow::new(0, vec![1])))
            .collect(),
    )
}
// Odd multiplication is a permutation modulo 2^32. This is an arbitrary input
// stream, independent of the expected transition y=x+time and of VM execution.
fn x(i: usize) -> u64 {
    u64::from((i as u32).wrapping_mul(2654435761).wrapping_add(97531))
}
fn y(i: usize) -> u64 {
    x(i) + i as u64
}
fn definition() -> Arc<Definition<u64, Op, u8, Meaning>> {
    Arc::new(Definition::new(
        0,
        code(Op::Add, vec![Operand::Input(0), Operand::Input(1)]),
        code(Op::Add, vec![Operand::Input(0), Operand::Input(1)]),
        InputBinding::new(0, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(),
        InputBinding::new(1, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(),
        Arc::new(Meaning {
            calls: AtomicUsize::new(0),
        }),
    ))
}
fn trial(n: usize) -> Arc<T> {
    trial_with_protocol(n, protocol())
}
fn trial_with_protocol(n: usize, protocol: Arc<residual::Protocol<u64, u64>>) -> Arc<T> {
    let f = Family::with_profile(vec![definition()], profile()).unwrap();
    let mut b = f.open_wire_trial(protocol).unwrap();
    let h = history(n);
    for i in 0..n {
        b.observe(Arc::clone(&h), i, x(i), InputRow::new(1, vec![x(i)]), y(i))
            .unwrap();
    }
    b.finish().unwrap()
}
fn evaluate(t: Arc<T>, grant: usize) -> (Arc<A>, usize) {
    let mut cursor = Evaluation::new(t, 0);
    let mut paid = 0;
    for turn in 0..1_000_000 {
        let mut work = Work {
            left: if turn % 2 == 0 { 0 } else { grant },
            paid: 0,
        };
        let result = cursor.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited));
        paid += work.paid;
        match result {
            Ok(Some(a)) => return (a, paid),
            Ok(None) => {}
            Err(e) if e.can_resume() => {}
            Err(e) => panic!("{e:?}"),
        }
    }
    panic!("finite native search did not finish")
}
fn admitted(n: usize, m: usize) -> Arc<Validated<u64, Op, u8, Meaning, u8, u64, u64>> {
    admitted_with_protocol(n, m, protocol())
}
fn admitted_with_protocol(
    n: usize,
    m: usize,
    protocol: Arc<residual::Protocol<u64, u64>>,
) -> Arc<Validated<u64, Op, u8, Meaning, u8, u64, u64>> {
    let (a, _) = evaluate(trial_with_protocol(n, protocol), 100_000);
    let accepted = a.accepted().unwrap().unwrap();
    let mut fresh = accepted.open_validation();
    let h = history(n + m);
    for i in n..n + m {
        fresh
            .observe(Arc::clone(&h), i, x(i), InputRow::new(1, vec![x(i)]), y(i))
            .unwrap();
    }
    let mut w = Work {
        left: 1_000_000,
        paid: 0,
    };
    fresh
        .finish()
        .unwrap()
        .evaluate(&mut Budget::new(&mut w, ExecutionLimit::Unlimited))
        .unwrap()
        .validated()
        .unwrap()
        .unwrap()
}
fn runtime(n: usize, m: usize) -> R {
    let v = admitted(n, m);
    let mut w = Work {
        left: 1_000_000,
        paid: 0,
    };
    v.install(
        history(n + m),
        n + m,
        &mut Budget::new(&mut w, ExecutionLimit::Unlimited),
    )
    .unwrap_or_else(|_| panic!("installation must replay the admitted prefix"))
    .into_predictive()
    .unwrap_or_else(|(_, e)| panic!("{e:?}"))
}
#[cfg(feature = "serde")]
type Transactions = installation::predictive::transaction_export::Export<u64, Op, u8, Meaning, u64>;
// This is the fixture's declared callback premise, not a callback-purity proof.
#[cfg(feature = "serde")]
fn u64_wire_protocol(padding: serde_json::Value) -> serde_json::Value {
    serde_json::json!({
        "evidence":"declared_fixture_callback_premise",
        "prediction":{"context":[],"mask":{
            "source":"native_reading","encoding":"u64_le","width_bytes":8,"padding":padding
        }},
        "target":{
            "source":"observed_outcome","encoding":"u64_le","width_bytes":8,"padding":padding
        }
    })
}
#[cfg(feature = "serde")]
fn transaction_export(wire_protocol: serde_json::Value) -> Option<Transactions> {
    std::env::var_os("SYNARC_RESIDUAL_TRANSACTIONS_EXPORT").map(|_| Transactions::new(
        |value| serde_json::json!(value), |interface| serde_json::json!(interface),
        |op| serde_json::json!(match op { Op::Identity => "identity", Op::Add => "checked_add" }),
        "u64 identity/checked_add with exact arity; overflow and foreign shapes refuse; Meaning.calls is observational only",
        wire_protocol,
    ))
}
#[cfg(feature = "serde")]
fn finish_transactions(case: &str, export: Option<Transactions>) {
    if let Some(export) = export {
        use std::io::Write;
        let path =
            std::env::var_os("SYNARC_RESIDUAL_TRANSACTIONS_EXPORT").expect("declared export path");
        let mut line = serde_json::to_vec(&export.finish(case)).unwrap();
        line.push(b'\n');
        std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)
            .unwrap()
            .write_all(&line)
            .unwrap();
    }
}
#[cfg(feature = "serde")]
fn stop_json(stop: &installation::predictive::Stop<u64, (), ()>) -> serde_json::Value {
    use installation::predictive::Stop;
    match stop {
        Stop::Native(reason) => serde_json::json!({"kind":"native","reason":format!("{reason:?}")}),
        Stop::Wire(reason) => serde_json::json!({"kind":"wire","reason":format!("{reason:?}")}),
        Stop::Work(reason) => serde_json::json!({"kind":"work","reason":format!("{reason:?}")}),
        Stop::AlreadyReturned => serde_json::json!({"kind":"already_returned"}),
    }
}
fn ticket(
    r: &R,
    i: usize,
    grant: usize,
) -> installation::predictive::Ticket<u64, Op, u8, Meaning, u64> {
    ticket_traced(
        r,
        i,
        grant,
        #[cfg(feature = "serde")]
        None,
    )
}
fn ticket_traced(
    r: &R,
    i: usize,
    grant: usize,
    #[cfg(feature = "serde")] mut export: Option<&mut Transactions>,
) -> installation::predictive::Ticket<u64, Op, u8, Meaning, u64> {
    let mut cursor = r.begin(InputRow::new(1, vec![x(i)]), InputRow::new(0, vec![1]));
    for turn in 0..10_000 {
        let allowance = grant;
        #[cfg(feature = "serde")]
        let allowance = if export.is_some() && turn % 2 == 0 {
            0
        } else {
            allowance
        };
        let _ = turn;
        let mut w = Work {
            left: allowance,
            paid: 0,
        };
        #[cfg(feature = "serde")]
        let before = export.as_deref_mut().map(|e| {
            let runtime = e.runtime(r);
            let pending = e.predicting(&cursor);
            serde_json::json!({"runtime":runtime,"predicting":pending})
        });
        let result = cursor.advance(&mut Budget::new(&mut w, ExecutionLimit::Unlimited));
        #[cfg(feature = "serde")]
        if let Some(e) = export.as_deref_mut() {
            let after = e.predicting(&cursor);
            let runtime = e.runtime(r);
            let outcome = match &result {
                Ok(Some(ticket)) => {
                    serde_json::json!({"kind":"ticket","value":e.ticket(&cursor,ticket)})
                }
                Ok(None) => serde_json::json!({"kind":"pending"}),
                Err(stop) => stop_json(stop),
            };
            e.push(
                serde_json::json!({"kind":"predicting_advance","grant":allowance,"paid":w.paid,
                "before":before,"after":{"runtime":runtime,"predicting":after},"result":outcome}),
            );
        }
        match result {
            Ok(Some(t)) => return t,
            Ok(None) => {}
            Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {}
            _ => panic!("pre-outcome read failed"),
        }
    }
    panic!("read never finished")
}
fn update(
    t: installation::predictive::Ticket<u64, Op, u8, Meaning, u64>,
    outcome: u64,
    grant: usize,
) -> installation::predictive::Update<u64, Op, u8, Meaning> {
    update_traced(
        t,
        outcome,
        grant,
        #[cfg(feature = "serde")]
        None,
    )
}
fn update_traced(
    t: installation::predictive::Ticket<u64, Op, u8, Meaning, u64>,
    outcome: u64,
    grant: usize,
    #[cfg(feature = "serde")] mut export: Option<(&R, &mut Transactions)>,
) -> installation::predictive::Update<u64, Op, u8, Meaning> {
    let mut cursor = t.observe(&outcome).unwrap();
    #[cfg(feature = "serde")]
    if let Some((runtime, e)) = export.as_mut() {
        let runtime = e.runtime(runtime);
        let learning = e.learning(&cursor);
        e.push(serde_json::json!({"kind":"observe","outcome":outcome,"runtime":runtime,"learning":learning}));
    }
    for turn in 0..10_000 {
        let allowance = grant;
        #[cfg(feature = "serde")]
        let allowance = if export.is_some() && turn % 2 == 0 {
            0
        } else {
            allowance
        };
        let _ = turn;
        let mut w = Work {
            left: allowance,
            paid: 0,
        };
        #[cfg(feature = "serde")]
        let before = export.as_mut().map(|(runtime, e)| {
            let runtime = e.runtime(runtime);
            let learning = e.learning(&cursor);
            serde_json::json!({"runtime":runtime,"learning":learning})
        });
        let result = cursor.advance(&mut Budget::new(&mut w, ExecutionLimit::Unlimited));
        #[cfg(feature = "serde")]
        if let Some((runtime, e)) = export.as_mut() {
            let runtime = e.runtime(runtime);
            let learning = e.learning(&cursor);
            let outcome = match &result {
                Ok(Some(update)) => serde_json::json!({"kind":"update","value":e.update(update)}),
                Ok(None) => serde_json::json!({"kind":"pending"}),
                Err(stop) => stop_json(stop),
            };
            e.push(
                serde_json::json!({"kind":"learning_advance","grant":allowance,"paid":w.paid,
                "before":before,"after":{"runtime":runtime,"learning":learning},"result":outcome}),
            );
        }
        match result {
            Ok(Some(t)) => return t,
            Ok(None) => {}
            Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {}
            Err(installation::predictive::Stop::Work(_)) => {}
            _ => panic!("target update failed"),
        }
    }
    panic!("learning never finished")
}
fn commit_traced(
    runtime: &mut R,
    update: installation::predictive::Update<u64, Op, u8, Meaning>,
    #[cfg(feature = "serde")] export: Option<&mut Transactions>,
) -> Result<
    installation::predictive::Receipt<u64, Op, u8, Meaning>,
    installation::predictive::Update<u64, Op, u8, Meaning>,
> {
    #[cfg(feature = "serde")]
    if let Some(export) = export {
        return export.commit(runtime, update);
    }
    runtime.commit(update)
}
// Independent scalar recurrence, without the production codec/model/accumulator.
fn oracle(n: usize) -> Ratio<BigUint> {
    let mut child = [[0u64; 2]; 64];
    let mut base = [[0u64; 2]; 64];
    let mut q = Ratio::from_integer(BigUint::from(1u8));
    for i in 0..n {
        for k in 0..64 {
            let bit = ((y(i) >> k) & 1) as usize;
            q *= Ratio::new(
                BigUint::from(2 * child[k][0] + 1),
                BigUint::from(2 * (child[k][0] + child[k][1]) + 2),
            );
            q /= Ratio::new(
                BigUint::from(2 * base[k][bit] + 1),
                BigUint::from(2 * (base[k][0] + base[k][1]) + 2),
            );
            child[k][0] += 1;
            base[k][bit] += 1;
        }
    }
    q
}
#[test]
fn unique_exact_states_and_targets_acquire_shared_program_without_outcome_alphabet() {
    let n = 48;
    assert_eq!((0..n).map(x).collect::<BTreeSet<_>>().len(), n);
    assert_eq!((0..n).map(y).collect::<BTreeSet<_>>().len(), n);
    let (a, paid) = evaluate(trial(n), 100_000);
    assert!(a.purchased().unwrap());
    let score = a.score().residual().unwrap();
    assert_eq!(score.ratio(), &oracle(n));
    assert_eq!(score.samples(), n as u64);
    assert_eq!(score.bits(), n as u64 * 64);
    let (b, sliced) = evaluate(Arc::clone(a.trial()), 1);
    assert_eq!(b.score().residual(), Some(score));
    assert_eq!(paid, sliced);
    assert_eq!(score.model().contexts(), 1);
    assert!(a.trial.alphabets.is_empty());
}
#[test]
fn training_fresh_install_and_live_execution_share_exact_predictive_frontier() {
    let admitted = admitted(32, 16);
    #[cfg(feature = "serde")]
    let mut rows = Vec::new();
    #[cfg(feature = "serde")]
    let mut frontiers = Vec::new();
    #[cfg(feature = "serde")]
    for (phase, assessment) in [
        ("training", admitted.validation().training().assessment()),
        ("fresh", admitted.validation().fresh()),
    ] {
        let protocol = assessment
            .trial
            .wire
            .as_ref()
            .expect("frozen native wire protocol");
        for (row, reading) in assessment.trial.rows.iter().zip(assessment.readings()) {
            let prediction = protocol.prediction(reading.value()).unwrap();
            rows.push(serde_json::json!({"phase":phase,"context":prediction.context(),"mask":prediction.mask(),
                "target":protocol.outcome(row.outcome()).unwrap().as_ref(),"native_read":reading.value(),
                "native_state":reading.cut().state(),"origin":row.id().origin(),"ordinal":row.id().ordinal()}));
        }
    }
    #[cfg(feature = "serde")]
    frontiers.push(
        admitted
            .validation()
            .training()
            .assessment()
            .score()
            .residual()
            .unwrap()
            .native_frontier(),
    );
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    let mut r = admitted
        .install(
            history(48),
            48,
            &mut Budget::new(&mut work, ExecutionLimit::Unlimited),
        )
        .unwrap_or_else(|_| panic!("native installation"))
        .into_predictive()
        .unwrap_or_else(|(_, reason)| panic!("{reason:?}"));
    #[cfg(feature = "serde")]
    frontiers.push(r.score().native_frontier());
    assert_eq!(r.score().ratio(), &oracle(48));
    assert_eq!(*r.cut().state(), 48);
    for i in 48..52 {
        let before = r.cut();
        let t = ticket(&r, i, 1);
        assert_eq!(t.forecast().prediction().mask(), y(i).to_le_bytes());
        // All previous targets have eight bytes. An empty target retains the
        // base half-count divided by completed training+fresh+online rows+1.
        // This checks the absolute probability, independently of the ratio.
        let frozen_forecast = t.forecast().clone();
        let empty_mass = Ratio::new(BigUint::from(1u8), BigUint::from(2 * (i + 1)));
        let empty = frozen_forecast.evaluate(Arc::from([])).unwrap();
        assert_eq!(empty.result(), Some((&empty_mass, &empty_mass)));
        #[cfg(feature = "serde")]
        let prediction = t.forecast().prediction().clone();
        let next = update(t, y(i), 1);
        assert!(
            before.same_revision(&r.cut()),
            "preparation published mutable state"
        );
        let receipt = r
            .commit(next)
            .unwrap_or_else(|_| panic!("same native owner"));
        assert_eq!(receipt.before.samples(), i as u64);
        assert_eq!(receipt.after.samples(), i as u64 + 1);
        assert_eq!(receipt.target.as_ref(), y(i).to_le_bytes());
        assert_eq!(*receipt.reading.value(), y(i));
        assert_eq!(*receipt.committed.after().state(), i as u64 + 1);
        assert_eq!(r.score().ratio(), &oracle(i + 1));
        let empty = frozen_forecast.evaluate(Arc::from([])).unwrap();
        assert_eq!(
            empty.result(),
            Some((&empty_mass, &empty_mass)),
            "frozen pre-outcome law changed"
        );
        #[cfg(feature = "serde")]
        {
            rows.push(serde_json::json!({"phase":"runtime","context":prediction.context(),"mask":prediction.mask(),
                "target":receipt.target.as_ref(),"native_read":receipt.reading.value(),"native_state":receipt.reading.cut().state(),
                "origin":7,"ordinal":i}));
            frontiers.push(r.score().native_frontier());
        }
    }
    #[cfg(feature = "serde")]
    if let Some(path) = std::env::var_os("SYNARC_RESIDUAL_EXPORT") {
        let document = serde_json::json!({"format":"synarc-residual-native-v2","bit_order":"lsb0","length_unit":"byte",
            "forecast_law":residual::FORECAST_LAW,"length_law":"(count(n)+2^-(n+1))/(N+1)","rows":rows,"frontiers":frontiers});
        std::fs::write(path, serde_json::to_vec_pretty(&document).unwrap()).unwrap();
    }
}
// The first eight bytes retain the whole u64. Padding varies the wire length
// without discarding any outcome information or consulting a learned model.
fn padded_wire(value: u64) -> Vec<u8> {
    let mut bytes = value.to_le_bytes().to_vec();
    bytes.resize(8 + (value % 3) as usize, 0);
    bytes
}
type WireRow = (Vec<u8>, Vec<u8>);

// A finite reference calculation rebuilt solely from the supplied mask/target
// rows. No production Model, Lengths, KT helper or Accumulator supplies counts.
fn wire_probability_oracle(
    rows: &[WireRow],
    mask: &[u8],
    probe: &[u8],
    prefix: bool,
) -> (Ratio<BigUint>, Ratio<BigUint>) {
    let mut lengths = BTreeMap::<usize, usize>::new();
    let mut child = BTreeMap::<usize, [usize; 2]>::new();
    let mut reference = BTreeMap::<usize, [usize; 2]>::new();
    for (old_mask, target) in rows {
        *lengths.entry(target.len()).or_default() += 1;
        for (byte, &value) in target.iter().enumerate() {
            for bit in 0..8 {
                let position = byte * 8 + bit;
                let actual = usize::from((value >> bit) & 1);
                let predicted = usize::from((old_mask.get(byte).copied().unwrap_or(0) >> bit) & 1);
                child.entry(position).or_default()[actual ^ predicted] += 1;
                reference.entry(position).or_default()[actual] += 1;
            }
        }
    }
    let count = if prefix {
        lengths.range(probe.len()..).map(|(_, count)| count).sum()
    } else {
        lengths.get(&probe.len()).copied().unwrap_or(0)
    };
    let base = Ratio::new(
        BigUint::from(1u8),
        BigUint::from(1u8) << (probe.len() + usize::from(!prefix)),
    );
    let mass = (Ratio::from_integer(BigUint::from(count)) + base)
        / Ratio::from_integer(BigUint::from(rows.len() + 1));
    let (mut a, mut b) = (mass.clone(), mass);
    for (byte, &value) in probe.iter().enumerate() {
        for bit in 0..8 {
            let position = byte * 8 + bit;
            let actual = usize::from((value >> bit) & 1);
            let predicted = usize::from((mask.get(byte).copied().unwrap_or(0) >> bit) & 1);
            let c = child.get(&position).copied().unwrap_or([0, 0]);
            let r = reference.get(&position).copied().unwrap_or([0, 0]);
            a *= Ratio::new(
                BigUint::from(2 * c[actual ^ predicted] + 1),
                BigUint::from(2 * (c[0] + c[1]) + 2),
            );
            b *= Ratio::new(
                BigUint::from(2 * r[actual] + 1),
                BigUint::from(2 * (r[0] + r[1]) + 2),
            );
        }
    }
    (a, b)
}

fn native_wire_probability(
    forecast: &residual::Forecast,
    probe: &[u8],
    prefix: bool,
) -> (Ratio<BigUint>, Ratio<BigUint>) {
    let mut cursor = if prefix {
        forecast.prefix(Arc::from(probe)).unwrap()
    } else {
        forecast.evaluate(Arc::from(probe)).unwrap()
    };
    for _ in 0..1024 {
        if let Some((a, b)) = cursor.result() {
            return (a.clone(), b.clone());
        }
        assert!(matches!(
            cursor.advance(&mut Work { left: 0, paid: 0 }),
            Err(residual::Refusal::Work(()))
        ));
        cursor.advance(&mut Work { left: 1, paid: 0 }).unwrap();
    }
    panic!("finite wire probability did not resume");
}

fn assert_wire_forecast(forecast: &residual::Forecast, rows: &[WireRow], mask: &[u8], phase: &str) {
    #[cfg(feature = "serde")]
    let export = std::env::var_os("SYNARC_RESIDUAL_QUERIES_EXPORT");
    #[cfg(feature = "serde")]
    let mut queries = Vec::new();
    assert!(forecast.prediction().context().is_empty());
    assert_eq!(forecast.prediction().mask(), mask);
    assert!(rows.iter().all(|(_, target)| target.len() < 11));
    for length in [0, 1, 8, 9, 10, 11] {
        let mut probe = mask.to_vec();
        probe.resize(length, 0);
        for altered in [false, true] {
            if altered {
                let Some(first) = probe.first_mut() else {
                    continue;
                };
                *first ^= 0x80;
            }
            for prefix in [false, true] {
                let expected = wire_probability_oracle(rows, mask, &probe, prefix);
                assert!(expected.0 > Ratio::from_integer(BigUint::from(0u8)));
                assert!(expected.1 > Ratio::from_integer(BigUint::from(0u8)));
                let actual = native_wire_probability(forecast, &probe, prefix);
                assert_eq!(
                    actual,
                    expected,
                    "phase={phase} rows={} length={length} prefix={prefix} altered={altered}",
                    rows.len()
                );
                #[cfg(feature = "serde")]
                if export.is_some() {
                    queries.push(serde_json::json!({
                        "prefix": prefix, "target": probe,
                        "candidate": {"numerator": actual.0.numer().to_string(), "denominator": actual.0.denom().to_string()},
                        "reference": {"numerator": actual.1.numer().to_string(), "denominator": actual.1.denom().to_string()},
                    }));
                }
            }
        }
    }
    #[cfg(feature = "serde")]
    if let Some(path) = export {
        use std::io::Write;
        // One packet owns the actual forecast frontier and all its queries.
        // Oracle results are assertions only and never exported as native facts.
        let mut packet = serde_json::to_vec(&serde_json::json!({
            "format": "synarc-residual-queries-v2", "phase": phase,
            "rows": rows.iter().map(|(mask, target)| serde_json::json!({
                "context": [], "mask": mask, "target": target,
            })).collect::<Vec<_>>(),
            "forecast": forecast.native_frontier(), "queries": queries,
        }))
        .unwrap();
        packet.push(b'\n');
        std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)
            .unwrap()
            .write_all(&packet)
            .unwrap();
    }
}

#[test]
fn mixed_length_native_lifecycle_matches_independent_point_and_prefix_oracle() {
    #[cfg(feature = "serde")]
    let mut transactions = transaction_export(u64_wire_protocol(
        serde_json::json!({"kind":"value_mod","modulus":3,"byte":0}),
    ));
    let protocol = residual::Protocol::new(
        |value| {
            Ok(residual::Prediction::new(
                Arc::from([]),
                Arc::from(padded_wire(*value)),
            ))
        },
        |value| Ok(Arc::from(padded_wire(*value))),
    );
    let admitted = admitted_with_protocol(32, 16, protocol);
    // y(i) is the fixture's independent arithmetic dynamics, not a VM result.
    let mut rows: Vec<WireRow> = (0..48)
        .map(|i| {
            let target = padded_wire(y(i));
            (target.clone(), target)
        })
        .collect();
    assert_eq!(
        rows.iter()
            .map(|(_, target)| target.len())
            .collect::<BTreeSet<_>>(),
        BTreeSet::from([8, 9, 10])
    );
    assert_eq!((0..52).map(x).collect::<BTreeSet<_>>().len(), 52);
    let mask = padded_wire(y(48));
    let prediction = || residual::Prediction::new(Arc::from([]), Arc::from(mask.clone()));
    let validation = admitted.validation();
    let training = validation
        .training()
        .assessment()
        .score()
        .residual()
        .unwrap();
    assert_eq!(training.samples(), 32);
    assert_wire_forecast(
        &training.model().forecast(prediction()),
        &rows[..32],
        &mask,
        "training",
    );
    let fresh = validation.fresh().score().residual().unwrap();
    assert_eq!(fresh.samples(), 16);
    assert_wire_forecast(
        &fresh.model().forecast(prediction()),
        &rows[32..],
        &mask,
        "fresh",
    );
    let joint = validation.score.residual().unwrap();
    assert_eq!(joint.samples(), 48);
    assert_wire_forecast(&joint.model().forecast(prediction()), &rows, &mask, "joint");
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    let mut runtime = admitted
        .install(
            history(48),
            48,
            &mut Budget::new(&mut work, ExecutionLimit::Unlimited),
        )
        .unwrap_or_else(|_| panic!("native mixed-length installation"))
        .into_predictive()
        .unwrap_or_else(|(_, reason)| panic!("{reason:?}"));
    assert_eq!(runtime.score(), joint);
    for i in 48..52 {
        let pending = ticket_traced(
            &runtime,
            i,
            1,
            #[cfg(feature = "serde")]
            transactions.as_mut(),
        );
        let mask = padded_wire(y(i));
        let frozen = pending.forecast().clone();
        #[cfg(feature = "serde")]
        if let Some(e) = &mut transactions {
            e.frozen(&format!("mixed-{i}-before"), &frozen);
        }
        assert_wire_forecast(
            &frozen,
            &rows,
            &mask,
            if i == 48 { "installed" } else { "live" },
        );
        let before = runtime.score().clone();
        let next = update_traced(
            pending,
            y(i),
            1,
            #[cfg(feature = "serde")]
            transactions.as_mut().map(|e| (&runtime, e)),
        );
        assert_eq!(
            runtime.score(),
            &before,
            "uncommitted length counts escaped"
        );
        let receipt = commit_traced(
            &mut runtime,
            next,
            #[cfg(feature = "serde")]
            transactions.as_mut(),
        )
        .unwrap_or_else(|_| panic!("owned live update"));
        assert_eq!(receipt.target.as_ref(), padded_wire(y(i)).as_slice());
        assert_eq!(*receipt.reading.value(), y(i));
        assert_eq!(*receipt.committed.after().state(), (i + 1) as u64);
        rows.push((mask.clone(), padded_wire(y(i))));
        assert_eq!(runtime.score().samples(), rows.len() as u64);
        assert_eq!(runtime.score().ratio(), &oracle(i + 1));
        assert_wire_forecast(&frozen, &rows[..i], &mask, "frozen");
        #[cfg(feature = "serde")]
        if let Some(e) = &mut transactions {
            e.frozen(&format!("mixed-{i}-after"), &frozen);
        }
        let current = ticket(&runtime, i + 1, 1);
        assert_wire_forecast(current.forecast(), &rows, &padded_wire(y(i + 1)), "live");
    }
    #[cfg(feature = "serde")]
    finish_transactions("mixed_length", transactions);
}

#[test]
fn stale_and_sibling_prediction_transactions_cannot_change_either_owner() {
    #[cfg(feature = "serde")]
    let mut transactions =
        transaction_export(u64_wire_protocol(serde_json::json!({"kind":"none"})));
    let mut r = runtime(24, 12);
    #[cfg(feature = "serde")]
    let fork_before = transactions.as_mut().map(|e| e.runtime(&r));
    let mut sibling = r.fork();
    #[cfg(feature = "serde")]
    if let Some(e) = &mut transactions {
        let source = e.runtime(&r);
        let branch = e.runtime(&sibling);
        e.push(
            serde_json::json!({"kind":"fork","before":fork_before,"after":source,"branch":branch}),
        );
    }
    let t = ticket_traced(
        &r,
        36,
        1000,
        #[cfg(feature = "serde")]
        transactions.as_mut(),
    );
    let stale = ticket_traced(
        &r,
        36,
        1,
        #[cfg(feature = "serde")]
        transactions.as_mut(),
    );
    #[cfg(feature = "serde")]
    let frozen = stale.forecast().clone();
    #[cfg(feature = "serde")]
    if let Some(e) = &mut transactions {
        e.frozen("stale-before", &frozen);
    }
    let next = update_traced(
        t,
        y(36),
        1,
        #[cfg(feature = "serde")]
        transactions.as_mut().map(|e| (&r, e)),
    );
    let sibling_before = sibling.cut();
    let sibling_score = sibling.score().clone();
    let next = commit_traced(
        &mut sibling,
        next,
        #[cfg(feature = "serde")]
        transactions.as_mut(),
    )
    .err()
    .expect("foreign branch rejected");
    assert!(sibling_before.same_revision(&sibling.cut()));
    assert_eq!(sibling.score(), &sibling_score);
    commit_traced(
        &mut r,
        next,
        #[cfg(feature = "serde")]
        transactions.as_mut(),
    )
    .unwrap_or_else(|_| panic!("original branch preserved"));
    let now = r.cut();
    let score = r.score().clone();
    let next = update_traced(
        stale,
        y(36),
        1,
        #[cfg(feature = "serde")]
        transactions.as_mut().map(|e| (&r, e)),
    );
    assert!(
        commit_traced(
            &mut r,
            next,
            #[cfg(feature = "serde")]
            transactions.as_mut()
        )
        .is_err()
    );
    assert!(now.same_revision(&r.cut()));
    assert_eq!(r.score(), &score);
    #[cfg(feature = "serde")]
    if let Some(e) = &mut transactions {
        e.frozen("stale-after", &frozen);
    }
    #[cfg(feature = "serde")]
    finish_transactions("stale_and_sibling", transactions);
}

#[test]
fn missing_protocol_reordered_rows_and_future_evidence_are_refused() {
    let f = Family::with_profile(vec![definition()], profile()).unwrap();
    assert!(matches!(
        f.open_trial::<u8, u64, u64>(BTreeMap::new()),
        Err(IntakeRefusal::ProtocolMismatch)
    ));
    let mut b = f.open_wire_trial::<u8, u64, u64>(protocol()).unwrap();
    let h = history(3);
    b.observe(Arc::clone(&h), 2, 0, InputRow::new(1, vec![0]), 2)
        .unwrap();
    assert!(matches!(
        b.observe(h, 1, 0, InputRow::new(1, vec![0]), 1),
        Err(IntakeRefusal::NonCausalOrder)
    ));
    let v = admitted(24, 12);
    let mut w = Work {
        left: 1_000_000,
        paid: 0,
    };
    let early = v
        .install(
            history(36),
            35,
            &mut Budget::new(&mut w, ExecutionLimit::Unlimited),
        )
        .unwrap_or_else(|_| panic!("native prefix replay"));
    assert!(matches!(
        early.into_predictive(),
        Err((
            _,
            installation::predictive::AdoptionRefusal::NotAtEvidenceFrontier
        ))
    ));
}
#[test]
fn fixed_future_reversal_cannot_reset_counts_and_relabel_itself_as_confirmation() {
    let (a, _) = evaluate(trial(32), 100_000);
    let accepted = a.accepted().unwrap().unwrap();
    let mut b = accepted.open_validation();
    let h = history(64);
    for i in 32..64 {
        b.observe(Arc::clone(&h), i, x(i), InputRow::new(1, vec![x(i)]), !y(i))
            .unwrap();
    }
    let mut w = Work {
        left: 1_000_000,
        paid: 0,
    };
    let v = b
        .finish()
        .unwrap()
        .evaluate(&mut Budget::new(&mut w, ExecutionLimit::Unlimited))
        .unwrap();
    assert!(!v.confirmed().unwrap());
    assert!(v.validated().unwrap().is_none());
}
#[test]
fn native_joint_search_materializes_and_pays_for_predictive_programs() {
    let update = code(Op::Add, vec![Operand::Input(0), Operand::Input(1)]);
    let initial = code(Op::Identity, vec![Operand::Literal(0)]);
    let triples = vec![
        [
            initial.clone(),
            update.clone(),
            code(Op::Identity, vec![Operand::Literal(0)]),
        ],
        [
            initial,
            update,
            code(Op::Add, vec![Operand::Input(0), Operand::Input(1)]),
        ],
    ];
    let mut series = joint::Series::declared_triples(
        triples,
        [0, 2, 2],
        InputBinding::new(0, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(),
        InputBinding::new(1, 1, vec![InputSource::State, InputSource::External(0)]).unwrap(),
        Arc::new(Meaning {
            calls: AtomicUsize::new(0),
        }),
        joint::Retention {
            address_cells: 128,
            pending: 8,
        },
    )
    .unwrap()
    .declare_admission(profile())
    .unwrap_or_else(|_| panic!("frozen profile"));
    let mut w = Work {
        left: 1_000_000,
        paid: 0,
    };
    let mut b = series
        .open_wire_trial_metered::<u8, u64, u64, _>(protocol(), &mut w)
        .unwrap();
    let h = history(40);
    for i in 0..40 {
        b.observe(Arc::clone(&h), i, x(i), InputRow::new(1, vec![x(i)]), y(i))
            .unwrap();
    }
    let mut search = b.finish::<()>().unwrap();
    let mut bought = Vec::new();
    for _ in 0..100_000 {
        match search.advance(&mut Budget::new(&mut w, ExecutionLimit::Unlimited)) {
            joint::Progress::Advanced => {}
            joint::Progress::Assessed {
                candidate,
                assessment,
            } => {
                if assessment.purchased().unwrap() {
                    bought.push(candidate.index().clone());
                    assert_eq!(assessment.score().residual().unwrap().ratio(), &oracle(40));
                }
            }
            joint::Progress::Complete { unknown } => {
                assert_eq!(unknown, 0);
                break;
            }
            _ => panic!("native predictor search refused"),
        }
    }
    assert!(search.is_complete());
    assert_eq!(bought, vec![BigUint::from(1u8)]);
}

#[test]
fn undefined_prediction_cannot_skip_the_current_target_and_buy_from_other_rows() {
    let f = Family::with_profile(vec![definition()], profile()).unwrap();
    let partial = residual::Protocol::new(
        |x: &u64| {
            if x & 1 == 0 {
                Ok(residual::Prediction::new(
                    Arc::from([]),
                    Arc::from(x.to_le_bytes()),
                ))
            } else {
                Err(residual::Invalid::Encoding)
            }
        },
        |y: &u64| Ok(Arc::from(y.to_le_bytes())),
    );
    let mut b = f.open_wire_trial::<u8, u64, u64>(partial).unwrap();
    let h = history(8);
    for i in 0..8 {
        b.observe(
            Arc::clone(&h),
            i,
            i as u64,
            InputRow::new(1, vec![0]),
            i as u64,
        )
        .unwrap();
    }
    let mut work = Work {
        left: 100_000,
        paid: 0,
    };
    let error = b
        .finish()
        .unwrap()
        .evaluate(0, &mut Budget::new(&mut work, ExecutionLimit::Unlimited))
        .err()
        .expect("partial prediction refused");
    assert!(matches!(
        error.reason(),
        FailureReason::Wire(residual::Invalid::Encoding)
    ));
    assert!(
        !error.incomplete(),
        "undefined prediction is not a new evidence window"
    );
    assert!(error.completed().is_none());
}
#[test]
fn another_protocol_cannot_reinterpret_the_original_fresh_validation() {
    let (a, _) = evaluate(trial(24), 100_000);
    let accepted = a.accepted().unwrap().unwrap();
    let mut b = accepted.open_validation();
    let h = history(25);
    b.observe(h, 24, x(24), InputRow::new(1, vec![x(24)]), y(24))
        .unwrap();
    // Even identical function pointers in a newly declared owner cannot replace
    // the exact protocol retained by the original paid acquisition.
    b.fresh.wire = Some(protocol());
    let mut cursor = b.finish().unwrap().resume();
    let mut work = Work {
        left: 100_000,
        paid: 0,
    };
    assert!(matches!(
        cursor.advance(&mut Budget::new(&mut work, ExecutionLimit::Unlimited)),
        Err(FailureReason::ForeignProfile)
    ));
}

#[test]
fn immutable_prediction_source_keeps_live_authority_without_creating_a_sibling() {
    fn from_snapshot(
        s: &installation::predictive::Snapshot<u64, Op, u8, Meaning, u64>,
        i: usize,
    ) -> installation::predictive::Ticket<u64, Op, u8, Meaning, u64> {
        let mut pending = s.begin(InputRow::new(1, vec![x(i)]), InputRow::new(0, vec![1]));
        for turn in 0..10_000 {
            let mut w = Work {
                left: turn % 2,
                paid: 0,
            };
            match pending.advance(&mut Budget::new(&mut w, ExecutionLimit::Unlimited)) {
                Ok(Some(ticket)) => return ticket,
                Ok(None) => {}
                Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {}
                Err(e) => panic!("unexpected snapshot read refusal: {e:?}"),
            }
        }
        panic!("snapshot failed to retain progress");
    }
    let mut live = runtime(24, 12);
    let saved = live.snapshot();
    let retained = saved.clone();
    let original_cut = live.cut();
    let original_score = live.score().clone();
    assert!(live.is_current(&saved));
    assert!(saved.cut().same_revision(&original_cut));
    assert!(!live.fork().is_current(&saved));
    let selected = from_snapshot(&saved, 36);
    let frozen = selected.forecast().clone();
    let mut branch = live.fork();
    let pending_update = update(selected, y(36), 1);
    let pending_update = branch
        .commit(pending_update)
        .err()
        .expect("sibling has no live authority");
    assert_eq!(live.score(), &original_score);
    assert!(live.cut().same_revision(&original_cut));
    live.commit(pending_update)
        .unwrap_or_else(|_| panic!("published source must serve its original live owner"));
    assert!(!live.is_current(&saved));
    assert!(live.is_current(&live.snapshot()));
    assert_eq!(saved.score(), &original_score);
    assert!(saved.cut().same_revision(&original_cut));
    let still_old = from_snapshot(&retained, 36);
    let mut w = Work {
        left: 10000,
        paid: 0,
    };
    let point = |forecast: &residual::Forecast, work: &mut Work| {
        let mut q = forecast.evaluate(Arc::from(y(36).to_le_bytes())).unwrap();
        while !q.advance(work).unwrap() {}
        let (candidate, reference) = q.result().expect("completed likelihood");
        (candidate.clone(), reference.clone())
    };
    assert_eq!(point(&frozen, &mut w), point(still_old.forecast(), &mut w));
    let after_cut = live.cut();
    let after_score = live.score().clone();
    assert!(live.commit(update(still_old, y(36), 1)).is_err());
    assert!(live.cut().same_revision(&after_cut));
    assert_eq!(live.score(), &after_score);
}

/// An explicit limitation of the pre-event update binding. Equal pre-events
/// and a fixed mask leave equal native states and KT banks after permuting
/// targets. This does not assert that other SYNARC observation routes are blind
/// to outcomes; it diagnoses this installed predictive interface only.
#[test]
fn legacy_predictive_update_does_not_retain_outcome_order() {
    fn fixed_ticket(r: &R) -> installation::predictive::Ticket<u64, Op, u8, Meaning, u64> {
        let mut cursor = r.begin(InputRow::new(1, vec![0]), InputRow::new(0, vec![0]));
        for turn in 0..10_000 {
            let mut w = Work { left: turn % 2, paid: 0 };
            match cursor.advance(&mut Budget::new(&mut w, ExecutionLimit::Unlimited)) {
                Ok(Some(t)) => return t,
                Ok(None) => {}
                Err(installation::predictive::Stop::Native(e)) if e.can_resume() => {}
                _ => panic!("fixed pre-outcome read failed"),
            }
        }
        panic!("fixed read lost its continuation")
    }
    let seed = runtime(24, 12);
    let mut left = seed.fork();
    let mut right = seed.fork();
    let mut retained_targets = Vec::new();
    for (runtime, targets) in [(&mut left, [0u64, 1]), (&mut right, [1u64, 0])] {
        let mut receipts = Vec::new();
        for target in targets {
            let transaction = update(fixed_ticket(runtime), target, 1);
            let receipt = runtime.commit(transaction)
                .unwrap_or_else(|_| panic!("same-owner complete transaction must commit"));
            receipts.push(receipt.target);
        }
        retained_targets.push(receipts);
    }
    assert_ne!(retained_targets[0], retained_targets[1], "actual outcomes remain distinct");
    assert_eq!(left.cut().state(), seed.cut().state());
    assert_eq!(right.cut().state(), seed.cut().state());
    assert_eq!(left.score().model(), right.score().model());
    assert_eq!(left.score().ratio(), right.score().ratio());
    let a = fixed_ticket(&left);
    let b = fixed_ticket(&right);
    assert_eq!(a.forecast().prediction(), b.forecast().prediction());
    for target in [0u64, 1, 255, u64::MAX] {
        let point = |f: &residual::Forecast| {
            let mut q = f.evaluate(Arc::from(target.to_le_bytes())).unwrap();
            let mut work = Work { left: 10_000, paid: 0 };
            while !q.advance(&mut work).unwrap() {}
            let (candidate, reference) = q.result().unwrap();
            (candidate.clone(), reference.clone())
        };
        assert_eq!(point(a.forecast()), point(b.forecast()));
    }
    #[cfg(feature = "serde")]
    {
        let owners = transaction_export(u64_wire_protocol(serde_json::Value::Null)).map(|mut e| {
            let initial = e.runtime(&seed);
            let left_final = e.runtime(&left);
            let right_final = e.runtime(&right);
            serde_json::json!({
                "initial":initial,"left_final":left_final,"right_final":right_final,
                "tables":e.finish("outcome_order_boundary_owners")
            })
        });
        println!("SYNARC_BOUNDARY={}", serde_json::json!({
            "kind":"pre_event_update_order_blindness", "query":{"interface":1,"values":[0]},
            "event":{"interface":0,"values":[0]}, "target_orders":[[0,1],[1,0]],
            "states":[seed.cut().state(),left.cut().state(),right.cut().state()],
            "left_forecast":a.forecast().native_frontier(),
            "right_forecast":b.forecast().native_frontier(),
            "native_owner_metadata":owners,
            "returned_target_wires":retained_targets.iter().map(|rows|
                rows.iter().map(|wire|wire.as_ref()).collect::<Vec<_>>()
            ).collect::<Vec<_>>(),
            "scope":"installed fixture with unchanged pre-events; snapshots do not expose internal VM continuations"
        }));
    }
}
