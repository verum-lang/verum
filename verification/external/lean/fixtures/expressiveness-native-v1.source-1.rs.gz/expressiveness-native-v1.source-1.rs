use super::*;
struct Work {
    left: usize,
    paid: usize,
}
impl WorkMeter for Work {
    type Error = ();
    fn charge(&mut self, n: usize) -> Result<(), ()> {
        self.left = self.left.checked_sub(n).ok_or(())?;
        self.paid += n;
        Ok(())
    }
}
fn bytes(x: &[u8]) -> Wire {
    Arc::from(x)
}
fn prediction(mask: &[u8]) -> Prediction {
    Prediction::new(bytes(b"shared"), bytes(mask))
}
fn finish(mut acc: Accumulator) -> Score {
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    while acc.pending() {
        acc.advance(&mut work).unwrap();
    }
    acc.finish()
        .unwrap_or_else(|_| panic!("all targets complete"))
}
fn learn(rows: &[(&[u8], &[u8])]) -> Score {
    let mut acc = Accumulator::new();
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    for (mask, target) in rows {
        acc.begin(prediction(mask), bytes(target)).unwrap();
        while acc.pending() {
            acc.advance(&mut work).unwrap();
        }
    }
    finish(acc)
}
fn probability(forecast: &Forecast, y: &[u8]) -> (Rational, Rational) {
    let mut q = forecast.evaluate(bytes(y)).unwrap();
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    while !q.advance(&mut work).unwrap() {}
    let (a, b) = q.result().unwrap();
    (a.clone(), b.clone())
}
#[test]
fn exact_one_byte_mass_and_learned_length_tail_are_normalized_after_learning() {
    let learned = learn(&[(&[7], &[7]), (&[253], &[253]), (&[0, 1], &[0, 3])]);
    for mask in [vec![], vec![0], vec![255], vec![61, 255]] {
        let f = learned.model().forecast(prediction(&mask));
        let empty = probability(&f, &[]);
        assert_eq!(
            empty,
            (
                Ratio::new(1u8.into(), 8u8.into()),
                Ratio::new(1u8.into(), 8u8.into())
            )
        );
        let sum = (0..=255u8).map(|b| probability(&f, &[b])).fold(
            (
                Ratio::from_integer(0u8.into()),
                Ratio::from_integer(0u8.into()),
            ),
            |(a, b), (c, d)| (a + c, b + d),
        );
        let length_one = Ratio::new(9u8.into(), 16u8.into());
        assert_eq!(sum, (length_one.clone(), length_one.clone()));
        let length_tail = Ratio::new(5u8.into(), 16u8.into());
        assert_eq!(empty.0 + sum.0 + length_tail, one()); // exact mass at lengths >= 2
        // Restricting an injective serialization to even bytes is NOT normalized.
        let restricted: Rational = (0..=127u8).map(|b| probability(&f, &[b * 2]).0).sum();
        assert!(restricted < length_one);
    }
}
#[test]
fn residual_noise_length_tags_and_every_target_bit_remain_in_the_likelihood() {
    let score = learn(&[
        (&[42, 0], &[42, 0]),
        (&[43, 0], &[43, 0]),
        (&[44, 0], &[44, 0]),
    ]);
    let forecast = score.model().forecast(prediction(&[45, 0]));
    let exact = probability(&forecast, &[45, 0]).0;
    for position in 0..16 {
        let mut target = [45, 0];
        target[position / 8] ^= 1 << (position % 8);
        assert!(
            probability(&forecast, &target).0 < exact,
            "ignored target bit {position}"
        );
    }
    assert_ne!(probability(&forecast, &[45]).0, exact);
    assert_ne!(probability(&forecast, &[45, 0, 0]).0, exact);
    assert_eq!(score.samples(), 3);
    assert_eq!(score.bits(), 48);
}
#[test]
fn unique_masks_share_a_law_but_unique_contexts_do_not_fabricate_learning() {
    let mut shared = Accumulator::new();
    let mut memorized = Accumulator::new();
    let mut work = Work {
        left: 1_000_000,
        paid: 0,
    };
    for x in 0..64u8 {
        let target = [x.wrapping_mul(37), x ^ 0x5a];
        shared.begin(prediction(&target), bytes(&target)).unwrap();
        memorized
            .begin(Prediction::new(bytes(&[x]), bytes(&target)), bytes(&target))
            .unwrap();
        while shared.pending() {
            shared.advance(&mut work).unwrap();
        }
        while memorized.pending() {
            memorized.advance(&mut work).unwrap();
        }
    }
    let shared = finish(shared);
    let memorized = finish(memorized);
    assert!(shared.ratio() > memorized.ratio());
    assert_eq!(shared.model().contexts(), 1);
    assert_eq!(memorized.model().contexts(), 64);
    // No bits from a past outcome are encoded after learning from those bits.
    let first = learn(&[(&[255], &[255])]);
    assert_eq!(first.ratio(), &one());
}
#[test]
fn sliced_scoring_and_online_continuation_preserve_exact_counts_and_work() {
    let rows: Vec<(Vec<u8>, Vec<u8>)> = (0..24u8)
        .map(|i| (vec![i], vec![i, i.wrapping_mul(71)]))
        .collect();
    let mut results = Vec::new();
    for grant in [1, 7, 10000] {
        let mut acc = Accumulator::new();
        let mut paid = 0;
        for (i, (mask, y)) in rows.iter().enumerate() {
            acc.begin(prediction(mask), bytes(y)).unwrap();
            assert!(matches!(
                acc.begin(prediction(mask), bytes(y)),
                Err(Invalid::PendingOutcome)
            ));
            while acc.pending() {
                let before = acc.samples();
                assert!(matches!(
                    acc.advance(&mut Work { left: 0, paid: 0 }),
                    Err(Refusal::Work(()))
                ));
                assert_eq!(acc.samples(), before);
                let mut work = Work {
                    left: grant,
                    paid: 0,
                };
                while work.left > 0 && acc.pending() {
                    acc.advance(&mut work).unwrap();
                }
                paid += work.paid;
            }
            if i == 8 {
                acc = Accumulator::continue_from(&finish(acc));
            }
        }
        results.push((finish(acc), paid));
    }
    assert_eq!(results[0], results[1]);
    assert_eq!(results[1], results[2]);
    assert_eq!(results[0].1, 24 * (16 + 1));
}
#[test]
fn overflow_and_unfinished_targets_cannot_publish_partial_evidence() {
    let mut acc = Accumulator::new();
    Arc::make_mut(&mut acc.model.residual).insert(bytes(b"shared"), Arc::new(vec![[u64::MAX, 0]]));
    acc.begin(prediction(&[0]), bytes(&[0])).unwrap();
    assert!(matches!(
        acc.advance(&mut Work { left: 1, paid: 0 }),
        Err(Refusal::Invalid(Invalid::CountOverflow))
    ));
    assert!(acc.finish().is_err());
    let mut acc = Accumulator::new();
    acc.begin(prediction(&[0]), bytes(&[0])).unwrap();
    assert!(acc.finish().is_err());
}

#[test]
fn frozen_forecast_and_online_updates_agree_for_mixed_contexts_and_lengths() {
    let mut acc = Accumulator::new();
    let mut w = Work {
        left: 100_000,
        paid: 0,
    };
    for i in 0..40u8 {
        let before = finish(acc);
        let p = Prediction::new(bytes(&[i % 3]), bytes(&[i, i.wrapping_mul(19)]));
        let target: Vec<u8> = (0..usize::from(i % 5))
            .map(|k| i.wrapping_add(k as u8).wrapping_mul(43))
            .collect();
        let forecast = before.model().forecast(p.clone());
        let (q, reference) = probability(&forecast, &target);
        acc = Accumulator::continue_from(&before);
        acc.begin(p, bytes(&target)).unwrap();
        while acc.pending() {
            acc.advance(&mut w).unwrap();
        }
        let after = finish(acc);
        assert_eq!(after.ratio() / before.ratio(), q / reference);
        assert_eq!(after.samples(), before.samples() + 1);
        acc = Accumulator::continue_from(&after);
    }
}

fn cylinder(forecast: &Forecast, prefix: &[u8], grant: usize) -> (Rational, Rational, usize) {
    let mut cursor = forecast.prefix(bytes(prefix)).unwrap();
    let mut paid = 0;
    loop {
        assert!(cursor.result().is_none());
        assert!(matches!(
            cursor.advance(&mut Work { left: 0, paid: 0 }),
            Err(Refusal::Work(()))
        ));
        let mut work = Work {
            left: grant,
            paid: 0,
        };
        while work.left > 0 && cursor.result().is_none() {
            cursor.advance(&mut work).unwrap();
        }
        paid += work.paid;
        if let Some((a, b)) = cursor.result() {
            return (a.clone(), b.clone(), paid);
        }
    }
}

#[test]
fn every_wire_prefix_partitions_into_its_point_and_all_next_bytes() {
    let learned = learn(&[
        (&[], &[]),
        (&[5], &[7]),
        (&[5, 1], &[7, 2]),
        (&[3, 8, 1], &[7, 8, 3]),
    ]);
    let f = learned.model().forecast(prediction(&[5, 1]));
    for prefix in [vec![], vec![7], vec![200], vec![7, 2], vec![0, 0, 0, 0]] {
        let (a, b, _) = cylinder(&f, &prefix, 17);
        let (mut sum_a, mut sum_b) = probability(&f, &prefix);
        for byte in 0..=255 {
            let mut child = prefix.clone();
            child.push(byte);
            let (ca, cb, _) = cylinder(&f, &child, 17);
            sum_a += ca;
            sum_b += cb;
        }
        assert_eq!((a, b), (sum_a, sum_b));
    }
    let (a, b, _) = cylinder(&f, &[], 1);
    assert_eq!((a, b), (one(), one()));
}

#[test]
fn learned_length_mass_releases_the_fixed_prior_ceiling_without_losing_support() {
    let target = vec![0; 18];
    let rows = vec![(target.as_slice(), target.as_slice()); 64];
    let score = learn(&rows);
    let lengths = &score.model().lengths;
    // Query the actual learned histogram, rather than supplying the expected
    // count to the formula. Point mass alone now exceeds the former tail cap.
    let mass = lengths.point(18).unwrap();
    assert_eq!(
        mass,
        Ratio::new(
            BigUint::from(64u64 * (1 << 19) + 1),
            BigUint::from(65u64 * (1 << 19))
        )
    );
    assert!(mass > Ratio::new(98u8.into(), 100u8.into()));
    for n in [0, 1, 17, 19, 63, 257] {
        assert!(lengths.point(n).unwrap() > Ratio::from_integer(0u8.into()));
    }
    let point_sum: Rational = (0..=257).map(|n| lengths.point(n).unwrap()).sum();
    assert_eq!(point_sum + lengths.mass(0, 258), one());
}

#[test]
fn length_observation_is_atomic_across_empty_partial_resumed_and_forked_rows() {
    let original = learn(&[(&[], &[]), (&[7], &[7])]);
    let frozen = original.model().forecast(prediction(&[]));
    let before = probability(&frozen, &[]);
    let mut acc = Accumulator::continue_from(&original);
    acc.begin(prediction(&[1, 2]), bytes(&[1, 2])).unwrap();
    let mut work = Work { left: 16, paid: 0 };
    for _ in 0..16 {
        acc.advance(&mut work).unwrap();
    }
    assert_eq!(acc.model.lengths.total, 2);
    assert_eq!(acc.samples(), 2);
    assert!(matches!(acc.advance(&mut work), Err(Refusal::Work(()))));
    acc.advance(&mut Work { left: 1, paid: 0 }).unwrap();
    let changed = finish(acc);
    assert_eq!(changed.model().lengths.total, 3);
    assert_eq!(changed.model().lengths.counts.get(&0), Some(&1));
    assert_eq!(original.model().lengths.total, 2);
    assert_eq!(probability(&frozen, &[]), before);
    assert_ne!(
        probability(&changed.model().forecast(prediction(&[])), &[]),
        before
    );
}

#[test]
fn prefix_census_resumes_with_identical_probability_and_exact_work() {
    let score = learn(&[
        (&[], &[]),
        (&[1], &[1]),
        (&[1, 2], &[1, 2]),
        (&[1, 2, 3], &[1, 2, 3]),
    ]);
    let f = score.model().forecast(prediction(&[1, 2, 3]));
    let one = cylinder(&f, &[1], 1);
    assert_eq!(one, cylinder(&f, &[1], 7));
    assert_eq!(one, cylinder(&f, &[1], 10000));
    assert_eq!(one.2, 3 + 1 + 8); // three retained lengths, tail closure, eight bits
}

#[test]
fn length_overflow_cannot_seal_a_partially_learned_model() {
    let mut acc = Accumulator::new();
    Arc::make_mut(&mut acc.model.lengths).total = u64::MAX;
    acc.begin(prediction(&[]), bytes(&[])).unwrap();
    assert!(matches!(
        acc.advance(&mut Work { left: 1, paid: 0 }),
        Err(Refusal::Invalid(Invalid::CountOverflow))
    ));
    assert_eq!(acc.samples(), 0);
    assert!(acc.finish().is_err());
}

#[test]
fn native_empty_and_partial_rows_publish_lengths_only_at_complete_boundary() {
    fn unfinished(acc: Accumulator) -> (Accumulator, bool) {
        let result = acc.finish();
        let refused = result.is_err();
        assert!(refused, "partial row was publishable");
        match result {
            Err(owner) => (owner, refused),
            Ok(_) => unreachable!(),
        }
    }
    let initial = learn(&[]);
    let frozen_initial = initial.model().forecast(prediction(&[5]));
    let mut acc = Accumulator::continue_from(&initial);
    acc.begin(prediction(&[]), bytes(&[])).unwrap();
    let (owner, empty_finish_refused) = unfinished(acc);
    acc = owner;
    let empty_zero_work_refused = matches!(
        acc.advance(&mut Work { left: 0, paid: 0 }),
        Err(Refusal::Work(()))
    );
    assert!(empty_zero_work_refused);
    assert_eq!(acc.model.lengths.total, 0);
    let empty = finish(acc);
    let frozen_empty = empty.model().forecast(prediction(&[5]));
    let mut acc = Accumulator::continue_from(&empty);
    acc.begin(prediction(&[5]), bytes(&[5])).unwrap();
    for _ in 0..7 {
        acc.advance(&mut Work { left: 1, paid: 0 }).unwrap();
    }
    let (owner, partial_finish_refused) = unfinished(acc);
    acc = owner;
    assert_eq!(acc.model.lengths.total, 1);
    let before_position = acc.pending.as_ref().unwrap().position;
    let before_length_total = acc.model.lengths.total;
    assert_eq!(before_position, 7);
    #[cfg(feature = "serde")]
    let before_refusal = acc.model.forecast_for_export(prediction(&[5]));
    let zero_work_refused = matches!(
        acc.advance(&mut Work { left: 0, paid: 0 }),
        Err(Refusal::Work(()))
    );
    assert!(zero_work_refused);
    assert_eq!(acc.model.lengths.total, 1);
    let refused_position = acc.pending.as_ref().unwrap().position;
    let refused_length_total = acc.model.lengths.total;
    assert_eq!(refused_position, 7);
    #[cfg(feature = "serde")]
    let after_refusal = acc.model.forecast_for_export(prediction(&[5]));
    #[cfg(feature = "serde")]
    assert_eq!(before_refusal, after_refusal);
    acc.advance(&mut Work { left: 1, paid: 0 }).unwrap();
    let (owner, last_bit_finish_refused) = unfinished(acc);
    acc = owner;
    assert_eq!(acc.model.lengths.total, 1);
    let last_bit_position = acc.pending.as_ref().unwrap().position;
    let last_bit_length_total = acc.model.lengths.total;
    assert_eq!(last_bit_position, 8);
    #[cfg(feature = "serde")]
    let after_last_bit = acc.model.forecast_for_export(prediction(&[5]));
    acc.advance(&mut Work { left: 1, paid: 0 }).unwrap();
    let complete = finish(acc);
    assert_eq!(complete.samples(), 2);
    assert_eq!(complete.model().lengths.total, 2);
    assert_eq!(
        complete.model().lengths.counts,
        BTreeMap::from([(0, 1), (1, 1)])
    );
    assert_eq!(
        probability(&frozen_initial, &[]).0,
        Ratio::new(1u8.into(), 2u8.into())
    );
    assert_eq!(
        probability(&frozen_empty, &[]).0,
        Ratio::new(3u8.into(), 4u8.into())
    );
    #[cfg(feature = "serde")]
    if let Some(path) = std::env::var_os("SYNARC_RESIDUAL_BOUNDARIES_EXPORT") {
        fn rational(q: &Rational) -> serde_json::Value {
            serde_json::json!({"numerator":q.numer().to_string(),"denominator":q.denom().to_string()})
        }
        let rows = vec![
            serde_json::json!({"context":b"shared".as_slice(),"mask":[],"target":[]}),
            serde_json::json!({"context":b"shared".as_slice(),"mask":[5],"target":[5]}),
        ];
        let mut packets = Vec::new();
        for (phase, forecast, n) in [
            ("initial", frozen_initial, 0),
            ("empty-row", frozen_empty, 1),
            (
                "complete-row",
                complete.model().forecast(prediction(&[5])),
                2,
            ),
        ] {
            let mut queries = Vec::new();
            for target in [vec![], vec![5], vec![0], vec![5, 0]] {
                for prefix in [false, true] {
                    let (a, b) = if prefix {
                        let (a, b, _) = cylinder(&forecast, &target, 1);
                        (a, b)
                    } else {
                        probability(&forecast, &target)
                    };
                    queries.push(serde_json::json!({"prefix":prefix,"target":target,"candidate":rational(&a),"reference":rational(&b)}));
                }
            }
            packets.push(
                serde_json::json!({"format":"synarc-residual-queries-v2","phase":phase,
                "rows":&rows[..n],"forecast":forecast.native_frontier(),"queries":queries}),
            );
        }
        let export = serde_json::json!({"format":"synarc-residual-boundaries-v2","queries":packets,
            "partial":{"before_refusal":before_refusal,"after_refusal":after_refusal,
                "after_last_bit":after_last_bit,"length_total":last_bit_length_total,
                "length_totals":[before_length_total,refused_length_total,last_bit_length_total],
                "positions":[before_position,refused_position,last_bit_position],
                "empty_finish_refused":empty_finish_refused,"empty_zero_work_refused":empty_zero_work_refused,
                "partial_finish_refused":partial_finish_refused,"last_bit_finish_refused":last_bit_finish_refused,"zero_work_refused":zero_work_refused},
            "committed":complete.native_frontier()});
        std::fs::write(path, serde_json::to_vec_pretty(&export).unwrap()).unwrap();
    }
}

#[cfg(feature = "serde")]
impl Model {
    fn forecast_for_export(&self, prediction: Prediction) -> serde_json::Value {
        Arc::new(self.clone())
            .forecast(prediction)
            .native_frontier()
    }
}

/// This is a capability boundary of the retained positional family, not an
/// acceptance test for a future joint kernel. All four witness events have
/// positive probability: the obstruction is independence, not zero support.
#[test]
fn positional_family_has_rank_one_two_bit_marginals() {
    let targets = [0u8, 0, 0, 3, 3, 3, 1, 2];
    let rows: Vec<_> = targets.iter().map(|y| (&[][..], std::slice::from_ref(y))).collect();
    let trained = learn(&rows);
    let witness: Vec<Rational> = [3u8, 1, 1, 3]
        .into_iter().map(|n| Ratio::new(n.into(), 8u8.into())).collect();
    assert_eq!(witness.iter().cloned().sum::<Rational>(), one());
    assert_ne!(&witness[0] * &witness[3], &witness[1] * &witness[2]);
    for mask in [0u8, 7, 255] {
        let forecast = trained.model().forecast(prediction(&[mask]));
        let points: Vec<_> = (0..4u8).map(|y| probability(&forecast, &[y]).0).collect();
        let mass: Rational = points.iter().cloned().sum();
        let conditional: Vec<_> = points.iter().map(|p| p / &mass).collect();
        // Condition on length one and the six remaining bits being zero. This
        // avoids conflating the separate learned length law with dependence.
        assert_eq!(&points[0] * &points[3], &points[1] * &points[2]);
        assert_eq!(conditional, vec![Ratio::new(1u8.into(), 4u8.into()); 4]);
        assert_ne!(conditional, witness);
        #[cfg(feature = "serde")]
        {
            let rational = |p: &Rational| serde_json::json!([
                p.numer().to_string(), p.denom().to_string()
            ]);
            println!("SYNARC_BOUNDARY={}", serde_json::json!({
                "format":"synarc-conditional-expressiveness-v2",
                "kind":"positional_rank_one", "targets":targets,
                "rows":targets.iter().map(|y| serde_json::json!({
                    "context":b"shared".as_slice(), "mask":[], "target":[y]
                })).collect::<Vec<_>>(),
                "query_targets":(0..4u8).map(|y| vec![y]).collect::<Vec<_>>(),
                "conditioning":{"wire_length":1,"high_six_bits":0},
                "forecast":forecast.native_frontier(),
                "points":points.iter().map(rational).collect::<Vec<_>>(),
                "conditionals":conditional.iter().map(rational).collect::<Vec<_>>(),
                "strict_positive_witness":witness.iter().map(rational).collect::<Vec<_>>()
            }));
        }
    }
}
