//! Full-wire prediction is separate from representation refinement. A learned
//! predictive context does not authorize erasing exact physical provenance.
//! This runtime consumes an installed native observer, retaining both learned
//! residual and reference counts. There is no separate interpreter or reset at
//! the training/fresh/installation boundary. Every live update commits the VM
//! and the full-target score together, or neither of them.
use super::*;
use crate::program::observer::{Preparing, ReadingCall};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AdoptionRefusal {
    NotPredictive,
    NotAtEvidenceFrontier,
    AlreadyAdvanced,
}

pub(crate) struct Runtime<V: Clone, P, D, S: Semantics<V, P>, H, K, Y> {
    installed: Installed<V, P, D, S, H, K, Y>,
    protocol: Arc<residual::Protocol<V, Y>>,
    score: Arc<residual::Score>,
}
impl<V: Clone, P, D, S: Semantics<V, P>, H: PartialEq, K, Y> Installed<V, P, D, S, H, K, Y> {
    /// The categorical runtime cannot silently acquire predictive authority.
    /// A tail with unknown targets must be replayed via prediction transactions,
    /// not by committing only program updates and resetting learned counts.
    pub(crate) fn into_predictive(
        self,
    ) -> Result<Runtime<V, P, D, S, H, K, Y>, (Self, AdoptionRefusal)> {
        if !self.installation_cut.same_revision(&self.cut()) {
            return Err((self, AdoptionRefusal::AlreadyAdvanced));
        }
        let (training, fresh, score) = match &self.admission {
            Admission::Accepted(a) => (&a.assessment.trial, None, &a.assessment.score),
            Admission::Validated(v) => (
                &v.validation.accepted.assessment.trial,
                Some(&v.validation.fresh.trial),
                &v.validation.score,
            ),
        };
        let Some(protocol) = training.wire.clone() else {
            return Err((self, AdoptionRefusal::NotPredictive));
        };
        let Some(score) = score.residual() else {
            return Err((self, AdoptionRefusal::NotPredictive));
        };
        let last = training
            .rows
            .iter()
            .chain(fresh.into_iter().flat_map(|t| t.rows.iter()))
            .filter(|r| r.history.origin == self.history.origin)
            .map(|r| r.cut)
            .max();
        if last.and_then(|cut| cut.checked_add(1)) != Some(self.origin_cut) {
            return Err((self, AdoptionRefusal::NotAtEvidenceFrontier));
        }
        let score = Arc::new(score.clone());
        Ok(Runtime {
            installed: self,
            protocol,
            score,
        })
    }
}
impl<V: Clone, P, D, S: Semantics<V, P>, H, K, Y> Runtime<V, P, D, S, H, K, Y> {
    pub(crate) fn cut(&self) -> Cut<V, P, D, S> {
        self.installed.cut()
    }
    pub(crate) fn score(&self) -> &residual::Score {
        &self.score
    }
    /// Immutable prediction authority at this exact native revision and bank.
    /// Unlike an imagined fork, its ticket can complete on this live owner.
    pub(crate) fn snapshot(&self) -> Snapshot<V, P, D, S, Y> {
        Snapshot {
            cut: self.cut(),
            protocol: Arc::clone(&self.protocol),
            score: Arc::clone(&self.score),
        }
    }
    pub(crate) fn is_current(&self, snapshot: &Snapshot<V, P, D, S, Y>) -> bool {
        self.cut().same_revision(&snapshot.cut) && Arc::ptr_eq(&self.score, &snapshot.score)
    }
    pub(crate) fn fork(&self) -> Self {
        Self {
            installed: self.installed.fork(),
            protocol: Arc::clone(&self.protocol),
            score: Arc::clone(&self.score),
        }
    }
    pub(crate) fn commit(
        &mut self,
        update: Update<V, P, D, S>,
    ) -> Result<Receipt<V, P, D, S>, Update<V, P, D, S>> {
        if !Arc::ptr_eq(&self.score, &update.previous)
            || !self.cut().same_revision(update.reading.cut())
        {
            return Err(update);
        }
        // Native instance and exact predictive frontier were checked before
        // either is mutated. The private prepared owner is from the same cut.
        let committed = self
            .installed
            .commit(update.prepared)
            .expect("private predictive transaction preserves the native cut");
        self.score = update.next;
        Ok(Receipt {
            reading: update.reading,
            committed,
            target: update.target,
            before: update.previous,
            after: Arc::clone(&self.score),
        })
    }
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>, H, K, Y> Runtime<V, P, D, S, H, K, Y> {
    /// Query and update input are frozen before the target is supplied. Their
    /// native interface must preserve the action/physical boundary as usual.
    pub(crate) fn begin(
        &self,
        query: InputRow<D, V>,
        event: InputRow<D, V>,
    ) -> Predicting<V, P, D, S, Y> {
        self.snapshot().begin(query, event)
    }
}
/// Read-only retained prediction source. Private fields prevent assembling a
/// current program cut with an unrelated learned bank. Cloning preserves the
/// owner; advancing that owner makes old tickets stale at the existing paired
/// commit guard. This grants no authority to merge physical states.
pub(crate) struct Snapshot<V: Clone, P, D, S: Semantics<V, P>, Y> {
    cut: Cut<V, P, D, S>,
    protocol: Arc<residual::Protocol<V, Y>>,
    score: Arc<residual::Score>,
}
impl<V: Clone, P, D, S: Semantics<V, P>, Y> Clone for Snapshot<V, P, D, S, Y> {
    fn clone(&self) -> Self {
        Self {
            cut: self.cut.clone(),
            protocol: Arc::clone(&self.protocol),
            score: Arc::clone(&self.score),
        }
    }
}
impl<V: Clone, P, D, S: Semantics<V, P>, Y> Snapshot<V, P, D, S, Y> {
    pub(crate) fn cut(&self) -> &Cut<V, P, D, S> {
        &self.cut
    }
    pub(crate) fn score(&self) -> &residual::Score {
        &self.score
    }
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>, Y> Snapshot<V, P, D, S, Y> {
    pub(crate) fn begin(
        &self,
        query: InputRow<D, V>,
        event: InputRow<D, V>,
    ) -> Predicting<V, P, D, S, Y> {
        Predicting {
            read: self.cut.begin_read(query),
            event: Some(event),
            protocol: Arc::clone(&self.protocol),
            previous: Arc::clone(&self.score),
            done: false,
        }
    }
}

#[derive(Debug)]
pub(crate) enum Stop<V, E, M> {
    Native(Refusal<V, E, M>),
    Wire(residual::Invalid),
    Work(WorkRefusal<M>),
    AlreadyReturned,
}

pub(crate) struct Predicting<V: Clone, P, D, S: Semantics<V, P>, Y> {
    read: ReadingCall<V, P, D, S>,
    event: Option<InputRow<D, V>>,
    protocol: Arc<residual::Protocol<V, Y>>,
    previous: Arc<residual::Score>,
    done: bool,
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>, Y> Predicting<V, P, D, S, Y> {
    pub(crate) fn advance<M: WorkMeter + ?Sized>(
        &mut self,
        budget: &mut Budget<'_, M>,
    ) -> Result<Option<Ticket<V, P, D, S, Y>>, Stop<V, S::Error, M::Error>> {
        if self.done {
            return Err(Stop::AlreadyReturned);
        }
        let Some(reading) = self.read.advance(budget).map_err(Stop::Native)? else {
            return Ok(None);
        };
        self.done = true;
        let prediction = self
            .protocol
            .prediction(reading.value())
            .map_err(Stop::Wire)?;
        let forecast = self.previous.model().forecast(prediction);
        Ok(Some(Ticket {
            reading,
            forecast,
            protocol: Arc::clone(&self.protocol),
            previous: Arc::clone(&self.previous),
            event: self.event.take().expect("owned pre-outcome event"),
        }))
    }
}
/// No target exists in this owner. It cannot be created from a caller-provided
/// score or prediction; only a successful native pre-outcome read returns it.
pub(crate) struct Ticket<V: Clone, P, D, S: Semantics<V, P>, Y> {
    reading: Reading<V, P, D, S>,
    forecast: residual::Forecast,
    protocol: Arc<residual::Protocol<V, Y>>,
    previous: Arc<residual::Score>,
    event: InputRow<D, V>,
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>, Y> Ticket<V, P, D, S, Y> {
    pub(crate) fn forecast(&self) -> &residual::Forecast {
        &self.forecast
    }
    pub(crate) fn observe(self, outcome: &Y) -> Result<Learning<V, P, D, S>, residual::Invalid> {
        let target = self.protocol.outcome(outcome)?;
        let mut acc = residual::Accumulator::continue_from(&self.previous);
        acc.begin(self.forecast.prediction().clone(), Arc::clone(&target))?;
        let (preparing, completion) = if self.protocol.requires_outcome() {
            (None, Some(self.protocol.begin_complete(self.event.clone(), Some(Arc::clone(&target)))))
        } else {
            (Some(self.reading.cut().begin_prepare(self.event.clone())), None)
        };
        Ok(Learning {
            reading: Some(self.reading),
            preparing,
            completion,
            completion_poisoned: false,
            event: self.event,
            prepared: None,
            acc: Some(acc),
            previous: self.previous,
            target,
            done: false,
        })
    }
}
pub(crate) struct Learning<V: Clone, P, D, S: Semantics<V, P>> {
    reading: Option<Reading<V, P, D, S>>,
    preparing: Option<Preparing<V, P, D, S>>,
    completion: Option<residual::OutcomeCompletion<D, V>>,
    completion_poisoned: bool,
    event: InputRow<D, V>,
    prepared: Option<Prepared<V, P, D, S>>,
    acc: Option<residual::Accumulator>,
    previous: Arc<residual::Score>,
    target: residual::Wire,
    done: bool,
}
struct Meter<'b, 'a, M: WorkMeter + ?Sized>(&'b mut Budget<'a, M>);
impl<M: WorkMeter + ?Sized> WorkMeter for Meter<'_, '_, M> {
    type Error = WorkRefusal<M::Error>;
    fn charge(&mut self, units: usize) -> Result<(), Self::Error> {
        self.0.reserve(units).map_err(Into::into)
    }
}
impl<V: Clone, P, D: PartialEq, S: Semantics<V, P>> Learning<V, P, D, S> {
    pub(crate) fn advance<M: WorkMeter + ?Sized>(
        &mut self,
        budget: &mut Budget<'_, M>,
    ) -> Result<Option<Update<V, P, D, S>>, Stop<V, S::Error, M::Error>> {
        if self.done {
            return Err(Stop::AlreadyReturned);
        }
        if self.completion_poisoned { return Err(Stop::Wire(residual::Invalid::Poisoned)); }
        if self.preparing.is_none() {
            budget.reserve(1).map_err(|e| Stop::Work(e.into()))?;
            self.completion_poisoned = true;
            let result = self.completion.as_ref().expect("retained causal completion").complete();
            self.completion_poisoned = false;
            let input = result.map_err(Stop::Wire)?;
            self.preparing = Some(self.reading.as_ref().expect("retained native read").cut().begin_prepare(input));
            self.completion = None;
            return Ok(None);
        }
        if self.prepared.is_none() {
            self.prepared = self.preparing.as_mut().unwrap().advance(budget).map_err(Stop::Native)?;
            return Ok(None);
        }
        let acc = self.acc.as_mut().expect("retained predictive counts");
        if acc.pending() {
            acc.advance(&mut Meter(budget)).map_err(|e| match e {
                residual::Refusal::Work(e) => Stop::Work(e),
                residual::Refusal::Invalid(e) => Stop::Wire(e),
            })?;
            return Ok(None);
        }
        let score = match self.acc.take().expect("owned completed predictor").finish() {
            Ok(score) => score,
            Err(acc) => {
                self.acc = Some(acc);
                return Err(Stop::Wire(residual::Invalid::Poisoned));
            }
        };
        self.done = true;
        Ok(Some(Update {
            reading: self.reading.take().expect("owned native reading"),
            prepared: self.prepared.take().expect("owned native update"),
            previous: Arc::clone(&self.previous),
            next: Arc::new(score),
            target: Arc::clone(&self.target),
        }))
    }
}
pub(crate) struct Update<V: Clone, P, D, S: Semantics<V, P>> {
    reading: Reading<V, P, D, S>,
    prepared: Prepared<V, P, D, S>,
    previous: Arc<residual::Score>,
    next: Arc<residual::Score>,
    target: residual::Wire,
}
pub(crate) struct Receipt<V: Clone, P, D, S: Semantics<V, P>> {
    pub(crate) reading: Reading<V, P, D, S>,
    pub(crate) committed: Committed<V, P, D, S>,
    pub(crate) target: residual::Wire,
    pub(crate) before: Arc<residual::Score>,
    pub(crate) after: Arc<residual::Score>,
}

#[cfg(all(test, feature = "serde"))]
pub(crate) mod transaction_export;
