use super::*;
use crate::organism::Resumption;
use super::super::Lineage;

fn phase() -> Phase {
    match kani::any::<u8>() { 0 => Phase::Ready, 1 => Phase::InFlight, _ => Phase::TerminalPending }
}
fn clock() -> Clock {
    Clock { origin: Arc::new(Origin), episode: kani::any(), life_age: kani::any(), phase: phase() }
}
fn kind() -> TerminalKind {
    match kani::any::<u8>() { 0 => TerminalKind::Death, 1 => TerminalKind::Time,
        2 => TerminalKind::Completed, _ => TerminalKind::Ended }
}
fn sample() -> Option<SampleId> {
    if kani::any() { Some(SampleId { lineage: Lineage { authority: kani::any(), birth: kani::any() }, ordinal: kani::any() }) } else { None }
}
fn next(value: u64) -> Option<u64> { if value == u64::MAX { None } else { Some(value + 1) } }
fn same(c: &Clock, origin: &Arc<Origin>, episode: Option<u64>, age: u64, phase: Phase) {
    assert!(Arc::ptr_eq(&c.origin, origin)); assert_eq!(c.episode, episode);
    assert_eq!(c.life_age, age); assert_eq!(c.phase, phase);
}

#[kani::proof]
fn restart_guard() {
    let c = clock();
    kani::cover!(c.phase == Phase::Ready, "ready");
    kani::cover!(c.phase == Phase::InFlight, "in_flight");
    kani::cover!(c.phase == Phase::TerminalPending, "terminal_pending");
    let expected = match c.phase { Phase::Ready => Ok(()), Phase::InFlight => Err(RestartRefusal::PendingOutcome), Phase::TerminalPending => Err(RestartRefusal::PendingTerminal) };
    assert_eq!(c.check_restart(), expected);
}

#[kani::proof]
fn restart_retains_or_freshens() {
    let mut c = clock();
    let (origin, episode, age, phase) = (Arc::clone(&c.origin), c.episode, c.life_age, c.phase);
    kani::cover!(phase == Phase::Ready && episode == Some(u64::MAX), "episode_limit");
    kani::cover!(phase == Phase::Ready && episode.is_none(), "exhausted_episode");
    kani::cover!(phase == Phase::InFlight, "in_flight");
    kani::cover!(phase == Phase::TerminalPending, "terminal_pending");
    let result = c.declared_restart();
    match phase {
        Phase::Ready => {
            assert_eq!(result, Ok(()));
            assert!(!Arc::ptr_eq(&c.origin, &origin));
            assert_eq!(c.episode, episode.and_then(next));
            assert_eq!(c.life_age, 0); assert_eq!(c.phase, Phase::Ready);
        }
        Phase::InFlight => { assert_eq!(result, Err(RestartRefusal::PendingOutcome)); same(&c,&origin,episode,age,phase); }
        Phase::TerminalPending => { assert_eq!(result, Err(RestartRefusal::PendingTerminal)); same(&c,&origin,episode,age,phase); }
    }
}

#[kani::proof]
fn point_preflight() {
    let c = clock();
    kani::cover!(c.phase == Phase::Ready && c.episode.is_some() && c.life_age == u64::MAX, "age_limit");
    kani::cover!(c.phase == Phase::Ready && c.episode.is_none(), "missing_episode");
    kani::cover!(c.phase == Phase::InFlight, "in_flight");
    let result = c.point();
    let refusal = match c.phase {
        Phase::InFlight => Some(Refusal::PendingOutcome),
        Phase::TerminalPending => Some(Refusal::PendingTerminal),
        Phase::Ready => if c.episode.is_none() { Some(Refusal::MissingEpisode) }
            else if c.life_age == u64::MAX { Some(Refusal::AgeOverflow) } else { None },
    };
    if let Some(reason) = refusal { assert_eq!(result, Err(reason)); }
    else {
        let point = result.unwrap();
        assert!(Arc::ptr_eq(&c.origin, &point.origin));
        assert_eq!(Some(point.time.episode),c.episode); assert_eq!(point.time.life_age,c.life_age);
    }
}

#[kani::proof]
fn start_exact_owner_and_time() {
    let mut c = clock();
    let (origin, episode, age, phase) = (Arc::clone(&c.origin), c.episode, c.life_age, c.phase);
    let own: bool = kani::any();
    let selected = Point { origin: if own { Arc::clone(&origin) } else { Arc::new(Origin) },
        time: PreActionTime { episode: kani::any(), life_age: kani::any() } };
    let expected = match phase {
        Phase::InFlight => Err(Refusal::PendingOutcome),
        Phase::TerminalPending => Err(Refusal::PendingTerminal),
        Phase::Ready => if episode.is_none() { Err(Refusal::MissingEpisode) }
            else if age == u64::MAX { Err(Refusal::AgeOverflow) }
            else if !own || episode != Some(selected.time.episode) || age != selected.time.life_age { Err(Refusal::ForeignPoint) } else { Ok(()) },
    };
    kani::cover!(expected.is_ok(), "admitted");
    kani::cover!(expected == Err(Refusal::ForeignPoint), "foreign");
    assert_eq!(c.start(&selected),expected);
    same(&c,&origin,episode,age,if expected.is_ok() { Phase::InFlight } else { phase });
}

#[kani::proof]
fn commit_exact_ownership_and_retention() {
    let mut c = clock();
    let (origin, episode, age, phase) = (Arc::clone(&c.origin), c.episode, c.life_age, c.phase);
    let own: bool = kani::any();
    let point = Point { origin: if own { Arc::clone(&origin) } else { Arc::new(Origin) }, time: PreActionTime { episode: kani::any(), life_age: kani::any() } };
    let tick: bool = kani::any();
    let successor = Some(PreActionTime { episode: kani::any(), life_age: kani::any() });
    let edge = Edge { point, sample: sample(), transition: if tick { Transition::Tick } else { Transition::TerminalReset(kind()) }, successor };
    let expected = phase == Phase::InFlight && own && episode == Some(edge.point.time.episode) && age == edge.point.time.life_age;
    kani::cover!(expected && tick, "admitted_tick");
    kani::cover!(expected && !tick, "admitted_terminal");
    kani::cover!(!expected && own, "stale");
    kani::cover!(!own, "foreign");
    let retained = edge.clone();
    match c.commit(Receipt::observed(edge)) {
        Ok(applied) => {
            assert!(expected);
            assert_eq!(applied.edge(), &retained);
            let next = applied.tick_successor();
            if tick {
                let next = next.unwrap();
                assert!(Arc::ptr_eq(&next.origin, &origin));
                assert_eq!(next.metadata(), successor.unwrap());
            } else { assert_eq!(next, None); }
            same(&c,&origin,episode,if tick { successor.unwrap().life_age } else { 0 },if tick { Phase::Ready } else { Phase::TerminalPending });
        }
        Err((reason, receipt)) => {
            assert!(!expected); assert_eq!(reason,Refusal::ForeignPoint);
            assert_eq!(receipt.edge,retained); same(&c,&origin,episode,age,phase);
        }
    }
}

#[kani::proof]
fn captured_tick_and_duplicate() {
    let episode: u64 = kani::any(); let age: u64 = kani::any();
    let mut c = Clock { origin: Arc::new(Origin), episode: Some(episode), life_age: age, phase: Phase::Ready };
    if age == u64::MAX { assert_eq!(c.point(),Err(Refusal::AgeOverflow)); return; }
    kani::cover!(age == u64::MAX - 1, "last_age");
    let point = c.point().unwrap(); c.start(&point).unwrap();
    let sample = sample();
    let edge = Edge::observed(point.clone(),sample,if kani::any() { ObservedAction::Step } else { ObservedAction::Refused });
    assert_eq!(edge.point,point); assert_eq!(edge.sample,sample); assert_eq!(edge.transition,Transition::Tick);
    assert_eq!(edge.successor,Some(PreActionTime { episode,life_age: age+1 }));
    let saved = edge.clone();
    c.commit(Receipt::observed(edge)).unwrap();
    same(&c,&point.origin,Some(episode),age+1,Phase::Ready);
    assert!(c.commit(Receipt::observed(saved.clone())).is_err());
    if let Ok(next_point) = c.point() {
        c.start(&next_point).unwrap();
        let (reason,returned) = c.commit(Receipt::observed(saved.clone())).unwrap_err();
        assert_eq!(reason,Refusal::ForeignPoint); assert_eq!(returned.edge,saved);
    }
}

#[kani::proof]
fn terminal_close_and_overflow() {
    let episode: u64 = kani::any(); let age: u64 = kani::any();
    let mut c = Clock { origin: Arc::new(Origin), episode: Some(episode), life_age: age, phase: Phase::Ready };
    if age == u64::MAX { assert_eq!(c.point(),Err(Refusal::AgeOverflow)); return; }
    let point = c.point().unwrap(); c.start(&point).unwrap();
    kani::cover!(episode == u64::MAX, "episode_limit");
    kani::cover!(episode < u64::MAX, "episode_successor");
    let sample = sample(); let kind = kind();
    let edge = Edge::observed(point.clone(),sample,ObservedAction::Terminal { kind, resumption: if kani::any() { Resumption::Resumed } else { Resumption::Stopped } });
    assert_eq!(edge.point,point); assert_eq!(edge.sample,sample); assert_eq!(edge.transition,Transition::TerminalReset(kind));
    assert_eq!(edge.successor,next(episode).map(|episode| PreActionTime { episode,life_age:0 }));
    c.commit(Receipt::observed(edge)).unwrap();
    same(&c,&point.origin,Some(episode),0,Phase::TerminalPending);
    assert_eq!(c.declared_restart(),Err(RestartRefusal::PendingTerminal));
    same(&c,&point.origin,Some(episode),0,Phase::TerminalPending);
    assert_eq!(c.close_terminal(),Ok(()));
    same(&c,&point.origin,next(episode),0,Phase::Ready);
    assert_eq!(c.close_terminal(),Err(Refusal::PendingTerminal));
    same(&c,&point.origin,next(episode),0,Phase::Ready);
}

#[kani::proof]
fn close_terminal_exact() {
    let mut c = clock();
    let (origin, episode, age, phase) = (Arc::clone(&c.origin), c.episode, c.life_age, c.phase);
    kani::cover!(phase == Phase::TerminalPending && episode == Some(u64::MAX), "episode_limit");
    kani::cover!(phase == Phase::TerminalPending && episode.is_none(), "exhausted_episode");
    kani::cover!(phase == Phase::Ready, "refused");
    let expected = phase == Phase::TerminalPending;
    assert_eq!(c.close_terminal(), if expected { Ok(()) } else { Err(Refusal::PendingTerminal) });
    same(&c,&origin,if expected { episode.and_then(next) } else { episode },age,if expected { Phase::Ready } else { phase });
}

// Observation of an Applied value grants no receipt. These properties also
// hold for private malformed edges, so no hidden validity assumption is used.
#[kani::proof]
fn applied_observation_retains_owner_and_terminal_boundary() {
    let origin = Arc::new(Origin);
    let point = Point { origin: Arc::clone(&origin),
        time: PreActionTime { episode: kani::any(), life_age: kani::any() } };
    let tick: bool = kani::any();
    let successor = if kani::any() { Some(PreActionTime {
        episode: kani::any(), life_age: kani::any() }) } else { None };
    let edge = Edge { point, sample: sample(),
        transition: if tick { Transition::Tick } else { Transition::TerminalReset(kind()) }, successor };
    let retained = edge.clone();
    let applied = Applied { edge };
    assert_eq!(applied.edge(), &retained);
    let next = applied.tick_successor();
    assert_eq!(applied.edge(), &retained);
    if tick && successor.is_some() {
        let next = next.unwrap();
        assert!(Arc::ptr_eq(&next.origin, &origin));
        assert_eq!(next.metadata(), successor.unwrap());
    } else { assert_eq!(next, None); }
    kani::cover!(tick && successor.is_some(), "tick");
    kani::cover!(!tick && successor.is_some(), "terminal");
    kani::cover!(tick && successor.is_none(), "missing_successor");
}

#[kani::proof]
fn restart_invalidates_retained_owner() {
    let mut c = clock();
    let old = Point { origin: Arc::clone(&c.origin),
        time: PreActionTime { episode: kani::any(), life_age: kani::any() } };
    assert!(c.has_origin(&old));
    let accepted = c.declared_restart().is_ok();
    assert_eq!(c.has_origin(&old), !accepted);
    if accepted { assert!(c.start(&old).is_err()); }
    kani::cover!(accepted, "restarted");
    kani::cover!(!accepted, "refused");
}
